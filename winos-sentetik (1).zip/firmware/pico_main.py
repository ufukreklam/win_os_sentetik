
# WinOS Hybrid - Pico Slave Firmware (Reference Implementation)
# Platform: Raspberry Pi Pico (RP2040)
# Language: MicroPython

import machine
import time
import json
import ustruct
import sys
import select

# --- PIN CONFIGURATION ---
# Motor Driver (L298N or similar)
PIN_ENA = 16
PIN_IN1 = 17
PIN_IN2 = 18
PIN_IN3 = 19
PIN_IN4 = 20
PIN_ENB = 21

# Servos
PIN_SERVO_PAN = 14
PIN_SERVO_TILT = 15

# Sensors
PIN_SDA = 0
PIN_SCL = 1
PIN_TRIG_F = 2
PIN_ECHO_F = 3
# ... other pins

# --- SETUP ---
# LED
led = machine.Pin(25, machine.Pin.OUT)

# Motors
m1_pwm = machine.PWM(machine.Pin(PIN_ENA))
m1_in1 = machine.Pin(PIN_IN1, machine.Pin.OUT)
m1_in2 = machine.Pin(PIN_IN2, machine.Pin.OUT)

m2_pwm = machine.PWM(machine.Pin(PIN_ENB))
m2_in3 = machine.Pin(PIN_IN3, machine.Pin.OUT)
m2_in4 = machine.Pin(PIN_IN4, machine.Pin.OUT)

m1_pwm.freq(1000)
m2_pwm.freq(1000)

# Servos
servo_pan = machine.PWM(machine.Pin(PIN_SERVO_PAN))
servo_tilt = machine.PWM(machine.Pin(PIN_SERVO_TILT))
servo_pan.freq(50)
servo_tilt.freq(50)

# Serial Buffer
input_buffer = ""
last_command_time = time.ticks_ms()
SAFETY_TIMEOUT = 500 # ms

# --- FUNCTIONS ---

# In a real implementation, you would import OLED (SSD1306) and NeoPixel libraries
def update_display(eye_l, eye_r, mouth):
    # Mock function: In reality, draw to OLED
    pass

def update_leds(r, g, b, mode):
    # Mock function: In reality, drive WS2812B
    pass

def set_motor(pwm_obj, in1, in2, speed):
    """
    Speed: -100 to 100
    """
    # Deadzone
    if abs(speed) < 5:
        speed = 0
        
    duty = int(abs(speed) * 65535 / 100)
    
    if speed > 0:
        in1.value(1)
        in2.value(0)
    elif speed < 0:
        in1.value(0)
        in2.value(1)
    else:
        in1.value(0)
        in2.value(0)
        
    pwm_obj.duty_u16(duty)

def set_servo(pwm_obj, angle):
    """
    Set servo angle (0-180)
    Standard SG90: 0.5ms (0 deg) to 2.5ms (180 deg) at 50Hz (20ms period)
    0.5ms / 20ms * 65535 = 1638
    2.5ms / 20ms * 65535 = 8192
    """
    # Clamp angle
    angle = max(0, min(180, angle))
    
    # Calculate duty
    min_duty = 1638
    max_duty = 8192
    duty = int(min_duty + (angle / 180.0) * (max_duty - min_duty))
    
    pwm_obj.duty_u16(duty)

def read_sensors():
    """
    Mock sensor reading for simulation compatibility
    In real deployment, read ADC/I2C here.
    """
    return {
        "v": 12.6, # Mock Battery
        "c": 0.5,  # Mock Current
        "i": {"p": 0, "r": 0, "y": 0}, # Mock IMU
        "u": [100, 200, 300], # Mock Ultrasonic
        "l_stat": "OK"
    }

# --- MAIN LOOP ---
while True:
    # 1. Read Serial Command (Non-blocking)
    while sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
        char = sys.stdin.read(1)
        if char == '\n':
            try:
                cmd = json.loads(input_buffer)
                
                # Motor Commands
                if "m" in cmd:
                    motors = cmd["m"]
                    set_motor(m1_pwm, m1_in1, m1_in2, motors[0])
                    set_motor(m2_pwm, m2_in3, m2_in4, motors[1])
                    last_command_time = time.ticks_ms()
                
                # Servo Commands ("s": [90, 45])
                if "s" in cmd:
                    servos = cmd["s"]
                    if len(servos) >= 2:
                        set_servo(servo_pan, servos[0])
                        set_servo(servo_tilt, servos[1])

                # Display Commands ("d": {"l": "happy", "r": "happy", "m": "smile"})
                if "d" in cmd:
                    d = cmd["d"]
                    update_display(d.get("l"), d.get("r"), d.get("m"))
                
                # LED Commands ("l": {"c": [255,0,0], "m": "solid"})
                if "l" in cmd:
                    l = cmd["l"]
                    if "c" in l:
                        r, g, b = l["c"]
                        mode = l.get("m", "solid")
                        update_leds(r, g, b, mode)

                led.toggle()
            except:
                pass
            input_buffer = ""
        else:
            input_buffer += char

    # 2. Safety Watchdog
    if time.ticks_diff(time.ticks_ms(), last_command_time) > SAFETY_TIMEOUT:
        set_motor(m1_pwm, m1_in1, m1_in2, 0)
        set_motor(m2_pwm, m2_in3, m2_in4, 0)
        # led.value(0)

    # 3. Send Telemetry (20Hz approx)
    # Simple rate limiting could be added
    telemetry = read_sensors()
    print(json.dumps(telemetry))
    
    time.sleep(0.05)
