
import { GoogleGenAI, Modality } from "@google/genai";

const apiKey = process.env.API_KEY || '';

class TTSService {
    private client: GoogleGenAI | null = null;
    private audioCtx: AudioContext | null = null;
    private gainNode: GainNode | null = null;
    public analyser: AnalyserNode | null = null;
    private isPlaying: boolean = false;
    private currentSource: AudioBufferSourceNode | null = null;

    // Callbacks
    public onStart: (() => void) | null = null;
    public onEnd: (() => void) | null = null;

    constructor() {
        if (apiKey) {
            this.client = new GoogleGenAI({ apiKey });
        }
    }

    private initAudioContext() {
        if (!this.audioCtx) {
            this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            this.analyser = this.audioCtx.createAnalyser();
            this.gainNode = this.audioCtx.createGain();
            
            this.gainNode.connect(this.analyser);
            this.analyser.connect(this.audioCtx.destination);
            
            // Resume if suspended (browser policy)
            if (this.audioCtx.state === 'suspended') {
                this.audioCtx.resume();
            }
        }
    }

    /**
     * Convert Base64 string to Uint8Array
     */
    private base64ToUint8Array(base64: string): Uint8Array {
        const binaryString = atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes;
    }

    /**
     * Decode raw PCM data (Gemini Output) to AudioBuffer
     */
    private async decodeAudioData(data: Uint8Array): Promise<AudioBuffer> {
        if (!this.audioCtx) throw new Error("AudioContext not initialized");

        // Gemini returns raw PCM 16-bit, 24kHz, Mono (usually)
        // We need to convert Int16 to Float32 manually if decodeAudioData fails on raw streams,
        // BUT the new Gemini SDK returns a format that requires manual PCM construction.
        
        const sampleRate = 24000;
        const numChannels = 1;
        
        const dataInt16 = new Int16Array(data.buffer);
        const frameCount = dataInt16.length / numChannels;
        const buffer = this.audioCtx.createBuffer(numChannels, frameCount, sampleRate);

        for (let channel = 0; channel < numChannels; channel++) {
            const channelData = buffer.getChannelData(channel);
            for (let i = 0; i < frameCount; i++) {
                // Normalize 16-bit int to -1.0 to 1.0 float
                channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
            }
        }
        return buffer;
    }

    /**
     * Stop current playback
     */
    stop() {
        if (this.currentSource) {
            try {
                this.currentSource.stop();
            } catch (e) {
                // Ignore if already stopped
            }
            this.currentSource = null;
        }
        this.isPlaying = false;
        if (window.speechSynthesis.speaking) {
            window.speechSynthesis.cancel();
        }
        if (this.onEnd) this.onEnd();
    }

    /**
     * Speak text using Gemini (Cloud) or WebSpeech (Local)
     */
    async speak(text: string, useCloud: boolean = true, voiceName: string = 'Kore') {
        this.stop(); // Stop previous
        this.initAudioContext();

        // 1. Cloud TTS (Gemini)
        if (useCloud && this.client && navigator.onLine) {
            try {
                if (this.onStart) this.onStart();
                this.isPlaying = true;

                const response = await this.client.models.generateContent({
                    model: "gemini-2.5-flash-preview-tts",
                    contents: [{ parts: [{ text }] }],
                    config: {
                        responseModalities: [Modality.AUDIO],
                        speechConfig: {
                            voiceConfig: {
                                prebuiltVoiceConfig: { voiceName: voiceName as any }, // Puck, Charon, Kore, Fenrir, Zephyr
                            },
                        },
                    },
                });

                const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
                
                if (base64Audio) {
                    const audioBytes = this.base64ToUint8Array(base64Audio);
                    const audioBuffer = await this.decodeAudioData(audioBytes);
                    
                    this.playBuffer(audioBuffer);
                    return;
                }
            } catch (error) {
                console.error("Gemini TTS Failed, falling back to local:", error);
            }
        }

        // 2. Local Fallback (Web Speech API)
        this.speakLocal(text);
    }

    private playBuffer(buffer: AudioBuffer) {
        if (!this.audioCtx || !this.gainNode) return;

        const source = this.audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(this.gainNode);
        
        source.onended = () => {
            this.isPlaying = false;
            this.currentSource = null;
            if (this.onEnd) this.onEnd();
        };

        this.currentSource = source;
        source.start();
    }

    private speakLocal(text: string) {
        if (!('speechSynthesis' in window)) return;

        if (this.onStart) this.onStart();
        this.isPlaying = true;

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        
        // Try to find a good English voice if available
        const voices = window.speechSynthesis.getVoices();
        const preferredVoice = voices.find(v => v.name.includes('Google') && v.lang.includes('en')) || 
                               voices.find(v => v.lang.includes('en'));
        
        if (preferredVoice) utterance.voice = preferredVoice;

        utterance.onend = () => {
            this.isPlaying = false;
            if (this.onEnd) this.onEnd();
        };

        utterance.onerror = () => {
            this.isPlaying = false;
            if (this.onEnd) this.onEnd();
        };

        window.speechSynthesis.speak(utterance);
    }
}

export const ttsService = new TTSService();
