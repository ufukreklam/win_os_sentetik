
import React from 'react';
import { useOS } from '../../context/OSContext';
import { X, Info, CheckCircle, AlertTriangle, AlertCircle } from 'lucide-react';

const Toaster: React.FC = () => {
  const { notifications, removeNotification } = useOS();

  // Only show active toasts
  const activeToasts = notifications.filter(n => n.showToast);

  if (activeToasts.length === 0) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle size={18} className="text-green-400" />;
      case 'warning': return <AlertTriangle size={18} className="text-yellow-400" />;
      case 'error': return <AlertCircle size={18} className="text-red-400" />;
      default: return <Info size={18} className="text-blue-400" />;
    }
  };

  return (
    <div className="fixed top-12 right-4 z-[100] flex flex-col gap-3 pointer-events-none">
      {activeToasts.map((n) => (
        <div 
          key={n.id}
          className="bg-slate-900/80 backdrop-blur-xl border border-white/10 p-4 rounded-xl shadow-2xl 
                     w-80 pointer-events-auto animate-in slide-in-from-right-10 fade-in duration-300
                     flex gap-3 relative overflow-hidden group"
        >
           {/* Progress bar simulation */}
           <div className="absolute bottom-0 left-0 h-0.5 bg-blue-500/50 w-full animate-[shrink_5s_linear_forwards]" />
           
           <div className="shrink-0 pt-0.5">
             {getIcon(n.type)}
           </div>
           <div className="flex-1 min-w-0">
             <h4 className="text-sm font-semibold text-white">{n.title}</h4>
             <p className="text-xs text-slate-300 mt-0.5">{n.message}</p>
           </div>
           <button 
             // Currently clicking 'X' on toast removes it completely (including from history). 
             // This is standard behavior (dismissing).
             onClick={() => removeNotification(n.id)}
             className="shrink-0 text-slate-400 hover:text-white transition-colors"
           >
             <X size={16} />
           </button>
        </div>
      ))}
    </div>
  );
};

export default Toaster;
