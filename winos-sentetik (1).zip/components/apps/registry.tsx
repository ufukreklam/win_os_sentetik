
import React from 'react';
import { AppID } from '../../types';
import GeminiChat from './GeminiChat';
import SettingsApp from './SettingsApp';
import FileManager from './FileManager';
import GalleryApp from './GalleryApp';
import BrowserApp from './BrowserApp';
import TerminalApp from './TerminalApp';
import NotepadApp from './NotepadApp';
import CalculatorApp from './CalculatorApp';
import CameraApp from './CameraApp';
import CodeEditorApp from './CodeEditorApp';
import MediaPlayerApp from './MediaPlayerApp';
import TaskManagerApp from './TaskManagerApp';
import AppStoreApp from './AppStoreApp';
import MindApp from './MindApp';
import SpatialApp from './SpatialApp';
import GoalsApp from './GoalsApp';
import SocialApp from './SocialApp';
import LearningApp from './LearningApp';
import SecurityApp from './SecurityApp';
import EnvironmentApp from './EnvironmentApp';
import IdentityApp from './IdentityApp';
import OrchestratorApp from './OrchestratorApp';
import BridgeApp from './BridgeApp';
import FaceApp from './FaceApp';
import ChessApp from './ChessApp';
import CreativityApp from './CreativityApp';
import MemoryApp from './MemoryApp';
import PolicyDebuggerApp from './PolicyDebuggerApp';
import ExtensionManagerApp from './ExtensionManagerApp';

// Registry mapping AppIDs to their components
export const APP_REGISTRY: Record<AppID, React.ComponentType> = {
  [AppID.CHAT]: GeminiChat,
  [AppID.FILES]: FileManager,
  [AppID.SETTINGS]: SettingsApp,
  [AppID.BROWSER]: BrowserApp,
  [AppID.PHOTOS]: GalleryApp,
  [AppID.TERMINAL]: TerminalApp,
  [AppID.NOTEPAD]: NotepadApp,
  [AppID.CALCULATOR]: CalculatorApp,
  [AppID.CAMERA]: CameraApp,
  [AppID.CODE_EDITOR]: CodeEditorApp,
  [AppID.MEDIA]: MediaPlayerApp,
  [AppID.TASK_MANAGER]: TaskManagerApp,
  [AppID.APP_STORE]: AppStoreApp,
  [AppID.MIND]: MindApp,
  [AppID.MEMORY]: MemoryApp,
  [AppID.SPATIAL]: SpatialApp,
  [AppID.GOALS]: GoalsApp,
  [AppID.SOCIAL]: SocialApp,
  [AppID.LEARNING]: LearningApp,
  [AppID.SECURITY]: SecurityApp,
  [AppID.CONNECT]: EnvironmentApp,
  [AppID.IDENTITY]: IdentityApp,
  [AppID.ORCHESTRATOR]: OrchestratorApp,
  [AppID.BRIDGE]: BridgeApp,
  [AppID.FACE]: FaceApp,
  [AppID.CHESS]: ChessApp,
  [AppID.CREATIVITY]: CreativityApp,
  [AppID.POLICY]: PolicyDebuggerApp,
  [AppID.EXTENSIONS]: ExtensionManagerApp,
};
