
import { useState, useCallback, useEffect, useRef } from 'react';
import { SerialStatus, SensorReadings, BluetoothDevice, FileTransfer, FileSystemItem, BridgePacket } from '../../types';
import { INITIAL_SENSORS } from '../initialStates';
import { serialService } from '../../services/serialService';
import { websocketService } from '../../services/websocketService';
import { apiService } from '../../services/apiService';

export const useHardwareInterface = (onNotify: (n: any) => void) => {
    // --- Serial & Sensors ---
    const [serialStatus, setSerialStatus] = useState<SerialStatus>('disconnected');
    const [sensorReadings, setSensorReadings] = useState<SensorReadings>(INITIAL_SENSORS);
    const [robotCameraFrame, setRobotCameraFrame] = useState<string | null>(null);
    const [slamMap, setSlamMap] = useState<string | null>(null);
    const [navigationPath, setNavigationPath] = useState<{x: number, y: number}[] | null>(null);

    // --- Simulation State ---
    // Motor yükü (0-100) ve işlemci yükü gibi dış etkenlerin donanımı etkilemesi için
    const simulationLoadRef = useRef({ motor: 0, cpu: 0 });

    // --- Bluetooth ---
    const [bluetoothDevices, setBluetoothDevices] = useState<BluetoothDevice[]>([]);
    const [fileTransfers, setFileTransfers] = useState<FileTransfer[]>([]);
    
    // --- WebSocket Integration ---
    useEffect(() => {
        // Subscribe to WebSocket data stream
        const unsubscribe = websocketService.subscribe((data) => {
            if (data.type === 'telemetry') {
                // Merge WS data with current state
                // This overrides the simulation loop when data comes in
                setSensorReadings(prev => ({
                    ...prev,
                    batteryVoltage: data.batteryVoltage ?? prev.batteryVoltage,
                    currentDraw: data.currentDraw ?? prev.currentDraw,
                    imu: { ...prev.imu, ...data.imu },
                    env: { ...prev.env, ...data.env },
                    lidarStatus: 'Backend Connected'
                }));
                
                // If we are receiving data, we consider ourselves connected to the backend hardware bridge
                if (serialStatus !== 'connected') {
                    setSerialStatus('connected'); 
                }
            } else if (data.type === 'camera_frame') {
                // Kamera verisi geldiğinde güncelle
                // Veri zaten Base64 string olarak geliyor, başına prefix ekliyoruz
                setRobotCameraFrame(`data:image/jpeg;base64,${data.data}`);
            } else if (data.type === 'lidar_scan') {
                // Lidar verisi ayrıca işlenip 'lidarMap' içine atılabilir
                // Basitlik için sensorReadings içine merge ediyoruz
                if (data.points) {
                     setSensorReadings(prev => ({
                         ...prev,
                         lidarMap: data.points // [{x, y, q}, ...]
                     }));
                }
            } else if (data.type === 'map_data') {
                // SLAM Map Update
                setSlamMap(`data:image/jpeg;base64,${data.image}`);
            } else if (data.type === 'navigation_path') {
                // Navigasyon Yolu
                setNavigationPath(data.path);
            }
        });
        
        // Auto-connect on mount (Try to find the RPi)
        websocketService.connect();

        return () => {
            unsubscribe();
            websocketService.disconnect();
        };
    }, []);

    // --- Serial Logic (Direct USB fallback) ---
    const connectSerial = useCallback(async () => {
        // Prefer WebSocket if available, but allow manual Serial override
        if (websocketService.getConnectionStatus()) {
             onNotify({ title: 'Already Connected', message: 'Backend Bridge is active via WiFi.', type: 'info' });
             return;
        }

        setSerialStatus('connecting');
        try {
            await serialService.connect(
                (data) => {
                    try {
                        const parsed = JSON.parse(data);
                        setSensorReadings(prev => ({ ...prev, ...parsed }));
                    } catch (e) {
                        console.debug("Received non-JSON serial data:", data);
                    }
                },
                (err) => {
                    console.error("Serial error:", err);
                    setSerialStatus('error');
                    onNotify({ title: 'Hardware Error', message: 'Connection lost to controller.', type: 'error' });
                }
            );
            setSerialStatus('connected');
            onNotify({ title: 'Hardware Connected', message: 'Serial link established with Master Controller.', type: 'success' });
        } catch (err) {
            setSerialStatus('error');
            onNotify({ title: 'Connection Failed', message: 'Could not access serial port (Check capabilities).', type: 'error' });
        }
    }, [onNotify]);

    const disconnectSerial = useCallback(async () => {
        await serialService.disconnect();
        websocketService.disconnect(); // Also cut WS
        setSerialStatus('disconnected');
        setSensorReadings(INITIAL_SENSORS);
        setRobotCameraFrame(null);
        setSlamMap(null);
        setNavigationPath(null);
        onNotify({ title: 'Disconnected', message: 'Hardware link terminated.', type: 'info' });
    }, [onNotify]);

    const sendSerialCommand = useCallback(async (cmd: string) => {
        // Priority: WebSocket -> Serial -> Simulation
        if (websocketService.getConnectionStatus()) {
            websocketService.send({ type: 'command', payload: cmd });
        } else if (serialStatus === 'connected') {
            await serialService.send(cmd);
        } else {
            console.warn("Hardware not connected (Simulated Command):", cmd);
        }
    }, [serialStatus]);
    
    const setNavigationGoal = useCallback(async (x: number, y: number) => {
        // Hedefi backend'e gönder
        try {
            await apiService.sendCommand("set_goal", { x, y });
            onNotify({ title: 'Navigation', message: `Calculating path to (${x}, ${y})...`, type: 'info' });
        } catch (e) {
            onNotify({ title: 'Navigation Error', message: 'Failed to send goal to robot.', type: 'error' });
        }
    }, [onNotify]);

    // Dışarıdan simülasyon yükünü güncellemek için fonksiyon
    const updateSimulationLoad = useCallback((type: 'motor' | 'cpu', value: number) => {
        simulationLoadRef.current = { ...simulationLoadRef.current, [type]: value };
    }, []);

    // --- MOCK DATA GENERATOR (SIMULATION MODE) ---
    // Sadece gerçek bağlantı (WS veya Serial) YOKSA çalışır.
    useEffect(() => {
        if (serialStatus === 'connected' || websocketService.getConnectionStatus()) return;

        const interval = setInterval(() => {
            setSensorReadings(prev => {
                // 1. Pil Simülasyonu: Motor yüküne göre daha hızlı tükenir
                const baseDrain = 0.01;
                const loadDrain = (simulationLoadRef.current.motor / 100) * 0.05;
                let newVoltage = prev.batteryVoltage - (baseDrain + loadDrain);
                if (newVoltage < 0) newVoltage = 0;
                
                // Şarj mantığı
                if (newVoltage < 10) {
                     if (Math.random() > 0.99) newVoltage = 12.6; 
                } else {
                     if (prev.batteryVoltage === 0) newVoltage = 12.4;
                }

                // 2. Akım Çekimi Simülasyonu
                const currentDraw = 0.5 + (simulationLoadRef.current.motor * 0.1) + (simulationLoadRef.current.cpu * 0.02);

                // 3. Sıcaklık Simülasyonu
                const targetTemp = 24 + (simulationLoadRef.current.cpu * 0.4) + (simulationLoadRef.current.motor * 0.2);
                const newTemp = prev.env.temp + (targetTemp - prev.env.temp) * 0.1;

                // 4. Lidar Simülasyonu
                const points = [];
                const noiseLevel = simulationLoadRef.current.motor > 0 ? 100 : 50;
                
                for (let i = 0; i < 360; i += 2) {
                    let dist = 0;
                    const rad = (i * Math.PI) / 180;
                    const xDist = Math.abs(2000 / Math.cos(rad));
                    const yDist = Math.abs(1500 / Math.sin(rad));
                    dist = Math.min(xDist, yDist);
                    dist += (Math.random() - 0.5) * noiseLevel;
                    if (i > 45 && i < 60) dist = 800 + Math.random() * 20;
                    points.push({ angle: i, distance: dist, quality: 100 });
                }

                return {
                    ...prev,
                    batteryVoltage: newVoltage,
                    currentDraw: currentDraw,
                    lidarStatus: 'Simulated (Local)',
                    lidarMap: points,
                    ultrasonic: {
                        front: 120 + Math.floor(Math.random() * 10),
                        left: 45 + Math.floor(Math.random() * 5),
                        right: 200 + Math.floor(Math.random() * 5)
                    },
                    env: {
                        temp: newTemp,
                        humidity: 45 + Math.random() * 2,
                        airQuality: 400 + Math.floor(Math.random() * 50)
                    }
                };
            });
        }, 200); 
        return () => clearInterval(interval);
    }, [serialStatus]);

    // --- Bluetooth Simulation (unchanged) ---
    const scanBluetooth = useCallback(() => {
        setTimeout(() => {
            const MOCK_DEVICES: BluetoothDevice[] = [
                { id: 'bt_1', name: 'iPhone 15 Pro', type: 'phone', status: 'disconnected', signal: 85 },
                { id: 'bt_2', name: 'Galaxy Tab S9', type: 'tablet', status: 'disconnected', signal: 60 },
                { id: 'bt_3', name: 'MacBook Air', type: 'laptop', status: 'disconnected', signal: 92 },
                { id: 'bt_4', name: 'Sony WH-1000XM5', type: 'headphones', status: 'disconnected', signal: 45 },
            ];
            setBluetoothDevices(prev => {
                const connected = prev.filter(d => d.status === 'connected');
                const others = MOCK_DEVICES.filter(d => !connected.find(c => c.id === d.id));
                return [...connected, ...others];
            });
        }, 1500);
    }, []);

    const pairDevice = useCallback((deviceId: string) => {
        setBluetoothDevices(prev => prev.map(d => {
            if (d.id === deviceId) return { ...d, status: 'pairing' };
            return d;
        }));
        
        setTimeout(() => {
            setBluetoothDevices(prev => prev.map(d => {
                if (d.id === deviceId) return { ...d, status: 'connected' };
                return d;
            }));
            onNotify({ title: 'Bluetooth Paired', message: 'Device connected successfully (Simulated).', type: 'success' });
        }, 2000);
    }, [onNotify]);

    const unpairDevice = useCallback((deviceId: string) => {
        setBluetoothDevices(prev => prev.map(d => {
            if (d.id === deviceId) return { ...d, status: 'disconnected' };
            return d;
        }));
    }, []);

    const sendFileBluetooth = useCallback((file: FileSystemItem, deviceId: string) => {
        // Mock transfer logic
        const transferId = `tf_${Date.now()}`;
        const newTransfer: FileTransfer = {
            id: transferId,
            fileName: file.name,
            direction: 'outgoing',
            progress: 0,
            status: 'pending',
            deviceId
        };
        
        setFileTransfers(prev => [...prev, newTransfer]);
        
        // Simulate progress
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            setFileTransfers(prev => prev.map(t => 
                t.id === transferId ? { ...t, progress, status: progress >= 100 ? 'completed' : 'transferring' } : t
            ));
            
            if (progress >= 100) {
                clearInterval(interval);
                onNotify({ title: 'Transfer Complete', message: `${file.name} sent successfully.`, type: 'success' });
            }
        }, 300);
    }, [onNotify]);

    return {
        serialStatus,
        sensorReadings,
        robotCameraFrame, 
        slamMap,
        navigationPath, // New state
        setNavigationGoal, // New action
        updateSimulationLoad,
        connectSerial,
        disconnectSerial,
        sendSerialCommand,
        bluetoothDevices,
        fileTransfers,
        scanBluetooth,
        pairDevice,
        unpairDevice,
        sendFileBluetooth
    };
};
