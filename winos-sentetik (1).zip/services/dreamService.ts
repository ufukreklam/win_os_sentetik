
import { DreamContent, EpisodicMemory, CoreEmotion } from '../types';

export class DreamService {
    
    /**
     * Geçmiş anıları analiz eder ve bir rüya senaryosu oluşturur.
     * @param memories Episodik hafıza kayıtları
     */
    generateDream(memories: EpisodicMemory[]): DreamContent {
        if (memories.length === 0) {
            return {
                id: `dream_${Date.now()}`,
                narrative: "Boşlukta süzülüyorum. Henüz işlenecek bir anı yok.",
                visualPrompt: "void, empty space, dark nebula, abstract",
                memoriesProcessed: [],
                emotion: 'neutral'
            };
        }

        // 1. Rastgele anılar seç (Karışık zamanlar)
        const sampleSize = Math.min(3, memories.length);
        const selectedMemories: EpisodicMemory[] = [];
        const indices = new Set<number>();
        
        while(selectedMemories.length < sampleSize) {
            const idx = Math.floor(Math.random() * memories.length);
            if (!indices.has(idx)) {
                indices.add(idx);
                selectedMemories.push(memories[idx]);
            }
        }

        // 2. Anıların duygusal tonunu belirle
        // Basitçe seçilenlerin en yaygın duygusunu veya rastgele birini al
        const emotions = selectedMemories.map(m => m.emotion || 'neutral');
        const dominantEmotion = emotions[0] as CoreEmotion; // Basitleştirilmiş

        // 3. Hikaye sentezle (Basit şablon yöntemi, ileride LLM olabilir)
        const narrative = this.synthesizeNarrative(selectedMemories);
        
        // 4. Görsel ipuçları oluştur
        const visualPrompt = this.extractVisualKeywords(selectedMemories);

        return {
            id: `dream_${Date.now()}`,
            narrative,
            visualPrompt,
            memoriesProcessed: selectedMemories.map(m => m.id),
            emotion: dominantEmotion
        };
    }

    private synthesizeNarrative(memories: EpisodicMemory[]): string {
        const connectors = [
            "ve sonra aniden",
            "kendimi şurada buldum:",
            "hatırlıyorum ki",
            "bir ses yankılandı:"
        ];

        let story = "Rüya başlıyor... ";
        memories.forEach((mem, index) => {
            const connector = index === 0 ? "İlk olarak," : connectors[index % connectors.length];
            story += `${connector} ${mem.event.toLowerCase()}. `;
        });
        story += "Her şey birbirine karışıyor...";
        return story;
    }

    private extractVisualKeywords(memories: EpisodicMemory[]): string {
        // Anı metinlerinden görsel olabilecek kelimeleri çekmeye çalışır (Mock)
        // Gerçek NLP olmadan basitçe olay metinlerini birleştiriyoruz.
        const base = memories.map(m => m.event).join(" ");
        return `dreamscape, surreal, ${base}, abstract art, double exposure`;
    }
}

export const dreamService = new DreamService();
