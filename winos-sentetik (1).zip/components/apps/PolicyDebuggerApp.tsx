
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { ShieldCheck, Brain, AlertOctagon, Activity, ChevronRight, Ban, CheckCircle, Clock, Zap, Play, Pause, Terminal } from 'lucide-react';
import { Action } from '../../types';

const PolicyDebuggerApp: React.FC = () => {
  const { policyState, evaluateAction, sensorReadings, performanceState } = useOS();
  const [activeTab, setActiveTab] = useState<'simulator' | 'rules'>('simulator');
  const [autoTest, setAutoTest] = useState(false);
  const [testLog, setTestLog] = useState<string[]>([]);
  
  // Simulator State
  const [simAction, setSimAction] = useState('MOVE_FORWARD');
  const [simCost, setSimCost] = useState(5);
  const [simPriority, setSimPriority] = useState(5);

  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-generate random actions for stress testing
  useEffect(() => {
      let interval: any;
      if (autoTest) {
          interval = setInterval(() => {
              const actions = ['MOVE', 'SPEAK', 'SCAN', 'CALCULATE', 'IDLE'];
              const randomAction = actions[Math.floor(Math.random() * actions.length)];
              const randomCost = Math.floor(Math.random() * 20);
              const randomRisk = Math.floor(Math.random() * 10);
              
              evaluateAction({
                  name: `AUTO_${randomAction}`,
                  type: randomAction as any,
                  cost: randomCost,
                  risk: randomRisk,
                  priority: Math.floor(Math.random() * 10),
                  reason: 'Auto-Stress Test'
              });
          }, 2000);
      }
      return () => clearInterval(interval);
  }, [autoTest, evaluateAction]);

  // Scroll to bottom on new logs
  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [policyState.decisionLog]);

  const handleManualTest = () => {
      const allowed = evaluateAction({
          name: simAction,
          type: simAction.includes('MOVE') ? 'MOVE' : 'LONG_TASK',
          cost: simCost,
          risk: simCost > 10 ? 8 : 2, // High cost usually implies high risk in this sim
          priority: simPriority,
          reason: 'Manual Operator Request'
      });
      setTestLog(prev => [...prev, `Action: ${simAction} -> ${allowed ? 'APPROVED' : 'DENIED'}`]);
  };

  const GateVisualizer: React.FC<{ 
      label: string, 
      icon: any, 
      status: 'pass' | 'fail' | 'idle', 
      detail: string,
      color: string 
  }> = ({ label, icon: Icon, status, detail, color }) => (
      <div className={`
          relative flex flex-col items-center p-4 rounded-xl border-2 transition-all duration-500 min-w-[120px]
          ${status === 'pass' ? `border-${color}-500 bg-${color}-500/10 shadow-[0_0_20px_rgba(var(--${color}-rgb),0.2)]` : 
            status === 'fail' ? 'border-red-500 bg-red-500/10 opacity-100' : 
            'border-slate-700 bg-slate-800/50 opacity-60'}
      `}>
          <div className={`p-3 rounded-full mb-2 ${status === 'pass' ? `bg-${color}-500 text-black` : status === 'fail' ? 'bg-red-500 text-white' : 'bg-slate-700 text-slate-400'}`}>
              <Icon size={24} />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider mb-1">{label}</span>
          <span className="text-[10px] text-center text-slate-400 max-w-[100px] leading-tight">{detail}</span>
          
          {/* Connection Line */}
          <div className="absolute top-1/2 -right-6 w-6 h-0.5 bg-slate-700 -z-10" />
      </div>
  );

  // Derive gate statuses from current sensor readings (Simulated Logic)
  const isSafetyPass = sensorReadings.batteryVoltage > 10.5; // Batarya > 10.5V
  const isAwarenessPass = performanceState.systemHealth > 50; // Sistem Sağlığı > %50
  const isStrategyPass = policyState.activePolicy !== 'SURVIVAL'; // Strateji modu

  return (
    <div className="flex h-full bg-[#111] text-slate-200 font-sans overflow-hidden">
        {/* Left Sidebar: Controls */}
        <div className="w-72 bg-slate-900 border-r border-white/5 flex flex-col">
            <div className="p-4 border-b border-white/5">
                <h2 className="text-lg font-bold flex items-center gap-2 text-white">
                    <ShieldCheck className="text-purple-500" /> Policy Core
                </h2>
                <p className="text-xs text-slate-400 mt-1">Decision Logic & Gates</p>
            </div>

            <div className="p-4 space-y-6 overflow-y-auto flex-1">
                {/* Status Cards */}
                <div className="grid grid-cols-2 gap-2">
                    <div className="bg-slate-800 p-3 rounded-lg border border-white/5">
                        <div className="text-[10px] uppercase text-slate-500 font-bold">Policy Mode</div>
                        <div className="text-sm font-bold text-blue-400 mt-1">{policyState.activePolicy}</div>
                    </div>
                    <div className="bg-slate-800 p-3 rounded-lg border border-white/5">
                        <div className="text-[10px] uppercase text-slate-500 font-bold">Blocked</div>
                        <div className="text-sm font-bold text-red-400 mt-1">{policyState.blockedActions}</div>
                    </div>
                </div>

                {/* Manual Simulator */}
                <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                    <div className="flex items-center gap-2 mb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">
                        <Terminal size={14} /> Action Simulator
                    </div>
                    
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs text-slate-500 block mb-1">Intent</label>
                            <select 
                                value={simAction} 
                                onChange={(e) => setSimAction(e.target.value)}
                                className="w-full bg-slate-950 border border-white/10 rounded px-2 py-1.5 text-xs text-white outline-none focus:border-blue-500"
                            >
                                <option value="MOVE_FORWARD">MOVE_FORWARD</option>
                                <option value="SPEAK_USER">SPEAK_USER</option>
                                <option value="HIGH_COMPUTE">HIGH_COMPUTE</option>
                                <option value="EMERGENCY_STOP">EMERGENCY_STOP</option>
                            </select>
                        </div>
                        
                        <div>
                            <label className="text-xs text-slate-500 block mb-1">Energy Cost ({simCost})</label>
                            <input 
                                type="range" min="0" max="100" 
                                value={simCost} 
                                onChange={(e) => setSimCost(parseInt(e.target.value))}
                                className="w-full accent-blue-500 h-1 bg-slate-700 rounded-lg appearance-none"
                            />
                        </div>

                        <div>
                            <label className="text-xs text-slate-500 block mb-1">Priority ({simPriority})</label>
                            <input 
                                type="range" min="1" max="10" 
                                value={simPriority} 
                                onChange={(e) => setSimPriority(parseInt(e.target.value))}
                                className="w-full accent-purple-500 h-1 bg-slate-700 rounded-lg appearance-none"
                            />
                        </div>

                        <button 
                            onClick={handleManualTest}
                            className="w-full bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg text-xs font-bold transition-all active:scale-95 shadow-lg shadow-blue-500/20"
                        >
                            INJECT SIGNAL
                        </button>
                    </div>
                </div>

                {/* Auto Test Toggle */}
                <div className="flex items-center justify-between bg-slate-800 p-3 rounded-lg border border-white/5">
                    <span className="text-xs font-medium">Auto Stress Test</span>
                    <button 
                        onClick={() => setAutoTest(!autoTest)}
                        className={`p-2 rounded-full transition-colors ${autoTest ? 'bg-red-500 text-white' : 'bg-green-500 text-white'}`}
                    >
                        {autoTest ? <Pause size={14} /> : <Play size={14} />}
                    </button>
                </div>
            </div>
        </div>

        {/* Main: Visualizer */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0a0a0a]">
            {/* 1. Logic Pipeline Visualization */}
            <div className="h-1/2 border-b border-white/5 p-8 flex flex-col relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#1e1b4b_0%,_transparent_70%)] opacity-30" />
                
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8 z-10">Real-time Decision Pipeline</h3>
                
                <div className="flex-1 flex items-center justify-center gap-6 z-10 overflow-x-auto px-4">
                    {/* Input Node */}
                    <div className="flex flex-col items-center opacity-70">
                        <div className="w-12 h-12 rounded-full border-2 border-dashed border-slate-600 flex items-center justify-center mb-2">
                            <Activity size={20} className="text-slate-400" />
                        </div>
                        <span className="text-[10px] font-mono text-slate-500">SIGNAL_IN</span>
                    </div>

                    <ChevronRight className="text-slate-700" />

                    {/* GATE 1: Safety (Hard Rules) */}
                    <GateVisualizer 
                        label="Safety Gate" 
                        icon={ShieldCheck} 
                        status={isSafetyPass ? 'pass' : 'fail'} 
                        detail={`Battery: ${sensorReadings.batteryVoltage.toFixed(1)}V`}
                        color="red"
                    />

                    <ChevronRight className={isSafetyPass ? 'text-green-500 animate-pulse' : 'text-slate-700'} />

                    {/* GATE 2: Awareness (Resource Check) */}
                    <GateVisualizer 
                        label="Awareness" 
                        icon={AlertOctagon} 
                        status={isSafetyPass ? (isAwarenessPass ? 'pass' : 'fail') : 'idle'} 
                        detail={`Health: ${performanceState.systemHealth}%`}
                        color="blue"
                    />

                    <ChevronRight className={isSafetyPass && isAwarenessPass ? 'text-green-500 animate-pulse' : 'text-slate-700'} />

                    {/* GATE 3: Strategy (Policy Rules) */}
                    <GateVisualizer 
                        label="Strategy" 
                        icon={Brain} 
                        status={isSafetyPass && isAwarenessPass ? (isStrategyPass ? 'pass' : 'fail') : 'idle'} 
                        detail={`Policy: ${policyState.activePolicy}`}
                        color="purple"
                    />

                    <ChevronRight className={isSafetyPass && isAwarenessPass && isStrategyPass ? 'text-green-500 animate-pulse' : 'text-slate-700'} />

                    {/* Output Node */}
                    <div className={`flex flex-col items-center transition-all ${isSafetyPass && isAwarenessPass && isStrategyPass ? 'opacity-100 scale-110' : 'opacity-30'}`}>
                        <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-2 shadow-lg ${isSafetyPass && isAwarenessPass && isStrategyPass ? 'bg-green-500 text-black shadow-green-500/50' : 'bg-slate-800 text-slate-500'}`}>
                            <Zap size={24} fill="currentColor" />
                        </div>
                        <span className="text-[10px] font-bold text-green-400">EXECUTE</span>
                    </div>
                </div>
            </div>

            {/* 2. Decision Log */}
            <div className="flex-1 flex flex-col bg-[#050505] min-h-0">
                <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Decision Trace Log</span>
                    <span className="text-[10px] font-mono text-slate-600">LIVE STREAM</span>
                </div>
                
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 font-mono">
                    {policyState.decisionLog.length === 0 ? (
                        <div className="text-center py-20 text-slate-700 italic">No decisions recorded. System idle.</div>
                    ) : (
                        policyState.decisionLog.map(log => (
                            <div key={log.id} className="group flex items-start gap-4 p-3 rounded-lg border border-white/5 hover:bg-white/5 transition-colors bg-slate-900/30">
                                <div className={`mt-0.5 shrink-0 ${log.outcome === 'APPROVED' ? 'text-green-500' : 'text-red-500'}`}>
                                    {log.outcome === 'APPROVED' ? <CheckCircle size={16} /> : <Ban size={16} />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="font-bold text-sm text-slate-200">{log.proposedAction.name}</span>
                                        <div className="flex items-center gap-2">
                                            <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
                                                log.layer === 'SAFETY' ? 'border-red-500/30 text-red-400 bg-red-500/10' :
                                                log.layer === 'AWARENESS' ? 'border-blue-500/30 text-blue-400 bg-blue-500/10' :
                                                'border-purple-500/30 text-purple-400 bg-purple-500/10'
                                            }`}>
                                                {log.layer} LAYER
                                            </span>
                                            <span className="text-[10px] text-slate-600">{log.timestamp.toLocaleTimeString()}</span>
                                        </div>
                                    </div>
                                    <p className="text-xs text-slate-400 truncate">{log.description}</p>
                                    <div className="flex gap-4 mt-2 text-[10px] text-slate-600">
                                        <span>COST: {log.proposedAction.cost}</span>
                                        <span>RISK: {log.proposedAction.risk}</span>
                                        <span>PRIORITY: {log.proposedAction.priority}</span>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    </div>
  );
};

export default PolicyDebuggerApp;
