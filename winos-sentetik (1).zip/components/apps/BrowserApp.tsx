
import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, ArrowRight, RotateCw, Home, Star, 
  MoreVertical, Search, Lock, X, Plus, Globe, Trash2
} from 'lucide-react';

interface Bookmark {
  name: string;
  url: string;
  icon: string;
}

const BrowserApp: React.FC = () => {
  const [url, setUrl] = useState('winos://newtab');
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<string[]>(['winos://newtab']);
  const [historyIndex, setHistoryIndex] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  // Bookmarks State with Persistence
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('winos_browser_bookmarks');
        if (saved) return JSON.parse(saved);
    }
    return [
        { name: 'Wikipedia', url: 'https://www.wikipedia.org', icon: 'W' },
        { name: 'Github', url: 'https://github.com', icon: 'G' },
        { name: 'Google', url: 'https://www.google.com/webhp?igu=1', icon: 'g' },
        { name: 'Bing', url: 'https://www.bing.com', icon: 'b' },
    ];
  });

  useEffect(() => {
     localStorage.setItem('winos_browser_bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  const navigate = (newUrl: string) => {
    setIsLoading(true);
    // Simulate loading delay
    setTimeout(() => setIsLoading(false), 1500);

    const nextUrl = newUrl.includes('://') ? newUrl : `https://${newUrl}`;
    
    // Update History
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(nextUrl);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    setUrl(nextUrl);
    setInputValue(nextUrl === 'winos://newtab' ? '' : nextUrl);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
        if (inputValue.includes('.') && !inputValue.includes(' ')) {
            navigate(inputValue);
        } else {
            // Treat as search
            navigate(`https://www.bing.com/search?q=${encodeURIComponent(inputValue)}`);
        }
    }
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      const prevIndex = historyIndex - 1;
      setHistoryIndex(prevIndex);
      setUrl(history[prevIndex]);
      setInputValue(history[prevIndex] === 'winos://newtab' ? '' : history[prevIndex]);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      const nextIndex = historyIndex + 1;
      setHistoryIndex(nextIndex);
      setUrl(history[nextIndex]);
      setInputValue(history[nextIndex] === 'winos://newtab' ? '' : history[nextIndex]);
    }
  };

  const handleRefresh = () => {
    setIsLoading(true);
    const current = iframeRef.current;
    if (current) {
        current.src = current.src; // Force reload
    }
    setTimeout(() => setIsLoading(false), 1000);
  };

  const toggleBookmark = () => {
      if (url === 'winos://newtab') return;
      
      const exists = bookmarks.find(b => b.url === url);
      if (exists) {
          setBookmarks(prev => prev.filter(b => b.url !== url));
      } else {
          // Attempt to get name from URL or generic
          let name = url;
          try {
              name = new URL(url).hostname.replace('www.', '');
          } catch(e) {}
          
          setBookmarks(prev => [...prev, {
              name: name.charAt(0).toUpperCase() + name.slice(1),
              url: url,
              icon: name.charAt(0).toUpperCase()
          }]);
      }
  };

  const removeBookmark = (e: React.MouseEvent, bookmarkUrl: string) => {
      e.stopPropagation();
      setBookmarks(prev => prev.filter(b => b.url !== bookmarkUrl));
  };

  const isInternalPage = url === 'winos://newtab';
  const isBookmarked = bookmarks.some(b => b.url === url);

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100 font-sans">
      {/* Tab Bar */}
      <div className="h-9 bg-black/40 flex items-end px-2 gap-2 select-none border-b border-white/5 pt-1">
        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-t-lg text-xs max-w-[200px] border-t border-x border-white/10 relative group">
           <Globe size={12} className="text-blue-400" />
           <span className="truncate flex-1">{isInternalPage ? 'New Tab' : url}</span>
           <button className="hover:bg-white/10 rounded p-0.5"><X size={10} /></button>
           <div className="absolute bottom-[-1px] left-0 right-0 h-0.5 bg-blue-500 rounded-full" />
        </div>
        <button className="p-1.5 hover:bg-white/10 rounded mb-1 text-slate-400">
            <Plus size={14} />
        </button>
      </div>

      {/* Navigation Bar */}
      <div className="h-12 bg-slate-800 border-b border-white/5 flex items-center px-4 gap-3">
        <div className="flex items-center gap-1">
            <button 
                onClick={handleBack} 
                disabled={historyIndex === 0}
                className="p-1.5 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
                <ArrowLeft size={16} />
            </button>
            <button 
                onClick={handleForward}
                disabled={historyIndex === history.length - 1}
                className="p-1.5 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
                <ArrowRight size={16} />
            </button>
            <button 
                onClick={handleRefresh}
                className={`p-1.5 hover:bg-white/10 rounded-full transition-all ${isLoading ? 'animate-spin' : ''}`}
            >
                <RotateCw size={16} />
            </button>
        </div>

        <button 
            onClick={() => navigate('winos://newtab')}
            className={`p-1.5 hover:bg-white/10 rounded-full transition-colors ${isInternalPage ? 'text-blue-400' : 'text-slate-400'}`}
        >
            <Home size={16} />
        </button>

        {/* Address Bar */}
        <form onSubmit={handleSubmit} className="flex-1">
            <div className="relative group">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    {url.startsWith('https') ? <Lock size={12} className="text-green-400" /> : <Search size={12} />}
                </div>
                <input 
                    type="text" 
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onFocus={(e) => e.target.select()}
                    placeholder="Search or enter web address"
                    className="w-full bg-slate-900 border border-slate-700 rounded-full py-1.5 pl-9 pr-10 text-sm focus:outline-none focus:border-blue-500 focus:bg-slate-900/80 transition-all text-slate-200"
                />
                <button 
                    type="button" 
                    onClick={toggleBookmark}
                    className={`absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-white/10 rounded-full transition-colors ${isBookmarked ? 'text-yellow-400 fill-yellow-400' : 'text-slate-400'}`}
                >
                    <Star size={12} />
                </button>
            </div>
        </form>

        <button className="p-1.5 hover:bg-white/10 rounded-full text-slate-400">
            <MoreVertical size={16} />
        </button>
      </div>

      {/* Browser Content */}
      <div className="flex-1 relative bg-white overflow-hidden">
         {isLoading && (
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-blue-500/20">
                <div className="h-full bg-blue-500 animate-[loading_1.5s_ease-in-out_infinite]" style={{ width: '30%' }} />
            </div>
         )}
         
         {isInternalPage ? (
            // New Tab Page
            <div className="h-full w-full bg-slate-900 flex flex-col items-center justify-center p-8 animate-in fade-in duration-300 overflow-y-auto">
                <div className="w-24 h-24 bg-gradient-to-tr from-blue-500 to-purple-600 rounded-2xl shadow-2xl flex items-center justify-center mb-8">
                    <Globe size={48} className="text-white" />
                </div>
                <h1 className="text-3xl font-light text-white mb-8">WinOS Browser</h1>
                
                <form onSubmit={handleSubmit} className="w-full max-w-lg mb-12">
                    <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-400 transition-colors" size={20} />
                        <input 
                            type="text" 
                            placeholder="Search the web..."
                            className="w-full bg-slate-800 border border-slate-700 rounded-full py-3.5 pl-12 pr-6 text-slate-200 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-lg transition-all"
                            onChange={(e) => setInputValue(e.target.value)}
                        />
                    </div>
                </form>

                {/* Bookmarks Grid */}
                <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-4">
                    {bookmarks.map((link) => (
                        <div 
                            key={link.url}
                            className="group relative flex flex-col items-center gap-3 p-4 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
                            onClick={() => navigate(link.url)}
                        >
                            <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-xl font-bold text-slate-300 group-hover:bg-slate-700 group-hover:scale-110 transition-all shadow-md border border-white/5 overflow-hidden">
                                {link.icon}
                            </div>
                            <span className="text-xs text-slate-400 group-hover:text-slate-200 text-center truncate w-full max-w-[80px]">{link.name}</span>
                            
                            {/* Remove Button */}
                            <button 
                                onClick={(e) => removeBookmark(e, link.url)}
                                className="absolute top-1 right-1 p-1 bg-slate-800 rounded-full text-slate-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <X size={10} />
                            </button>
                        </div>
                    ))}
                    
                    {/* Add Button Placeholder */}
                     <div className="flex flex-col items-center gap-3 p-4 rounded-xl hover:bg-white/5 transition-colors cursor-pointer opacity-50 hover:opacity-100">
                        <div className="w-12 h-12 bg-slate-800/50 rounded-full flex items-center justify-center text-slate-500 border border-white/5 border-dashed">
                             <Plus size={20} />
                        </div>
                        <span className="text-xs text-slate-500">Add</span>
                    </div>
                </div>
            </div>
         ) : (
            // External Content (Iframe)
            <div className="w-full h-full bg-white relative">
                 <iframe 
                    ref={iframeRef}
                    src={url}
                    className="w-full h-full border-none"
                    title="Browser Content"
                    sandbox="allow-same-origin allow-scripts allow-forms"
                    onLoad={() => setIsLoading(false)}
                 />
                 {/* Overlay for blocked sites (visual feedback) */}
                 <div className="absolute bottom-4 right-4 bg-black/80 text-white text-xs px-3 py-2 rounded-md backdrop-blur-md pointer-events-none opacity-50">
                    Note: Many sites block iframe embedding (X-Frame-Options).
                 </div>
            </div>
         )}
      </div>
    </div>
  );
};

export default BrowserApp;
