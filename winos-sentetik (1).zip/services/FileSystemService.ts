
import { FileSystemItem } from '../types';
import { idbService } from './idbService';

export const INITIAL_FS: Record<string, FileSystemItem[]> = {
  '/': [
    { name: 'bin', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'boot', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'dev', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'etc', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'home', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'usr', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'var', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
  ],
  '/home': [
    { name: 'user', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' },
    { name: 'Admin', type: 'folder', permissions: 'drwxr-xr-x', owner: 'root' }
  ],
  '/home/user': [
    { name: 'Desktop', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Documents', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Downloads', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Music', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Pictures', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Public', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Videos', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: '.Trash', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user', size: '0 B' },
    { name: 'todo.txt', type: 'file', fileType: 'text', size: '2 KB', permissions: '-rw-r--r--', owner: 'user', content: '1. Build OS\n2. Integrate AI\n3. Profit' },
    { name: 'script.sh', type: 'file', fileType: 'code', size: '4 KB', permissions: '-rwxr-xr-x', owner: 'user', content: '#!/bin/bash\necho "Hello World"' },
  ],
  '/home/user/Desktop': [
    { 
        name: 'Welcome_Guide.md', 
        type: 'file', 
        fileType: 'text', 
        size: '3 KB', 
        permissions: '-rw-r--r--', 
        owner: 'system', 
        content: `# Welcome to WinOS Hybrid v1.0\n\nThank you for trying out WinOS Hybrid! This is a web-based operating system simulation combining the best of desktop and mobile UI paradigms.\n\n## Key Features to Try:\n\n1. **Window Management**:\n   - Drag windows by their title bar.\n   - Snap windows to edges (left/right) for split-screen.\n   - Resize using the bottom-right handle.\n\n2. **AI Integration**:\n   - Open "Gemini Assistant" from the taskbar.\n   - Ask it to "Change wallpaper to neon" or "Open Calculator".\n\n3. **Hardware Simulation**:\n   - Open **Settings > Robot Sensors** to see the simulated telemetry dashboard.\n   - This is prepared for real Web Serial integration.\n\n4. **Files & Code**:\n   - Create files on the Desktop (Right Click > New Text Document).\n   - Open scripts in the Code Editor.\n\nEnjoy exploring!\n- The WinOS Team` 
    },
    { name: 'Project_Specs.txt', type: 'file', fileType: 'text', size: '1 KB', permissions: '-rw-r--r--', owner: 'user', content: 'Robot Arm Specs:\n- 6 DOF\n- Payload: 500g' },
    { name: 'Logs', type: 'folder', permissions: 'drwxr-xr-x', size: '0 B', owner: 'user' },
    { name: 'Meeting_Notes.txt', type: 'file', fileType: 'text', size: '2 KB', permissions: '-rw-r--r--', owner: 'user', content: 'Meeting Notes:\n- Discussed Q4 roadmap\n- AI features prioritized' },
  ],
  '/home/user/Desktop/Logs': [],
  '/home/user/Documents': [
    { name: 'Project_Alpha', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Strategy', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'Resume.pdf', type: 'file', fileType: 'text', size: '1.2 MB', permissions: '-rw-r--r--', owner: 'user', content: '[PDF Content]' },
    { name: 'Notes.md', type: 'file', fileType: 'text', size: '5 KB', permissions: '-rw-r--r--', owner: 'user', content: '# Meeting Notes\n- Discuss Q3 goals' },
    { name: 'Budget_2024.xlsx', type: 'file', fileType: 'unknown', size: '15 KB', permissions: '-rw-r--r--', owner: 'user' },
  ],
  '/home/user/Documents/Strategy': [
      { name: 'Q1_Goals.txt', type: 'file', fileType: 'text', size: '1 KB', permissions: '-rw-r--r--', owner: 'user', content: 'Goals for Q1:\n- Launch MVP\n- Gather user feedback' },
  ],
  '/home/user/Downloads': [
    { name: 'installer_v2.deb', type: 'file', fileType: 'unknown', size: '45 MB', permissions: '-rw-r--r--', owner: 'user' },
    { name: 'wallpapers.zip', type: 'file', fileType: 'unknown', size: '120 MB', permissions: '-rw-r--r--', owner: 'user' },
    { name: 'drivers.tar.gz', type: 'file', fileType: 'unknown', size: '12 MB', permissions: '-rw-r--r--', owner: 'user' },
  ],
  '/home/user/Pictures': [
    { name: 'Vacation', type: 'folder', permissions: 'drwxr-xr-x', owner: 'user' },
    { name: 'screenshot_01.png', type: 'file', fileType: 'image', size: '2.4 MB', permissions: '-rw-r--r--', owner: 'user' },
    { name: 'design_mockup.png', type: 'file', fileType: 'image', size: '1.8 MB', permissions: '-rw-r--r--', owner: 'user' },
  ],
  '/home/user/Music': [
    { name: 'Ambient_Dream.mp3', type: 'file', fileType: 'music', size: '4.2 MB', permissions: '-rw-r--r--', owner: 'user', content: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
    { name: 'Synthwave_Mix.mp3', type: 'file', fileType: 'music', size: '3.5 MB', permissions: '-rw-r--r--', owner: 'user', content: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
    { name: 'LoFi_Beats.mp3', type: 'file', fileType: 'music', size: '5.1 MB', permissions: '-rw-r--r--', owner: 'user', content: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
  ],
  '/home/user/Videos': [
    { name: 'Big_Buck_Bunny.mp4', type: 'file', fileType: 'video', size: '12 MB', permissions: '-rw-r--r--', owner: 'user', content: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
    { name: 'Tech_Demo.mp4', type: 'file', fileType: 'video', size: '8 MB', permissions: '-rw-r--r--', owner: 'user', content: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' }
  ],
  '/home/user/Documents/Project_Alpha': [],
  '/home/user/Pictures/Vacation': [],
  '/home/user/.Trash': [],
};

class FileSystemService {
  /**
   * Load FS from IndexedDB (Async)
   * Also handles migration from LocalStorage if needed.
   */
  async loadFileSystem(): Promise<Record<string, FileSystemItem[]>> {
    if (typeof window === 'undefined') return INITIAL_FS;

    try {
        // 1. Try Loading from IDB
        const idbFS = await idbService.loadFileSystem();
        
        if (idbFS) {
            // Hydrate Dates
            Object.keys(idbFS).forEach(path => {
                idbFS[path] = idbFS[path].map((item: any) => ({
                    ...item,
                    dateModified: item.dateModified ? new Date(item.dateModified) : undefined
                }));
            });
            return idbFS;
        }

        // 2. Migration Check: LocalStorage fallback
        const lsFS = localStorage.getItem('winos_fs');
        if (lsFS) {
            console.log("Migrating FileSystem from LocalStorage to IndexedDB...");
            const parsed = JSON.parse(lsFS);
            await idbService.saveFileSystem(parsed);
            localStorage.removeItem('winos_fs'); // Cleanup
            
            // Hydrate and return
            Object.keys(parsed).forEach(path => {
                parsed[path] = parsed[path].map((item: any) => ({
                    ...item,
                    dateModified: item.dateModified ? new Date(item.dateModified) : undefined
                }));
            });
            return parsed;
        }

    } catch (e) {
        console.error("FS Load Error:", e);
    }

    // Default
    return INITIAL_FS;
  }

  /**
   * Save State (Persist to IDB)
   */
  async saveState(fs: Record<string, FileSystemItem[]>, useCloud: boolean): Promise<void> {
      // Save to IDB asynchronously
      if (typeof window !== 'undefined') {
          idbService.saveFileSystem(fs).catch(e => console.error("IDB Save Failed", e));
      }

      // Simulate Cloud Latency
      if (useCloud) {
          const delay = Math.floor(Math.random() * 800) + 400; 
          await new Promise(resolve => setTimeout(resolve, delay));
          if (Math.random() < 0.01) {
              throw new Error("Cloud sync failed: Connection timed out");
          }
      }
  }

  /**
   * Write file to a directory
   */
  writeFile(
    fs: Record<string, FileSystemItem[]>, 
    path: string, 
    file: FileSystemItem,
    owner: string,
    timeOffset: number
  ): { newFs: Record<string, FileSystemItem[]>, success: boolean, message?: string } {
    
    const dir = fs[path] || [];
    
    const fileWithMeta = {
        ...file,
        owner: file.owner || owner,
        dateModified: new Date(Date.now() + timeOffset)
    };

    const newDir = dir.filter(f => f.name !== file.name);
    newDir.push(fileWithMeta);
    
    return {
        newFs: { ...fs, [path]: newDir },
        success: true
    };
  }

  /**
   * Create Directory
   */
  mkdir(
    fs: Record<string, FileSystemItem[]>, 
    path: string, 
    folderName: string,
    owner: string,
    timeOffset: number
  ) {
    const newPath = path === '/' ? `/${folderName}` : `${path}/${folderName}`;
    if (fs[path]?.find(f => f.name === folderName)) return { newFs: fs, success: false };

    const dir = fs[path] || [];
    const newFolder: FileSystemItem = { 
        name: folderName, 
        type: 'folder', 
        permissions: 'drwxr-xr-x',
        size: '0 B',
        owner: owner,
        dateModified: new Date(Date.now() + timeOffset)
    };

    return {
        newFs: { 
            ...fs, 
            [path]: [...dir, newFolder],
            [newPath]: [] 
        },
        success: true
    };
  }

  /**
   * Delete or Move to Trash
   */
  deleteItem(
    fs: Record<string, FileSystemItem[]>, 
    path: string, 
    itemName: string,
    user: { username: string, isAdmin: boolean }
  ) {
    const dir = fs[path];
    if (!dir) return { newFs: fs, success: false };
    
    const item = dir.find(f => f.name === itemName);
    if (!item) return { newFs: fs, success: false };

    // Permission Check
    if (item.owner === 'root' && !user.isAdmin) {
        return { newFs: fs, success: false, message: 'Permission denied: System Item' };
    }
    if (item.owner !== user.username && !user.isAdmin && item.owner !== 'root') {
        return { newFs: fs, success: false, message: `Permission denied: Owned by ${item.owner}` };
    }

    const trashPath = '/home/user/.Trash';

    // Move to Trash logic
    if (path !== trashPath && path.startsWith('/home/user')) {
        const trashDir = fs[trashPath] || [];
        const newSourceDir = dir.filter(f => f.name !== itemName);
        
        let newName = itemName;
        let counter = 1;
        while(trashDir.find(f => f.name === newName)) {
            const parts = itemName.split('.');
            if (parts.length > 1) {
                const ext = parts.pop();
                newName = `${parts.join('.')}_${counter}.${ext}`;
            } else {
                newName = `${itemName}_${counter}`;
            }
            counter++;
        }

        const newTrashItem = { ...item, name: newName, originalPath: path };
        
        return {
            newFs: { ...fs, [path]: newSourceDir, [trashPath]: [...trashDir, newTrashItem] },
            success: true,
            message: 'Moved to Recycle Bin'
        };
    }

    // Permanent Delete
    const newDir = dir.filter(f => f.name !== itemName);
    return {
        newFs: { ...fs, [path]: newDir },
        success: true,
        message: 'Permanently deleted'
    };
  }

  /**
   * Restore from Trash
   */
  restoreItem(fs: Record<string, FileSystemItem[]>, itemName: string) {
      const trashDir = fs['/home/user/.Trash'] || [];
      const itemToRestore = trashDir.find(i => i.name === itemName);
      if (!itemToRestore) return { newFs: fs, success: false };

      const targetPath = itemToRestore.originalPath || '/home/user';
      const destDirExists = !!fs[targetPath];
      const finalPath = destDirExists ? targetPath : '/home/user';
      
      const destDir = fs[finalPath] || [];
      
      if (destDir.find(f => f.name === itemToRestore.name)) {
           return { newFs: fs, success: false, message: 'Name collision in destination' };
      }

      const { originalPath, ...rest } = itemToRestore;
      const restoredItem = rest as FileSystemItem;

      return {
          newFs: {
              ...fs,
              ['/home/user/.Trash']: trashDir.filter(i => i.name !== itemName),
              [finalPath]: [...destDir, restoredItem]
          },
          success: true,
          message: 'Restored successfully'
      };
  }

  /**
   * Move File
   */
  moveFile(fs: Record<string, FileSystemItem[]>, sourcePath: string, destPath: string, itemName: string) {
      if (sourcePath === destPath) return { newFs: fs, success: false };

      const sourceDir = fs[sourcePath] || [];
      const fileToMove = sourceDir.find(f => f.name === itemName);
      if (!fileToMove) return { newFs: fs, success: false };

      const destDir = fs[destPath] || [];
      if (destDir.find(f => f.name === itemName)) {
          return { newFs: fs, success: false, message: 'Destination exists' };
      }

      const newSourceDir = sourceDir.filter(f => f.name !== itemName);
      
      return {
          newFs: {
              ...fs,
              [sourcePath]: newSourceDir,
              [destPath]: [...destDir, fileToMove]
          },
          success: true
      };
  }
}

export const fileSystemService = new FileSystemService();
