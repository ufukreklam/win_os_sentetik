
import { GoogleGenAI, FunctionDeclaration, Type, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL } from "../constants";

// NOTE: In a real production app, never expose keys on client side.
const apiKey = process.env.API_KEY || ''; 

let aiClient: GoogleGenAI | null = null;

const getClient = () => {
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
};

// --- Tool Definitions ---

const openAppTool: FunctionDeclaration = {
  name: "openApp",
  description: "Opens a specific application on the computer.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      appName: {
        type: Type.STRING,
        description: "The name or ID of the app to open (e.g., 'calculator', 'browser', 'settings', 'notepad', 'terminal', 'photos', 'files').",
      },
    },
    required: ["appName"],
  },
};

const closeAppTool: FunctionDeclaration = {
  name: "closeApp",
  description: "Closes a specific application.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      appName: {
        type: Type.STRING,
        description: "The name or ID of the app to close.",
      },
    },
    required: ["appName"],
  },
};

const changeWallpaperTool: FunctionDeclaration = {
  name: "changeWallpaper",
  description: "Changes the desktop wallpaper to a specific theme or URL.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      theme: {
        type: Type.STRING,
        description: "The theme name (e.g., 'dark', 'neon', 'nature', 'minimal') or a direct image URL.",
      },
    },
    required: ["theme"],
  },
};

export interface GeminiResponse {
  text: string;
  functionCalls?: Array<{
    name: string;
    args: any;
  }>;
}

export const generateResponse = async (prompt: string, context?: string): Promise<GeminiResponse> => {
  if (!apiKey) {
    return { text: "API Key is missing. Please configure process.env.API_KEY." };
  }

  try {
    const ai = getClient();
    
    // RAG Context Injection
    const fullContent = context 
        ? `Use the following context to answer the user's question. If the answer is not in the context, answer generally.\n\nContext:\n${context}\n\nUser Question: ${prompt}`
        : prompt;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: fullContent,
      config: {
        tools: [{ functionDeclarations: [openAppTool, closeAppTool, changeWallpaperTool] }],
        systemInstruction: "You are WinOS Assistant, a helpful AI integrated into a web-based operating system. You can open apps, close them, and change wallpapers. Always be concise. If a user asks to perform an action you have a tool for, call the tool.",
      }
    });

    const functionCalls = response.functionCalls?.map(fc => ({
      name: fc.name,
      args: fc.args
    }));

    return {
      text: response.text || (functionCalls ? "Executing system command..." : "I heard you, but I have nothing to say."),
      functionCalls
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    return { text: "I encountered an error while thinking. Please try again." };
  }
};

/**
 * Sends an image to Gemini for analysis.
 * @param base64Data Base64 encoded image data (without data:image/png;base64, prefix)
 * @param mimeType IANA standard MIME type
 */
export const analyzeImage = async (base64Data: string, mimeType: string = 'image/png'): Promise<string> => {
    if (!apiKey) return "API Key missing.";

    try {
        const ai = getClient();
        const imagePart = {
            inlineData: {
                data: base64Data,
                mimeType: mimeType,
            },
        };
        const textPart = {
            text: "Identify everything you see in this image clearly. If it's a robotic environment, mention technical details. Be concise."
        };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: GEMINI_MODEL,
            contents: { parts: [imagePart, textPart] },
        });

        return response.text || "I see the image, but I can't describe it right now.";
    } catch (error) {
        console.error("Gemini Vision Error:", error);
        return "Failed to analyze image. Check console for details.";
    }
};

/**
 * Generates an embedding vector for the given text using Gemini.
 * @param text The text to embed
 * @returns An array of numbers representing the vector
 */
export const getEmbedding = async (text: string): Promise<number[] | null> => {
    if (!apiKey) return null;
    try {
        const ai = getClient();
        const result = await ai.models.embedContent({
            model: "text-embedding-004",
            content: text,
        });
        return result.embedding.values;
    } catch (error) {
        console.error("Embedding Error:", error);
        return null;
    }
};
