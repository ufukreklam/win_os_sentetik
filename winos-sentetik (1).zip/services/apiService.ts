
import { BridgePacket } from '../types';

const API_BASE_URL = 'http://localhost:8000'; // RPi IP'si buraya gelecek

export interface SystemHealth {
    status: 'nominal' | 'warning' | 'critical';
    uptime: number;
    cpu_usage: number;
    memory_usage: number;
    disk_usage: number;
    temperature: number;
}

class ApiService {
    private isConnected: boolean = false;

    async checkConnection(): Promise<boolean> {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 2000);
            
            const response = await fetch(`${API_BASE_URL}/`, { 
                method: 'GET',
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            this.isConnected = response.ok;
            return response.ok;
        } catch (e) {
            this.isConnected = false;
            return false;
        }
    }

    async getSystemHealth(): Promise<SystemHealth | null> {
        if (!this.isConnected) return null;
        
        try {
            const response = await fetch(`${API_BASE_URL}/health`);
            if (!response.ok) throw new Error('Health check failed');
            return await response.json();
        } catch (e) {
            console.warn("Backend health check failed", e);
            this.isConnected = false;
            return null;
        }
    }

    async sendCommand(command: string, params: any = {}): Promise<any> {
        try {
            const response = await fetch(`${API_BASE_URL}/command`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command, parameters: params })
            });
            return await response.json();
        } catch (e) {
            console.error("Command execution failed", e);
            throw e;
        }
    }
}

export const apiService = new ApiService();
