
import heapq
import numpy as np
import logging
import base64
import cv2
from ..core.robot_system import RobotNode

logger = logging.getLogger("NavigationNode")

class NavigationNode(RobotNode):
    """
    Otonom Navigasyon Düğümü
    - 'map_data' üzerinden Occupancy Grid'i alır.
    - 'user_input' üzerinden 'set_goal' komutunu dinler.
    - A* Algoritması ile en kısa yolu hesaplar.
    - 'navigation_path' kanalından yolu yayınlar.
    """
    def __init__(self, bus):
        super().__init__("NavigationNode", bus)
        self.map_grid = None
        self.map_size = 800
        self.center = 400
        self.current_path = []
        self.goal = None
        self.robot_pos = (400, 400) # Varsayılan merkez
        self.loop_interval = 0.5 

    async def setup(self):
        self.bus.subscribe("map_data", self.handle_map_update)
        self.bus.subscribe("user_input", self.handle_user_input)

    async def handle_map_update(self, data):
        """SLAM'den gelen haritayı güncelle"""
        try:
            if "image" in data:
                # Base64 JPEG -> Numpy Array
                nparr = np.frombuffer(base64.b64decode(data["image"]), np.uint8)
                # Gri tonlamalı oku (0=Engel, 255=Boş, 127=Bilinmeyen)
                self.map_grid = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
        except Exception as e:
            logger.error(f"Harita işleme hatası: {e}")

    async def handle_user_input(self, data):
        """Kullanıcı komutlarını işle"""
        if data.get("action") == "set_goal":
            # Koordinatlar grid indeksleridir (0-800)
            target_x = int(data.get("x", 400))
            target_y = int(data.get("y", 400))
            
            logger.info(f"Yeni Hedef Alındı: {target_x}, {target_y}")
            self.goal = (target_x, target_y)
            await self.plan_path()

    def heuristic(self, a, b):
        # Manhattan mesafesi (Hızlı)
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    async def plan_path(self):
        """A* Algoritması ile yol planla"""
        if self.map_grid is None or self.goal is None:
            logger.warning("Harita veya hedef eksik.")
            return

        start = self.robot_pos
        goal = self.goal
        
        # Sınır Kontrolü
        if not (0 <= goal[0] < self.map_size and 0 <= goal[1] < self.map_size):
            logger.warning("Hedef harita dışında.")
            return
            
        # Hedef Nokta Kontrolü (Engel içinde mi?)
        # 100 eşiği: Siyah(0) engeldir, Gri(127) bilinmeyen, Beyaz(255) boştur.
        # Güvenli geçiş için > 100 kabul edelim (Bilinmeyen veya Boş)
        if self.map_grid[goal[1], goal[0]] < 100:
             logger.warning("Hedef bir engel üzerinde!")
             # Yine de en yakın noktayı bulmaya çalışabiliriz ama şimdilik iptal.
             return

        # A* Başlangıç
        open_set = []
        heapq.heappush(open_set, (0, start))
        came_from = {}
        
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}
        
        found = False
        iterations = 0
        max_iterations = 10000 # Sonsuz döngüyü önle (Python yavaş olabilir)

        # Grid boyutunu küçülterek (Downsampling) hızlandırabiliriz ama
        # şimdilik tam çözünürlükte, sınırlı iterasyonla deneyelim.
        
        while open_set:
            iterations += 1
            if iterations > max_iterations:
                logger.warning("Yol bulma zaman aşımı (Max Iterasyon).")
                break

            current = heapq.heappop(open_set)[1]

            if current == goal:
                found = True
                break

            # 4-Komşuluk (Sağ, Sol, Yukarı, Aşağı)
            for dx, dy in [(0, 10), (10, 0), (0, -10), (-10, 0)]: # 10 piksel atlayarak hızlan (Grid Step)
                neighbor = (current[0] + dx, current[1] + dy)
                
                # Harita sınırları
                if 0 <= neighbor[0] < self.map_size and 0 <= neighbor[1] < self.map_size:
                    
                    # Engel Kontrolü (Siyah bölgelerden kaçın)
                    if self.map_grid[neighbor[1], neighbor[0]] < 80:
                        continue
                        
                    tentative_g_score = g_score[current] + 1
                    
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal)
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        if found:
            # Yolu geri izle
            path = []
            curr = goal
            while curr in came_from:
                path.append(curr)
                curr = came_from[curr]
            path.append(start)
            path.reverse()
            self.current_path = path
            
            logger.info(f"Yol bulundu: {len(path)} adım.")
            
            # Yolu Yayınla
            await self.bus.publish("navigation_path", {
                "timestamp": 0,
                "path": path # List of (x, y) tuples
            })
        else:
            logger.warning("Hedefe yol bulunamadı.")

    async def loop(self):
        pass
