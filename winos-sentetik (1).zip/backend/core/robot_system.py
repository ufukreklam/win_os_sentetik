
import asyncio
import logging
from typing import Callable, Dict, List, Any

# Loglama yapılandırması
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("WinOS-Core")

class MessageBus:
    """
    Basit Pub/Sub Mesaj Hattı.
    Node'ların birbirleriyle ve WebSocket ile konuşmasını sağlar.
    """
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}

    def subscribe(self, topic: str, handler: Callable):
        if topic not in self._subscribers:
            self._subscribers[topic] = []
        self._subscribers[topic].append(handler)
        logger.debug(f"Abone olundu: {topic}")

    async def publish(self, topic: str, data: Any):
        if topic in self._subscribers:
            # Tüm abonelere asenkron olarak veriyi dağıt
            for handler in self._subscribers[topic]:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(data)
                    else:
                        handler(data)
                except Exception as e:
                    logger.error(f"Mesaj dağıtım hatası ({topic}): {e}")

class RobotNode:
    """
    Her bir donanım veya mantık birimi (Lidar, Motor, AI) bir Node'dur.
    ROS Node mantığına benzer ama daha hafiftir.
    """
    def __init__(self, name: str, bus: MessageBus):
        self.name = name
        self.bus = bus
        self.running = False
        self.loop_interval = 1.0 # Varsayılan döngü hızı (saniye)

    async def start(self):
        self.running = True
        logger.info(f"Node Başlatıldı: {self.name}")
        asyncio.create_task(self._lifecycle())

    async def stop(self):
        self.running = False
        logger.info(f"Node Durduruldu: {self.name}")

    async def _lifecycle(self):
        await self.setup()
        while self.running:
            await self.loop()
            await asyncio.sleep(self.loop_interval)
        await self.teardown()

    async def setup(self):
        """Node başlatılırken çalışır (Override edilebilir)"""
        pass

    async def loop(self):
        """Sürekli döngü (Override edilebilir)"""
        pass

    async def teardown(self):
        """Node kapatılırken çalışır (Override edilebilir)"""
        pass

class RobotSystem:
    """
    Tüm sistemi yöneten Orkestratör.
    """
    def __init__(self):
        self.bus = MessageBus()
        self.nodes: List[RobotNode] = []

    def register_node(self, node: RobotNode):
        self.nodes.append(node)

    async def start_all(self):
        logger.info("WinOS Robot Sistemi Başlatılıyor...")
        for node in self.nodes:
            await node.start()

    async def stop_all(self):
        logger.info("Sistem Kapatılıyor...")
        for node in self.nodes:
            await node.stop()
