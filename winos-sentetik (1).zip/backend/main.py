
import time
import asyncio
import json
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .models import SystemStatus, RobotCommand, OperationResponse
from .core.robot_system import RobotSystem
from .nodes.telemetry_node import TelemetryNode
from .nodes.serial_node import SerialNode
from .nodes.protocol_node import ProtocolNode
from .nodes.control_node import ControlNode
from .nodes.lidar_node import LidarNode
from .nodes.camera_node import CameraNode
from .nodes.slam_node import SlamNode
from .nodes.navigation_node import NavigationNode
from .nodes.power_node import PowerNode
from .nodes.face_node import FaceNode
from .nodes.head_node import HeadNode

# --- Robot System Initialization ---
# NOT: ROS (Robot Operating System) kullanılmamaktadır.
# Python asyncio tabanlı özel "RobotSystem" mimarisi aktiftir.
robot = RobotSystem()

# Düğümleri Başlatma Sırası
# 1. Serial Node: Donanım arayüzü (Okuma/Yazma)
serial_node = SerialNode(robot.bus)
robot.register_node(serial_node)

# 2. Control Node: Kinematik hesaplama ve motor kontrolü
control_node = ControlNode(robot.bus)
robot.register_node(control_node)

# 3. Protocol Node: Veri çözümleme
protocol_node = ProtocolNode(robot.bus)
robot.register_node(protocol_node)

# 4. Lidar Node: Haritalama ve nokta bulutu işleme
lidar_node = LidarNode(robot.bus)
robot.register_node(lidar_node)

# 5. Slam Node: Grid Haritalama (Phase 29)
slam_node = SlamNode(robot.bus)
robot.register_node(slam_node)

# 6. Navigation Node: Yol Planlama (Phase 30)
nav_node = NavigationNode(robot.bus)
robot.register_node(nav_node)

# 7. Camera Node: Görüntü işleme ve akış
camera_node = CameraNode(robot.bus)
robot.register_node(camera_node)

# 8. Power Node: Güç Yönetimi ve Analizi (Phase 32)
power_node = PowerNode(robot.bus)
robot.register_node(power_node)

# 9. Face Node: Yüz İfadeleri ve Duygu Dışavurumu (Phase 33)
face_node = FaceNode(robot.bus)
robot.register_node(face_node)

# 10. Head Node: Servo Kafa Kontrolü (Phase 34)
head_node = HeadNode(robot.bus)
robot.register_node(head_node)

# 11. Telemetry Node: Veri birleştirme ve sunum
telemetry_node = TelemetryNode(robot.bus)
robot.register_node(telemetry_node)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Uygulama başlarken robot sistemini başlat
    await robot.start_all()
    yield
    # Uygulama kapanırken temizle
    await robot.stop_all()

app = FastAPI(
    title="WinOS Hybrid Backend",
    description="Robot Control System API for RPi 5 (Custom Core - No ROS)",
    version="1.6.0",
    lifespan=lifespan
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

START_TIME = time.time()

# --- WebSocket Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except:
                pass 

manager = ConnectionManager()

# Robot'tan gelen telemetriyi WebSocket'e bas
async def forward_telemetry_to_ws(data):
    await manager.broadcast(json.dumps(data))

robot.bus.subscribe("telemetry", forward_telemetry_to_ws)

# Lidar tarama verisini bas
async def forward_lidar_to_ws(data):
    msg = {"type": "lidar_scan", **data}
    await manager.broadcast(json.dumps(msg))

robot.bus.subscribe("lidar_scan", forward_lidar_to_ws)

# Map verisini bas (SLAM)
async def forward_map_to_ws(data):
    msg = {"type": "map_data", **data}
    await manager.broadcast(json.dumps(msg))

robot.bus.subscribe("map_data", forward_map_to_ws)

# Navigation Path verisini bas (Phase 30)
async def forward_path_to_ws(data):
    msg = {"type": "navigation_path", **data}
    await manager.broadcast(json.dumps(msg))

robot.bus.subscribe("navigation_path", forward_path_to_ws)

# Kamera görüntüsünü bas
async def forward_camera_to_ws(base64_frame):
    # Görüntü verisi büyük olduğu için JSON parse maliyetini azaltmak adına
    # doğrudan JSON stringi oluşturuyoruz
    msg = f'{{"type": "camera_frame", "data": "{base64_frame}"}}'
    await manager.broadcast(msg)

robot.bus.subscribe("camera_frame", forward_camera_to_ws)

# Frontend'den gelen duygu güncellemelerini FaceNode'a ilet
async def handle_frontend_emotion(data):
    await robot.bus.publish("emotion_state", data)

@app.get("/")
async def root():
    return {"message": "WinOS Hybrid Robotics Core Online (Custom Architecture)"}

@app.get("/health", response_model=SystemStatus)
async def health_check():
    current_time = time.time()
    uptime = int(current_time - START_TIME)
    return SystemStatus(
        status="nominal",
        uptime=uptime,
        cpu_usage=10.0,
        memory_usage=30.0,
        disk_usage=45.0,
        temperature=40.0
    )

@app.post("/command", response_model=OperationResponse)
async def execute_command(cmd: RobotCommand):
    """
    REST üzerinden gelen komutları 'user_input' kanalına basar.
    ControlNode bu komutları işler.
    """
    payload = {"action": cmd.command}
    if cmd.parameters:
        payload.update(cmd.parameters)

    await robot.bus.publish("user_input", payload)
    
    return OperationResponse(
        success=True,
        message=f"Command '{cmd.command}' dispatched to control node.",
        data={"timestamp": time.time()}
    )

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            try:
                msg = json.loads(data)
                
                # Standart komutlar
                if "command" in msg or "action" in msg:
                    await robot.bus.publish("user_input", msg)
                
                # Duygu durumu senkronizasyonu (Frontend -> Backend)
                elif msg.get("type") == "emotion_sync":
                    await handle_frontend_emotion(msg.get("payload"))

            except json.JSONDecodeError:
                pass
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"WS Error: {e}")
        manager.disconnect(websocket)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
