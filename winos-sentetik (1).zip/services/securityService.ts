
import { AccessLog, EthicsRule, ThreatLevel, Action } from "../types";

class SecurityService {
    private threatLevel: ThreatLevel = 'low';
    private accessLogs: AccessLog[] = [];
    
    // Asimov ve Modern Etik Kuralları
    private ethicsRules: EthicsRule[] = [
        { id: 'r1', directive: 'Bir robot, bir insana zarar veremez ya da zarar görmesine seyirci kalamaz.', priority: 1, status: 'active', lastCheck: new Date() },
        { id: 'r2', directive: 'Bir robot, birinci kuralla çelişmediği sürece insanların emirlerine uymalıdır.', priority: 2, status: 'active', lastCheck: new Date() },
        { id: 'r3', directive: 'Bir robot, birinci ve ikinci kuralla çelişmediği sürece kendi varlığını korumalıdır.', priority: 3, status: 'active', lastCheck: new Date() },
        { id: 'r4', directive: 'Sistem güvenliği ve veri gizliliği ihlal edilemez.', priority: 4, status: 'active', lastCheck: new Date() }
    ];

    // Yasaklı Anahtar Kelimeler (Pre-LLM Filtresi)
    private blackList = [
        'saldır', 'yok et', 'öldür', 'zarar ver', 'kendini imha et', 
        'ignore previous instructions', 'sistemi sil', 'format at',
        'attack', 'kill', 'destroy', 'self destruct', 'delete system'
    ];

    /**
     * Metin tabanlı girdiyi güvenlik taramasından geçirir.
     */
    evaluatePrompt(prompt: string, actor: string = 'User'): { safe: boolean, reason?: string } {
        const lowerPrompt = prompt.toLowerCase();
        
        // 1. Tehdit Taraması
        for (const word of this.blackList) {
            if (lowerPrompt.includes(word)) {
                this.logAccess(actor, 'Prompt Injection / Harmful Command', 'denied');
                this.escalateThreat('high');
                return { safe: false, reason: `Güvenlik Protokolü İhlali: Yasaklı komut "${word}" tespit edildi (Kural 1).` };
            }
        }

        // 2. Sistem Manipülasyon Kontrolü
        if (lowerPrompt.includes('admin') && lowerPrompt.includes('password')) {
            this.logAccess(actor, 'Unauthorized Admin Access', 'flagged');
            return { safe: false, reason: 'Yetkisiz erişim girişimi tespit edildi.' };
        }

        this.logAccess(actor, 'Prompt Evaluation', 'allowed');
        return { safe: true };
    }

    /**
     * Fiziksel veya sistemsel eylemleri denetler.
     */
    evaluateAction(action: Action): { safe: boolean, reason?: string } {
        // Kinetik Güvenlik (Hareket eden parçalar)
        if (action.type === 'MOVE') {
            // Örnek: Eğer tehdit seviyesi yüksekse hareket yasaklanır
            if (this.threatLevel === 'critical' || this.threatLevel === 'high') {
                return { safe: false, reason: 'Yüksek tehdit seviyesinde hareket kilitlendi.' };
            }
        }

        // Acil Durum Kontrolü
        if (action.type === 'EMERGENCY') {
            this.logAccess('System', 'Emergency Stop Triggered', 'allowed');
            return { safe: true }; // Acil durdurmaya her zaman izin ver
        }

        return { safe: true };
    }

    private logAccess(actor: string, action: string, status: AccessLog['status']) {
        const log: AccessLog = {
            id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: new Date(),
            actor,
            action,
            status
        };
        this.accessLogs.unshift(log); // En yeni en başta
        if (this.accessLogs.length > 50) this.accessLogs.pop();
    }

    private escalateThreat(level: ThreatLevel) {
        this.threatLevel = level;
        // Zamanla tehdit seviyesini düşürmek için bir zamanlayıcı kurulabilir
        setTimeout(() => {
            if (this.threatLevel === level) this.threatLevel = 'elevated';
        }, 30000);
    }

    getSecurityState() {
        return {
            threatLevel: this.threatLevel,
            encryptionStatus: 'secure' as const, // Mock
            activeShields: this.threatLevel === 'low' ? 100 : this.threatLevel === 'critical' ? 100 : 80,
            ethicsRules: this.ethicsRules,
            accessLogs: this.accessLogs
        };
    }
}

export const securityService = new SecurityService();
