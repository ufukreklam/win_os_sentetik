
export interface VectorDocument {
    id: string;
    content: string;
    embedding: number[];
    metadata: Record<string, any>;
    score?: number; // Similarity score
}

class VectorStore {
    private documents: VectorDocument[] = [];

    constructor() {
        this.loadFromStorage();
    }

    private loadFromStorage() {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('winos_vector_store');
            if (saved) {
                try {
                    this.documents = JSON.parse(saved);
                } catch (e) {
                    console.error("Vector Store Load Failed", e);
                }
            }
        }
    }

    private saveToStorage() {
        if (typeof window !== 'undefined') {
            // In a real app, this should be IndexedDB, localStorage has limits
            try {
                localStorage.setItem('winos_vector_store', JSON.stringify(this.documents));
            } catch (e) {
                console.error("Vector Store Save Failed (Quota Exceeded?)", e);
            }
        }
    }

    // Cosine Similarity
    private similarity(a: number[], b: number[]): number {
        let dotProduct = 0;
        let normA = 0;
        let normB = 0;
        for (let i = 0; i < a.length; i++) {
            dotProduct += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    async addDocument(doc: Omit<VectorDocument, 'score'>): Promise<void> {
        // Remove existing if id matches
        this.documents = this.documents.filter(d => d.id !== doc.id);
        this.documents.push(doc as VectorDocument);
        this.saveToStorage();
    }

    async search(queryEmbedding: number[], topK: number = 3): Promise<VectorDocument[]> {
        if (this.documents.length === 0) return [];

        const scoredDocs = this.documents.map(doc => ({
            ...doc,
            score: this.similarity(queryEmbedding, doc.embedding)
        }));

        // Sort by score descending
        scoredDocs.sort((a, b) => (b.score || 0) - (a.score || 0));

        return scoredDocs.slice(0, topK);
    }

    getStats() {
        return {
            count: this.documents.length,
            memoryUsage: JSON.stringify(this.documents).length
        };
    }

    clear() {
        this.documents = [];
        this.saveToStorage();
    }
}

export const vectorStore = new VectorStore();
