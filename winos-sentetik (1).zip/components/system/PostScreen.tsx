
import React, { useEffect, useState } from 'react';
import { useOS } from '../../context/OSContext';

const PostScreen: React.FC = () => {
  const { setBootState, hardwareConfig } = useOS();
  const [lines, setLines] = useState<string[]>([]);
  
  useEffect(() => {
    const sequence = [
      { text: "WinOS Hybrid BIOS v1.15.0 Hardware Bridge", delay: 100 },
      { text: "Copyright (C) 2024 WinOS Technologies, Inc.", delay: 200 },
      { text: `CPU: Broadcom BCM2712 @ 2.4GHz`, delay: 400 },
      { text: `Memory Test: ${hardwareConfig.ramSize} OK`, delay: 800 },
      { text: `Primary Master: NVMe PCIe 512GB`, delay: 1000 },
      { text: `Detecting USB Devices... Done.`, delay: 1400 },
      { text: `System UUID: ${hardwareConfig.uuid}`, delay: 1600 },
      { text: " ", delay: 1700 },
      { text: "Press DEL to enter Setup", delay: 1800 },
    ];

    let timeouts: number[] = [];
    
    // Line printing sequence
    sequence.forEach(({ text, delay }) => {
      const t = window.setTimeout(() => {
        setLines(prev => [...prev, text]);
      }, delay);
      timeouts.push(t);
    });

    // Auto-boot sequence
    const bootTimeout = window.setTimeout(() => {
      setBootState('os');
    }, hardwareConfig.fastBoot ? 2000 : 3500);
    timeouts.push(bootTimeout);

    // Key listener
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' || e.key === 'F2') {
        e.preventDefault();
        // Clear auto-boot timer
        timeouts.forEach(clearTimeout);
        setLines(prev => [...prev, "Entering Setup..."]);
        setTimeout(() => setBootState('bios'), 800);
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      timeouts.forEach(clearTimeout);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [setBootState, hardwareConfig]);

  return (
    <div className="fixed inset-0 bg-black text-white font-mono p-8 text-lg z-[9999] cursor-none select-none">
      <div className="flex flex-col items-start gap-1">
        {/* Energy Star Logo Simulation */}
        <div className="absolute top-4 right-4 border-2 border-white p-2 text-xs w-24 h-20 flex flex-col items-center justify-center opacity-80">
           <span className="font-bold text-xl italic">energy</span>
           <span className="mt-1">STAR</span>
        </div>

        {lines.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
        <div className="animate-pulse">_</div>
      </div>
      
      <div className="absolute bottom-4 left-4 text-xs text-gray-500">
        00-11-22-33-44-55-66-WinOS-Hybrid
      </div>
    </div>
  );
};

export default PostScreen;
