
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { ArrowRight, User, Users } from 'lucide-react';
import { format } from 'date-fns';

const LockScreen: React.FC = () => {
  const { users, login, setLocked, playSound, wallpaper, timeOffset } = useOS();
  const [currentTime, setCurrentTime] = useState(new Date(Date.now() + timeOffset));
  const [showLogin, setShowLogin] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  
  // Select the first user by default
  const [selectedUserId, setSelectedUserId] = useState(users[0]?.id);
  const selectedUser = users.find(u => u.id === selectedUserId) || users[0];

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date(Date.now() + timeOffset)), 1000);
    return () => clearInterval(timer);
  }, [timeOffset]);

  const handleInteraction = () => {
    if (!showLogin) {
      setShowLogin(true);
      playSound('click');
    }
  };

  const handleLogin = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!selectedUser) return;

    const success = login(selectedUser.id, password);
    
    if (success) {
        playSound('startup');
        setPassword('');
    } else {
        playSound('error');
        setError(true);
        setPassword('');
        setTimeout(() => setError(false), 2000);
    }
  };

  const handleUserSwitch = (userId: string) => {
      setSelectedUserId(userId);
      setPassword('');
      setError(false);
      // Optional: change background to that user's wallpaper preference if we had access to it directly here
  };

  // Determine background. If multiple users, ideally we'd show selected user's wallpaper.
  // For now, we use the context's current wallpaper which defaults to DEFAULT or last logged in.
  const bgImage = selectedUser?.wallpaper || wallpaper;

  return (
    <div 
      className="fixed inset-0 z-[1000] bg-cover bg-center bg-no-repeat overflow-hidden transition-all duration-700 select-none"
      style={{ backgroundImage: `url(${bgImage})` }}
      onClick={handleInteraction}
      onKeyDown={(e) => {
          if (!showLogin && e.key !== 'F12') {
             setShowLogin(true);
             playSound('click');
          }
      }}
      tabIndex={0}
    >
      {/* Overlay */}
      <div className={`absolute inset-0 bg-black/20 transition-all duration-500 ${showLogin ? 'backdrop-blur-xl bg-black/50' : ''}`} />

      {/* Clock Content (Slides up when logging in) */}
      <div 
        className={`
            absolute top-[15%] w-full flex flex-col items-center text-white text-shadow-lg transition-all duration-700 ease-in-out
            ${showLogin ? '-translate-y-full opacity-0' : 'translate-y-0 opacity-100'}
        `}
      >
        <div className="text-8xl md:text-9xl font-semibold tracking-tighter">
            {format(currentTime, 'h:mm')}
        </div>
        <div className="text-xl md:text-2xl font-medium mt-2">
            {format(currentTime, 'EEEE, MMMM d')}
        </div>
      </div>

      {/* Login Form (Slides up from bottom) */}
      <div 
        className={`
            absolute inset-0 flex flex-col items-center justify-center transition-all duration-500 ease-out
            ${showLogin ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20 pointer-events-none'}
        `}
      >
        <div 
            className="flex flex-col items-center gap-6 p-8 rounded-2xl"
            onClick={(e) => e.stopPropagation()} 
        >
            {/* User Avatar */}
            <div className="w-32 h-32 rounded-full bg-slate-200 shadow-2xl flex items-center justify-center relative overflow-hidden group border-4 border-white/10">
               <div className={`w-full h-full ${selectedUser?.avatarColor || 'bg-blue-600'} flex items-center justify-center`}>
                    <User size={64} className="text-white/80" />
               </div>
            </div>

            <div className="text-2xl font-semibold text-white tracking-wide">{selectedUser?.username}</div>

            {/* Password Input */}
            <form onSubmit={handleLogin} className="flex flex-col gap-2 w-full max-w-xs relative">
                <div className="relative group">
                    <input 
                        type="password" 
                        placeholder={selectedUser?.pin ? "PIN" : "No PIN required"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className={`
                            w-full bg-black/30 border-2 rounded-lg py-2.5 px-4 text-white placeholder-white/50 
                            outline-none backdrop-blur-sm transition-all
                            ${error ? 'border-red-500 shake-animation' : 'border-transparent focus:border-white/30 hover:bg-black/40'}
                        `}
                        autoFocus={showLogin}
                    />
                    <button 
                        type="submit"
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-white/10 hover:bg-white/20 rounded-md transition-colors text-white"
                    >
                        <ArrowRight size={18} />
                    </button>
                </div>
                {error && (
                    <div className="text-center text-sm text-red-300 font-medium animate-in fade-in slide-in-from-top-1">
                        Incorrect PIN. Try 1234.
                    </div>
                )}
                
                <div className="text-center text-xs text-white/60 mt-4 cursor-pointer hover:text-white transition-colors">
                    I forgot my PIN
                </div>
            </form>

            {/* User Switcher */}
            {users.length > 1 && (
                <div className="flex gap-4 mt-8">
                    {users.map(u => (
                        <button
                            key={u.id}
                            onClick={() => handleUserSwitch(u.id)}
                            className={`
                                flex flex-col items-center gap-2 transition-all opacity-70 hover:opacity-100
                                ${selectedUserId === u.id ? 'opacity-100 scale-110 font-bold' : ''}
                            `}
                        >
                            <div className={`w-10 h-10 rounded-full ${u.avatarColor} flex items-center justify-center border-2 border-white/20`}>
                                <User size={16} className="text-white" />
                            </div>
                            <span className="text-xs text-white">{u.username}</span>
                        </button>
                    ))}
                </div>
            )}
        </div>
      </div>

      {/* Bottom Hint */}
      {!showLogin && (
        <div className="absolute bottom-10 w-full text-center text-white/80 text-sm animate-pulse">
            Click or Press Key to Unlock
        </div>
      )}
    </div>
  );
};

export default LockScreen;
