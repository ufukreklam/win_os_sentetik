
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { ShieldCheck, ShieldAlert, Lock, Unlock, Eye, FileText, Activity, AlertTriangle, CheckCircle } from 'lucide-react';
import { EthicsRule, AccessLog } from '../../types';

const SecurityApp: React.FC = () => {
  const { securityState } = useOS();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'ethics' | 'privacy'>('dashboard');

  const getThreatColor = (level: string) => {
      switch (level) {
          case 'low': return 'text-green-400';
          case 'elevated': return 'text-yellow-400';
          case 'high': return 'text-orange-500';
          case 'critical': return 'text-red-500 animate-pulse';
          default: return 'text-slate-400';
      }
  };

  const getStatusIcon = (status: string) => {
      switch (status) {
          case 'active': return <CheckCircle size={16} className="text-green-400" />;
          case 'evaluating': return <Activity size={16} className="text-blue-400 animate-pulse" />;
          case 'override': return <AlertTriangle size={16} className="text-yellow-400" />;
          default: return null;
      }
  };

  const getAccessColor = (status: string) => {
      switch (status) {
          case 'allowed': return 'text-green-400';
          case 'denied': return 'text-red-400';
          case 'flagged': return 'text-yellow-400';
          default: return 'text-slate-400';
      }
  };

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('dashboard')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'dashboard' ? 'bg-green-600/20 text-green-400 border-l-2 border-green-500' : 'text-slate-400'}`}
            >
                <ShieldCheck size={20} />
                <span className="hidden md:inline text-sm font-medium">Dashboard</span>
            </button>
            <button 
                onClick={() => setActiveTab('ethics')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'ethics' ? 'bg-blue-600/20 text-blue-400 border-l-2 border-blue-500' : 'text-slate-400'}`}
            >
                <ScaleIcon size={20} />
                <span className="hidden md:inline text-sm font-medium">Ethics Core</span>
            </button>
            <button 
                onClick={() => setActiveTab('privacy')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'privacy' ? 'bg-purple-600/20 text-purple-400 border-l-2 border-purple-500' : 'text-slate-400'}`}
            >
                <Lock size={20} />
                <span className="hidden md:inline text-sm font-medium">Privacy Vault</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'dashboard' && (
                <div className="flex-1 p-6 overflow-y-auto space-y-6">
                    {/* Header Status */}
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1 bg-white/5 border border-white/5 rounded-xl p-6 flex flex-col items-center justify-center relative overflow-hidden">
                            <div className={`absolute inset-0 bg-gradient-to-br from-transparent to-${getThreatColor(securityState.threatLevel).split('-')[1]}/10 opacity-20`} />
                            <ShieldAlert size={48} className={getThreatColor(securityState.threatLevel)} />
                            <div className="mt-4 text-center">
                                <h2 className="text-2xl font-bold uppercase tracking-widest">{securityState.threatLevel}</h2>
                                <p className="text-xs text-slate-400">Current Threat Level</p>
                            </div>
                        </div>
                        <div className="flex-1 bg-white/5 border border-white/5 rounded-xl p-6 flex flex-col justify-between">
                            <div>
                                <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-widest mb-2">Active Shields</h3>
                                <div className="text-4xl font-light text-green-400">{securityState.activeShields}%</div>
                            </div>
                            <div className="w-full h-2 bg-slate-800 rounded-full mt-4 overflow-hidden">
                                <div className="h-full bg-green-500 transition-all duration-500" style={{ width: `${securityState.activeShields}%` }} />
                            </div>
                        </div>
                    </div>

                    {/* Encryption Status */}
                    <div className="bg-slate-800/50 border border-white/5 rounded-xl p-6 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <div className={`p-3 rounded-full ${securityState.encryptionStatus === 'secure' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                {securityState.encryptionStatus === 'secure' ? <Lock size={24} /> : <Unlock size={24} />}
                            </div>
                            <div>
                                <h3 className="font-bold text-lg">System Encryption</h3>
                                <p className="text-sm text-slate-400">
                                    {securityState.encryptionStatus === 'secure' ? 'AES-256 Active. Data is protected.' : 'Encryption Vulnerable.'}
                                </p>
                            </div>
                        </div>
                        <div className="text-xs font-mono bg-black/40 px-3 py-1 rounded text-slate-500">
                            ID: SYS-SEC-001
                        </div>
                    </div>

                    {/* Recent Alerts (Mock) */}
                    <div>
                        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-widest mb-3">Security Alerts</h3>
                        <div className="space-y-2">
                            {securityState.accessLogs.filter(l => l.status === 'denied' || l.status === 'flagged').slice(0, 3).map(log => (
                                <div key={log.id} className="bg-red-500/10 border border-red-500/20 p-3 rounded-lg flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <AlertTriangle size={16} className="text-red-400" />
                                        <span className="text-sm text-red-200">{log.action} blocked from {log.actor}</span>
                                    </div>
                                    <span className="text-xs text-red-400/70 font-mono">{log.timestamp.toLocaleTimeString()}</span>
                                </div>
                            ))}
                            {securityState.accessLogs.filter(l => l.status === 'denied' || l.status === 'flagged').length === 0 && (
                                <div className="text-center text-slate-500 py-4 text-sm italic">No recent alerts.</div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'ethics' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="mb-6">
                        <h2 className="text-2xl font-light mb-1">Ethical Directives</h2>
                        <p className="text-sm text-slate-400">Core behavioral constraints and decision boundaries.</p>
                    </div>

                    <div className="space-y-4">
                        {securityState.ethicsRules.sort((a, b) => a.priority - b.priority).map(rule => (
                            <div key={rule.id} className="bg-white/5 border border-white/5 rounded-xl p-4 flex items-center gap-4 hover:bg-white/10 transition-colors">
                                <div className="text-2xl font-bold text-slate-600 w-8 text-center">{rule.priority}</div>
                                <div className="flex-1">
                                    <div className="font-medium text-lg">{rule.directive}</div>
                                    <div className="text-xs text-slate-500 font-mono mt-1">Last Checked: {rule.lastCheck.toLocaleTimeString()}</div>
                                </div>
                                <div className="flex items-center gap-2 bg-black/20 px-3 py-1.5 rounded-full border border-white/5">
                                    {getStatusIcon(rule.status)}
                                    <span className="text-xs uppercase font-bold tracking-wider text-slate-300">{rule.status}</span>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="mt-8 bg-blue-900/20 border border-blue-500/20 rounded-xl p-6">
                        <h3 className="font-bold text-blue-400 mb-2 flex items-center gap-2"><Eye size={18} /> Compliance Monitor</h3>
                        <p className="text-sm text-slate-300 leading-relaxed">
                            The ethics module continuously evaluates proposed actions against the active directive set. 
                            Actions with a high probability of violating Priority 1 rules are automatically pre-empted at the kernel level.
                        </p>
                    </div>
                </div>
            )}

            {activeTab === 'privacy' && (
                <div className="flex-1 p-6 overflow-y-auto flex flex-col">
                    <h2 className="text-2xl font-light mb-6">Access Logs & Privacy</h2>
                    
                    <div className="flex-1 bg-black/40 border border-white/10 rounded-xl overflow-hidden flex flex-col font-mono text-xs">
                        <div className="bg-white/5 p-3 flex justify-between text-slate-400 font-bold border-b border-white/5">
                            <span className="w-24">Time</span>
                            <span className="flex-1">Actor</span>
                            <span className="flex-1">Action</span>
                            <span className="w-20 text-right">Status</span>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2 space-y-1">
                            {securityState.accessLogs.map(log => (
                                <div key={log.id} className="flex justify-between p-2 hover:bg-white/5 rounded transition-colors">
                                    <span className="w-24 text-slate-500">{log.timestamp.toLocaleTimeString()}</span>
                                    <span className="flex-1 text-slate-300">{log.actor}</span>
                                    <span className="flex-1 text-slate-400">{log.action}</span>
                                    <span className={`w-20 text-right font-bold uppercase ${getAccessColor(log.status)}`}>
                                        {log.status}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

// Helper Icon for Ethics Tab (Scale)
const ScaleIcon = ({ size, className }: { size: number, className?: string }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} 
        height={size} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        className={className}
    >
        <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/>
        <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/>
        <path d="M7 21h10"/>
        <path d="M12 3v18"/>
        <path d="M3 7h2v2"/>
        <path d="M19 7h2v2"/>
    </svg>
);

export default SecurityApp;
