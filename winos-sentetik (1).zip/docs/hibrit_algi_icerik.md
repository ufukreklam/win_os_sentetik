# 👁️ Hibrit Algı ve Sensör Sistemi Dashboard Talimatları

## 📋 Sayfa Yapısı ve İçerik Gereksinimleri

### **1. ANA HEADER BÖLÜMÜ**
- Sistem başlığı: "Hibrit Algı ve Sensör Sistemi"
- Canlı algı durumu göstergesi (active/processing/idle/error)
- Toplam aktif sensör sayısı
- Genel sistem sağlık skoru (0-100)
- Gerçek zamanlı latans göstergesi (ms)

---

### **2. GENEL DURUM KARTLARI (5 Kart)**

#### Kart 1: Görsel Algı Performansı
- Nesne tespit sayısı (son 1 saat)
- Tespit doğruluğu (%)
- Frame işleme hızı (FPS)
- Aktif kamera sayısı

#### Kart 2: İşitsel İşleme
- Ses tanıma doğruluğu (%)
- İşlenen ses süresi (dakika)
- Aktif mikrofon sayısı
- Duygu tespit başarısı (%)

#### Kart 3: Multimodal Füzyon
- Füzyon doğruluğu (%)
- Cross-modal senkronizasyon skoru
- Temporal alignment latansı (ms)
- Çözülen çelişki sayısı

#### Kart 4: Desen Tanıma
- Tanınan pattern sayısı
- Anomali tespit sayısı
- Pattern matching doğruluğu (%)
- Zamansal analiz başarısı

#### Kart 5: Reality Model
- 3D harita güncellik durumu
- Takip edilen nesne sayısı
- Fizik simülasyonu doğruluğu
- Tahmin başarı oranı (%)

---

### **3. GÖRSEL ALGI MOTORu PANELİ**

#### Visual Perception Core Metrikleri
- **Object Detection**
  - Son 1 saatte tespit edilen nesneler (grafik)
  - Nesne kategorileri dağılımı (pie chart)
  - Tespit güven skoru ortalaması
  - Real-time tespit hızı

- **Scene Analysis**
  - Analiz edilen sahne sayısı
  - Sahne karmaşıklık skoru (0-10)
  - Bağlam çıkarım başarısı (%)
  - İşlem süresi ortalaması (ms)

- **Depth Estimation**
  - Derinlik haritası kalitesi
  - 3D uzamsal doğruluk (%)
  - İşlenen frame sayısı
  - Depth estimation latansı

- **Motion Tracking**
  - Takip edilen hareketli nesne sayısı
  - Tracking accuracy (%)
  - Hareket vektörü sayısı
  - Kayıp tracking oranı (%)

#### Advanced Visual Features
- **Face Recognition**: Tanınan yüz sayısı, accuracy
- **Emotion Analysis**: Tespit edilen ifadeler, güven skoru
- **OCR Performance**: Okunan metin miktarı, doğruluk
- **Visual Memory**: Kaydedilen görsel deneyim sayısı

---

### **4. İŞİTSEL İŞLEME SİSTEMİ PANELİ**

#### Audio Processing Core
- **Speech Recognition**
  - Transcribe edilen ses süresi (dakika)
  - Tanıma doğruluğu (%)
  - Desteklenen dil sayısı
  - WER (Word Error Rate) skoru

- **Sound Classification**
  - Sınıflandırılan ses türleri (müzik, gürültü, doğa vs.)
  - Sınıflandırma güven skoru
  - İşlenen ses segmenti sayısı
  - Gerçek zamanlı sınıflandırma hızı

- **Emotional Tone Analysis**
  - Tespit edilen duygusal tonlar dağılımı
  - Duygu tespit doğruluğu
  - Analiz edilen konuşma sayısı
  - Ortalama duygu yoğunluğu skoru

- **Spatial Audio Processing**
  - Lokalize edilen ses kaynağı sayısı
  - Lokalizasyon doğruluğu (derece)
  - 3D ses haritası güncellik durumu
  - Ses kaynak takip başarısı

#### Advanced Audio Features
- **Source Separation**: Ayrıştırılan ses kaynağı sayısı
- **Music Analysis**: Tespit edilen tempo, ritim, melodi
- **Noise Cancellation**: Gürültü azaltma oranı (dB)

---

### **5. MULTIMODAL FÜZYON PANELİ**

#### Fusion Metrics
- **Temporal Alignment**
  - Senkronize edilen modalite çifti sayısı
  - Ortalama alignment latansı (ms)
  - Sync başarı oranı (%)
  - Temporal drift miktarı

- **Cross-Modal Attention**
  - Attention weight dağılımı (grafik)
  - Modalite önem skorları
  - Adaptive attention karar sayısı
  - Attention switch sıklığı

- **Confidence Estimation**
  - Her modalite için güven skorları
  - Genel füzyon güveni (%)
  - Düşük güven uyarısı sayısı
  - Confidence threshold violations

- **Conflict Resolution**
  - Çözülen çelişki sayısı
  - Modalite anlaşmazlık oranı
  - Resolution stratejisi dağılımı
  - Çözülemeyen çelişki sayısı

#### Cross-Modal Learning Stats
- Öğrenilen cross-modal pattern sayısı
- Transfer learning başarısı
- Bir modaliteden diğerine tahmin doğruluğu

---

### **6. DESEN TANIMA MOTORU PANELİ**

#### Pattern Recognition Core

**Spatial Patterns**
- Tespit edilen uzamsal desen sayısı
- Pattern matching doğruluğu
- Geometrik pattern kategorileri
- Yeni pattern öğrenme hızı

**Temporal Patterns**
- Zamansal desen sayısı
- Trend analizi başarısı
- Sequence prediction accuracy
- Pattern tekrar sıklığı

**Behavioral Patterns**
- Davranış kalıbı sayısı
- Davranış tahmin doğruluğu
- Anormal davranış tespiti
- Pattern evolution tracking

**Contextual Patterns**
- Bağlamsal desen sayısı
- Context switch tespiti
- Bağlam uyumluluk skoru
- Context prediction accuracy

#### Anomaly Detection
- **Real-time Anomalies**
  - Son 1 saatte tespit edilen anomali sayısı
  - Anomali türleri dağılımı
  - False positive oranı
  - Anomali şiddet skoru (0-10)

---

### **7. SENSÖR ENTEGRASYON KATMANI PANELİ**

#### Sensor Registry
| Sensör Tipi | Durum | Sayı | Son Kalibrasyon | Sağlık Skoru |
|-------------|-------|------|-----------------|--------------|
| RGB Camera | Active | 4 | 2h ago | 98% |
| Depth Camera | Active | 2 | 1d ago | 95% |
| Microphone Array | Active | 6 | 3h ago | 100% |
| ... | ... | ... | ... | ... |

#### Sensor Health Monitoring
- **Her sensör için ayrı kart:**
  - Sensör ID ve tipi
  - Durum (healthy/warning/critical)
  - Veri kalitesi skoru
  - Calibration durumu
  - Son hata zamanı
  - Data rate (Hz)
  - Latency (ms)

#### Supported Sensor Types Stats
- **Cameras**: RGB (x), IR (x), Depth (x), Thermal (x)
- **Microphones**: Mono (x), Stereo (x), Array (x)
- **IMU**: Accelerometer (x), Gyroscope (x), Magnetometer (x)
- **Environmental**: Temp (x), Humidity (x), Pressure (x), Light (x)
- **Proximity**: LiDAR (x), Radar (x), Ultrasonic (x)
- **Biometric**: Heart Rate (x), Skin Conductance (x)

#### Data Normalization Stats
- İşlenen ham veri miktarı (MB/s)
- Normalize edilen veri oranı
- Normalizasyon başarı oranı
- Outlier tespit ve filtreleme sayısı

---

### **8. GERÇEKLİK MODELLEME SİSTEMİ PANELİ**

#### 3D Spatial Mapping
- **SLAM Status**
  - Harita boyutu (m³)
  - Harita güvenilirliği (%)
  - Son güncelleme zamanı
  - Mapping hızı (m³/s)
  - Loop closure sayısı

- **Environment Map Visualization**
  - 3D harita önizlemesi (WebGL/Three.js)
  - Haritalanan alan gösterimi
  - Keşfedilmemiş alanlar
  - Harita çözünürlüğü

#### Object Persistence Tracking
- **Tracked Objects Table**
  | Object ID | Type | Last Seen | Track Duration | Confidence |
  |-----------|------|-----------|----------------|------------|
  | OBJ-001 | Person | 2s ago | 45s | 98% |
  | ... | ... | ... | ... | ... |

- **Tracking Metrics**
  - Toplam takip edilen nesne sayısı
  - Ortalama tracking süresi
  - Kayıp nesne sayısı
  - Re-identification başarısı

#### Physics Simulation
- **Physics Engine Stats**
  - Simüle edilen nesne sayısı
  - Fizik günceleme hızı (Hz)
  - Collision detection sayısı
  - Fizik doğruluk skoru

- **Simulation Metrics**
  - Gravity hesaplama sayısı
  - Momentum tracking
  - Force calculation count
  - Constraint satisfaction rate

#### Predictive Modeling
- **Environmental Predictions**
  - Aktif tahmin sayısı
  - Tahmin doğruluğu (%)
  - Tahmin horizonu (saniye)
  - Confidence level dağılımı

- **Prediction Types**
  - Object trajectory predictions
  - Scene change predictions
  - Interaction predictions
  - Event predictions

---

### **9. HAFIZA ENTEGRASYONU PANELİ**

#### Perceptual Memory Interface
- **Episodic Memory Storage**
  - Kaydedilen algısal deneyim sayısı
  - Bellek kullanımı (GB)
  - Ortalama kayıt süresi (ms)
  - Episodic memory retention rate

- **Semantic Knowledge Extraction**
  - Çıkarılan semantik bilgi sayısı
  - Knowledge graph boyutu
  - Semantic update sıklığı
  - Knowledge consolidation başarısı

- **Memory Recall Performance**
  - Recall query sayısı
  - Ortalama retrieval süresi (ms)
  - Similarity matching accuracy
  - False memory rate

#### Visual Memory Stats
- Kaydedilen görsel deneyim sayısı
- Visual embedding boyutu
- Benzerlik araması performansı
- Visual memory compression oranı

---

### **10. BİLİNÇ SİSTEMİ ENTEGRASYONU PANELİ**

#### Conscious Perception Interface
- **Attention Management**
  - Aktif dikkat odağı sayısı
  - Attention switch sıklığı (per min)
  - Focus duration ortalaması (s)
  - Distraction event sayısı

- **Global Workspace Broadcast**
  - Broadcast edilen algı sayısı
  - Workspace kapasitesi kullanımı (%)
  - Integration latency (ms)
  - Conscious access rate

#### Awareness Integration
- Bilinçli farkındalık seviyesi (0-10)
- Attention-perception alignment skoru
- Conscious processing load (%)
- Metacognitive monitoring aktifliği

---

### **11. PERFORMANS OPTİMİZASYONU PANELİ**

#### Real-Time Processing Metrics
- **Latency Monitoring**
  - Genel sistem latansı (ms) - Line chart
  - Modalite bazlı latans dağılımı
  - P50, P95, P99 latency değerleri
  - Latency SLA compliance (%)

- **Throughput Stats**
  - İşlenen veri miktarı (MB/s)
  - Frame/sample processing rate
  - Queue depth monitoring
  - Dropped data percentage

#### Resource Utilization
- **Compute Resources**
  - CPU kullanımı (%) - per core grafik
  - GPU kullanımı (%) - per device
  - Memory usage (GB) - breakdown by module
  - Network bandwidth (Mbps)

- **Load Balancing**
  - Task distribution balance skoru
  - Worker utilization (%)
  - Queue wait time (ms)
  - Load rebalancing event sayısı

#### Adaptive Quality Control
- **Quality Settings**
  - Current quality level (low/medium/high/ultra)
  - Adaptive adjustment sayısı
  - Quality-performance trade-off skoru
  - Manual override durumu

- **Quality Metrics by Module**
  - Visual processing quality
  - Audio processing quality
  - Fusion quality
  - Overall output quality

---

### **12. GÜVENLİK VE GİZLİLİK PANELİ**

#### Security Status
- **Data Protection**
  - Şifrelenen veri oranı (%)
  - Encryption latency overhead (ms)
  - Privacy filter aktif durumu
  - Sensitive data detection count

- **Security Threats**
  - Tespit edilen anomali sayısı
  - Security alert sayısı (critical/warning/info)
  - Blocked attempt sayısı
  - Security posture skoru (0-100)

#### Privacy Preservation
- **Privacy Filters**
  - Aktif filter sayısı
  - Filtrelenen veri miktarı (%)
  - PII detection count
  - Anonymization başarı oranı

---

### **13. PERFORMANS GRAFİKLERİ (4 Ana Grafik)**

#### Grafik 1: Çoklu Modalite Performans Trendi
- Son 24 saat, her modalite için işlem sayısı ve doğruluk
- Line chart (multi-line)
- X: Zaman, Y: İşlem sayısı/Doğruluk

#### Grafik 2: Latans Dağılımı Heatmap
- Her modül için son 1 saatlik latans dağılımı
- Heatmap visualization
- Renk kodlu performans göstergesi

#### Grafik 3: Sensör Sağlık Durumu
- Tüm sensörlerin sağlık skoru zaman serisi
- Area chart
- Threshold çizgileri ile

#### Grafik 4: Pattern Detection Timeline
- Tespit edilen pattern türlerinin zaman içinde dağılımı
- Stacked bar chart
- Her pattern türü farklı renk

---

### **14. CANLI ALGI AKIŞI İZLEME**

#### Live Perception Stream
- **Real-time Preview Panel**
  - Son görsel frame önizlemesi
  - Son ses dalga formu
  - Aktif algı overlay'leri (bounding box, labels)
  - Refresh rate: 5 FPS

#### Recent Detections (Tablo - Son 50 kayıt)
| Timestamp | Modalite | Tip | Nesne/Ses | Güven | Latans |
|-----------|----------|-----|-----------|-------|--------|
| 13:45:32 | Visual | Object | Person | 98% | 45ms |
| 13:45:31 | Audio | Speech | "Hello" | 95% | 67ms |
| ... | ... | ... | ... | ... | ... |

---

### **15. UYARI VE BİLDİRİMLER**

#### Alert System
- **Critical Alerts** (Kırmızı)
  - Sensör arızaları
  - Sistem hataları
  - Güvenlik tehditleri

- **Warnings** (Sarı)
  - Performans düşüşleri
  - Kalite degradation
  - Resource constraints

- **Info** (Mavi)
  - Başarılı kalibrasyonlar
  - Sistem güncellemeleri
  - Normal operasyon bildirimleri

#### Alert History (Liste)
- Timestamp
- Severity level
- Module/Sensor affected
- Alert message
- Status (active/resolved/acknowledged)
- Resolution time

---

### **16. ROADMAP İLERLEME PANELİ**

#### Development Phases (4 Faz)

**Her faz için ayrı kart:**
- **Faz adı ve süresi**
- **Progress bar** (tamamlanma yüzdesi)
- **Completed tasks / Total tasks**
- **Key deliverables listesi** (checkbox)
- **Status indicator**: On Track / At Risk / Delayed / Completed
- **Estimated completion date**
- **Actual completion date** (varsa)

#### Current Sprint Info
- Aktif görevler
- Tamamlanan görevler (bu sprint)
- Sprint velocity
- Remaining work estimate

---

### **17. BAŞARI KRİTERLERİ DASHBOARD**

#### Performance Indicators
- **Algı Latansı**: Mevcut vs Hedef (<100ms)
  - Progress bar ve trend
- **Doğruluk Oranı**: Mevcut vs Hedef (>95%)
  - Gauge chart
- **Multimodal Fusion Accuracy**: Mevcut vs Hedef (>90%)
  - Percentage indicator
- **Memory Integration Speed**: Mevcut vs Hedef (<50ms)
  - Line chart with threshold
- **Adaptive Response Time**: Mevcut vs Hedef (<200ms)
  - Real-time monitoring

#### Quality Indicators
- Cross-Modal Consistency Score
- Robustness Score (noisy environments)
- Scalability Score
- Energy Efficiency Rating

---

### **18. SİSTEM KOMPONENTLERİ HARITASI**

#### Architecture Visualization
- Tüm modüllerin görsel haritası
- Modül arası veri akışı gösterimi
- Gerçek zamanlı aktivite göstergesi
- Tıklanabilir modül kartları (detay modal açar)

---

## 🔌 API Endpoints ve Veri Yolları

### **Genel Sistem Durumu**
```
GET /api/perception/system/status
Response: {
  status: "active" | "processing" | "idle" | "error",
  healthScore: number,
  activeSensors: number,
  latency: number,
  uptime: number
}
```

### **Genel Durum Metrikleri**
```
GET /api/perception/metrics/visual
Response: {
  objectDetectionCount: number,
  detectionAccuracy: number,
  processingFPS: number,
  activeCameras: number
}

GET /api/perception/metrics/audio
Response: {
  recognitionAccuracy: number,
  processedDuration: number,
  activeMicrophones: number,
  emotionDetectionSuccess: number
}

GET /api/perception/metrics/multimodal
Response: {
  fusionAccuracy: number,
  syncScore: number,
  alignmentLatency: number,
  resolvedConflicts: number
}

GET /api/perception/metrics/pattern
Response: {
  recognizedPatterns: number,
  anomalyCount: number,
  matchingAccuracy: number,
  temporalAnalysisSuccess: number
}

GET /api/perception/metrics/reality
Response: {
  mapUpdateStatus: string,
  trackedObjects: number,
  physicsAccuracy: number,
  predictionSuccess: number
}
```

### **Görsel Algı Motoru**
```
GET /api/perception/visual/object-detection
Response: {
  recentDetections: [{ timestamp, objects[], confidence }],
  categoryDistribution: { [category: string]: number },
  avgConfidence: number,
  detectionRate: number
}

GET /api/perception/visual/scene-analysis
Response: {
  analyzedScenes: number,
  complexityScore: number,
  contextSuccess: number,
  avgProcessingTime: number
}

GET /api/perception/visual/depth-estimation
Response: {
  mapQuality: number,
  spatialAccuracy: number,
  processedFrames: number,
  latency: number
}

GET /api/perception/visual/motion-tracking
Response: {
  trackedObjects: number,
  trackingAccuracy: number,
  motionVectors: number,
  lostTrackingRate: number
}

GET /api/perception/visual/advanced-features
Response: {
  faceRecognition: { count, accuracy },
  emotionAnalysis: { detections, confidence },
  ocrPerformance: { textAmount, accuracy },
  visualMemory: { storedExperiences }
}
```

### **İşitsel İşleme Sistemi**
```
GET /api/perception/audio/speech-recognition
Response: {
  transcribedDuration: number,
  accuracy: number,
  supportedLanguages: number,
  werScore: number
}

GET /api/perception/audio/sound-classification
Response: {
  classifications: { [type: string]: number },
  confidence: number,
  segmentCount: number,
  classificationRate: number
}

GET /api/perception/audio/emotion-analysis
Response: {
  emotionDistribution: { [emotion: string]: number },
  detectionAccuracy: number,
  analyzedSpeech: number,
  avgIntensity: number
}

GET /api/perception/audio/spatial-processing
Response: {
  localizedSources: number,
  localizationAccuracy: number,
  mapUpdateStatus: string,
  trackingSuccess: number
}

GET /api/perception/audio/advanced-features
Response: {
  sourceSeparation: { count },
  musicAnalysis: { tempo, rhythm, melody },
  noiseCancellation: { reductionDB }
}
```

### **Multimodal Füzyon**
```
GET /api/perception/fusion/temporal-alignment
Response: {
  syncedPairs: number,
  avgLatency: number,
  syncSuccess: number,
  temporalDrift: number
}

GET /api/perception/fusion/attention
Response: {
  attentionWeights: { [modality: string]: number },
  importanceScores: { [modality: string]: number },
  decisionCount: number,
  switchFrequency: number
}

GET /api/perception/fusion/confidence
Response: {
  modalityConfidence: { [modality: string]: number },
  overallConfidence: number,
  lowConfidenceAlerts: number,
  thresholdViolations: number
}

GET /api/perception/fusion/conflict-resolution
Response: {
  resolvedConflicts: number,
  disagreementRate: number,
  strategyDistribution: { [strategy: string]: number },
  unresolvedConflicts: number
}

GET /api/perception/fusion/cross-modal-learning
Response: {
  learnedPatterns: number,
  transferSuccess: number,
  crossModalAccuracy: number
}
```

### **Desen Tanıma Motoru**
```
GET /api/perception/pattern/spatial
Response: {
  detectedPatterns: number,
  matchingAccuracy: number,
  categories: string[],
  learningRate: number
}

GET /api/perception/pattern/temporal
Response: {
  temporalPatterns: number,
  trendAnalysis: number,
  sequencePrediction: number,
  repeatFrequency: number
}

GET /api/perception/pattern/behavioral
Response: {
  behaviorPatterns: number,
  predictionAccuracy: number,
  abnormalDetections: number,
  evolutionTracking: number
}

GET /api/perception/pattern/contextual
Response: {
  contextualPatterns: number,
  switchDetections: number,
  compatibilityScore: number,
  predictionAccuracy: number
}

GET /api/perception/pattern/anomaly-detection
Response: {
  recentAnomalies: [{ timestamp, type, severity }],
  typeDistribution: { [type: string]: number },
  falsePositiveRate: number,
  severityScore: number
}
```

### **Sensör Entegrasyon Katmanı**
```
GET /api/perception/sensors/registry
Response: {
  sensors: [{
    id: string,
    type: string,
    status: "healthy" | "warning" | "critical",
    count: number,
    lastCalibration: timestamp,
    healthScore: number
  }]
}

GET /api/perception/sensors/health/{sensorId}
Response: {
  sensorId: string,
  type: string,
  status: string,
  dataQuality: number,
  calibrationStatus: string,
  lastError: timestamp,
  dataRate: number,
  latency: number
}

GET /api/perception/sensors/types
Response: {
  cameras: { rgb, ir, depth, thermal },
  microphones: { mono, stereo, array },
  imu: { accelerometer, gyroscope, magnetometer },
  environmental: { temp, humidity, pressure, light },
  proximity: { lidar, radar, ultrasonic },
  biometric: { heartRate, skinConductance }
}

GET /api/perception/sensors/normalization-stats
Response: {
  rawDataRate: number,
  normalizedRate: number,
  successRate: number,
  outlierCount: number
}
```

### **Gerçeklik Modelleme Sistemi**
```
GET /api/perception/reality/slam-status
Response: {
  mapSize: number,
  reliability: number,
  lastUpdate: timestamp,
  mappingRate: number,
  loopClosures: number
}

GET /api/perception/reality/map-data
Response: {
  mapPreview: string (base64 or URL),
  mappedArea: number,
  unexploredAreas: number,
  resolution: number
}

GET /api/perception/reality/object-tracking
Response: {
  trackedObjects: [{
    id: string,
    type: string,
    lastSeen: timestamp,
    trackDuration: number,
    confidence: number
  }],
  totalTracked: number,
  avgDuration: number,
  lostObjects: number,
  reidentificationSuccess: number
}

GET /api/perception/reality/physics-simulation
Response: {
  simulatedObjects: number,
  updateRate: number,
  collisionDetections: number,
  accuracyScore: number,
  gravityCalculations: number,
  constraintSatisfaction: number
}

GET /api/perception/reality/predictions
Response: {
  activePredictions: number,
  accuracy: number,
  predictionHorizon: number,
  confidenceDistribution: { [level: string]: number },
  predictionTypes: {
    trajectory: number,
    sceneChange: number,
    interaction: number,
    event: number
  }
}
```

### **Hafıza Entegrasyonu**
```
GET /api/perception/memory/episodic
Response: {
  storedExperiences: number,
  memoryUsage: number,
  avgRecordTime: number,
  retentionRate: number
}

GET /api/perception/memory/semantic
Response: {
  extractedKnowledge: number,
  knowledgeGraphSize: number,
  updateFrequency: number,
  consolidationSuccess: number
}

GET /api/perception/memory/recall
Response: {
  recallQueries: number,
  avgRetrievalTime: number,
  similarityAccuracy: number,
  falseMemoryRate: number
}

GET /api/perception/memory/visual-memory
Response: {
  storedVisuals: number,
  embeddingSize: number,
  searchPerformance: number,
  compressionRatio: number
}
```

### **Bilinç Sistemi Entegrasyonu**
```
GET /api/perception/consciousness/attention
Response: {
  activeFocusCount: number,
  switchFrequency: number,
  avgFocusDuration: number,
  distractionEvents: number
}

GET /api/perception/consciousness/global-workspace
Response: {
  broadcastCount: number,
  capacityUsage: number,
  integrationLatency: number,
  consciousAccessRate: number
}

GET /api/perception/consciousness/awareness
Response: {
  awarenessLevel: number,
  alignmentScore: number,
  processingLoad: number,
  metacognitiveActivity: number
}
```

### **Performans Optimizasyonu**
```
GET /api/perception/performance/latency
Response: {
  overallLatency: number,
  modalityLatency: { [modality: string]: number },
  percentiles: { p50, p95, p99 },
  slaCompliance: number
}

GET /api/perception/performance/throughput
Response: {
  dataRate: number,
  processingRate: number,
  queueDepth: number,
  droppedDataPercentage: number
}

GET /api/perception/performance/resources
Response: {
  cpu: { usage: number, perCore: number[] },
  gpu: { usage: number, perDevice: number[] },
  memory: { used: number, breakdown: {} },
  network: { bandwidth: number }
}

GET /api/perception/performance/load-balancing
Response: {
  balanceScore: number,
  workerUtilization: number,
  queueWaitTime: number,
  rebalancingEvents: number
}

GET /api/perception/performance/adaptive-quality
Response: {
  currentLevel: "low" | "medium" | "high" | "ultra",
  adjustmentCount: number,
  tradeoffScore: number,
  manualOverride: boolean,
  qualityByModule: { [module: string]: number }
}
```

### **Güvenlik ve Gizlilik**
```
GET /api/perception/security/status
Response: {
  encryptedDataRate: number,
  encryptionOverhead: number,
  privacyFilterActive: boolean,
  sensitiveDataDetections: number
}

GET /api/perception/security/threats
Response: {
  anomalyCount: number,
  alerts: [{ severity, timestamp, message }],
  blockedAttempts: number,
  securityPosture: number
}

GET /api/perception/security/privacy
Response: {
  activeFilters: number,
  filteredDataPercentage: number,
  piiDetections: number,
  anonymizationSuccess: number
}
```

### **Performans Graf