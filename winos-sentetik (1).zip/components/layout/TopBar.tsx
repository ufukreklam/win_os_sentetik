
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { CloudSun, Droplets, Mic, MicOff } from 'lucide-react';

const TopBar: React.FC = () => {
  const { 
    voiceState, 
    lastVoiceText, 
    perceptionState, 
    emotionState,
    startListening,
    stopListening,
    sensorReadings,
    voiceEnergy, // Real energy from VAD
    isHandsFree,
    toggleHandsFree
  } = useOS();

  const [eyePos, setEyePos] = useState({ x: 0, y: 0 });
  const [blink, setBlink] = useState(false);

  // --- Eye Tracking Logic ---
  useEffect(() => {
    // Göz kırpma döngüsü
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 200);
    }, 4000 + Math.random() * 2000);

    // Göz hareketi (Algı durumu varsa oraya bak, yoksa rastgele/fare)
    const moveEyes = (e?: MouseEvent) => {
        if (perceptionState.visualAttention) {
            // Algısal odak varsa (Yapay Zeka bir şeye odaklanmışsa)
            setEyePos({ 
                x: (perceptionState.visualAttention.x - 0.5) * 16, 
                y: (perceptionState.visualAttention.y - 0.5) * 16 
            });
        } else if (e) {
            // Fare takibi - Gözler büyüdüğü için hareket alanı genişletildi
            const x = (e.clientX / window.innerWidth - 0.5) * 18;
            const y = (e.clientY / window.innerHeight - 0.5) * 18;
            setEyePos({ x, y });
        } else {
            // Rastgele hareket (Idle)
            if (Math.random() > 0.95) {
                setEyePos({ 
                    x: (Math.random() - 0.5) * 14, 
                    y: (Math.random() - 0.5) * 8 
                });
            }
        }
    };

    window.addEventListener('mousemove', moveEyes);
    const idleInterval = setInterval(() => moveEyes(), 1000);

    return () => {
        clearInterval(blinkInterval);
        clearInterval(idleInterval);
        window.removeEventListener('mousemove', moveEyes);
    };
  }, [perceptionState.visualAttention]);

  // --- Spectrum Bars Render ---
  const renderSpectrum = () => {
      const bars = 12;
      const isListening = voiceState === 'listening';
      const isSpeaking = voiceState === 'speaking' || voiceState === 'processing';
      const isActive = isListening || isSpeaking || isHandsFree;
      
      // Use real energy if available, otherwise simulate
      const getBarHeight = () => {
          if (voiceEnergy > 0) return Math.min(100, Math.max(20, voiceEnergy * Math.random() * 2));
          return Math.random() * 80 + 20;
      };

      const colorClass = isListening ? 'bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.8)]' : 
                         isSpeaking ? 'bg-green-400 shadow-[0_0_10px_rgba(74,222,128,0.8)]' : 
                         isHandsFree ? 'bg-red-400/50' : // Hands-free idle color
                         'bg-slate-600';

      return (
          <div className="flex items-center justify-center gap-[2px] h-6">
              {Array.from({ length: bars }).map((_, i) => (
                  <div 
                    key={i}
                    className={`w-1 rounded-full transition-all duration-75 ${colorClass}`}
                    style={{
                        height: isActive ? `${getBarHeight()}%` : '20%',
                        // Only animate if we don't have real energy or if speaking (output energy)
                        animation: (isActive && voiceEnergy === 0) ? `pulse 0.${5 + i%3}s infinite` : 'none'
                    }}
                  />
              ))}
          </div>
      );
  };

  const handleInteraction = () => {
      if (voiceState === 'listening') stopListening();
      else startListening();
  };

  return (
    <div className="h-12 w-full fixed top-0 left-0 z-[9999] flex items-center justify-between px-4 bg-slate-950/90 backdrop-blur-md border-b border-white/10 text-white shadow-lg select-none">
        
        {/* LEFT: VISION (EYES & CAMERA) */}
        <div className="flex items-center gap-4 w-1/4">
            <div className="relative group cursor-pointer" title="Vision System">
                <div className="flex gap-2 p-1">
                    {/* Left Eye */}
                    <div className={`relative w-10 h-8 bg-white rounded-full overflow-hidden transition-all duration-100 shadow-[0_0_15px_rgba(255,255,255,0.3)] ${blink ? 'scale-y-0' : 'scale-y-100'}`}>
                        <div 
                            className="absolute w-3 h-3 bg-black rounded-full top-1/2 left-1/2 transition-transform duration-100 ease-out"
                            style={{ transform: `translate(-50%, -50%) translate(${eyePos.x}px, ${eyePos.y}px)` }}
                        />
                    </div>
                    {/* Right Eye */}
                    <div className={`relative w-10 h-8 bg-white rounded-full overflow-hidden transition-all duration-100 shadow-[0_0_15px_rgba(255,255,255,0.3)] ${blink ? 'scale-y-0' : 'scale-y-100'}`}>
                        <div 
                            className="absolute w-3 h-3 bg-black rounded-full top-1/2 left-1/2 transition-transform duration-100 ease-out"
                            style={{ transform: `translate(-50%, -50%) translate(${eyePos.x}px, ${eyePos.y}px)` }}
                        />
                    </div>
                </div>
                {/* Camera Active Dot */}
                <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_5px_red]" />
            </div>
            
            {/* Hands-Free Toggle */}
            <button 
                onClick={toggleHandsFree}
                className={`p-1.5 rounded-full transition-all ${isHandsFree ? 'bg-red-500/20 text-red-400 border border-red-500/50' : 'hover:bg-white/10 text-slate-400'}`}
                title="Hands-Free Mode (Always Listening)"
            >
                {isHandsFree ? <Mic size={14} /> : <MicOff size={14} />}
            </button>
        </div>

        {/* CENTER: VOICE SPECTRUM */}
        <div 
            className="flex-1 flex flex-col items-center justify-center cursor-pointer group"
            onClick={handleInteraction}
        >
            {renderSpectrum()}
        </div>

        {/* RIGHT: TEXT LOG & WEATHER */}
        <div className="flex items-center justify-end gap-4 w-1/4">
            {/* Live Text Log */}
            <div className="flex-1 text-right overflow-hidden hidden sm:block">
                <div className="text-xs font-mono text-cyan-400 truncate max-w-[200px] md:max-w-[300px] opacity-90">
                    {lastVoiceText ? `> ${lastVoiceText}` : '> ...'}
                </div>
            </div>

            {/* Weather Widget (Sensor Based) */}
            <div className="flex items-center gap-3 pl-3 border-l border-white/10 text-slate-400">
                <div className="flex flex-col items-end">
                    <div className="flex items-center gap-2 text-white">
                        <span className="text-sm font-bold">{sensorReadings.env.temp.toFixed(1)}°C</span>
                        <CloudSun size={20} className="text-yellow-400" />
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-500">
                        <Droplets size={10} />
                        <span>%{sensorReadings.env.humidity.toFixed(0)}</span>
                        <span className="mx-1">•</span>
                        <span>Açık</span>
                    </div>
                </div>
            </div>
        </div>

        {/* Emotion Tint Overlay (Subtle) */}
        <div className={`absolute inset-0 pointer-events-none opacity-10 transition-colors duration-1000 z-[-1]
            ${emotionState.primary === 'angry' ? 'bg-red-500' : 
              emotionState.primary === 'happy' ? 'bg-yellow-500' : 
              emotionState.primary === 'fear' ? 'bg-purple-500' : 'bg-transparent'}
        `} />
    </div>
  );
};

export default TopBar;
