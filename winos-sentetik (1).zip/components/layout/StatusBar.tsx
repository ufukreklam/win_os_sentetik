import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Grip, Volume2, Wifi, WifiOff, Battery, Bell, Cloud, CloudOff, RefreshCw, Smile, Zap, Activity, Mic, Download } from 'lucide-react';
import QuickSettings from './QuickSettings';
import CalendarWidget from './CalendarWidget';
import NotificationCenter from './NotificationCenter';
import { AppID, WindowState } from '../../types';

const StatusBar: React.FC = () => {
  const { windows, openApp, toggleStartMenu, isStartMenuOpen, notifications, timeOffset, syncStatus, isCloudEnabled, emotionState, startListening, stopListening, voiceState, isOnline, canInstallPWA, installPWA } = useOS();
  const [showQuickSettings, setShowQuickSettings] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date(Date.now() + timeOffset));
  
  const quickSettingsRef = useRef<HTMLDivElement>(null);
  const calendarRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  // Filter for apps that are currently open
  const taskbarApps = (Object.values(windows) as WindowState[]).filter(app => app.isOpen);

  // Clock Ticker (Synced with System Time Offset)
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date(Date.now() + timeOffset));
    }, 1000); 
    return () => clearInterval(timer);
  }, [timeOffset]);

  // Close Popups when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;

      // Handle Quick Settings Outside Click
      if (quickSettingsRef.current && !quickSettingsRef.current.contains(target)) {
        setShowQuickSettings(false);
      }
      
      // Handle Calendar Outside Click
      if (calendarRef.current && !calendarRef.current.contains(target)) {
        setShowCalendar(false);
      }

      // Handle Notification Center Outside Click
      if (notificationRef.current && !notificationRef.current.contains(target)) {
        setShowNotifications(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getEmotionIcon = () => {
      switch(emotionState.primary) {
          case 'happy': return <Smile size={16} className="text-yellow-400" />;
          case 'angry': return <Zap size={16} className="text-red-400" />;
          case 'fear': return <Activity size={16} className="text-purple-400" />;
          default: return null; 
      }
  };

  return (
    <>
      <div 
        className="h-12 w-full fixed bottom-0 left-0 z-50 flex items-center justify-between px-2 md:px-4 bg-white/40 dark:bg-black/40 backdrop-blur-xl border-t border-white/20 shadow-2xl"
        role="navigation"
        aria-label="Taskbar"
      >
        
        {/* Left: App Dock */}
        <div className="flex-1 flex items-center justify-start gap-1 md:gap-2 overflow-x-auto no-scrollbar mask-linear-fade-right">
          {/* Start Button */}
          <button
            onClick={toggleStartMenu}
            className={`p-2 rounded-md transition-all duration-200 group mr-1 md:mr-2 active:scale-90 shrink-0 ${
              isStartMenuOpen ? 'bg-white/20' : 'hover:bg-white/10'
            }`}
            aria-label="Start Menu"
            aria-expanded={isStartMenuOpen}
          >
            <Grip 
              size={24} 
              className={`text-blue-400 group-hover:text-blue-300 transition-colors ${isStartMenuOpen ? 'text-blue-300' : ''}`} 
            />
          </button>

          {/* Global Mic Trigger */}
          <button
            onClick={voiceState === 'listening' ? stopListening : startListening}
            className={`p-2 rounded-md transition-all duration-200 group active:scale-90 shrink-0 ${
              voiceState === 'listening' ? 'bg-red-500/20 text-red-400' : 'hover:bg-white/10 text-slate-300'
            }`}
            title="Voice Command"
          >
             <Mic size={20} className={voiceState === 'listening' ? 'animate-pulse' : ''} />
          </button>

          {/* PWA Install Button (Only if available) */}
          {canInstallPWA && (
              <button
                onClick={installPWA}
                className="hidden md:flex p-2 rounded-md hover:bg-white/10 text-slate-300 active:scale-90 shrink-0 items-center gap-2"
                title="Install App"
              >
                  <Download size={18} />
                  <span className="text-xs font-bold">Install</span>
              </button>
          )}

          {/* Separator - Hide on Mobile if no apps */}
          {taskbarApps.length > 0 && (
            <div className="h-6 w-[1px] bg-white/20 mx-1 shrink-0 hidden md:block" />
          )}

          {/* Running Apps (Only Open Ones) */}
          <div className="flex gap-1 overflow-x-auto no-scrollbar">
            {taskbarApps.map((app) => (
                <button
                key={app.id}
                onClick={() => openApp(app.id)}
                className={`
                    relative p-2 rounded-md transition-all duration-200 shrink-0
                    hover:bg-white/10 active:scale-95 flex flex-col items-center justify-center
                    ${app.isOpen ? 'bg-white/5' : ''}
                `}
                title={app.title}
                aria-label={`Switch to ${app.title}`}
                >
                <app.icon 
                    size={22} 
                    className={app.isOpen ? 'text-blue-400' : 'text-slate-200'} 
                />
                {app.isOpen && (
                    <div className="absolute -bottom-1 w-1.5 h-1.5 bg-blue-400 rounded-full" />
                )}
                {app.isOpen && !app.isMinimized && (
                    <div className="absolute -bottom-1 w-3 h-0.5 bg-blue-400/50 rounded-full blur-[1px]" />
                )}
                </button>
            ))}
          </div>
        </div>

        {/* Right: System Tray */}
        <div className="flex items-center justify-end gap-1 md:gap-2 shrink-0 pl-2">
          
          {/* Emotion Indicator (Only if not neutral) */}
          {emotionState.primary !== 'neutral' && (
              <button 
                onClick={() => openApp(AppID.MIND)}
                className="p-1.5 hover:bg-white/10 rounded-full transition-colors animate-in fade-in hidden sm:block"
                title={`Current Mood: ${emotionState.primary}`}
              >
                  {getEmotionIcon()}
              </button>
          )}

          {/* Cloud Sync Status - Hide on Mobile */}
          {isCloudEnabled && (
             <div className="flex items-center px-1 hidden sm:flex" title={`Cloud Sync: ${syncStatus}`}>
                {syncStatus === 'syncing' ? (
                    <RefreshCw size={16} className="text-blue-400 animate-spin" />
                ) : syncStatus === 'error' ? (
                    <CloudOff size={16} className="text-red-400" />
                ) : (
                    <Cloud size={16} className="text-white" />
                )}
             </div>
          )}

          {/* Quick Settings Trigger */}
          <div ref={quickSettingsRef}>
            <button 
                onClick={() => setShowQuickSettings(!showQuickSettings)}
                className={`
                flex items-center gap-2 px-2 py-1.5 rounded-md transition-all duration-200 active:scale-95
                ${showQuickSettings ? 'bg-white/20' : 'hover:bg-white/10'}
                `}
                aria-label="Quick Settings"
                aria-expanded={showQuickSettings}
            >
                {isOnline ? <Wifi size={16} className="text-white" /> : <WifiOff size={16} className="text-red-400 animate-pulse" />}
                <div className="hidden sm:block"><Volume2 size={16} className="text-white" /></div>
                <Battery size={16} className="text-white" />
            </button>
          </div>
          
          {/* Clock / Calendar Trigger */}
          <div ref={calendarRef}>
             <button 
               onClick={() => setShowCalendar(!showCalendar)}
               className={`
                  flex flex-col items-end justify-center text-white select-none px-2 py-0.5 rounded-md transition-all duration-200 active:scale-95
                  ${showCalendar ? 'bg-white/20' : 'hover:bg-white/10'}
               `}
               aria-label={`Clock: ${currentTime.toLocaleTimeString()}`}
               aria-expanded={showCalendar}
             >
                <span className="text-xs font-medium leading-none">
                  {currentTime.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
                </span>
                <span className="text-[10px] opacity-70 leading-none mt-0.5 hidden sm:block">
                  {currentTime.toLocaleDateString()}
                </span>
             </button>
          </div>

          {/* Notification Trigger - Hide text log on mobile */}
          <div ref={notificationRef}>
             <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className={`
                    relative p-2 rounded-md transition-all duration-200 active:scale-95
                    ${showNotifications ? 'bg-white/20' : 'hover:bg-white/10'}
                `}
                aria-label="Notifications"
                aria-expanded={showNotifications}
             >
                 <Bell size={18} className="text-white" />
                 {notifications.length > 0 && (
                     <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-slate-900" />
                 )}
             </button>
          </div>
        </div>
      </div>

      {/* Quick Settings Flyout */}
      <QuickSettings isOpen={showQuickSettings} onClose={() => setShowQuickSettings(false)} />
      
      {/* Calendar Flyout */}
      <CalendarWidget isOpen={showCalendar} onClose={() => setShowCalendar(false)} />

      {/* Notification Center */}
      <NotificationCenter isOpen={showNotifications} onClose={() => setShowNotifications(false)} />
    </>
  );
};

export default StatusBar;