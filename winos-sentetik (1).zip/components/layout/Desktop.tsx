
import React, { useState, useEffect, useRef } from 'react';
import Window from '../ui/Window';
import { useOS } from '../../context/OSContext';
import { AppID, FileSystemItem } from '../../types';
import { APP_REGISTRY } from '../apps/registry';
import { APP_CONFIGS } from '../../constants';
import { AppErrorBoundary } from '../system/AppErrorBoundary';
import { RefreshCw, Monitor, Settings, FolderPlus, Terminal, ChevronRight, FileText, Trash2, Folder, File, Code, Image, Music, Video } from 'lucide-react';

const Desktop: React.FC = () => {
  const { openApp, snapPreview, readdir, mkdir, writeFile, deleteItem, isMovingWindow } = useOS();
  const [contextMenu, setContextMenu] = useState<{ show: boolean; x: number; y: number } | null>(null);
  const desktopRef = useRef<HTMLDivElement>(null);

  // Fetch Desktop Items from FS
  const desktopItems = readdir('/home/user/Desktop');

  // Handle Right Click
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    // Adjust position to prevent menu going off-screen (basic logic)
    const x = e.pageX;
    const y = e.pageY;
    setContextMenu({ show: true, x, y });
  };

  // Close menu on left click
  const handleClick = () => {
    if (contextMenu) setContextMenu(null);
  };

  // Close menu when clicking outside (global listener for safety)
  useEffect(() => {
    const handleGlobalClick = () => setContextMenu(null);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [contextMenu]);

  const handleRefresh = () => {
    setContextMenu(null);
  };

  const handlePersonalize = () => {
    openApp(AppID.SETTINGS);
    setContextMenu(null);
  };

  const handleNewFolder = () => {
    const name = `New Folder ${Math.floor(Math.random() * 100)}`;
    mkdir('/home/user/Desktop', name);
    setContextMenu(null);
  };

  const handleNewTextFile = () => {
    const name = `New Text Document ${Math.floor(Math.random() * 100)}.txt`;
    writeFile('/home/user/Desktop', {
        name,
        type: 'file',
        fileType: 'text',
        size: '0 B',
        permissions: '-rw-r--r--',
        content: ''
    });
    setContextMenu(null);
  };

  const handleItemDoubleClick = (item: FileSystemItem) => {
     if (item.type === 'folder') {
         openApp(AppID.FILES);
     } else if (item.name.endsWith('.app')) {
         // Handle App Shortcut
         const appId = item.content as AppID;
         if (appId && APP_CONFIGS[appId]) {
             openApp(appId);
         }
     } else if (item.fileType === 'code' || item.name.endsWith('.js') || item.name.endsWith('.sh') || item.name.endsWith('.code')) {
         openApp(AppID.CODE_EDITOR);
     } else if (item.fileType === 'text') {
         openApp(AppID.NOTEPAD);
     } else if (item.name.endsWith('.sh')) {
         openApp(AppID.TERMINAL);
     } else if (item.fileType === 'image') {
         openApp(AppID.PHOTOS);
     } else if (item.fileType === 'music' || item.fileType === 'video') {
         openApp(AppID.MEDIA);
     }
  };

  const handleDeleteItem = (e: React.MouseEvent, name: string) => {
      e.stopPropagation();
      if (confirm(`Delete ${name}?`)) {
          deleteItem('/home/user/Desktop', name);
      }
  };

  const getIcon = (item: FileSystemItem) => {
      if (item.type === 'folder') return <Folder className="text-blue-400 fill-blue-400/20 drop-shadow-md" size={32} />;
      
      // Handle App Shortcut Icon
      if (item.name.endsWith('.app')) {
          const appId = item.content as AppID;
          const config = APP_CONFIGS[appId];
          if (config) {
              return <config.icon className="text-cyan-400 drop-shadow-md" size={32} />;
          }
      }

      if (item.fileType === 'code') return <Code className="text-green-400 drop-shadow-md" size={32} />;
      if (item.fileType === 'image') return <Image className="text-purple-400 drop-shadow-md" size={32} />;
      if (item.fileType === 'music') return <Music className="text-pink-400 drop-shadow-md" size={32} />;
      if (item.fileType === 'video') return <Video className="text-red-400 drop-shadow-md" size={32} />;
      return <FileText className="text-slate-200 drop-shadow-md" size={32} />;
  };

  return (
    <div 
      ref={desktopRef}
      className="flex-1 relative overflow-hidden mt-12 mb-12 z-0 h-full"
      onContextMenu={handleContextMenu}
      onClick={handleClick}
    >
      {/* Global Drag Overlay: Prevents iframes from capturing mouse events during drag */}
      {isMovingWindow && (
        <div className="fixed inset-0 z-[10000] cursor-move bg-transparent" />
      )}

      {/* Snap Preview Overlay */}
      {snapPreview && (
        <div 
          className="absolute bg-white/10 backdrop-blur-md border-2 border-white/20 rounded-xl transition-all duration-200 z-10 pointer-events-none"
          style={{
            left: snapPreview.x,
            top: snapPreview.y,
            width: snapPreview.width,
            height: snapPreview.height,
          }}
        />
      )}

      {/* Desktop Icons Grid */}
      <div className="absolute top-4 left-4 flex flex-col gap-4 p-2 flex-wrap h-[calc(100%-60px)] content-start">
        {/* Static Shortcuts */}
        <div 
            className="group flex flex-col items-center gap-1 w-20 cursor-pointer mb-2" 
            onDoubleClick={() => openApp(AppID.FILES)}
        >
            <div className="w-12 h-12 bg-blue-500/20 backdrop-blur-sm border border-blue-400/30 rounded-lg flex items-center justify-center group-hover:bg-blue-500/40 transition-colors shadow-sm">
                <span className="text-2xl drop-shadow-md">📁</span>
            </div>
            <span className="text-xs text-white font-medium drop-shadow-md bg-black/20 px-2 rounded-full py-0.5 border border-white/5 text-center line-clamp-2">My PC</span>
        </div>
        
        <div 
            className="group flex flex-col items-center gap-1 w-20 cursor-pointer mb-2" 
            onDoubleClick={() => openApp(AppID.TERMINAL)}
        >
            <div className="w-12 h-12 bg-slate-900/60 backdrop-blur-sm border border-slate-500/30 rounded-lg flex items-center justify-center group-hover:bg-slate-800/80 transition-colors shadow-sm">
                 <Terminal className="text-green-400 drop-shadow-md" size={24} />
            </div>
            <span className="text-xs text-white font-medium drop-shadow-md bg-black/20 px-2 rounded-full py-0.5 border border-white/5 text-center line-clamp-2">Terminal</span>
        </div>

        <div className="group flex flex-col items-center gap-1 w-20 cursor-pointer mb-2">
            <div className="w-12 h-12 bg-green-500/20 backdrop-blur-sm border border-green-400/30 rounded-lg flex items-center justify-center group-hover:bg-green-500/40 transition-colors shadow-sm">
                 <span className="text-2xl drop-shadow-md">🗑️</span>
            </div>
            <span className="text-xs text-white font-medium drop-shadow-md bg-black/20 px-2 rounded-full py-0.5 border border-white/5 text-center line-clamp-2">Recycle Bin</span>
        </div>

        {/* Dynamic Items from /home/user/Desktop */}
        {desktopItems.map((item, idx) => (
            <div 
                key={idx}
                className="group flex flex-col items-center gap-1 w-20 cursor-pointer relative mb-2"
                onDoubleClick={() => handleItemDoubleClick(item)}
            >
                 <div className="w-12 h-12 hover:bg-white/10 rounded-lg flex items-center justify-center transition-colors">
                    {getIcon(item)}
                 </div>
                 <span className="text-xs text-white font-medium drop-shadow-md bg-black/20 px-2 rounded-full py-0.5 border border-white/5 text-center break-all line-clamp-2 leading-tight">
                    {item.name.replace('.app', '')}
                 </span>
                 
                 {/* Quick Delete for Desktop Items */}
                 <button 
                    onClick={(e) => handleDeleteItem(e, item.name)}
                    className="absolute -top-1 -right-1 bg-red-500 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                    title="Delete"
                 >
                    <Trash2 size={10} className="text-white" />
                 </button>
            </div>
        ))}
      </div>

      {/* Render Windows Dynamically from Registry */}
      {Object.entries(APP_REGISTRY).map(([id, AppComponent]) => (
        <Window key={id} appId={id as AppID}>
          <AppErrorBoundary appName={APP_CONFIGS[id as AppID]?.name}>
             <AppComponent />
          </AppErrorBoundary>
        </Window>
      ))}

      {/* Context Menu */}
      {contextMenu && (
        <div 
          className="fixed z-[9999] w-64 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl py-1.5 animate-in fade-in zoom-in-95 duration-100 origin-top-left select-none"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside menu
        >
           <div className="px-1 space-y-0.5">
              <div className="group flex items-center justify-between px-3 py-2 hover:bg-white/10 rounded cursor-default text-slate-200 text-sm">
                 <div className="flex items-center gap-3">
                    <Monitor size={16} className="text-slate-400" />
                    <span>View</span>
                 </div>
                 <ChevronRight size={14} className="text-slate-500" />
              </div>
              <div className="group flex items-center justify-between px-3 py-2 hover:bg-white/10 rounded cursor-default text-slate-200 text-sm">
                 <div className="flex items-center gap-3">
                    <span className="w-4 ml-0.5">⇅</span>
                    <span>Sort by</span>
                 </div>
                 <ChevronRight size={14} className="text-slate-500" />
              </div>
              <button 
                onClick={handleRefresh}
                className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm"
              >
                 <RefreshCw size={16} className="text-slate-400" />
                 <span>Refresh</span>
              </button>
           </div>

           <div className="h-[1px] bg-white/10 my-1 mx-2" />

           <div className="px-1 space-y-0.5">
              <button 
                onClick={handleNewFolder}
                className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm"
              >
                 <FolderPlus size={16} className="text-slate-400" />
                 <span>New folder</span>
              </button>
              <button 
                onClick={handleNewTextFile}
                className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm"
              >
                 <FileText size={16} className="text-slate-400" />
                 <span>New Text Document</span>
              </button>
           </div>

           <div className="h-[1px] bg-white/10 my-1 mx-2" />

           <div className="px-1 space-y-0.5">
              <button className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm">
                 <Monitor size={16} className="text-slate-400" />
                 <span>Display settings</span>
              </button>
              <button 
                onClick={handlePersonalize}
                className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm"
              >
                 <Settings size={16} className="text-slate-400" />
                 <span>Personalize</span>
              </button>
              <button 
                onClick={() => { openApp(AppID.TERMINAL); setContextMenu(null); }}
                className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded text-left text-slate-200 text-sm"
              >
                 <Terminal size={16} className="text-slate-400" />
                 <span>Open in Terminal</span>
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default Desktop;
