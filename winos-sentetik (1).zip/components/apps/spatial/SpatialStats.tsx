
import React from 'react';
import { Navigation, Video } from 'lucide-react';
import { SensorReadings, PerceptionState, SerialStatus } from '../../../types';

interface SpatialStatsProps {
    serialStatus: SerialStatus;
    activeTab: string;
    sensorReadings: SensorReadings;
    perceptionState: PerceptionState;
}

export const SpatialStats: React.FC<SpatialStatsProps> = ({ 
    serialStatus, 
    activeTab, 
    sensorReadings, 
    perceptionState 
}) => {
    return (
        <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur border border-white/10 p-3 rounded-lg text-xs font-mono space-y-2 pointer-events-none select-none">
            <div className="flex items-center gap-2 mb-1">
                <Navigation size={12} className={serialStatus === 'connected' ? 'text-green-400' : 'text-yellow-400'} />
                <span>DURUM: {serialStatus === 'connected' ? 'DONANIM AKTİF' : 'SİMÜLASYON'}</span>
            </div>
            <div>MOD: {activeTab === 'slam_2d' ? '2D GRID (Lidar)' : '3D VOXEL (Lidar + Stereo)'}</div>
            <div>NOKTA: {sensorReadings.lidarMap?.length || 0}</div>
            <div>ÖN MESAFE: {sensorReadings.ultrasonic.front}mm</div>
            {activeTab === 'slam_3d' && (
                <div className="flex items-center gap-1 text-purple-400 border-t border-white/10 pt-1 mt-1">
                    <Video size={10} />
                    <span>Stereo Derinlik: AKTİF</span>
                </div>
            )}
            <div className="pt-2 border-t border-white/10 mt-2">
                <div className="text-slate-400 mb-1">TESPİT EDİLENLER:</div>
                {perceptionState.detectedObjects.length === 0 ? (
                    <span className="text-slate-500 italic">Yok</span>
                ) : (
                    perceptionState.detectedObjects.map(obj => (
                        <div key={obj.id} className="flex justify-between gap-4">
                            <span className={obj.type === 'living' ? 'text-green-400' : 'text-blue-300'}>{obj.label}</span>
                            <span className="text-slate-500">{(obj.confidence * 100).toFixed(0)}%</span>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};
