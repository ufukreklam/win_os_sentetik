
# Faz 31: Master-Slave İletişim Protokolü Spesifikasyonu

Bu döküman, Raspberry Pi 5 (Master/Backend) ile Raspberry Pi Pico (Slave/Motor & Sensor Controller) arasındaki veri alışverişi standardını tanımlar.

## 1. Fiziksel Katman
*   **Bağlantı**: USB Serial (UART over USB)
*   **Baud Rate**: 115200
*   **Format**: ASCII (UTF-8)
*   **Ayrıştırıcı**: Newline (`\n`) karakteri ile ayrılmış JSON nesneleri (JSON Lines).

## 2. Veri Akışı

### 2.1 Master -> Slave (Komutlar)
RPi 5, Pico'ya eyleyici (actuator) komutları gönderir.

**Format:**
```json
{
  "m": [sol_pwm, sag_pwm],  // Motorlar: -100 ile 100 arası
  "s": [pan, tilt],         // Servolar: 0-180 derece (Opsiyonel)
  "l": [r, g, b]            // LED Durumu (Opsiyonel)
}
```

*   `m` (Motors): Zorunlu. Sol ve Sağ motor hızları.
    *   `0`: Dur.
    *   `100`: Tam ileri.
    *   `-100`: Tam geri.

### 2.2 Slave -> Master (Telemetri)
Pico, RPi 5'e sensör verilerini sürekli (örn. 20Hz) gönderir.

**Format:**
```json
{
  "v": 12.4,        // Batarya Voltajı (Volt)
  "c": 1.2,         // Akım Çekimi (Amper)
  "i": {            // IMU (Atalet Sensörü)
    "p": 2.1,       // Pitch
    "r": -0.5,      // Roll
    "y": 120.5      // Yaw
  },
  "u": [120, 45, 200], // Ultrasonik Mesafe (mm): [Ön, Sol, Sağ]
  "l_stat": "OK"    // Lidar/Sistem Durumu
}
```

*   Veri tasarrufu için kısa anahtarlar (`v`, `c`, `i`, `u`) kullanılır.
*   Backend'deki `ProtocolNode`, bu kısa anahtarları uzun formatlı `hardware_update` mesajına çevirir.

## 3. Güvenlik ve Hata Yönetimi

1.  **Watchdog (Master Tarafı):** `ProtocolNode`, 2 saniye boyunca Pico'dan veri gelmezse sistemi "Warning" durumuna geçirir ve `serial_node`'u yeniden bağlanmaya zorlar.
2.  **Watchdog (Slave Tarafı):** Pico, 500ms boyunca Master'dan komut almazsa motorları otomatik olarak durdurur (`m: [0, 0]`). Bu, Master çökerse robotun kontrolden çıkmasını engeller.
3.  **Veri Bütünlüğü:** JSON parse hatası alınan satırlar yoksayılır.

## 4. Örnek Senaryo

1.  **Kullanıcı** Joystick ile ileri gider.
2.  **ControlNode**: `{"m": [50, 50]}` paketini hazırlar.
3.  **SerialNode**: Paketi USB üzerinden yazar (`b'{"m": [50, 50]}\n'`).
4.  **Pico**: Paketi okur, motor sürücülerine %50 Duty Cycle uygular.
5.  **Pico**: Sensörleri okur ve `{"v": 12.1, ...}` paketini yazar.
6.  **SerialNode**: Paketi okur ve yayınlar.
7.  **ProtocolNode**: Paketi parse eder, `batteryVoltage` olarak UI'a basar.
