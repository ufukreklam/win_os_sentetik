# 🤖 Seviye 5 Hibrit Robotlar için State Machine Tasarımı

**Proje:** Birey AI / TT Platformu  
**Versiyon:** v1.0  
**Konum:** Çekirdek Davranış Yönetimi

---

## 1. Genel Tanım

Seviye 5 otonom robotlar, **hibrit yapıya** sahiptir:

*   **Endüstriyel Katman:** Görev, keşif, araştırma, bakım gibi fiziksel ve operasyonel işlevler.
*   **İnsansı Katman:** Sosyal etkileşim, eğlence, duygusal ifade gibi HRI (Human-Robot Interaction) işlevleri.

Bütün bu işlevler **Durum Makinesi (State Machine)** altında kontrol edilir. Her mod, bir **plugin** mantığı ile sisteme eklenebilir veya çıkarılabilir, bu da sistemin esnekliğini artırır.

---

## 2. Mod Kategorileri

Sistem, işlevlerine göre gruplandırılmış 5 ana kategori altında çalışır:

### 🔹 Yaşam & Enerji Modları
*   **Şarj Modu**: Dock istasyonunu bulma, şarj olma ve enerji tüketimini minimize etme.
*   **Uyku Modu**: Düşük güç tüketimi, sensörlerin kapatılması, hafıza optimizasyonu.
*   **Standby**: Komut bekleme durumu, sensörler minimal seviyede dinlemede.
*   **Sağlık Kontrol Modu**: Motor, sensör, batarya ve çevre birimlerinin POST (Power-On Self Test) testleri.

### 🔹 Görev & Araştırma Modları
*   **Keşif Modu**: SLAM (Eş zamanlı konumlandırma ve haritalama), yol planlama, engel algılama.
*   **Araştırma Modu**: Çevresel veri toplama, numune analizi, deneysel çalışma.
*   **Görev İcra Modu**: Teslimat, nesne taşıma, manipülasyon, ölçüm.
*   **Navigasyon Modu**: Uzun mesafe rota planlama ve A noktasından B noktasına gitme.
*   **Bakım Modu**: Kalibrasyon, firmware güncelleme, kendi kendini onarma rutinleri.

### 🔹 Sosyal & Eğlence Modları
*   **Etkileşim Modu**: Doğal dil işleme (NLP) ile sohbet, sesli komut algılama, jest/mimik takibi.
*   **Eğlence Modu**: Dans, müzik çalma, görsel şov sunma.
*   **Oyun Modu**: Çocuk veya evcil hayvan ile etkileşimli oyunlar.
*   **İfade Modu**: OLED göz/ağız ifadeleri ve sesli tepkilerle duygu yansıtma.

### 🔹 Zeka & Öğrenme Modları
*   **Eğitim Modu**: Yeni görevler öğrenme, reinforcement learning (pekiştirmeli öğrenme) döngüleri.
*   **Bilgi Modu**: Rehberlik, danışmanlık, ansiklopedik bilgi paylaşımı.
*   **Tahmin Modu**: Kullanıcı davranışı veya çevre koşullarını öngörme.
*   **Kendi Kendini Geliştirme**: Sistem parametrelerinin ve algoritmaların optimizasyonu.

### 🔹 Güvenlik & Acil Durum Modları
*   **Koruma Modu**: Anomali algılama, güvenlik izleme, devriye.
*   **Acil Durum Modu**: Yangın, çarpışma, devrilme gibi durumlarda güvenli duruş (Safety Stop).
*   **İşbirliği Modu (Swarm)**: Diğer robotlarla sürü zekası koordinasyonu.

---

## 3. Hiyerarşik State Machine (HSM) Yapısı

Sistem, durumları düz bir liste yerine hiyerarşik bir ağaç yapısında yönetir. Bu, karmaşıklığı yönetilebilir kılar.

```mermaid
graph TD
    Root[ROOT STATE] --> Energy[Yaşam & Enerji]
    Root --> Mission[Görev & Araştırma]
    Root --> Social[Sosyal & Eğlence]
    Root --> Intel[Zeka & Öğrenme]
    Root --> Safety[Güvenlik & Acil Durum]

    Energy --> Charge[Şarj]
    Energy --> Sleep[Uyku]
    Energy --> Standby[Standby]

    Mission --> Explore[Keşif]
    Mission --> Research[Araştırma]
    Mission --> Execute[Görev İcra]

    Social --> Interact[Etkileşim]
    Social --> Play[Oyun]

    Intel --> Learn[Eğitim]
    Intel --> SelfImp[Self-Improvement]

    Safety --> Guard[Koruma]
    Safety --> Emergency[Acil Durum]
```

---

## 4. Raspberry Pi 5 Uyumluluk & Sınır Yönetimi

Pi 5, sistemin **Master (Beyin)** ünitesi olarak çalışır. Donanım kısıtlamalarını aşmak için aşağıdaki stratejiler uygulanır:

1.  **CPU / GPU Yükü**
    *   *Sorun:* NLP, Computer Vision, SLAM gibi ağır işlerde işlemci darboğazı.
    *   *Çözüm:* Gerçek zamanlı motor/sensör iş yükünü **RPi Pico (Slave)** kümesine dağıtmak.

2.  **Bellek (RAM) Kısıtı (8GB max)**
    *   *Sorun:* Büyük LLM ve Vision modelleri RAM'i doldurabilir.
    *   *Çözüm:* TinyML modelleri kullanımı, model kuantizasyonu (INT8), disk tabanlı swap ve on-demand (ihtiyaç anında) model yükleme.

3.  **I/O Sınırları**
    *   *Sorun:* Kamera, Lidar, sensörler ve motor sürücüler aynı anda veri akıtır.
    *   *Çözüm:* UART/I2C çoklayıcılar (Multiplexer) ve Pico üzerinden veri ön işleme/filtreleme.

4.  **Enerji Yönetimi**
    *   *Sorun:* Pi 5 yük altında 15-25W güç tüketebilir.
    *   *Çözüm:* Akıllı Şarj Modu, Dinamik Frekans Ölçekleme (DFS) ve Pico ile güç optimizasyonu.

5.  **Gerçek Zamanlılık (Real-time)**
    *   *Sorun:* Pi 5 (Linux OS) deterministik gerçek zamanlı tepki veremez.
    *   *Çözüm:* RPi Pico (MicroPython/C++) milisaniye hassasiyetindeki kontrolleri yapar, Pi 5 yüksek seviyeli kararları verir.

---

## 5. Plugin & Manifesto Yapısı

Sistem modülerliği, dosya tabanlı bir plugin mimarisi ile sağlanır.

### 📂 Klasör Yapısı

```
/state_machine
   /core
      ├── state_manager.py      # Ana durum yöneticisi
      ├── transitions.json      # Durum geçiş kuralları
   /plugins
      ├── exploration.plugin    # Keşif modu mantığı
      ├── dance.plugin          # Dans modu mantığı
      ├── research.plugin       # Araştırma modu mantığı
      ├── safety.plugin         # Güvenlik modu mantığı
   /manifest
      ├── state_manifest.yaml   # Sistem konfigürasyonu
```

### 📜 Manifesto Örneği (`state_manifest.yaml`)

```yaml
robot_name: Birey AI
version: 1.0
state_machine:
  categories:
    - name: Energy
      states: [Charging, Sleep, Standby, HealthCheck]
    - name: Mission
      states: [Exploration, Research, TaskExecution, Navigation, Maintenance]
    - name: Social
      states: [Interaction, Entertainment, Play, Expression]
    - name: Intelligence
      states: [Learning, Knowledge, Prediction, SelfImprovement]
    - name: Safety
      states: [Guard, Emergency, Swarm]
resources:
  cpu_limit: 80%
  ram_limit: 6GB
  pico_usage: true
```

---

## 6. Sonuç & Yol Haritası

*   **Özet:** Seviye 5 Hibrit Robotlar için tasarlanan bu State Machine; yaşam, görev, sosyal, zeka ve güvenlik modlarını kapsayan bütünleşik bir yapıdır.
*   **Donanım Stratejisi:** Pi 5 sınırları gözetilerek, ağır ve gerçek zamanlı işlerin Pico kümesine dağıtılması esastır.
*   **Esneklik:** Plugin + Manifesto mimarisi sayesinde kod değiştirmeden yeni yetenekler eklenebilir.

**Uygulama Adımları:**
1.  Öncelikle **çekirdek state manager (Core)** yazılmalı.
2.  Her mod **plugin** formatında kodlanmalı.
3.  **Manifesto dosyası** ile sistem orkestrasyonu sağlanmalı.
4.  Pi 5 (Master) + Pico (Slave) entegrasyonu ve iletişim protokolü test edilmeli.
