
import { AppID, AppMetadata, CoreEmotion } from './types';
import { MessageSquare, Settings, Globe, Image as ImageIcon, FolderOpen, Terminal, FileText, Calculator, Camera, Code2, Play, Activity, ShoppingBag, BrainCircuit, Radar, Target, Users, BookOpen, ShieldAlert, Home, Fingerprint, Workflow, Cable, Smile, Trophy, Lightbulb, Database, Scale, Puzzle } from 'lucide-react';

export const WALLPAPERS = {
  DEFAULT: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=2070&auto=format&fit=crop',
};

export const WALLPAPER_PRESETS = [
  { 
    name: 'Varsayılan Akış', 
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=2070&auto=format&fit=crop' 
  },
  { 
    name: 'Soyut Karanlık', 
    url: 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?q=80&w=2070&auto=format&fit=crop' 
  },
  { 
    name: 'Neon Şehir', 
    url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?q=80&w=2000&auto=format&fit=crop' 
  },
  { 
    name: 'Dağ Gölü', 
    url: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=80&w=2070&auto=format&fit=crop' 
  },
  { 
    name: 'Minimal Kumullar', 
    url: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=2070&auto=format&fit=crop' 
  },
  {
    name: 'Aydınlık Akış',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2064&auto=format&fit=crop'
  }
];

export const GEMINI_MODEL = 'gemini-3-flash-preview';

// Color mappings for Layer 3 (Emotion) visualization
export const EMOTION_COLORS: Record<CoreEmotion, string> = {
    neutral: 'bg-blue-500/10',
    happy: 'bg-yellow-500/20',
    angry: 'bg-red-500/20',
    sad: 'bg-indigo-500/20',
    surprised: 'bg-pink-500/20',
    fear: 'bg-purple-900/40',
    curious: 'bg-green-500/20'
};

export const APP_CONFIGS: Record<AppID, AppMetadata> = {
  [AppID.CHAT]: {
    id: AppID.CHAT,
    name: 'Gemini Yapay Zeka Asistanı',
    icon: MessageSquare,
    version: '2.0.0-AI',
    size: '15 MB',
    isSystem: true,
    category: 'productivity',
    description: 'Günlük görevleriniz için yapay zeka destekli asistan.'
  },
  [AppID.FILES]: {
    id: AppID.FILES,
    name: 'Dosya Yöneticisi',
    icon: FolderOpen,
    version: '10.0.2',
    size: '8 MB',
    isSystem: true,
    category: 'system',
    description: 'Dosyalarınızı tarayın ve yönetin.'
  },
  [AppID.SETTINGS]: {
    id: AppID.SETTINGS,
    name: 'Sistem Ayarları',
    icon: Settings,
    version: '1.0.0',
    size: '24 MB',
    isSystem: true,
    category: 'system',
    description: 'Sistem tercihlerinizi yapılandırın.'
  },
  [AppID.BROWSER]: {
    id: AppID.BROWSER,
    name: 'İnternet Tarayıcısı',
    icon: Globe,
    version: '120.0.6099',
    size: '450 MB',
    isSystem: false,
    category: 'utilities',
    description: 'İnternette güvenle gezinin.'
  },
  [AppID.PHOTOS]: {
    id: AppID.PHOTOS,
    name: 'Fotoğraf Galerisi',
    icon: ImageIcon,
    version: '2024.1.12',
    size: '12 MB',
    isSystem: false,
    category: 'media',
    description: 'Fotoğraflarınızı görüntüleyin ve düzenleyin.'
  },
  [AppID.MEDIA]: {
    id: AppID.MEDIA,
    name: 'Medya Merkezi',
    icon: Play,
    version: '3.0.1',
    size: '35 MB',
    isSystem: false,
    category: 'media',
    description: 'Müzik ve video oynatın.'
  },
  [AppID.TERMINAL]: {
    id: AppID.TERMINAL,
    name: 'Komut Satırı Arayüzü',
    icon: Terminal,
    version: '1.0.0-beta',
    size: '2 MB',
    isSystem: true,
    category: 'development',
    description: 'Sistem komut satırı arayüzü.'
  },
  [AppID.TASK_MANAGER]: {
    id: AppID.TASK_MANAGER,
    name: 'Görev Yöneticisi',
    icon: Activity,
    version: '1.5.0',
    size: '3 MB',
    isSystem: true,
    category: 'system',
    description: 'Sistem performansını izleyin.'
  },
  [AppID.NOTEPAD]: {
    id: AppID.NOTEPAD,
    name: 'Not Defteri',
    icon: FileText,
    version: '11.2311',
    size: '1.5 MB',
    isSystem: false,
    category: 'productivity',
    description: 'Basit metin düzenleyici.'
  },
  [AppID.CALCULATOR]: {
    id: AppID.CALCULATOR,
    name: 'Hesap Makinesi',
    icon: Calculator,
    version: '11.2307',
    size: '5 MB',
    isSystem: false,
    category: 'utilities',
    description: 'Temel hesaplamaları yapın.'
  },
  [AppID.CAMERA]: {
    id: AppID.CAMERA,
    name: 'Vizyon Kamerası',
    icon: Camera,
    version: '1.0.0',
    size: '4 MB',
    isSystem: true,
    category: 'media',
    description: 'Fotoğraf çekin ve yapay zeka ile analiz edin.'
  },
  [AppID.CODE_EDITOR]: {
    id: AppID.CODE_EDITOR,
    name: 'Kod Düzenleyici',
    icon: Code2,
    version: '1.2.0',
    size: '18 MB',
    isSystem: false,
    category: 'development',
    description: 'Kod parçacıkları yazın ve çalıştırın.'
  },
  [AppID.APP_STORE]: {
    id: AppID.APP_STORE,
    name: 'Uygulama Mağazası',
    icon: ShoppingBag,
    version: '1.0.0',
    size: '10 MB',
    isSystem: true,
    category: 'system',
    description: 'Yeni uygulamalar keşfedin ve yükleyin.'
  },
  [AppID.MIND]: {
    id: AppID.MIND,
    name: 'Zihin Monitörü',
    icon: BrainCircuit,
    version: '1.0.0-Layer3',
    size: '6 MB',
    isSystem: true,
    category: 'robot',
    description: 'Hibrit bilinç katmanlarını ve duygu motorunu izleyin.'
  },
  [AppID.MEMORY]: {
    id: AppID.MEMORY,
    name: 'Bellek Bankası',
    icon: Database,
    version: '1.0.0-Layer2',
    size: '10 MB',
    isSystem: true,
    category: 'robot',
    description: 'Katman 2: Hibrit Bellek Sistemi (Anısal, Semantik, Çalışma).'
  },
  [AppID.SPATIAL]: {
    id: AppID.SPATIAL,
    name: 'Uzamsal Farkındalık',
    icon: Radar,
    version: '1.5.0-L5',
    size: '12 MB',
    isSystem: true,
    category: 'robot',
    description: 'Lidar SLAM görselleştirme ve sensör füzyon arayüzü.'
  },
  [AppID.GOALS]: {
    id: AppID.GOALS,
    name: 'Görev Kontrol Merkezi',
    icon: Target,
    version: '1.0.0-L6',
    size: '8 MB',
    isSystem: true,
    category: 'robot',
    description: 'Robot hedeflerini, motivasyon sürücülerini ve aktif görevleri yönetin.'
  },
  [AppID.SOCIAL]: {
    id: AppID.SOCIAL,
    name: 'Sosyal Grafik',
    icon: Users,
    version: '1.0.0-L7',
    size: '10 MB',
    isSystem: true,
    category: 'robot',
    description: 'Güven matrisi, yüz tanıma ve sosyal biliş arayüzü.'
  },
  [AppID.LEARNING]: {
    id: AppID.LEARNING,
    name: 'Sinirsel Bağlantı',
    icon: BookOpen,
    version: '1.0.0-L9',
    size: '12 MB',
    isSystem: true,
    category: 'robot',
    description: 'Beceri ağacı, bilgi grafiği ve adaptasyon metrikleri.'
  },
  [AppID.SECURITY]: {
    id: AppID.SECURITY,
    name: 'Güvenlik Koruması',
    icon: ShieldAlert,
    version: '1.0.0-L11',
    size: '8 MB',
    isSystem: true,
    category: 'robot',
    description: 'Etik modülü, tehdit izleme ve veri gizliliği kasası.'
  },
  [AppID.CONNECT]: {
    id: AppID.CONNECT,
    name: 'Akıllı Bağlantı',
    icon: Home,
    version: '1.0.0-L12',
    size: '14 MB',
    isSystem: true,
    category: 'robot',
    description: 'Akıllı ev IoT kontrolü ve çevresel bağlam farkındalığı.'
  },
  [AppID.IDENTITY]: {
    id: AppID.IDENTITY,
    name: 'Kimlik Çekirdeği',
    icon: Fingerprint,
    version: '1.0.0-L13',
    size: '20 MB',
    isSystem: true,
    category: 'robot',
    description: 'İç monolog, öz-model ve bilinç akışı.'
  },
  [AppID.ORCHESTRATOR]: {
    id: AppID.ORCHESTRATOR,
    name: 'Sistem Koordinasyonu',
    icon: Workflow,
    version: '1.0.0-L14',
    size: '25 MB',
    isSystem: true,
    category: 'robot',
    description: 'Küresel sistem koordinasyonu, çatışma çözümü ve veri akışı görselleştirme.'
  },
  [AppID.BRIDGE]: {
    id: AppID.BRIDGE,
    name: 'Donanım Köprüsü',
    icon: Cable,
    version: '1.0.0-L15',
    size: '12 MB',
    isSystem: true,
    category: 'development',
    description: 'Donanım soyutlama katmanı köprüsü ve ham akış monitörü.'
  },
  [AppID.EXTENSIONS]: {
    id: AppID.EXTENSIONS,
    name: 'Eklenti Yöneticisi',
    icon: Puzzle,
    version: '1.0.0-L16',
    size: '15 MB',
    isSystem: true,
    category: 'development',
    description: 'Katman 16: Eklenti yükleme, doğrulama ve çalışma zamanı yönetimi.'
  },
  [AppID.FACE]: {
    id: AppID.FACE,
    name: 'Yüz Arayüzü',
    icon: Smile,
    version: '1.0.0',
    size: '15 MB',
    isSystem: true,
    category: 'robot',
    description: 'Robot yüz görselleştirme, duygu ifadesi ve sesli etkileşim arayüzü.'
  },
  [AppID.CHESS]: {
    id: AppID.CHESS,
    name: 'Derin Mavi Satranç',
    icon: Trophy,
    version: '2.4.0',
    size: '45 MB',
    isSystem: false,
    category: 'games',
    description: 'Eklenti Sistemi (Katman 16) tarafından sağlanan gelişmiş yapay zeka satranç becerisi.'
  },
  [AppID.CREATIVITY]: {
    id: AppID.CREATIVITY,
    name: 'İnovasyon Motoru',
    icon: Lightbulb,
    version: '1.0.0-L8',
    size: '18 MB',
    isSystem: true,
    category: 'robot',
    description: 'Katman 8: Yaratıcılık ve Problem Çözme. Yeni fikirler ve simülasyonlar üretir.'
  },
  [AppID.POLICY]: {
    id: AppID.POLICY,
    name: 'Karar Çekirdeği',
    icon: Scale,
    version: '1.0.0-Core',
    size: '5 MB',
    isSystem: true,
    category: 'robot',
    description: 'Güvenlik, Farkındalık ve Strateji katmanlarını yöneten merkezi karar mekanizması.'
  }
};
