
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { generateResponse } from '../../services/geminiService';
import { Mic, Send, StopCircle, Volume2, Settings, Code, MessageSquare, Sliders, Save, User, Smile, Eye, Scissors, Monitor, Menu, X as CloseIcon } from 'lucide-react';

// --- Types & Constants ---

type Gender = 'female' | 'male' | 'neutral';
type FaceShape = 'oval' | 'round' | 'square' | 'heart' | 'diamond';
type HairStyle = 'bob' | 'long' | 'short' | 'pixie' | 'mohawk' | 'bald';
type EyeType = 'human' | 'anime' | 'robot' | 'cyclops' | 'cat' | 'hypno';
type BrowType = 'natural' | 'thick' | 'thin' | 'arched' | 'straight';

interface FaceConfig {
    gender: Gender;
    headWidth: number;
    headHeight: number;
    skinHue: number; // -180 to 180
    faceShape: FaceShape;
    hairStyle: HairStyle;
    hairColor: string; // hex
    eyeType: EyeType;
    eyeSize: number;
    eyeColor: string; // preset name
    browType: BrowType;
    mouthWidth: number;
    voicePitch: number;
    voiceRate: number;
    neckWidth: number;
    voiceName: string; // Specific voice ID/Name
}

const DEFAULT_CONFIG: FaceConfig = {
    gender: 'female',
    headWidth: 380,
    headHeight: 500,
    skinHue: 0,
    faceShape: 'heart',
    hairStyle: 'bob',
    hairColor: '#2a1d15',
    eyeType: 'human',
    eyeSize: 1.0,
    eyeColor: 'emerald',
    browType: 'natural',
    mouthWidth: 50,
    voicePitch: 1.1,
    voiceRate: 1.0,
    neckWidth: 24,
    voiceName: ''
};

const PRESETS = {
    female: { ...DEFAULT_CONFIG, headWidth: 380, faceShape: 'heart' as FaceShape, hairStyle: 'bob' as HairStyle, voicePitch: 1.1, neckWidth: 24, eyeSize: 1.0 },
    male: { ...DEFAULT_CONFIG, headWidth: 400, faceShape: 'square' as FaceShape, hairStyle: 'short' as HairStyle, voicePitch: 0.9, neckWidth: 35, eyeSize: 0.9, mouthWidth: 60 },
    neutral: { ...DEFAULT_CONFIG, headWidth: 390, faceShape: 'oval' as FaceShape, hairStyle: 'pixie' as HairStyle, voicePitch: 1.0, neckWidth: 30 }
};

const FaceApp: React.FC = () => {
  const { 
    emotionState, voiceState, startListening, stopListening, 
    lastVoiceText 
  } = useOS();
  
  const [activeTab, setActiveTab] = useState<'chat' | 'studio' | 'editor'>('chat');
  const [config, setConfig] = useState<FaceConfig>(DEFAULT_CONFIG);
  const [editorText, setEditorText] = useState(JSON.stringify(DEFAULT_CONFIG, null, 2));

  // Chat State
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'bot', text: string}[]>([]);
  
  // Voice State
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  // Animation State
  const [headPos, setHeadPos] = useState({ x: 0, y: 0 });
  const [eyeOffset, setEyeOffset] = useState({ x: 0, y: 0 });
  const [blink, setBlink] = useState(false);
  const [mouthOpen, setMouthOpen] = useState(0); 

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isThinking]);

  // --- Voice Loading Logic ---
  useEffect(() => {
      const loadVoices = () => {
          const voices = window.speechSynthesis.getVoices();
          setAvailableVoices(voices);
          if (!config.voiceName && voices.length > 0) {
              const trFemale = voices.find(v => 
                  v.lang.includes('tr') && (v.name.includes('Google') || v.name.includes('Female') || v.name.includes('Yelda'))
              );
              const trAny = voices.find(v => v.lang.includes('tr'));
              if (trFemale) setConfig(prev => ({ ...prev, voiceName: trFemale.name }));
              else if (trAny) setConfig(prev => ({ ...prev, voiceName: trAny.name }));
          }
      };
      loadVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
          window.speechSynthesis.onvoiceschanged = loadVoices;
      }
  }, [config.voiceName]);

  const speakVoice = (text: string) => {
      if (!('speechSynthesis' in window)) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      let selectedVoice = availableVoices.find(v => v.name === config.voiceName);
      if (!selectedVoice) {
          selectedVoice = availableVoices.find(v => v.lang.includes('tr') && v.name.includes('Google')) ||
                         availableVoices.find(v => v.lang.includes('tr')) ||
                         availableVoices.find(v => v.name.includes('Female'));
      }
      if (selectedVoice) utterance.voice = selectedVoice;
      utterance.pitch = config.voicePitch;
      utterance.rate = config.voiceRate;
      window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setHeadPos({ x: (Math.random() - 0.5) * 2, y: (Math.random() - 0.5) * 2 });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const blinkLoop = () => {
      setBlink(true);
      setTimeout(() => setBlink(false), 200); 
      setTimeout(blinkLoop, 3000 + Math.random() * 5000);
    };
    const timer = setTimeout(blinkLoop, 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const lookLoop = () => {
      if (Math.random() > 0.6) {
        setEyeOffset({ x: (Math.random() - 0.5) * 15, y: (Math.random() - 0.5) * 8 });
      } else {
        setEyeOffset({ x: 0, y: 0 });
      }
      setTimeout(lookLoop, 1500 + Math.random() * 3000);
    };
    const timer = setTimeout(lookLoop, 1000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
      let animFrame: number;
      const isSpeaking = window.speechSynthesis.speaking || voiceState === 'speaking';
      if (isSpeaking) {
          const animateMouth = () => {
              setMouthOpen(0.1 + Math.random() * 0.5); 
              animFrame = requestAnimationFrame(() => setTimeout(animateMouth, 100));
          };
          animateMouth();
      } else {
          setMouthOpen(0);
      }
      return () => cancelAnimationFrame(animFrame);
  }, [voiceState, chatHistory]);

  const handleSend = async () => {
    if (!inputText.trim()) return;
    const userText = inputText;
    setInputText('');
    setChatHistory(prev => [...prev, { role: 'user', text: userText }]);
    setIsThinking(true);
    try {
      const response = await generateResponse(userText);
      setChatHistory(prev => [...prev, { role: 'bot', text: response.text }]);
      speakVoice(response.text);
    } catch (e) {
      speakVoice("Bir hata oluştu.");
    } finally {
      setIsThinking(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  useEffect(() => {
    if (voiceState === 'processing' && lastVoiceText) {
       setChatHistory(prev => [...prev, { role: 'user', text: lastVoiceText }]);
       setIsThinking(true);
       generateResponse(lastVoiceText).then(res => {
           setChatHistory(prev => [...prev, { role: 'bot', text: res.text }]);
           speakVoice(res.text);
           setIsThinking(false);
       });
    }
  }, [voiceState, lastVoiceText]);

  const getShapeStyle = () => {
      switch (config.faceShape) {
          case 'round': return '50% 50% 50% 50% / 50% 50% 50% 50%';
          case 'square': return '20% 20% 25% 25% / 20% 20% 20% 20%';
          case 'oval': return '40% 40% 50% 50% / 40% 40% 60% 60%';
          case 'diamond': return '30% 30% 50% 50% / 20% 20% 80% 80%';
          case 'heart': 
          default: return '35% 35% 45% 45% / 40% 40% 60% 60%';
      }
  };

  const renderEyeInternal = () => {
      const colors: any = {
          emerald: 'from-emerald-300 to-teal-600',
          blue: 'from-cyan-300 to-blue-600',
          amber: 'from-amber-300 to-orange-600',
          violet: 'from-purple-400 to-indigo-600',
          red: 'from-red-500 to-rose-900',
          white: 'from-slate-100 to-slate-300',
          black: 'from-gray-800 to-black',
      };
      const gradient = colors[config.eyeColor] || colors.emerald;
      switch(config.eyeType) {
          case 'anime':
              return (
                <div className={`w-full h-full rounded-full bg-gradient-to-b ${gradient} relative overflow-hidden`}>
                    <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-black rounded-full" />
                    <div className="absolute top-2 left-2 w-4 h-4 bg-white rounded-full blur-[1px]" />
                    <div className="absolute bottom-3 right-3 w-2 h-2 bg-white/50 rounded-full" />
                </div>
              );
          case 'robot':
              return (
                <div className={`w-full h-full rounded-full bg-black relative flex items-center justify-center border-2 border-${config.eyeColor}-400`}>
                    <div className={`w-2/3 h-2/3 border border-white/30 rounded-full animate-spin`} style={{ animationDuration: '3s' }} />
                    <div className={`absolute w-2 h-2 bg-${config.eyeColor === 'emerald' ? 'green' : config.eyeColor === 'amber' ? 'yellow' : 'blue'}-400 rounded-full shadow-[0_0_10px_currentColor]`} />
                    <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.5)_50%)] bg-[length:4px_4px]" />
                </div>
              );
          case 'cat':
              return (
                <div className={`w-full h-full rounded-full bg-gradient-to-br ${gradient} flex items-center justify-center relative`}>
                    <div className="w-1.5 h-3/4 bg-black rounded-[50%] absolute" />
                    <div className="absolute top-2 left-3 w-2 h-2 bg-white rounded-full opacity-80" />
                </div>
              );
          case 'hypno':
              return (
                <div className={`w-full h-full rounded-full bg-black relative overflow-hidden`}>
                     <div className={`absolute inset-0 bg-[conic-gradient(from_0deg,white,black,white,black,white,black)] animate-[spin_2s_linear_infinite] opacity-50`} />
                     <div className={`absolute inset-2 rounded-full bg-gradient-to-br ${gradient} mix-blend-overlay`} />
                </div>
              );
          case 'human':
          default:
              return (
                <div className={`w-full h-full rounded-full bg-gradient-to-br ${gradient} shadow-inner border border-black/30 flex items-center justify-center relative`}>
                    <div className={`rounded-full bg-[#1a1a1a] shadow-md transition-all duration-300 ${emotionState.primary === 'fear' ? 'w-2 h-2' : 'w-1/3 h-1/3'}`} />
                    <div className="absolute top-2 left-2 w-2.5 h-1.5 bg-white rounded-full blur-[0.3px] opacity-90" />
                    <div className="absolute bottom-3 right-3 w-1 h-1 bg-white rounded-full blur-[0.3px] opacity-60" />
                </div>
              );
      }
  };

  const renderHair = () => {
      const color = config.hairColor;
      switch(config.hairStyle) {
          case 'bald': return null;
          case 'short':
              return (
                  <>
                    <div className="absolute -top-12 left-0 right-0 h-40 bg-current rounded-[50%_50%_40%_40%_/_60%_60%_20%_20%] -z-10 shadow-lg" style={{ color }} />
                    <div className="absolute top-0 left-0 w-full h-12 bg-current opacity-90" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 80% 60%, 50% 90%, 20% 60%, 0 100%)', color }} />
                  </>
              );
          case 'pixie':
              return (
                  <>
                    <div className="absolute -top-10 -left-2 -right-2 h-48 bg-current rounded-[50%_50%_50%_50%] -z-10 shadow-lg" style={{ color }} />
                    <div className="absolute top-0 left-0 w-full h-20 bg-current" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 60%, 90% 40%, 70% 80%, 40% 30%, 10% 70%, 0 50%)', color }} />
                  </>
              );
          case 'long':
              return (
                  <>
                    <div className="absolute -top-16 -left-12 -right-12 bottom-[-100px] bg-current rounded-[50%_50%_0_0] -z-10 shadow-2xl" style={{ color }} />
                    <div className="absolute top-0 left-0 right-0 h-32 bg-current z-20 pointer-events-none" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 80% 80%, 50% 90%, 20% 80%, 0 100%)', color }} />
                    <div className="absolute top-20 -left-8 w-24 h-[400px] bg-current -z-5 rounded-b-full" style={{ color }} />
                    <div className="absolute top-20 -right-8 w-24 h-[400px] bg-current -z-5 rounded-b-full" style={{ color }} />
                  </>
              );
          case 'mohawk':
              return (
                  <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-24 h-48 bg-current rounded-[50%_50%_0_0] -z-10" style={{ color, filter: 'drop-shadow(0 0 10px rgba(0,0,0,0.5))' }}>
                      <div className="w-full h-full bg-white/10" style={{ clipPath: 'polygon(50% 0, 100% 20%, 80% 40%, 100% 60%, 80% 80%, 50% 100%, 20% 80%, 0 60%, 20% 40%, 0 20%)' }} />
                  </div>
              );
          case 'bob':
          default:
              return (
                  <>
                    <div className="absolute -top-10 -left-10 -right-10 bottom-10 bg-current rounded-[40%_40%_0_0] -z-10 shadow-2xl" style={{ color }}>
                        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(90deg, transparent 50%, rgba(0,0,0,0.3) 50%)', backgroundSize: '20px 100%' }} />
                    </div>
                    <div className="absolute top-20 -left-8 w-20 h-64 bg-current -z-10 rounded-b-full origin-top rotate-3" style={{ color }} />
                    <div className="absolute top-20 -right-8 w-20 h-64 bg-current -z-10 rounded-b-full origin-top -rotate-3" style={{ color }} />
                    <div className="absolute top-0 left-4 right-4 h-32 bg-current rounded-[50%_50%_40%_40%_/_80%_80%_20%_20%] shadow-lg z-20" style={{ color }} />
                  </>
              );
      }
  };

  const renderBrows = () => {
      let height = 'h-2';
      let width = 'w-16 md:w-20';
      let radius = 'rounded-full';
      if (config.browType === 'thick') height = 'h-4';
      if (config.browType === 'thin') height = 'h-1';
      if (config.browType === 'straight') radius = 'rounded-sm';
      const getBrowStyle = (side: 'left' | 'right') => {
          let rotate = 0, translateY = 0;
          switch (emotionState.primary) {
              case 'angry': rotate = side === 'left' ? 25 : -25; translateY = 10; break;
              case 'sad': rotate = side === 'left' ? -15 : 15; translateY = -5; break;
              case 'surprised': translateY = -15; break;
              case 'happy': translateY = -8; break;
              case 'fear': rotate = side === 'left' ? -10 : 10; translateY = -10; break;
          }
          if (config.browType === 'arched') rotate += (side === 'left' ? -10 : 10);
          return { transform: `rotate(${rotate}deg) translateY(${translateY}px)` };
      };
      return (
        <div className="flex gap-10 md:gap-14 mb-5 w-full justify-center opacity-80">
            <div className="relative transition-transform duration-300" style={getBrowStyle('left')}>
                <div className={`${width} ${height} ${radius} bg-[#3e2c22] blur-[0.5px] shadow-sm`} style={{ backgroundColor: config.hairColor }} /> 
            </div>
            <div className="relative transition-transform duration-300" style={getBrowStyle('right')}>
                <div className={`${width} ${height} ${radius} bg-[#3e2c22] blur-[0.5px] shadow-sm`} style={{ backgroundColor: config.hairColor }} />
            </div>
        </div>
      );
  };

  const getCheekGradient = () => {
      switch (emotionState.primary) {
          case 'happy': return { backgroundImage: 'radial-gradient(closest-side, rgba(255,100,100,0.4), transparent)' };
          case 'sad': return { backgroundImage: 'radial-gradient(closest-side, rgba(100,100,255,0.2), transparent)' };
          case 'angry': return { backgroundImage: 'radial-gradient(closest-side, rgba(255,50,50,0.5), transparent)' };
          case 'fear': return { backgroundImage: 'radial-gradient(closest-side, rgba(200,200,255,0.3), transparent)' };
          case 'surprised': return { backgroundImage: 'radial-gradient(closest-side, rgba(255,200,100,0.3), transparent)' };
          default: return { backgroundImage: 'radial-gradient(closest-side, rgba(200,100,100,0.15), transparent)' };
      }
  };

  const RobotFace = () => (
    <div 
        className="relative flex flex-col items-center justify-center transition-transform duration-1000 ease-in-out"
        style={{ 
            transform: `rotateX(${headPos.y}deg) rotateY(${headPos.x}deg)`,
            width: `min(100%, ${config.headWidth}px)`, 
            height: `min(100%, ${config.headHeight}px)`,
            aspectRatio: '3/4'
        }}
    >
        {renderHair()}
        <div className="absolute bottom-[-20px] h-32 -z-10 rounded-full shadow-[inset_0_10px_20px_rgba(0,0,0,0.3)]" 
             style={{ width: `${config.neckWidth}%`, backgroundColor: '#d6ae7b', filter: `hue-rotate(${config.skinHue}deg)` }} 
        />
        <div className="absolute inset-0 overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/5 z-0"
                style={{ borderRadius: getShapeStyle(), filter: `hue-rotate(${config.skinHue}deg)` }}
        >
            <div className="absolute inset-0 bg-gradient-to-b from-[#f3d4b6] to-[#dcb48b]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,_rgba(255,255,255,0.2),_transparent_60%)]" />
            <div className="absolute inset-0 shadow-[inset_0_-10px_40px_rgba(80,50,30,0.2),inset_0_10px_30px_rgba(255,255,255,0.3)]" />
            <div className="absolute inset-0 opacity-20 mix-blend-overlay" style={{ backgroundImage: 'radial-gradient(#a07050 1px, transparent 1px)', backgroundSize: '5px 5px' }} />
        </div>
        <div className="absolute top-[55%] left-[10%] w-20 h-16 rounded-full blur-xl transition-all duration-1000 z-10" style={getCheekGradient()} />
        <div className="absolute top-[55%] right-[10%] w-20 h-16 rounded-full blur-xl transition-all duration-1000 z-10" style={getCheekGradient()} />
        <div className="relative z-10 w-full h-full flex flex-col items-center justify-center pt-8 md:pt-12">
            {renderBrows()}
            <div className="flex gap-6 md:gap-10 mb-6" style={{ transform: `translate(${eyeOffset.x}px, ${eyeOffset.y}px)`, transition: 'transform 0.1s ease-out' }}>
                {['left', 'right'].map((side) => (
                    <div key={side} className="relative w-14 h-9 md:w-20 md:h-12 bg-slate-100 rounded-[50%] overflow-hidden shadow-[inset_0_2px_8px_rgba(0,0,0,0.4)] border-t border-black/10">
                        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-red-500/5" />
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 flex items-center justify-center" style={{ transform: `translate(-50%, -50%) scale(${config.eyeSize})` }}>
                            {renderEyeInternal()}
                        </div>
                        <div className="absolute top-0 left-0 right-0 bg-[#dcb48b] transition-all duration-100 z-20 border-b border-[#bd9265]"
                            style={{ height: blink ? '60%' : '0%', filter: `hue-rotate(${config.skinHue}deg)` }} />
                        <div className="absolute bottom-0 left-0 right-0 bg-[#dcb48b] transition-all duration-100 z-20 border-t border-[#bd9265]"
                            style={{ height: blink ? '60%' : '0%', filter: `hue-rotate(${config.skinHue}deg)` }} />
                        {config.gender === 'female' && <div className="absolute top-[-2px] left-0 w-full h-1 bg-black/20 blur-[1px] rounded-t-full" />}
                    </div>
                ))}
            </div>
            <div className="relative w-8 h-10 mb-4 opacity-80" style={{ filter: `hue-rotate(${config.skinHue}deg)` }}>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-full bg-white/10 blur-sm rounded-full" />
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-5 bg-black/10 blur-md rounded-full shadow-[0_2px_2px_rgba(0,0,0,0.05)]" />
            </div>
            <div className="relative w-20 h-12 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible drop-shadow-sm">
                    {(() => {
                        let curve = 0; 
                        switch (emotionState.primary) {
                            case 'happy': curve = 20; break;
                            case 'sad': curve = -15; break;
                            case 'angry': curve = -10; break;
                            case 'surprised': curve = 0; break;
                            default: curve = 3;
                        }
                        const openAmount = mouthOpen * 20;
                        const startX = 50 - (config.mouthWidth / 2);
                        const endX = 50 + (config.mouthWidth / 2);
                        const upperControlY = 50 - (curve / 3) - (openAmount / 2);
                        const lowerControlY = 50 + curve + (openAmount / 2);
                        return (
                            <path 
                                d={`M ${startX} 50 Q 50 ${upperControlY} ${endX} 50 Q 50 ${lowerControlY} ${startX} 50`}
                                fill={config.gender === 'male' ? '#c48e8e' : '#e08d8d'}
                                stroke="#c46e6e"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="transition-all duration-100 ease-linear"
                            />
                        );
                    })()}
                </svg>
            </div>
        </div>
    </div>
  );

  const saveEditorConfig = () => {
      try {
          const parsed = JSON.parse(editorText);
          setConfig(parsed);
      } catch (e) {
          console.error("Invalid JSON config", e);
      }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] text-white font-sans overflow-hidden relative">
        
        {/* Navigation Tabs - Casual Horizontal Scrolling */}
        <div className="h-14 bg-slate-900/90 backdrop-blur-md border-b border-white/5 flex items-center px-4 z-30 shrink-0 overflow-x-auto no-scrollbar scroll-smooth">
            <div className="flex gap-2 min-w-max">
              <button onClick={() => setActiveTab('chat')} className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all ${activeTab === 'chat' ? 'bg-blue-600 text-white shadow-lg' : 'bg-white/5 text-slate-400'}`}>
                <MessageSquare size={14} /> CHAT
              </button>
              <button onClick={() => setActiveTab('studio')} className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all ${activeTab === 'studio' ? 'bg-purple-600 text-white shadow-lg' : 'bg-white/5 text-slate-400'}`}>
                <Sliders size={14} /> STUDIO
              </button>
              <button onClick={() => setActiveTab('editor')} className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all ${activeTab === 'editor' ? 'bg-amber-600 text-white shadow-lg' : 'bg-white/5 text-slate-400'}`}>
                <Code size={14} /> EDITOR
              </button>
            </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex overflow-hidden relative">
            
            {/* 1. CHAT MODE - Adaptive Stacking */}
            {activeTab === 'chat' && (
                <div className="flex flex-col md:flex-row w-full h-full">
                    {/* Face Section - Top on Mobile (%50) */}
                    <div className="h-1/2 md:h-full md:flex-1 flex items-center justify-center perspective-1000 bg-gradient-to-b from-[#0a0a0a] to-[#111] relative border-b md:border-b-0 border-white/5">
                        <div className="scale-75 md:scale-100">
                          <RobotFace />
                        </div>
                        {isThinking && (
                            <div className="absolute top-4 right-4 flex items-center gap-2 bg-blue-600/20 px-3 py-1 rounded-full border border-blue-500/50">
                                <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                                <span className="text-[10px] font-bold tracking-widest text-blue-400 uppercase">Thinking</span>
                            </div>
                        )}
                    </div>

                    {/* Chat Section - Bottom on Mobile */}
                    <div className="h-1/2 md:h-full md:w-96 lg:w-[450px] bg-slate-900/50 backdrop-blur-xl border-l border-white/5 flex flex-col z-20">
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                            {chatHistory.length === 0 && (
                                <div className="h-full flex flex-col items-center justify-center text-center opacity-30 px-8">
                                    <Smile size={48} className="mb-4" />
                                    <p className="text-sm">Merhaba! Benimle konuşmak için aşağıdaki kutuyu kullanabilir veya mikrofona basabilirsin.</p>
                                </div>
                            )}
                            {chatHistory.map((msg, i) => (
                                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed shadow-lg ${
                                        msg.role === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-slate-800 text-cyan-50 rounded-bl-none border border-white/5'
                                    }`}>
                                        <span className="text-[9px] uppercase font-black opacity-50 block mb-1">
                                            {msg.role === 'user' ? 'You' : 'Robot'}
                                        </span>
                                        {msg.text}
                                    </div>
                                </div>
                            ))}
                            <div ref={chatEndRef} />
                        </div>

                        {/* Input Area */}
                        <div className="p-4 bg-black/20 border-t border-white/5 flex items-center gap-3">
                            <button 
                                onClick={voiceState === 'listening' ? stopListening : startListening}
                                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-all ${
                                    voiceState === 'listening' ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-slate-400'
                                }`}
                            >
                                {voiceState === 'listening' ? <StopCircle size={20} /> : <Mic size={20} />}
                            </button>
                            <div className="flex-1 relative">
                                <input 
                                    type="text" 
                                    value={inputText}
                                    onChange={(e) => setInputText(e.target.value)}
                                    onKeyDown={handleKeyDown}
                                    placeholder="Mesaj yaz..."
                                    className="w-full bg-slate-800 border border-white/10 rounded-full py-2 px-4 pr-10 text-sm text-white focus:outline-none focus:border-cyan-500 transition-all"
                                />
                                <button 
                                    onClick={handleSend}
                                    className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 text-cyan-400 hover:text-cyan-300 transition-colors"
                                >
                                    <Send size={18} />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* 2. STUDIO MODE - Stacked on Mobile */}
            {activeTab === 'studio' && (
                <div className="flex flex-col md:flex-row w-full h-full">
                    <div className="h-[40%] md:h-full md:flex-1 flex items-center justify-center bg-black perspective-1000 relative">
                        <div className="scale-50 md:scale-75"><RobotFace /></div>
                    </div>
                    <div className="flex-1 md:w-96 bg-slate-900 border-t md:border-t-0 md:border-l border-white/10 overflow-y-auto custom-scrollbar">
                        <div className="p-4 border-b border-white/5 grid grid-cols-3 gap-2 sticky top-0 bg-slate-900 z-10">
                            {(['female', 'male', 'neutral'] as Gender[]).map(g => (
                                <button key={g} onClick={() => setConfig({ ...PRESETS[g], skinHue: config.skinHue })} className={`px-2 py-1.5 rounded text-[10px] font-bold uppercase ${config.gender === g ? 'bg-blue-600 text-white' : 'bg-white/5 text-slate-400'}`}>{g}</button>
                            ))}
                        </div>
                        <div className="p-6 space-y-8 pb-20">
                            <div className="space-y-4">
                                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><User size={14} /> Structure</h3>
                                <div className="space-y-4">
                                    <div className="grid grid-cols-3 gap-1">
                                        {(['oval', 'round', 'square', 'heart', 'diamond'] as FaceShape[]).map(s => (
                                            <button key={s} onClick={() => setConfig({...config, faceShape: s})} className={`text-[10px] py-2 border rounded ${config.faceShape === s ? 'border-blue-500 bg-blue-500/20 text-blue-300' : 'border-white/10 text-slate-400'}`}>{s}</button>
                                        ))}
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-[10px] text-slate-400 uppercase font-bold"><span>Head Width</span><span>{config.headWidth}</span></div>
                                        <input type="range" min="300" max="450" value={config.headWidth} onChange={(e) => setConfig({...config, headWidth: parseInt(e.target.value)})} className="w-full accent-slate-500 h-1 bg-slate-700 rounded-lg appearance-none" />
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-[10px] text-slate-400 uppercase font-bold"><span>Skin Tone</span><span>{config.skinHue}</span></div>
                                        <input type="range" min="-180" max="180" value={config.skinHue} onChange={(e) => setConfig({...config, skinHue: parseInt(e.target.value)})} className="w-full accent-orange-500 h-1 bg-slate-700 rounded-lg appearance-none" />
                                    </div>
                                </div>
                            </div>
                            <div className="space-y-4">
                                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><Scissors size={14} /> Hair</h3>
                                <div className="grid grid-cols-3 gap-2">
                                    {(['bob', 'long', 'short', 'pixie', 'mohawk', 'bald'] as HairStyle[]).map(h => (
                                        <button key={h} onClick={() => setConfig({...config, hairStyle: h})} className={`text-[10px] py-2 rounded border ${config.hairStyle === h ? 'border-purple-500 bg-purple-500/20 text-white' : 'border-white/10 text-slate-400'}`}>{h}</button>
                                    ))}
                                </div>
                            </div>
                            <div className="space-y-4">
                                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><Eye size={14} /> Eyes</h3>
                                <div className="grid grid-cols-3 gap-1">
                                    {(['human', 'anime', 'robot', 'cat', 'hypno'] as EyeType[]).map(t => (
                                        <button key={t} onClick={() => setConfig({...config, eyeType: t})} className={`text-[10px] py-2 border rounded ${config.eyeType === t ? 'border-green-500 bg-green-500/20 text-green-300' : 'border-white/10 text-slate-400'}`}>{t}</button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* 3. EDITOR MODE - Stacked on Mobile */}
            {activeTab === 'editor' && (
                <div className="flex flex-col md:flex-row w-full h-full bg-[#0d1117]">
                    <div className="flex-1 flex flex-col">
                        <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 bg-slate-900/50">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">config.json</span>
                            <button onClick={saveEditorConfig} className="flex items-center gap-2 text-[10px] bg-green-600 hover:bg-green-500 text-white px-3 py-1 rounded-full font-black uppercase transition-all shadow-lg"><Save size={12} /> Apply</button>
                        </div>
                        <textarea 
                            value={editorText}
                            onChange={(e) => setEditorText(e.target.value)}
                            className="flex-1 w-full bg-transparent text-xs font-mono text-blue-300 p-4 outline-none resize-none custom-scrollbar"
                            spellCheck={false}
                        />
                    </div>
                    <div className="h-[30%] md:h-full md:w-64 bg-black flex items-center justify-center border-t md:border-t-0 md:border-l border-white/10 overflow-hidden shrink-0">
                        <div className="scale-50 origin-center pointer-events-none">
                            <RobotFace />
                        </div>
                    </div>
                </div>
            )}

        </div>

        <style>{`
            .perspective-1000 { perspective: 1000px; }
            .no-scrollbar::-webkit-scrollbar { display: none; }
            .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
            .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
            .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
        `}</style>
    </div>
  );
};

export default FaceApp;
