
import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { FileSystemItem } from '../../types';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, 
  Volume1, VolumeX, Music, Video, List, X, 
  Menu, Maximize2, Repeat, Shuffle 
} from 'lucide-react';

const MediaPlayerApp: React.FC = () => {
  const { readdir } = useOS();
  const [activeTab, setActiveTab] = useState<'music' | 'video'>('music');
  const [currentMedia, setCurrentMedia] = useState<FileSystemItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const musicFiles = readdir('/home/user/Music').filter(f => f.type === 'file' && f.fileType === 'music');
  const videoFiles = readdir('/home/user/Videos').filter(f => f.type === 'file' && f.fileType === 'video');

  const activeRef = currentMedia?.fileType === 'video' ? videoRef : audioRef;

  // Handle media switching
  useEffect(() => {
    if (currentMedia) {
        setIsPlaying(true);
        setCurrentTime(0);
    }
  }, [currentMedia]);

  // Sync play/pause state
  useEffect(() => {
      const el = activeRef.current;
      if (el) {
          if (isPlaying) el.play().catch(() => setIsPlaying(false));
          else el.pause();
      }
  }, [isPlaying, currentMedia]);

  const handleTimeUpdate = () => {
      if (activeRef.current) {
          setCurrentTime(activeRef.current.currentTime);
          setDuration(activeRef.current.duration || 0);
      }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
      const time = parseFloat(e.target.value);
      if (activeRef.current) {
          activeRef.current.currentTime = time;
          setCurrentTime(time);
      }
  };

  const formatTime = (time: number) => {
      const min = Math.floor(time / 60);
      const sec = Math.floor(time % 60);
      return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const vol = parseFloat(e.target.value);
      setVolume(vol);
      if (audioRef.current) audioRef.current.volume = vol;
      if (videoRef.current) videoRef.current.volume = vol;
  };

  const playMedia = (file: FileSystemItem) => {
      setCurrentMedia(file);
      if (isMobile) setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans relative overflow-hidden">
      
      {/* Sidebar Navigation */}
      <div className={`
        w-60 bg-slate-900/95 backdrop-blur-xl border-r border-white/5 flex flex-col z-50 transition-all duration-300
        ${isSidebarOpen ? (isMobile ? 'absolute inset-0 w-full' : 'shrink-0') : 'w-0 overflow-hidden'}
      `}>
         <div className="h-14 flex items-center justify-between px-6 border-b border-white/5 shrink-0">
             <div className="flex items-center gap-2 font-bold text-lg text-blue-400">
                 <Play size={20} fill="currentColor" />
                 <span>Media</span>
             </div>
             {isMobile && <button onClick={() => setIsSidebarOpen(false)}><X size={20} /></button>}
         </div>

         <div className="flex-1 overflow-y-auto p-4 space-y-6">
             <div>
                 <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Library</h3>
                 <button 
                    onClick={() => setActiveTab('music')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'music' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'hover:bg-white/5 text-slate-300'}`}
                 >
                     <Music size={18} />
                     <span className="font-medium text-sm">Music</span>
                 </button>
                 <button 
                    onClick={() => setActiveTab('video')}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all mt-2 ${activeTab === 'video' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'hover:bg-white/5 text-slate-300'}`}
                 >
                     <Video size={18} />
                     <span className="font-medium text-sm">Videos</span>
                 </button>
             </div>

             <div>
                 <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Playlists</h3>
                 <div className="space-y-1">
                     {['Favorites', 'Chill Mix', 'Workout'].map(pl => (
                         <button key={pl} className="w-full flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-slate-200 text-sm">
                             <List size={16} />
                             <span>{pl}</span>
                         </button>
                     ))}
                 </div>
             </div>
         </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-gradient-to-br from-slate-900 to-black">
          {/* Header */}
          <div className="h-14 border-b border-white/5 flex items-center px-4 shrink-0 justify-between">
              <div className="flex items-center gap-4">
                  {!isSidebarOpen && (
                      <button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-white/10 rounded-lg text-slate-400">
                          <Menu size={20} />
                      </button>
                  )}
                  <h2 className="text-lg font-medium">{activeTab === 'music' ? 'Music Library' : 'Video Library'}</h2>
              </div>
          </div>

          {/* Media List or Video Player */}
          <div className="flex-1 overflow-y-auto p-6 relative">
              {currentMedia?.fileType === 'video' ? (
                  <div className="w-full h-full flex items-center justify-center bg-black rounded-xl overflow-hidden shadow-2xl border border-white/10 relative group">
                      <video 
                        ref={videoRef}
                        src={currentMedia.content}
                        className="max-w-full max-h-full"
                        onTimeUpdate={handleTimeUpdate}
                        onEnded={() => setIsPlaying(false)}
                        onClick={() => setIsPlaying(!isPlaying)}
                      />
                      {/* Video Overlay Controls (Optional, simplistic) */}
                      {!isPlaying && (
                          <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
                              <Play size={64} className="text-white/80" fill="currentColor" />
                          </div>
                      )}
                  </div>
              ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                      {(activeTab === 'music' ? musicFiles : videoFiles).map((file, idx) => (
                          <div 
                            key={idx}
                            onClick={() => playMedia(file)}
                            className={`
                                group p-4 rounded-xl cursor-pointer transition-all hover:bg-white/5 border border-transparent hover:border-white/10
                                ${currentMedia?.name === file.name ? 'bg-white/10 border-blue-500/30' : ''}
                            `}
                          >
                              <div className="aspect-square bg-slate-800 rounded-lg mb-3 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform overflow-hidden relative">
                                  {activeTab === 'music' ? (
                                      <div className="w-full h-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center">
                                          <Music size={32} className="text-white/50" />
                                      </div>
                                  ) : (
                                      <div className="w-full h-full bg-slate-900 flex items-center justify-center">
                                          <Video size={32} className="text-slate-600" />
                                      </div>
                                  )}
                                  
                                  {/* Play Overlay */}
                                  <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${currentMedia?.name === file.name && isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                                      {currentMedia?.name === file.name && isPlaying ? (
                                          <div className="flex gap-1 items-end h-4">
                                              <div className="w-1 bg-white animate-[bounce_1s_infinite] h-2" />
                                              <div className="w-1 bg-white animate-[bounce_1.2s_infinite] h-4" />
                                              <div className="w-1 bg-white animate-[bounce_0.8s_infinite] h-3" />
                                          </div>
                                      ) : (
                                          <Play size={24} fill="currentColor" />
                                      )}
                                  </div>
                              </div>
                              <div className="space-y-1">
                                  <h4 className="font-medium text-sm truncate text-slate-200">{file.name}</h4>
                                  <p className="text-xs text-slate-500 truncate">Unknown Artist</p>
                              </div>
                          </div>
                      ))}
                  </div>
              )}
          </div>

          {/* Player Bar */}
          <div className="h-24 bg-slate-900/90 backdrop-blur-xl border-t border-white/5 px-4 md:px-8 flex items-center gap-4 md:gap-8 shrink-0 relative z-20">
              {/* Hidden Audio Element */}
              <audio 
                ref={audioRef}
                src={currentMedia?.fileType === 'music' ? currentMedia.content : undefined}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => setIsPlaying(false)}
              />

              {/* Now Playing Info */}
              <div className="flex items-center gap-4 w-48 md:w-60 shrink-0">
                  {currentMedia ? (
                      <>
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-md shrink-0 flex items-center justify-center">
                            {currentMedia.fileType === 'music' ? <Music size={20} className="text-white/50" /> : <Video size={20} className="text-white/50" />}
                        </div>
                        <div className="min-w-0">
                            <h4 className="text-sm font-medium text-white truncate">{currentMedia.name}</h4>
                            <p className="text-xs text-slate-400 truncate">Now Playing</p>
                        </div>
                      </>
                  ) : (
                      <div className="text-xs text-slate-500 italic">Select media to play</div>
                  )}
              </div>

              {/* Central Controls */}
              <div className="flex-1 flex flex-col items-center max-w-2xl">
                  <div className="flex items-center gap-6 mb-2">
                      <button className="text-slate-400 hover:text-white transition-colors"><Shuffle size={16} /></button>
                      <button className="text-slate-300 hover:text-white transition-colors"><SkipBack size={20} fill="currentColor" /></button>
                      <button 
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-black hover:scale-105 transition-transform"
                        disabled={!currentMedia}
                      >
                          {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
                      </button>
                      <button className="text-slate-300 hover:text-white transition-colors"><SkipForward size={20} fill="currentColor" /></button>
                      <button className="text-slate-400 hover:text-white transition-colors"><Repeat size={16} /></button>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="w-full flex items-center gap-3 text-xs text-slate-400 font-mono">
                      <span>{formatTime(currentTime)}</span>
                      <div className="flex-1 h-1 bg-slate-700 rounded-full relative group cursor-pointer">
                          <input 
                            type="range" 
                            min="0" 
                            max={duration || 100} 
                            value={currentTime} 
                            onChange={handleSeek}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                            disabled={!currentMedia}
                          />
                          <div 
                            className="absolute top-0 left-0 h-full bg-blue-500 rounded-full group-hover:bg-blue-400 transition-colors"
                            style={{ width: `${(currentTime / (duration || 1)) * 100}%` }} 
                          />
                      </div>
                      <span>{formatTime(duration)}</span>
                  </div>
              </div>

              {/* Volume & Misc */}
              <div className="flex items-center justify-end gap-3 w-48 md:w-60 shrink-0">
                  <div className="flex items-center gap-2 group">
                      <button onClick={() => setVolume(volume === 0 ? 0.8 : 0)} className="text-slate-400 hover:text-white">
                          {volume === 0 ? <VolumeX size={18} /> : volume < 0.5 ? <Volume1 size={18} /> : <Volume2 size={18} />}
                      </button>
                      <div className="w-20 h-1 bg-slate-700 rounded-full relative overflow-hidden">
                          <div 
                            className="absolute top-0 left-0 h-full bg-white rounded-full"
                            style={{ width: `${volume * 100}%` }}
                          />
                          <input 
                            type="range" 
                            min="0" 
                            max="1" 
                            step="0.01"
                            value={volume}
                            onChange={handleVolumeChange}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                          />
                      </div>
                  </div>
                  <button className="text-slate-400 hover:text-white hidden sm:block"><Maximize2 size={16} /></button>
              </div>
          </div>
      </div>
    </div>
  );
};

export default MediaPlayerApp;
