
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { WALLPAPER_PRESETS, APP_CONFIGS } from '../../constants';
import { AppID, AIMode } from '../../types';
import { 
  Monitor, User, Palette, Wifi, Bluetooth, Shield, Check, Settings, 
  Cpu, CircuitBoard, HardDrive, MemoryStick, Copy, Info,
  Mouse, Keyboard, Smartphone, Plus, RefreshCw, Signal, Lock,
  Search, Trash2, LogOut, Camera, Moon, Sun, Laptop, Disc,
  Zap, Thermometer, Fan, Server, Box, Stethoscope, CheckCircle, AlertTriangle, AlertCircle, 
  Activity, Radar, Compass, Battery, Users, UserPlus, Link2, Link2Off, 
  Loader2, Headphones, Tablet, FileText, Clock, Globe, Cloud, RotateCcw,
  Puzzle, Brain, CloudLightning, ToggleLeft, ToggleRight, Power,
  Download, Save, X, Menu
} from 'lucide-react';

// --- Shared UI Components ---
const ToggleSwitch: React.FC<{ checked: boolean; onChange: (v: boolean) => void }> = ({ checked, onChange }) => (
  <button 
    onClick={() => onChange(!checked)}
    className={`w-11 h-6 rounded-full transition-colors relative ${checked ? 'bg-blue-600' : 'bg-slate-600'}`}
  >
    <div className={`
      absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform duration-200
      ${checked ? 'translate-x-5' : 'translate-x-0'}
    `} />
  </button>
);

const SettingRow: React.FC<{ 
  icon?: React.ElementType; 
  title: string; 
  subtitle?: string; 
  children?: React.ReactNode;
  onClick?: () => void;
}> = ({ icon: Icon, title, subtitle, children, onClick }) => (
  <div 
    onClick={onClick}
    className={`
      flex items-center gap-4 p-4 bg-white/5 border border-white/5 rounded-xl 
      ${onClick ? 'cursor-pointer hover:bg-white/10' : ''} transition-colors
    `}
  >
    {Icon && (
      <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center shrink-0">
        <Icon size={20} className="text-blue-400" />
      </div>
    )}
    <div className="flex-1 min-w-0">
      <div className="text-sm font-medium text-slate-200">{title}</div>
      {subtitle && <div className="text-xs text-slate-400 mt-0.5">{subtitle}</div>}
    </div>
    <div className="flex items-center gap-2">
      {children}
    </div>
  </div>
);

// --- Main Component ---
const SettingsApp: React.FC = () => {
  const { 
    wallpaper, setWallpaper, installedApps, uninstallApp, installApp,
    users, currentUser, updateUser, addUser, removeUser, logout,
    hardwareConfig, setHardwareConfig,
    serialStatus, sensorReadings, connectSerial, disconnectSerial,
    bluetoothDevices, scanBluetooth, pairDevice, unpairDevice, fileTransfers,
    timeOffset, isAutoTime, setTimeConfig, addNotification,
    isCloudEnabled, setCloudEnabled, factoryReset,
    pluginState, togglePlugin, openApp,
    aiMode, setAIMode, localModelStatus, loadLocalModel, modelLoadingProgress,
    bridgeState
  } = useOS();
  
  const [activeTab, setActiveTab] = useState('system');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // New User Form State
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserPin, setNewUserPin] = useState('');
  const [newUserAdmin, setNewUserAdmin] = useState(false);

  // Scanning State
  const [isScanning, setIsScanning] = useState(false);

  // Time Form State
  const [manualDate, setManualDate] = useState('');
  const [manualTime, setManualTime] = useState('');

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // -- Local Simulated State --
  const [deviceName, setDeviceName] = useState('Robot-Master-Pi5');
  const [btEnabled, setBtEnabled] = useState(true);
  const [wifiEnabled, setWifiEnabled] = useState(true);
  const [appSearch, setAppSearch] = useState('');

  // Sensor Data Source (Mock vs Real)
  const isConnected = serialStatus === 'connected';

  const displaySensors = [
      { 
          name: "LDS Laser", 
          type: "Lidar", 
          status: isConnected ? sensorReadings.lidarStatus : "Scanning", 
          value: isConnected ? "Active" : "360° Map" 
      },
      // ... (other sensors same as before)
  ];

  // Apps Calculation
  const allPossibleApps = Object.values(APP_CONFIGS);

  const handleToggleInstall = (appId: AppID) => {
      const isInstalled = installedApps.some(a => a.id === appId);
      if (isInstalled) {
          if (APP_CONFIGS[appId].isSystem) {
              alert('Cannot uninstall system app');
              return;
          }
          if (confirm(`Uninstall ${APP_CONFIGS[appId].name}?`)) {
              uninstallApp(appId);
          }
      } else {
          (installApp as any)(appId); 
      }
  };

  const handleCreateUser = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newUserName.trim()) return;
      
      const colors = ['bg-blue-600', 'bg-green-600', 'bg-purple-600', 'bg-orange-600', 'bg-red-600'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      
      addUser({
          username: newUserName,
          pin: newUserPin,
          isAdmin: newUserAdmin,
          avatarColor: randomColor
      });
      
      setNewUserName('');
      setNewUserPin('');
      setShowAddUser(false);
  };

  const handleSavePiConfig = () => {
    alert("Configuration saved to EEPROM. Changes will persist across reboots.");
  };

  const handleScanBluetooth = () => {
      if (!btEnabled) return;
      setIsScanning(true);
      scanBluetooth();
      setTimeout(() => setIsScanning(false), 2000);
  };

  const handleTimeChange = () => {
      if (!manualDate || !manualTime) return;
      const newTime = new Date(`${manualDate}T${manualTime}`);
      if (!isNaN(newTime.getTime())) {
          setTimeConfig({ isAuto: false, offset: newTime.getTime() - Date.now() });
          addNotification({ title: 'Time Updated', message: 'System clock updated manually.', type: 'success' });
      }
  };

  const handleSyncTime = () => {
      setIsScanning(true); // Reuse scanning state for loading
      setTimeout(() => {
          setTimeConfig({ isAuto: true, offset: 0 });
          setIsScanning(false);
          addNotification({ title: 'Time Synced', message: 'Synchronized with time.windows.com (Simulated)', type: 'success' });
      }, 1500);
  };

  const getDeviceIcon = (type: string) => {
      switch (type) {
          case 'phone': return Smartphone;
          case 'laptop': return Laptop;
          case 'tablet': return Tablet;
          case 'headphones': return Headphones;
          default: return Bluetooth;
      }
  };

  const menuItems = [
    { id: 'system', icon: Monitor, label: 'System' },
    { id: 'power', icon: Zap, label: 'Power Grid' }, // Renamed from Battery/Power
    { id: 'intelligence', icon: Brain, label: 'Intelligence' }, // New Tab
    { id: 'robot_sensors', icon: Activity, label: 'Robot Sensors' },
    { id: 'bluetooth', icon: Bluetooth, label: 'Bluetooth & devices' },
    { id: 'network', icon: Wifi, label: 'Network & internet' },
    { id: 'personalization', icon: Palette, label: 'Personalization' },
    { id: 'apps', icon: Shield, label: 'Apps' },
    { id: 'accounts', icon: User, label: 'Accounts' },
    { id: 'time', icon: Clock, label: 'Time & language' },
    { id: 'extensions', icon: Puzzle, label: 'Extensions' },
    { id: 'pi_config', icon: CircuitBoard, label: 'Pi5 Boot Config' },
    { id: 'venv', icon: Box, label: 'Developer & Venv' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'system':
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            {/* Device Hero */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col md:flex-row items-center gap-6">
              <div className="w-24 h-24 bg-gradient-to-br from-green-600 to-emerald-500 rounded-lg shadow-2xl flex items-center justify-center shrink-0 border border-white/10">
                 <CircuitBoard size={48} className="text-white/80" />
              </div>
              <div className="text-center md:text-left flex-1">
                 <h2 className="text-2xl font-bold text-white mb-1">{deviceName}</h2>
                 <p className="text-slate-400 text-sm">WinOS Hybrid • Robotics Edition</p>
                 <div className="flex items-center gap-2 mt-3 justify-center md:justify-start">
                    <button 
                        onClick={() => {
                            const newName = prompt("Enter new device name:", deviceName);
                            if (newName) setDeviceName(newName);
                        }}
                        className="text-xs bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-md transition-colors font-medium"
                    >
                      Rename
                    </button>
                    <button className="text-xs bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-md transition-colors font-medium flex items-center gap-1">
                      <Copy size={12} /> Copy info
                    </button>
                 </div>
              </div>
            </div>

            {/* Specs List */}
            <div>
              <h3 className="text-sm font-semibold text-slate-400 mb-3 px-1">Hardware Specifications</h3>
              <div className="grid grid-cols-1 gap-2">
                <SettingRow icon={Cpu} title="Master Processor" subtitle={`Broadcom BCM2712 @ ${hardwareConfig.overclock ? '2.8GHz (OC)' : '2.4GHz'}`} />
                <SettingRow icon={Cpu} title="Slave Controllers" subtitle="5x RP2040 (Raspberry Pi Pico) via UART" />
                <SettingRow icon={MemoryStick} title="Installed RAM" subtitle={hardwareConfig.ramSize} />
                <SettingRow icon={Battery} title="Power System" subtitle="3S 20A BMS Li-ion Array" />
                <SettingRow icon={HardDrive} title="Storage" subtitle="SD Card + NVMe (Hybrid Boot)" />
              </div>
            </div>
            
             <div className="bg-slate-800/30 rounded-lg p-4 border border-white/5">
               <h3 className="text-sm font-semibold text-slate-400 mb-2">OS Specifications</h3>
               <div className="space-y-1 text-sm">
                  <div className="flex justify-between py-1 border-b border-white/5">
                     <span className="text-slate-400">Distro</span>
                     <span className="text-slate-200">WinOS Hybrid (React Kernel)</span>
                  </div>
                  <div className="flex justify-between py-1">
                     <span className="text-slate-400">Version</span>
                     <span className="text-slate-200">1.3.0 (Resilience Update)</span>
                  </div>
               </div>
            </div>

            {/* Recovery */}
            <div className="bg-red-900/10 border border-red-500/20 rounded-xl p-4">
               <h3 className="text-sm font-semibold text-red-400 mb-2 flex items-center gap-2">
                   <RotateCcw size={16} /> Recovery
               </h3>
               <p className="text-xs text-slate-300 mb-4">
                   If your PC isn't running well, resetting it might help. This lets you reinstall WinOS Hybrid.
               </p>
               <button 
                   onClick={factoryReset}
                   className="bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors"
               >
                   Reset this PC
               </button>
            </div>
          </div>
        );

      case 'intelligence':
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-white/10 rounded-xl p-6 flex flex-col md:flex-row items-center gap-6">
                    <div className="w-20 h-20 bg-black/40 rounded-full flex items-center justify-center border border-white/20">
                        {aiMode === 'cloud' ? <CloudLightning size={32} className="text-blue-400" /> : 
                         aiMode === 'local' ? <Cpu size={32} className="text-green-400" /> : 
                         <Activity size={32} className="text-purple-400" />}
                    </div>
                    <div className="flex-1">
                        <h2 className="text-2xl font-bold mb-1">Hybrid Intelligence</h2>
                        <p className="text-sm text-slate-300 mb-2">Layer 4 Logic Processing Unit</p>
                        <div className="flex gap-2">
                            <span className="text-xs bg-white/10 px-2 py-1 rounded">Active Mode: <strong className="uppercase">{aiMode}</strong></span>
                            {localModelStatus !== 'unloaded' && (
                                <span className={`text-xs px-2 py-1 rounded ${localModelStatus === 'ready' ? 'bg-green-900/30 text-green-400' : localModelStatus === 'error' ? 'bg-red-900/30 text-red-400' : 'bg-yellow-900/30 text-yellow-400'}`}>
                                    Local Model: {localModelStatus.toUpperCase()}
                                </span>
                            )}
                        </div>
                    </div>
                </div>

                <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-slate-400 px-1">Inference Provider</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <button 
                            onClick={() => setAIMode('cloud')}
                            className={`p-4 rounded-xl border text-left transition-all ${aiMode === 'cloud' ? 'bg-blue-600/20 border-blue-500' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                        >
                            <CloudLightning size={24} className="mb-2 text-blue-400" />
                            <div className="font-bold text-sm">Cloud Priority</div>
                            <div className="text-xs text-slate-400 mt-1">Gemini 3 Flash. High capability, requires internet.</div>
                        </button>
                        <button 
                            onClick={() => setAIMode('local')}
                            className={`p-4 rounded-xl border text-left transition-all ${aiMode === 'local' ? 'bg-green-600/20 border-green-500' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                        >
                            <Cpu size={24} className="mb-2 text-green-400" />
                            <div className="font-bold text-sm">Privacy Mode</div>
                            <div className="text-xs text-slate-400 mt-1">Local Llama-3-8B. Offline, private, lower latency.</div>
                        </button>
                        <button 
                            onClick={() => setAIMode('hybrid')}
                            className={`p-4 rounded-xl border text-left transition-all ${aiMode === 'hybrid' ? 'bg-purple-600/20 border-purple-500' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                        >
                            <Activity size={24} className="mb-2 text-purple-400" />
                            <div className="font-bold text-sm">Adaptive Hybrid</div>
                            <div className="text-xs text-slate-400 mt-1">Auto-switch based on sensitive data or network.</div>
                        </button>
                    </div>
                </div>

                {/* Local Model Settings & Progress */}
                {(aiMode === 'local' || aiMode === 'hybrid') && (
                    <div className="bg-white/5 border border-white/5 rounded-xl p-4 animate-in fade-in">
                        <h3 className="text-sm font-semibold mb-3">Local Model Configuration</h3>
                        
                        {modelLoadingProgress && (
                            <div className="mb-4 bg-slate-800/50 p-3 rounded-lg border border-blue-500/20">
                                <div className="flex justify-between text-xs mb-1 text-slate-300">
                                    <span>Downloading Weights...</span>
                                    <span>{modelLoadingProgress.progress}%</span>
                                </div>
                                <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden mb-2">
                                    <div 
                                        className="h-full bg-blue-500 transition-all duration-300"
                                        style={{ width: `${modelLoadingProgress.progress}%` }}
                                    />
                                </div>
                                <div className="text-[10px] text-slate-400 font-mono truncate">
                                    {modelLoadingProgress.text}
                                </div>
                            </div>
                        )}

                        <div className="space-y-2">
                            <SettingRow icon={Cpu} title="Llama-3-8B-Instruct (WebGPU)" subtitle="Requires ~6GB VRAM/RAM. Downloads once.">
                                {localModelStatus === 'unloaded' || localModelStatus === 'error' ? (
                                    <button 
                                        onClick={loadLocalModel}
                                        className="text-xs bg-green-600 hover:bg-green-500 text-white px-3 py-1.5 rounded transition-colors"
                                    >
                                        Load Model
                                    </button>
                                ) : (
                                    <span className="text-xs bg-green-900/30 text-green-400 px-3 py-1.5 rounded border border-green-500/30">
                                        {localModelStatus === 'loading' ? 'Loading...' : 'Loaded'}
                                    </span>
                                )}
                            </SettingRow>
                            <SettingRow icon={Zap} title="GPU Acceleration" subtitle="WebGPU / NPU Backend">
                                <ToggleSwitch checked={true} onChange={() => {}} />
                            </SettingRow>
                        </div>
                    </div>
                )}
            </div>
        );
      
      case 'power':
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                        <Zap className="text-yellow-400" /> Power Grid Topology
                    </h2>
                    <div className="text-xs font-mono text-slate-400">BMS: ACTIVE • RAIL: STABLE</div>
                </div>

                {/* Primary Rails */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {bridgeState.power.rails.map(rail => (
                        <div key={rail.id} className="bg-white/5 border border-white/5 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden">
                            <div className={`absolute top-0 right-0 w-16 h-16 rounded-full blur-2xl opacity-20 ${rail.status === 'stable' ? 'bg-green-500' : 'bg-red-500'}`} />
                            <div className="flex justify-between items-center">
                                <span className="text-lg font-bold text-white">{rail.id.toUpperCase().replace('RAIL_', '')}</span>
                                <span className={`text-xs px-2 py-0.5 rounded ${rail.status === 'stable' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{rail.status.toUpperCase()}</span>
                            </div>
                            <div className="text-2xl font-mono text-slate-200">{rail.voltage.toFixed(2)}V</div>
                            <div className="flex justify-between text-xs text-slate-400">
                                <span>{rail.current}A</span>
                                <span>Load: {rail.load}%</span>
                            </div>
                            <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-1">
                                <div className={`h-full ${rail.status === 'stable' ? 'bg-green-500' : 'bg-red-500'}`} style={{ width: `${rail.load}%` }} />
                            </div>
                        </div>
                    ))}
                </div>

                {/* BMS Cells */}
                <div className="bg-slate-800/50 border border-white/5 rounded-xl p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-bold text-slate-300">3S 20A BMS Array</h3>
                        <span className="text-xs font-mono text-green-400">{bridgeState.power.bms[0].totalVoltage.toFixed(2)}V Total</span>
                    </div>
                    <div className="flex gap-4">
                        {bridgeState.power.bms[0].cells.map(cell => (
                            <div key={cell.id} className="flex-1 bg-black/20 p-3 rounded-lg border border-white/5 flex flex-col items-center gap-1">
                                <div className="text-xs text-slate-500">CELL {cell.id}</div>
                                <div className="h-16 w-8 bg-slate-700 rounded-md relative overflow-hidden border border-slate-600">
                                    <div 
                                        className="absolute bottom-0 w-full bg-green-500 transition-all duration-500"
                                        style={{ height: `${((cell.voltage - 3.0) / 1.2) * 100}%` }}
                                    />
                                </div>
                                <div className="text-xs font-mono">{cell.voltage.toFixed(2)}V</div>
                                {cell.balance && <span className="text-[9px] text-yellow-400 animate-pulse">BALANCING</span>}
                            </div>
                        ))}
                    </div>
                </div>

                {/* MOSFET Controls */}
                <div>
                    <h3 className="text-sm font-bold text-slate-400 mb-3 uppercase tracking-wider">Active Switching (MOSFETs)</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {bridgeState.power.mosfets.map(mos => (
                            <div key={mos.id} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg">
                                <div className="flex items-center gap-3">
                                    <div className={`w-8 h-8 rounded flex items-center justify-center ${mos.state === 'on' ? 'bg-green-500/20 text-green-400' : 'bg-slate-700 text-slate-500'}`}>
                                        <Power size={16} />
                                    </div>
                                    <div>
                                        <div className="text-sm font-medium">{mos.name}</div>
                                        <div className="text-xs text-slate-500">{mos.load}</div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className={`text-xs font-bold ${mos.state === 'on' ? 'text-green-400' : 'text-slate-500'}`}>{mos.state.toUpperCase()}</div>
                                    <div className="text-[10px] text-slate-500">PWM: {mos.pwm}%</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );

      case 'extensions':
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-lg font-bold">Extensions</h2>
                        <p className="text-xs text-slate-400">Manage dynamically loaded skills and drivers (Layer 16)</p>
                    </div>
                    <button 
                        onClick={() => openApp(AppID.APP_STORE)}
                        className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2"
                    >
                        <Download size={14} /> Browse Store
                    </button>
                </div>

                <div className="space-y-4">
                    {pluginState.map(plugin => (
                        <div key={plugin.id} className="bg-white/5 border border-white/5 rounded-xl p-4 flex items-start gap-4">
                            <div className={`p-3 rounded-lg ${plugin.metadata.type === 'skill' ? 'bg-purple-500/20 text-purple-400' : 'bg-green-500/20 text-green-400'}`}>
                                {plugin.metadata.type === 'skill' ? <Brain size={24} /> : <Cpu size={24} />}
                            </div>
                            <div className="flex-1">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="font-bold text-sm">{plugin.metadata.name}</h3>
                                        <div className="text-xs text-slate-400">v{plugin.metadata.version} • by {plugin.metadata.author}</div>
                                    </div>
                                    <ToggleSwitch checked={plugin.isEnabled} onChange={() => togglePlugin(plugin.id)} />
                                </div>
                                <p className="text-xs text-slate-300 mt-2">{plugin.metadata.description}</p>
                                <div className="flex gap-2 mt-3">
                                    <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded text-slate-400 uppercase tracking-wider">{plugin.metadata.type}</span>
                                    {plugin.isEnabled && (
                                        <span className="text-[10px] text-green-400 flex items-center gap-1">
                                            <Activity size={10} /> Active ({plugin.memoryUsage}MB)
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                    {pluginState.length === 0 && (
                        <div className="text-center py-10 text-slate-500 text-sm">
                            No extensions installed. Visit the App Store to add new skills.
                        </div>
                    )}
                </div>
            </div>
        );
    }
    
    if (activeTab === 'time') {
        const currentTime = new Date(Date.now() + timeOffset);
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-white/5 border border-white/10 rounded-xl p-6 text-center">
                    <div className="text-4xl font-light mb-1">{currentTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                    <div className="text-sm text-slate-400">{currentTime.toLocaleDateString(undefined, {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'})}</div>
                </div>
                <div className="space-y-2">
                    <SettingRow icon={Clock} title="Set time automatically" subtitle="Synchronize with time.windows.com">
                        <ToggleSwitch checked={isAutoTime} onChange={(v) => v ? handleSyncTime() : setTimeConfig({ isAuto: false, offset: timeOffset })} />
                    </SettingRow>
                    {!isAutoTime && (
                        <div className="bg-white/5 border border-white/5 rounded-xl p-4 space-y-4 animate-in fade-in">
                            <div className="flex flex-col gap-2">
                                <label className="text-xs text-slate-400">Set Date & Time Manually</label>
                                <div className="flex gap-2">
                                    <input type="date" className="bg-slate-800 border border-white/10 rounded px-3 py-2 text-sm outline-none" onChange={(e) => setManualDate(e.target.value)} />
                                    <input type="time" className="bg-slate-800 border border-white/10 rounded px-3 py-2 text-sm outline-none" onChange={(e) => setManualTime(e.target.value)} />
                                    <button onClick={handleTimeChange} className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded text-sm font-medium transition-colors">Change</button>
                                </div>
                            </div>
                        </div>
                    )}
                    <SettingRow icon={Globe} title="Set time zone automatically" subtitle="UTC-07:00 Pacific Time (US & Canada)">
                        <ToggleSwitch checked={true} onChange={() => {}} />
                    </SettingRow>
                    <button onClick={handleSyncTime} disabled={isScanning} className="w-full flex items-center justify-center gap-2 p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl transition-colors text-sm font-medium disabled:opacity-50">
                        {isScanning ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
                        {isScanning ? 'Syncing...' : 'Sync now'}
                    </button>
                </div>
            </div>
        );
    }
    
    if (activeTab === 'robot_sensors') {
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex justify-between items-center mb-2">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                        Real-time Telemetry
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${isConnected ? 'bg-green-500/20 border-green-500/50 text-green-400' : 'bg-slate-500/20 border-slate-500/50 text-slate-400'}`}>{isConnected ? 'LIVE' : 'SIMULATION'}</span>
                    </h2>
                    <button onClick={isConnected ? disconnectSerial : connectSerial} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${isConnected ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white'}`}>
                        {isConnected ? <Link2Off size={16} /> : <Link2 size={16} />} {isConnected ? 'Disconnect' : 'Connect Hardware'}
                    </button>
                </div>
                <div className="flex gap-4">
                     <div className="flex-1 bg-green-900/20 border border-green-500/30 rounded-xl p-6 flex flex-col items-center justify-center gap-2">
                        <Radar size={48} className={`text-green-400 ${isConnected ? 'animate-[spin_4s_linear_infinite]' : 'animate-pulse'}`} />
                        <div className="text-lg font-bold">LDS Lidar</div>
                        <div className="text-xs text-green-200">Scanning Area</div>
                     </div>
                     <div className="flex-1 bg-white/5 border border-white/5 rounded-xl p-6 flex flex-col gap-4">
                        <div className="flex justify-between items-center"><span className="text-sm text-slate-400">Battery (3S Pack)</span></div>
                        <div className="flex items-end gap-1"><span className="text-3xl font-light">{isConnected ? sensorReadings.batteryVoltage.toFixed(1) : '11.8'}</span><span className="text-sm font-medium text-slate-400 mb-1">V</span></div>
                        <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-green-500 transition-all duration-500" style={{ width: `${Math.min(100, Math.max(0, ((isConnected ? sensorReadings.batteryVoltage : 11.8) - 9) / (12.6 - 9) * 100))}%` }} /></div>
                     </div>
                </div>
                <div>
                    <h3 className="text-sm font-semibold text-slate-400 mb-3 px-1">Connected Sensors (I2C/UART)</h3>
                    <div className="space-y-2">
                        {displaySensors.map((s, idx) => (
                            <div key={idx} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg">
                                <div className="flex items-center gap-3"><div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center text-blue-400"><Activity size={16} /></div><div><div className="text-sm font-medium text-slate-200">{s.name}</div><div className="text-xs text-slate-400">{s.type}</div></div></div>
                                <div className="text-right"><div className="text-sm font-mono text-green-400">{s.value}</div><div className="text-[10px] text-slate-500 uppercase">{s.status}</div></div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    if (activeTab === 'bluetooth') {
        return (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
             <SettingRow title="Bluetooth" subtitle={btEnabled ? "Discoverable as \"" + deviceName + "\"" : "Turned off"}><ToggleSwitch checked={btEnabled} onChange={setBtEnabled} /></SettingRow>
             {btEnabled && (
                 <>
                    <div className="flex justify-between items-center px-1"><h3 className="text-sm font-semibold text-slate-400">Available Devices</h3><button onClick={handleScanBluetooth} disabled={isScanning} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${isScanning ? 'bg-white/5 text-slate-400 cursor-wait' : 'bg-blue-600/20 text-blue-400 hover:bg-blue-600/30'}`}>{isScanning ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} {isScanning ? 'Scanning...' : 'Scan'}</button></div>
                    <div className="space-y-2">
                        {bluetoothDevices.map(device => {
                            const DeviceIcon = getDeviceIcon(device.type);
                            return (
                                <div key={device.id} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg">
                                    <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-blue-400"><DeviceIcon size={20} /></div><div><div className="text-sm font-medium text-slate-200">{device.name}</div><div className="flex items-center gap-2"><span className={`text-[10px] uppercase font-bold ${device.status === 'connected' ? 'text-green-400' : device.status === 'pairing' ? 'text-yellow-400' : 'text-slate-500'}`}>{device.status}</span><span className="text-[10px] text-slate-500">• Signal: {device.signal}%</span></div></div></div>
                                    {device.status === 'connected' ? <button onClick={() => unpairDevice(device.id)} className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-medium transition-colors">Disconnect</button> : <button onClick={() => pairDevice(device.id)} disabled={device.status === 'pairing'} className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors disabled:opacity-50">{device.status === 'pairing' ? 'Pairing...' : 'Connect'}</button>}
                                </div>
                            );
                        })}
                        {bluetoothDevices.length === 0 && !isScanning && <div className="text-center py-8 text-slate-500 text-sm">No devices found. Click scan to search.</div>}
                    </div>
                    {fileTransfers.length > 0 && (
                        <div className="mt-6"><h3 className="text-sm font-semibold text-slate-400 mb-3 px-1">File Transfers</h3><div className="space-y-2">{fileTransfers.map(tf => (<div key={tf.id} className="bg-white/5 border border-white/5 rounded-lg p-3"><div className="flex justify-between text-xs mb-1"><span className="font-medium flex items-center gap-2"><FileText size={12} className="text-blue-400" />{tf.fileName}</span><span className="text-slate-400">{tf.progress}%</span></div><div className="w-full h-1 bg-slate-700 rounded-full overflow-hidden"><div className={`h-full transition-all duration-200 ${tf.status === 'failed' ? 'bg-red-500' : 'bg-blue-500'}`} style={{ width: `${tf.progress}%` }} /></div><div className="flex justify-between mt-1"><span className="text-[10px] text-slate-500 uppercase">{tf.direction}</span><span className="text-[10px] text-slate-500 uppercase">{tf.status}</span></div></div>))}</div></div>
                    )}
                 </>
             )}
          </div>
        );
    }

    if (activeTab === 'network') {
        return (
           <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
             <div className="flex gap-4">
                 <div className="flex-1 bg-blue-600/20 border border-blue-500/30 rounded-xl p-6 flex flex-col items-center justify-center gap-2"><Wifi size={48} className="text-blue-400" /><div className="text-lg font-bold">Connected</div><div className="text-xs text-blue-200">WinOS_5G_Secure</div></div>
                 <div className="flex-1 bg-white/5 border border-white/5 rounded-xl p-6 flex flex-col gap-4"><div className="flex justify-between items-center"><span className="text-sm text-slate-400">ESP8266 Telemetry</span><span className="text-xs text-green-400">Active</span></div><div className="flex items-end gap-1"><span className="text-3xl font-light">14</span><span className="text-sm font-medium text-slate-400 mb-1">ms latency</span></div></div>
             </div>
             <SettingRow title="Wi-Fi" subtitle={wifiEnabled ? "On, connected" : "Off"}><ToggleSwitch checked={wifiEnabled} onChange={setWifiEnabled} /></SettingRow>
             <SettingRow icon={Cloud} title="Cloud Sync Simulation" subtitle="Enable latency to simulate remote storage operations"><ToggleSwitch checked={isCloudEnabled} onChange={setCloudEnabled} /></SettingRow>
           </div>
        );
    }

    if (activeTab === 'personalization') {
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="space-y-4"><h2 className="text-sm font-medium text-slate-400">Current Background</h2><div className="relative w-full h-48 rounded-xl overflow-hidden border border-white/10 shadow-lg group"><img src={wallpaper} alt="Current Wallpaper" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" /></div></div>
            <div className="space-y-4">
               <h2 className="text-sm font-medium text-slate-400">Select a Theme</h2>
               <div className="grid grid-cols-2 md:grid-cols-3 gap-4">{WALLPAPER_PRESETS.map((wp) => (<button key={wp.url} onClick={() => setWallpaper(wp.url)} className={`relative group rounded-lg overflow-hidden border-2 transition-all duration-200 ${wallpaper === wp.url ? 'border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.5)] scale-[1.02]' : 'border-transparent hover:border-white/20 hover:scale-[1.01]'}`}><div className="aspect-video bg-slate-800"><img src={wp.url} alt={wp.name} className="w-full h-full object-cover" loading="lazy" /></div>{wallpaper === wp.url && (<div className="absolute top-2 right-2 bg-blue-500 text-white p-1 rounded-full shadow-lg"><Check size={12} strokeWidth={3} /></div>)}<div className="absolute bottom-0 left-0 right-0 bg-black/60 backdrop-blur-sm p-2 transform translate-y-full group-hover:translate-y-0 transition-transform"><span className="text-xs font-medium text-white">{wp.name}</span></div></button>))}</div>
            </div>
          </div>
        );
    }

    if (activeTab === 'apps') {
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300 relative h-full flex flex-col">
                <div className="flex items-center gap-3"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} /><input type="text" placeholder="Search apps..." value={appSearch} onChange={(e) => setAppSearch(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-blue-500" /></div></div>
                <div className="space-y-2 overflow-y-auto flex-1 pr-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-500 px-4"><span>Application</span><span>Status</span></div>
                    {allPossibleApps.filter(app => app.name.toLowerCase().includes(appSearch.toLowerCase())).map(app => {
                            const isInstalled = installedApps.some(a => a.id === app.id);
                            return (
                                <div key={app.id} className="group flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-colors">
                                    <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-blue-400"><app.icon size={20} /></div><div><div className="text-sm font-medium text-slate-200">{app.name}</div><div className="text-xs text-slate-400">v{app.version} • {app.size}</div></div></div>
                                    <div className="flex items-center gap-2">{app.isSystem && (<span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full mr-2">System</span>)}<button onClick={() => handleToggleInstall(app.id)} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${isInstalled ? 'bg-white/5 text-slate-300 hover:bg-red-500/20 hover:text-red-300' : 'bg-blue-600 text-white hover:bg-blue-500'} ${app.isSystem ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={app.isSystem}>{isInstalled ? <Trash2 size={14} /> : <Download size={14} />} {isInstalled ? 'Uninstall' : 'Install'}</button></div>
                                </div>
                            );
                        })}
                </div>
            </div>
        );
    }

    if (activeTab === 'accounts') {
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                {currentUser && (<div className="bg-white/5 border border-white/10 rounded-xl p-6 flex items-center gap-6"><div className="relative group cursor-pointer"><div className={`w-20 h-20 rounded-full ${currentUser.avatarColor} flex items-center justify-center text-2xl font-bold shadow-lg`}>{currentUser.username.substring(0,1).toUpperCase()}</div></div><div className="flex-1"><h2 className="text-xl font-bold flex items-center gap-2">{currentUser.username}{currentUser.isAdmin && (<span title="Administrator" className="flex items-center"><Shield size={16} className="text-yellow-400" /></span>)}</h2><p className="text-slate-400 text-sm">{currentUser.isAdmin ? 'Administrator' : 'Standard User'} • Local Account</p></div><button onClick={logout} className="bg-white/10 hover:bg-red-500/20 hover:text-red-400 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors text-sm font-medium"><LogOut size={16} /> Sign out</button></div>)}
                <div className="h-[1px] bg-white/10 my-4" />
                <div><div className="flex justify-between items-center mb-4"><h3 className="text-sm font-semibold text-slate-400">Other Users</h3>{currentUser?.isAdmin && !showAddUser && (<button onClick={() => setShowAddUser(true)} className="text-xs bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded flex items-center gap-1 transition-colors"><UserPlus size={14} /> Add User</button>)}</div>
                     {showAddUser && (<form onSubmit={handleCreateUser} className="bg-white/5 border border-white/10 rounded-lg p-4 mb-4 flex flex-col gap-3"><div className="grid grid-cols-2 gap-3"><input type="text" placeholder="Username" value={newUserName} onChange={e => setNewUserName(e.target.value)} className="bg-slate-900 border border-white/10 rounded px-3 py-2 text-sm outline-none focus:border-blue-500" required /><input type="text" placeholder="PIN (Optional)" value={newUserPin} onChange={e => setNewUserPin(e.target.value)} className="bg-slate-900 border border-white/10 rounded px-3 py-2 text-sm outline-none focus:border-blue-500" /></div><div className="flex items-center gap-2"><input type="checkbox" id="isAdmin" checked={newUserAdmin} onChange={e => setNewUserAdmin(e.target.checked)} /><label htmlFor="isAdmin" className="text-sm text-slate-300 select-none">Administrator privileges</label></div><div className="flex justify-end gap-2 mt-2"><button type="button" onClick={() => setShowAddUser(false)} className="text-xs px-3 py-1.5 hover:bg-white/10 rounded">Cancel</button><button type="submit" className="text-xs bg-blue-600 px-3 py-1.5 rounded text-white">Create</button></div></form>)}
                     <div className="space-y-2">{users.filter(u => u.id !== currentUser?.id).map(user => (<div key={user.id} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg"><div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-full ${user.avatarColor} flex items-center justify-center font-bold text-sm`}>{user.username.substring(0,1).toUpperCase()}</div><div><div className="text-sm font-medium text-slate-200">{user.username}</div><div className="text-xs text-slate-400">{user.isAdmin ? 'Admin' : 'User'}</div></div></div>{currentUser?.isAdmin && (<button onClick={() => {if (confirm(`Are you sure you want to delete ${user.username}?`)) {removeUser(user.id);}}} className="p-2 hover:bg-white/10 rounded-lg text-slate-500 hover:text-red-400 transition-colors" title="Delete User"><Trash2 size={16} /></button>)}</div>))}{users.length === 1 && !showAddUser && (<div className="text-center py-4 text-sm text-slate-500 italic">No other users found.</div>)}</div>
                </div>
            </div>
        );
    }

    if (activeTab === 'pi_config') {
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-xl flex gap-3"><Info className="text-yellow-500 shrink-0" size={20} /><div><h4 className="text-sm font-bold text-yellow-500 mb-1">Advanced Configuration</h4><p className="text-xs text-slate-300">Modifying EEPROM settings and overclocking values may cause system instability or boot failures. Proceed with caution.</p></div></div>
                <div><h3 className="text-sm font-semibold text-slate-400 mb-3 px-1 uppercase tracking-wider">EEPROM & Boot</h3><div className="grid grid-cols-1 gap-2"><SettingRow icon={CircuitBoard} title="Boot Order" subtitle="Define the priority of boot devices"><select value={hardwareConfig.bootOrder} onChange={(e) => setHardwareConfig({...hardwareConfig, bootOrder: e.target.value})} className="bg-slate-800 border border-white/10 rounded px-2 py-1 text-xs text-white outline-none focus:border-blue-500"><option>0xf41 (SD -> NVMe -> USB)</option><option>0xf14 (NVMe -> USB -> SD)</option><option>0x41 (SD -> USB)</option><option>0x1 (SD Card Only)</option></select></SettingRow><SettingRow icon={HardDrive} title="NVMe Boot" subtitle="Enable booting from PCIe storage"><ToggleSwitch checked={true} onChange={() => {}} /></SettingRow><SettingRow icon={Zap} title="Overclock (2.8GHz)" subtitle="Requires active cooling"><ToggleSwitch checked={hardwareConfig.overclock} onChange={(v) => setHardwareConfig({...hardwareConfig, overclock: v})} /></SettingRow><SettingRow icon={Activity} title="Fast Boot" subtitle="Skip extensive POST checks"><ToggleSwitch checked={hardwareConfig.fastBoot} onChange={(v) => setHardwareConfig({...hardwareConfig, fastBoot: v})} /></SettingRow></div></div>
                <div className="flex justify-end pt-4 border-t border-white/5"><button onClick={handleSavePiConfig} className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-lg shadow-blue-500/20 transition-all active:scale-95 font-medium"><Save size={16} /> Save to EEPROM</button></div>
            </div>
        );
    }

    if (activeTab === 'venv') {
        return (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300 h-full flex flex-col">
                <div className="flex items-center justify-between"><div className="flex items-center gap-3"><div className="w-10 h-10 bg-blue-600/20 rounded-lg flex items-center justify-center text-blue-400"><Box size={20} /></div><div><h2 className="text-lg font-bold">Dependency Manager</h2><p className="text-xs text-slate-400">Manage Python virtual environments</p></div></div></div>
                <div className="p-4 bg-white/5 border border-white/5 rounded-xl text-center text-slate-400 text-sm">Venv management is active.</div>
            </div>
        );
    }

    return null;
  };

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 relative">
      {/* Sidebar */}
      <div className={`
        w-64 bg-slate-900/90 backdrop-blur-xl border-r border-white/5 p-4 flex flex-col gap-1
        transition-transform duration-300 z-50
        ${isMobile ? 'absolute h-full' : 'relative'}
        ${isMobile && !isSidebarOpen ? '-translate-x-full' : 'translate-x-0'}
      `}>
        {isMobile && (
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full"
          >
            <X size={20} />
          </button>
        )}
        <div className="mb-6 px-4 py-2 flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full ${currentUser?.avatarColor || 'bg-blue-600'} flex items-center justify-center text-sm font-bold`}>
                {currentUser?.username.substring(0,1).toUpperCase()}
            </div>
            <div className="flex flex-col">
                <span className="text-sm font-medium truncate max-w-[120px]">{currentUser?.username}</span>
                <span className="text-xs text-slate-400">Local Account</span>
            </div>
        </div>
        
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              if (isMobile) setIsSidebarOpen(false);
            }}
            className={`
              flex items-center gap-3 px-4 py-2.5 rounded-md text-sm transition-all
              ${activeTab === item.id 
                ? 'bg-white/10 text-white font-medium shadow-sm' 
                : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
              }
            `}
          >
            <item.icon size={18} />
            <span>{item.label}</span>
            {activeTab === item.id && (
                <div className="ml-auto w-1 h-4 bg-blue-500 rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="flex items-center gap-4 mb-6">
          {isMobile && (
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 hover:bg-white/10 rounded-lg text-slate-400"
            >
              <Menu size={24} />
            </button>
          )}
          <h1 className="text-xl md:text-2xl font-semibold">
            {menuItems.find(i => i.id === activeTab)?.label}
          </h1>
        </div>
        {renderContent()}
      </div>

      {/* Mobile Backdrop */}
      {isMobile && isSidebarOpen && (
        <div 
          className="absolute inset-0 bg-black/40 backdrop-blur-sm z-40 animate-in fade-in"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default SettingsApp;
