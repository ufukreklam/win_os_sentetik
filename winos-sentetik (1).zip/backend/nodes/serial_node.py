
import asyncio
import logging
import json
import random
import serial
import serial.tools.list_ports
from ..core.robot_system import RobotNode

logger = logging.getLogger("SerialNode")

class SerialNode(RobotNode):
    """
    RPi Pico (Slave) cihazları ile seri port (USB/UART) üzerinden konuşur.
    Donanım yoksa simülasyon moduna geçer.
    """
    def __init__(self, bus, port=None, baudrate=115200):
        super().__init__("SerialNode", bus)
        self.port = port
        self.baudrate = baudrate
        self.serial_connection = None
        self.loop_interval = 0.05 # 20Hz okuma döngüsü
        self.simulated_mode = False
        
    async def setup(self):
        # ControlNode'dan gelen işlenmiş motor komutlarını dinle
        self.bus.subscribe("serial_write", self.handle_serial_write)
        await self.connect()

    async def connect(self):
        """Seri porta bağlanmayı dener, bulamazsa simülasyonu açar"""
        if self.serial_connection and self.serial_connection.is_open:
            return

        try:
            target_port = self.port
            if not target_port:
                ports = list(serial.tools.list_ports.comports())
                for p in ports:
                    if "USB" in p.description or "ACM" in p.device:
                        target_port = p.device
                        break
            
            if target_port:
                self.serial_connection = serial.Serial(target_port, self.baudrate, timeout=0.1)
                self.simulated_mode = False
                logger.info(f"Seri Port Bağlandı: {target_port}")
            else:
                raise Exception("Uygun seri port bulunamadı.")

        except Exception as e:
            if not self.simulated_mode:
                logger.warning(f"Seri Port Hatası: {e}. Simülasyon moduna geçiliyor.")
                self.simulated_mode = True

    async def loop(self):
        """Ana döngü: Veri oku ve yayınla"""
        
        # 1. Gerçek Donanım Modu
        if self.serial_connection and self.serial_connection.is_open:
            try:
                if self.serial_connection.in_waiting > 0:
                    line = self.serial_connection.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        await self.bus.publish("raw_serial", line)
            except Exception as e:
                logger.error(f"Okuma Hatası: {e}")
                self.serial_connection.close()
                self.simulated_mode = True
        
        # 2. Simülasyon Modu (Compact Protocol)
        elif self.simulated_mode:
            if random.random() < 0.5: 
                sim_data = {
                    "v": round(12.0 + random.uniform(-0.5, 0.5), 2),
                    "c": round(1.5 + random.uniform(0, 0.5), 2),
                    "i": { 
                        "p": round(random.uniform(-2, 2), 1),
                        "r": round(random.uniform(-2, 2), 1),
                        "y": round(random.uniform(0, 360), 1)
                    },
                    "u": [
                        random.randint(10, 200),
                        random.randint(10, 100),
                        random.randint(10, 100)
                    ]
                }
                if random.random() < 0.1:
                    sim_data["l_stat"] = "Scanning"
                
                await self.bus.publish("raw_serial", json.dumps(sim_data))

        else:
             if random.random() < 0.05:
                 await self.connect()

    async def handle_serial_write(self, data):
        """MessageBus'tan gelen paketi donanıma yazar (JSON Line formatında)"""
        if isinstance(data, dict):
            msg_str = json.dumps(data) + "\n"
        else:
            msg_str = str(data) + "\n"
        
        if self.serial_connection and self.serial_connection.is_open:
            try:
                self.serial_connection.write(msg_str.encode('utf-8'))
                # logger.debug(f"TX: {msg_str.strip()}")
            except Exception as e:
                logger.error(f"Yazma Hatası: {e}")
        elif self.simulated_mode:
            # Simülasyon modunda logla (Debug için)
            pass 
            # logger.info(f"[SIM-SERIAL] TX: {msg_str.strip()}")

    async def teardown(self):
        if self.serial_connection and self.serial_connection.is_open:
            self.serial_connection.close()
