
import { CreateMLCEngine, MLCEngine, InitProgressCallback } from "@mlc-ai/web-llm";
import { LocalModelStatus } from "../types";

// Selected model ID from WebLLM model list (compatible with browser)
const SELECTED_MODEL = "Llama-3-8B-Instruct-q4f32_1-MLC";

export class LocalAIService {
    private engine: MLCEngine | null = null;
    private status: LocalModelStatus = 'unloaded';
    private progressCallback: ((progress: number, text: string) => void) | null = null;

    getStatus(): LocalModelStatus {
        return this.status;
    }

    setProgressCallback(cb: (progress: number, text: string) => void) {
        this.progressCallback = cb;
    }

    async loadModel(): Promise<void> {
        if (this.status === 'ready' || this.status === 'loading') return;
        
        this.status = 'loading';
        console.log(`[LocalAI] Initializing WebLLM with ${SELECTED_MODEL}...`);
        
        try {
            const initProgressCallback: InitProgressCallback = (report) => {
                // Determine percentage
                // WebLLM report.text often looks like "Loading model from cache[1/30]: 4MB loaded"
                // or report.progress which is 0-1.
                const percentage = Math.round(report.progress * 100);
                if (this.progressCallback) {
                    this.progressCallback(percentage, report.text);
                }
            };

            this.engine = await CreateMLCEngine(
                SELECTED_MODEL,
                { initProgressCallback }
            );

            this.status = 'ready';
            console.log(`[LocalAI] Model loaded successfully.`);
        } catch (error) {
            console.error("[LocalAI] Failed to load model:", error);
            this.status = 'error';
            if (this.progressCallback) {
                this.progressCallback(0, "Error loading model. Check console.");
            }
        }
    }

    async generate(prompt: string): Promise<string> {
        if (this.status !== 'ready' || !this.engine) {
            // Attempt auto-load if called prematurely
             try {
                await this.loadModel();
             } catch {
                return "Error: Local model could not be loaded.";
             }
        }

        if (!this.engine) return "Error: Engine not initialized.";

        try {
            // Standard Chat Completion
            const messages = [
                { role: "system", content: "You are a helpful, concise AI assistant embedded in a web OS." },
                { role: "user", content: prompt }
            ];

            const reply = await this.engine.chat.completions.create({
                messages: messages as any,
                temperature: 0.7,
                max_tokens: 512, // Limit response length for performance
            });

            return reply.choices[0].message.content || "";
        } catch (error) {
            console.error("[LocalAI] Inference error:", error);
            return "Error: Failed to generate response locally.";
        }
    }

    async unload(): Promise<void> {
        if (this.engine) {
            await this.engine.unload();
            this.engine = null;
        }
        this.status = 'unloaded';
        if (this.progressCallback) this.progressCallback(0, "Model unloaded.");
    }
}

export const localAI = new LocalAIService();
