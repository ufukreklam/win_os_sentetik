import React from 'react';
import { CloudSun, CloudRain, Sun, Wind, Droplets, MapPin } from 'lucide-react';

interface WeatherWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

const WeatherWidget: React.FC<WeatherWidgetProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed top-10 left-4 z-50 w-72
                 bg-slate-900/80 backdrop-blur-2xl 
                 border border-white/10 rounded-xl shadow-2xl p-5
                 animate-in slide-in-from-top-2 fade-in duration-200 origin-top-left text-white"
      onClick={(e) => e.stopPropagation()}
    >
        {/* Header */}
        <div className="flex justify-between items-start mb-6">
            <div>
                <div className="flex items-center gap-1 text-xs text-slate-400 font-medium uppercase tracking-wide">
                    <MapPin size={10} /> San Francisco
                </div>
                <div className="text-4xl font-light mt-1">72°</div>
            </div>
            <div className="flex flex-col items-end">
                <CloudSun size={32} className="text-yellow-400" />
                <span className="text-sm font-medium mt-1">Partly Cloudy</span>
            </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white/5 rounded-lg p-2 flex items-center gap-3">
                <Wind size={16} className="text-blue-300" />
                <div>
                    <div className="text-[10px] text-slate-400">Wind</div>
                    <div className="text-xs font-semibold">8 mph</div>
                </div>
            </div>
            <div className="bg-white/5 rounded-lg p-2 flex items-center gap-3">
                <Droplets size={16} className="text-blue-300" />
                <div>
                    <div className="text-[10px] text-slate-400">Humidity</div>
                    <div className="text-xs font-semibold">42%</div>
                </div>
            </div>
        </div>

        {/* Forecast */}
        <div className="space-y-3">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase">3-Day Forecast</h3>
            
            <div className="flex items-center justify-between text-sm">
                <span className="w-8">Mon</span>
                <div className="flex-1 px-4 flex items-center gap-2">
                    <div className="flex-1 h-1 bg-slate-700 rounded-full overflow-hidden">
                        <div className="w-[70%] h-full bg-gradient-to-r from-blue-500 to-yellow-400" />
                    </div>
                </div>
                <div className="flex items-center gap-2 w-12 justify-end">
                    <Sun size={14} className="text-yellow-400" />
                    <span>75°</span>
                </div>
            </div>

            <div className="flex items-center justify-between text-sm">
                <span className="w-8">Tue</span>
                <div className="flex-1 px-4 flex items-center gap-2">
                     <div className="flex-1 h-1 bg-slate-700 rounded-full overflow-hidden">
                        <div className="w-[50%] h-full bg-gradient-to-r from-blue-400 to-slate-400" />
                    </div>
                </div>
                <div className="flex items-center gap-2 w-12 justify-end">
                    <CloudRain size={14} className="text-blue-400" />
                    <span>68°</span>
                </div>
            </div>

            <div className="flex items-center justify-between text-sm">
                <span className="w-8">Wed</span>
                 <div className="flex-1 px-4 flex items-center gap-2">
                     <div className="flex-1 h-1 bg-slate-700 rounded-full overflow-hidden">
                        <div className="w-[80%] h-full bg-gradient-to-r from-yellow-300 to-orange-400" />
                    </div>
                </div>
                <div className="flex items-center gap-2 w-12 justify-end">
                    <Sun size={14} className="text-orange-400" />
                    <span>78°</span>
                </div>
            </div>
        </div>
    </div>
  );
};

export default WeatherWidget;