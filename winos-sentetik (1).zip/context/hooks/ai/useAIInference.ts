
import { useState, useCallback, useEffect } from 'react';
import { AIMode, LocalModelStatus, LocalModelProgress } from '../../../types';
import { generateResponse, getEmbedding } from '../../../services/geminiService';
import { localAI } from '../../../services/localAIService';
import { vectorStore } from '../../../services/vectorStore';
import { securityService } from '../../../services/securityService';
import { emotionService } from '../../../services/emotionService';
import { personalityService } from '../../../services/personalityService';
import { playSystemSound } from '../../../utils/soundUtils';

export const useAIInference = (
    serialStatus: string,
    updateSimulationLoad: (type: 'motor' | 'cpu', value: number) => void,
    addEpisodicMemory: (event: string, category: any) => void
) => {
    const [aiMode, setAIMode] = useState<AIMode>('cloud');
    const [localModelStatus, setLocalModelStatus] = useState<LocalModelStatus>('unloaded');
    const [modelLoadingProgress, setModelLoadingProgress] = useState<LocalModelProgress | null>(null);

    // Local Model Monitoring
    useEffect(() => {
        localAI.setProgressCallback((progress, text) => {
             setModelLoadingProgress({ progress, text, timeElapsed: 0 });
             if (progress >= 100 && text.toLowerCase().includes('finish')) {
                 setLocalModelStatus('ready');
                 setModelLoadingProgress(null);
             } else {
                 setLocalModelStatus('loading');
             }
        });
        const interval = setInterval(() => {
            setLocalModelStatus(localAI.getStatus());
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const loadLocalModel = useCallback(async () => {
        if (localModelStatus === 'unloaded' || localModelStatus === 'error') {
            await localAI.loadModel();
        }
    }, [localModelStatus]);

    const analyzeInput = useCallback((text: string) => {
         // Duygu servisine girdi vererek anlık analiz yap
         emotionService.processInput(text);
         const currentEmotion = emotionService.getCurrentState();
         
         const intent = text.includes('?') ? 'query' : text.length > 30 ? 'chat' : 'command';
         
         // Kişilik evrimi tetikleyicileri
         if (text.includes('good') || text.includes('great')) personalityService.evolve('social_success', 0.2);
         if (text.includes('bad') || text.includes('hate')) personalityService.evolve('social_failure', 0.4);

         return { 
             intent: intent as any, 
             sentiment: currentEmotion.pad.pleasure, 
             keywords: [] 
         };
    }, []);

    const askAI = useCallback(async (prompt: string): Promise<{ text: string, provider: 'cloud' | 'local', analysis?: any }> => {
        // 1. Güvenlik Kontrolü
        const securityCheck = securityService.evaluatePrompt(prompt);
        if (!securityCheck.safe) {
            addEpisodicMemory(`THREAT PREVENTED: ${securityCheck.reason}`, 'error');
            playSystemSound('error');
            return { 
                text: `I cannot comply. ${securityCheck.reason}`, 
                provider: 'local', 
                analysis: { intent: 'blocked', sentiment: -1, keywords: [] } 
            };
        }

        // Simülasyon Yükü (Hardware bağlı değilse)
        if (serialStatus !== 'connected') {
             updateSimulationLoad('cpu', 50);
             setTimeout(() => updateSimulationLoad('cpu', 10), 1000);
        }

        const analysis = analyzeInput(prompt);
        const isSensitive = prompt.toLowerCase().includes('password') || prompt.toLowerCase().includes('secret');
        const useLocal = aiMode === 'local' || (aiMode === 'hybrid' && isSensitive);

        let responseText = '';
        let provider: 'cloud' | 'local' = 'cloud';
        let contextString = '';

        // 2. RAG: Hafızadan Bağlam Getir
        try {
            const queryEmbedding = await getEmbedding(prompt);
            if (queryEmbedding) {
                const relevantDocs = await vectorStore.search(queryEmbedding, 3);
                if (relevantDocs.length > 0) {
                    contextString = relevantDocs.map(d => d.content).join('\n---\n');
                    console.log(`[RAG] Found ${relevantDocs.length} relevant memories.`);
                }
            }
        } catch (e) {
            console.error("RAG Error:", e);
        }

        // 3. Model Sorgulama
        if (useLocal) {
            if (localModelStatus !== 'ready') {
                try { await loadLocalModel(); } 
                catch (e) { return { text: "Local model failed to load.", provider: 'local' }; }
            }
            
            const fullPrompt = contextString ? `Context:\n${contextString}\n\nUser: ${prompt}` : prompt;
            responseText = await localAI.generate(fullPrompt);
            provider = 'local';
        } else {
            const response = await generateResponse(prompt, contextString);
            responseText = response.text;
            provider = 'cloud';
        }

        return { text: responseText, provider, analysis };
    }, [aiMode, serialStatus, updateSimulationLoad, localModelStatus, loadLocalModel, addEpisodicMemory, analyzeInput]);

    return {
        aiMode,
        setAIMode,
        localModelStatus,
        modelLoadingProgress,
        loadLocalModel,
        askAI
    };
};
