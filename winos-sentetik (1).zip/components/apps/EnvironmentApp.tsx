
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Home, Lightbulb, Thermometer, Lock, Camera, Zap, MapPin, Sun, Moon, CloudRain, Activity, Globe, Wifi, RefreshCw } from 'lucide-react';
import { IoTDevice } from '../../types';

const EnvironmentApp: React.FC = () => {
  const { environmentState, toggleIoTDevice, updateIoTDevice, timeOffset } = useOS();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'devices' | 'sync'>('dashboard');

  const currentTime = new Date(Date.now() + timeOffset);
  const isNight = currentTime.getHours() >= 19 || currentTime.getHours() < 6;

  const getDeviceIcon = (type: string) => {
      switch (type) {
          case 'light': return Lightbulb;
          case 'thermostat': return Thermometer;
          case 'lock': return Lock;
          case 'camera': return Camera;
          case 'outlet': return Zap;
          default: return Wifi;
      }
  };

  const getStatusColor = (status: string) => {
      switch (status) {
          case 'on': return 'bg-yellow-500 text-white';
          case 'off': return 'bg-slate-700 text-slate-400';
          case 'offline': return 'bg-red-900/50 text-red-400 border border-red-500/30';
          default: return 'bg-slate-700';
      }
  };

  const DeviceCard: React.FC<{ device: IoTDevice }> = ({ device }) => {
      const Icon = getDeviceIcon(device.type);
      const isOn = device.status === 'on';

      return (
          <div 
            onClick={() => toggleIoTDevice(device.id)}
            className={`
                p-4 rounded-xl cursor-pointer transition-all duration-300 relative overflow-hidden group
                ${isOn ? 'bg-white/10 border border-white/20' : 'bg-black/20 border border-white/5'}
            `}
          >
              <div className="flex justify-between items-start mb-2">
                  <div className={`p-2 rounded-full transition-colors ${isOn ? 'bg-yellow-500/20 text-yellow-400' : 'bg-slate-800 text-slate-500'}`}>
                      <Icon size={20} />
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">{device.room}</div>
              </div>
              
              <div>
                  <h4 className="font-bold text-sm mb-1">{device.name}</h4>
                  <div className="text-xs text-slate-400">
                      {device.status === 'offline' ? 'Not Responding' : 
                       device.type === 'thermostat' ? `${device.value}°C` : 
                       device.type === 'light' && isOn ? `${device.value}% Brightness` : 
                       device.status === 'on' ? 'Active' : 'Off'}
                  </div>
              </div>

              {/* Slider for lights/thermostat (Mock interactive) */}
              {(device.type === 'light' || device.type === 'thermostat') && isOn && (
                  <div 
                    className="absolute bottom-0 left-0 h-1 bg-yellow-500 transition-all" 
                    style={{ width: `${device.value ? (device.type === 'thermostat' ? (device.value - 10) * 5 : device.value) : 100}%` }}
                  />
              )}
          </div>
      );
  };

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('dashboard')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <Globe size={20} />
                <span className="hidden md:inline text-sm font-medium">Context</span>
            </button>
            <button 
                onClick={() => setActiveTab('devices')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'devices' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <Home size={20} />
                <span className="hidden md:inline text-sm font-medium">Smart Home</span>
            </button>
            <button 
                onClick={() => setActiveTab('sync')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'sync' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <RefreshCw size={20} />
                <span className="hidden md:inline text-sm font-medium">Reality Sync</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'dashboard' && (
                <div className="flex-1 p-6 overflow-y-auto space-y-6">
                    {/* Time & Weather Hero */}
                    <div className={`
                        rounded-2xl p-8 relative overflow-hidden transition-colors duration-1000
                        ${isNight ? 'bg-gradient-to-br from-indigo-900 to-slate-900' : 'bg-gradient-to-br from-blue-500 to-cyan-400'}
                    `}>
                        <div className="relative z-10 flex justify-between items-end">
                            <div>
                                <h2 className="text-4xl font-light text-white mb-2">
                                    {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </h2>
                                <div className="flex items-center gap-2 text-white/80 text-sm font-medium">
                                    <MapPin size={14} />
                                    <span>37.7749° N, 122.4194° W (Home Base)</span>
                                </div>
                            </div>
                            <div className="text-right text-white">
                                {isNight ? <Moon size={48} className="mb-2 ml-auto" /> : <Sun size={48} className="mb-2 ml-auto" />}
                                <div className="text-2xl font-bold">22°C</div>
                                <div className="text-sm opacity-80">Clear Sky</div>
                            </div>
                        </div>
                    </div>

                    {/* Context Cards */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/5 border border-white/5 rounded-xl p-4">
                            <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Current Context</h3>
                            <div className="text-xl font-medium text-white capitalize flex items-center gap-2">
                                <Home size={20} className="text-blue-400" />
                                {environmentState.currentContext.replace('_', ' ')}
                            </div>
                        </div>
                        <div className="bg-white/5 border border-white/5 rounded-xl p-4">
                            <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Ambient Noise</h3>
                            <div className="text-xl font-medium text-white flex items-center gap-2">
                                <Activity size={20} className="text-green-400" />
                                {Math.round(environmentState.ambientNoiseLevel)} dB
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'devices' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <h2 className="text-xl font-bold mb-6">Connected Devices</h2>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {environmentState.iotDevices.map(device => (
                            <DeviceCard key={device.id} device={device} />
                        ))}
                        {/* Add Device Placeholder */}
                        <div className="border-2 border-dashed border-white/10 rounded-xl p-4 flex flex-col items-center justify-center gap-2 text-slate-500 hover:border-white/20 hover:text-slate-400 cursor-pointer transition-colors min-h-[120px]">
                            <span className="text-3xl">+</span>
                            <span className="text-xs font-medium">Add Device</span>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'sync' && (
                <div className="flex-1 p-6 overflow-y-auto flex flex-col items-center justify-center">
                    <div className="w-64 h-64 rounded-full border-8 border-slate-800 flex items-center justify-center relative">
                        {/* Circular Progress (Simulated with CSS conic gradient) */}
                        <div 
                            className="absolute inset-0 rounded-full"
                            style={{ 
                                background: `conic-gradient(#3b82f6 ${environmentState.realitySync}%, transparent 0)` 
                            }} 
                        />
                        <div className="absolute inset-2 bg-slate-950 rounded-full flex flex-col items-center justify-center z-10">
                            <div className="text-5xl font-bold text-white">{Math.round(environmentState.realitySync)}%</div>
                            <div className="text-sm text-slate-400 uppercase tracking-widest mt-2">Sync Stable</div>
                        </div>
                    </div>
                    
                    <div className="mt-8 max-w-md text-center">
                        <h3 className="text-lg font-bold mb-2">Reality Synchronization</h3>
                        <p className="text-sm text-slate-400 leading-relaxed">
                            Comparing internal SLAM maps with real-time Lidar/Visual telemetry. 
                            High synchronization indicates the robot's internal model matches external reality.
                        </p>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default EnvironmentApp;
