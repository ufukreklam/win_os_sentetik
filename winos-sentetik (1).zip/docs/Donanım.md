Tahrik ve Tahrik Kontrol
4 x 6V 250 Rpm Motor ve Tekerlek Seti
2 x L298 Mini DC ve Step Motor Sürücü Modülü 
2 x L298N Voltaj Regulatörlü Çift Motor Sürücü Kartı (opsiyonel)
""

""
Sensör Füzyon Slam
5x TCRT5000 Kızılötesi Sensör Modülü Zemin tespit ve yükseklik için (2 ön sol sağ - 2 arka sol sağ)
4x LM393 hız sensörü 3,3V - 5V
1x MPU6050 6 Eksen İvme ve Gyro Sensörü gy-521
1x MPU-9250/MPU6500:** 9 Eksenli Jiroskop/İvmeölçer/Manyetometre
2x web cam ile derinlik kamerası
5x adet HC-SR04 (3x ön / sol / sağ için)

1x ESP8266 Ekonomik Wifi Serial Transceiver Module (Opsiyonel Wifi Yayını)

1x DS3231 Hassas RTC ve 24C32 EEPROM Modülü (Gerçek Zaman için) (Ayrıca Online Güncelleme)
Robotun Zamansal farkı bilmesi için.

### Çoklayıcılar
12x TXS0108E 8 Kanal Mantık Seviye Dönüştürücü (5v ve 3,3v geçişlerinde)
3x CD74HC4067 16 kanal Analog Dijital Çoklayıcı Mavi Modül
1x PCF8574 I2C 8 Kanal Dijital Çoklayıcı Sarı Modül
3x PCA9548A I2C 8 Kanal Dijital Çoklayıcı Mor Modül
2x ADS1115 16-Bit 4 Kanal ADC Modülü

### Ana işlemciler 
5x RPİ Pico Slave Uart
1x Rpi 5 4gb Master


Yüz (1 Ağız ve 2 Göz) Emotion I/O System
3x I2c 0.96" 128x64 mono OLED ekran
2x 8li Halka WS2812B 5050 RGB LED Yanaklarda (Animatronik Duygu Renkleri)	
3x RGB Led Modül Duygu Renkleri (Sağ Sol Kolda ve Gövde İçinde)

### Konum ve Çevre
1x GY-NEO6MV2 GPS Modülü
1x Xiaomi Mijia 1S LDS Lazer Mesafe Sensörü
1x AHT10 Dijital Sıcaklık ve Nem Sensörü Modülü I2C
7x TTP223B Dokunmatik Sensör
1x Yağmur Damlası Sensörü
1x VEML 7700 Ortam Işık Sensörü
1x MQ-2 Gaz Sensör Modülü
1x MQ-135 Hava Kalite Sensörü
1x HLK-LD2402 İnsan Varlık Sensörü
1x HB100 Mikrodalga Doppler Radar

2 Dof Boyun (Öne ve Sağa Sola)
2 Dof Kol (Yana ve İleri Geri)
1x PCA9685 16 Kanal 12 bit Pwm Servo Kontrol
6x SG90 9g Servo Motor - Mini RC Servo Motor 180° Çalışma gerilimi: 4.8 - 6.0V DC Hız @4.8V: 0.1 sn/60° Zorlanma Torku @6V: 1.8 kg.cm Dönüş açısı: 0-180° Çalışma PWM sinyali: 500-2400 μs

RF ve Fiziksel Giriş
1x TTP229 16 Kanallı Dokunmatik Tuş Takımı 

###Güç Yönetim Sistemi
1x INA219 I2C Çift Yönlü Akım Sensörü Modülü
1x ACS712 Analog Akım Sensörü AC / DC +30A / -30A
3x INA3221 I2C 3 Kanal Akım/Voltaj Monitörü

10x 15A 400W PWM Kontrollü Mosfet Anahtarlama Modülü ( Far, Motor ve gereksiz birimleri on off için)


1x GND Bus Breadboard
1x 12v Bus Breadboard
1x 5v Bus Breadboard
1x 3.3v Bus Breadboard
2x BMS 3S 20A Koruma Kartı
2x 18650 3'lü Pano Tipi Kapaklı Pil Yuvası
1x Ams1117 3.3v Voltaj Regülatörü Modülü
3x orta boy breadboard (Gnd ve 12v 5v 3.3v bus için)

2x XH-M603 Şarj Kontrol Devresi 12-24V Akü ve Lityum Pil Uyumlu
2x XL4015 5A Voltaj Düşürücü Gerilim Azaltıcı Modül Step Down
2x LM2596-ADJ (3v ve 5v sabit voltaj bus için)
2x 0-50V 4A DC Filtre (Ses Sistemi ve Ana işlemci power parazitleri için)

2x IC-266B1 Type-C Erkek Seyyar Kapaklı
3x 2.1mm Plastik DC Güç Soketi
1x DC Jack Modülü 5.5mm
2x E-TEN1121 Toggle Siviç On-On
10x KW10-Z3P Micro Switch



### Ses Sistemi
1x PAM8610 2X15W Amplifier Modül
1x PCM5102A DAC Modül
1x dfplayer Mini MP3 Ses Modülü
1x 3W 2 Kanal Mini Amfi Devresi - PAM8403
1x 2'li 4PIN 100mm x 45mm x 21 mm 8Ω 5W Speaker

### Ses ve Konum Tespiti
3x INMP441 Mikrofon Modülü - I2C Arayüzü
2x MAX4466 Elektret Mikrofon Modülü




### IR Receiver ve IR Kumanda
IR Kumanda Kodları:
ON/OFF: 0xFFA25D
MENÜ: 0xFFE21D
TEST: 0xFF22DD
MENÜ GERİ: 0xFFC23D
İLERİ (+): 0xFF02FD
GERİ (-): 0xFF9867
SOLA: 0xFFE01F
SAĞA: 0xFF906F
PLAY/PAUSE/OK: 0xFFA857
0: 0xFF6897
C/EXIT: 0xFFB04F
1: 0xFF30CF
2: 0xFF18E7
3: 0xFF7A85
4: 0xFF10EF
5: 0xFF38C7
6: 0xFF5AA5
7: 0xFF42BD
8: 0xFF4AB5
9: 0xFF52AD


Kullanılabilir OPSİYONEL Sensörler
1 x XY JoyStick
1 x Relay (Röle)
1 x Big Sound
1 x Small Microphone (Küçük Mikrofon)
1 x Tracking
1 x Avoid
1 x Flame (Yangın sensörü)
1 x Linear Hall
1 x Touch (Dokunmatik Buton)
1 x Digital Temperature (Dijital Sıcaklık)
1 x Buzzer
1 x Passive Buzzer
1 x RGB LED
1 x SMD RGB
1 x 2-Color LED
1 x 2-Color
1 x Reed Switch
1 x Mini Reed
1 x Heartbeat (Kalp Atışı Sensörü)
1 x 7 Color Flash
1 x Caser Emit
1 x Button
1 x Shock
1 x Rotary Encoders
2 x Magic Cup
1 x Tilt Switch
1 x Ball Switch
1 x Photoresistor
1 x Temp and Humidity
1 x Analog Hall
1 x Hall Magnetic
1 x TEMP
1 x Analog Temp
1 x IR Emission
1 x IR Receiver
1 x Tap module
1 x Light Blocking
""