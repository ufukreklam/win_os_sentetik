
import React, { createContext, useContext, useMemo, ReactNode, useEffect } from 'react';
import { OSContextType, AppID } from '../types';
import { useSystemOperations } from './hooks/useSystemOperations';
import { useWindowManager } from './hooks/useWindowManager';
import { useFileSystem } from './hooks/useFileSystem';
import { useHardwareInterface } from './hooks/useHardwareInterface';
import { useArtificialIntelligence } from './hooks/useArtificialIntelligence';
import { usePluginManager } from './hooks/usePluginManager';
import { AVAILABLE_PLUGINS } from '../services/pluginService';
import { APP_CONFIGS } from '../constants';
import { playSystemSound } from '../utils/soundUtils';

const OSContext = createContext<OSContextType | undefined>(undefined);

export const OSProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // 1. System Core (User, Time, Boot, Notifications, Network)
  const system = useSystemOperations();

  // 2. Window Manager (Needs logout trigger to close apps)
  const winMgr = useWindowManager(system.installedApps, system.currentUser);

  // 3. File System (Needs User + Time + Cloud setting)
  const fs = useFileSystem(
      system.currentUser?.username || 'user', 
      system.currentUser?.isAdmin || false,
      system.timeOffset,
      false, // Cloud status handling inside hook or passed from system if needed
      system.addNotification
  );

  // 4. Hardware (Serial, Sensors, Bluetooth)
  // updateSimulationLoad fonksiyonunu alıyoruz
  const hardware = useHardwareInterface(system.addNotification);

  // 5. Artificial Intelligence (Needs data from all other layers)
  // Hardware simülasyonunu etkileyebilmesi için updateSimulationLoad'u buraya geçiriyoruz
  const ai = useArtificialIntelligence(
      hardware.sensorReadings,
      winMgr.windows,
      system.timeOffset,
      hardware.serialStatus,
      winMgr.openApp,
      winMgr.closeApp,
      hardware.updateSimulationLoad // YENİ: AI kararları artık donanım simülasyonunu etkiler
  );

  // 6. Plugin Architecture (Layer 16)
  const plugins = usePluginManager(system.addNotification, system.setWallpaper);

  // --- Auto-switch AI mode on offline ---
  useEffect(() => {
      if (!system.isOnline && ai.aiMode === 'cloud') {
          ai.setAIMode('local');
          system.addNotification({ title: 'AI Mode Switched', message: 'Switched to Local AI (Privacy Mode) due to network loss.', type: 'warning' });
      }
  }, [system.isOnline, ai.aiMode, ai.setAIMode, system.addNotification]);

  // --- Dynamic Plugin Linking Logic ---
  useEffect(() => {
      const chessPlugin = plugins.pluginState.find(p => p.id === 'skill_chess');
      const isChessInstalled = system.installedApps.includes(AppID.CHESS);

      if (chessPlugin?.isEnabled && !isChessInstalled) {
          system.installApp(AppID.CHESS);
      } else if (!chessPlugin?.isEnabled && isChessInstalled) {
          system.uninstallApp(AppID.CHESS);
      }
  }, [plugins.pluginState, system.installedApps, system.installApp, system.uninstallApp]);

  // Combine Cloud Sync Logic
  const [isCloudEnabled, setCloudEnabled] = React.useState(false);

  // Patching installedApps to return actual metadata for UI consumption
  const installedAppsMetadata = useMemo(() => {
      return system.installedApps.map(id => APP_CONFIGS[id]).filter(Boolean);
  }, [system.installedApps]);

  const pinnedAppsMetadata = useMemo(() => {
      return system.pinnedApps.map(id => APP_CONFIGS[id]).filter(Boolean);
  }, [system.pinnedApps]);

  const contextValue = useMemo<OSContextType>(() => ({
      // System Core
      users: system.users,
      currentUser: system.currentUser,
      login: system.login,
      logout: system.logout,
      addUser: system.addUser,
      removeUser: system.removeUser,
      updateUser: system.updateUser,
      isLocked: system.isLocked,
      setLocked: system.setLocked,
      wallpaper: system.wallpaper,
      setWallpaper: system.setWallpaper,
      installedApps: installedAppsMetadata,
      installApp: system.installApp,
      uninstallApp: system.uninstallApp,
      togglePin: system.togglePin,
      pinnedApps: pinnedAppsMetadata,
      timeOffset: system.timeOffset,
      isAutoTime: system.isAutoTime,
      setTimeConfig: system.setTimeConfig,
      bootState: system.bootState,
      setBootState: system.setBootState,
      bootMode: system.bootMode,
      setBootMode: system.setBootMode,
      hardwareConfig: system.hardwareConfig,
      setHardwareConfig: system.setHardwareConfig,
      notifications: system.notifications,
      addNotification: system.addNotification,
      removeNotification: system.removeNotification,
      clearNotifications: system.clearNotifications,
      crashSystem: system.crashSystem,
      factoryReset: system.factoryReset,
      playSound: () => {}, 
      isOnline: system.isOnline,
      installPWA: system.installPWA,
      canInstallPWA: system.canInstallPWA,

      // Window Manager
      isStartMenuOpen: winMgr.isStartMenuOpen,
      toggleStartMenu: winMgr.toggleStartMenu,
      openApp: winMgr.openApp,
      closeApp: winMgr.closeApp,
      minimizeApp: winMgr.minimizeApp,
      maximizeApp: winMgr.maximizeApp,
      focusApp: winMgr.focusApp,
      updateWindow: winMgr.updateWindow,
      windows: winMgr.windows,
      isMovingWindow: winMgr.isMovingWindow,
      setMovingWindow: winMgr.setMovingWindow,
      snapPreview: winMgr.snapPreview,
      setSnapPreview: winMgr.setSnapPreview,

      // File System
      fs: fs.fs,
      syncStatus: fs.syncStatus,
      isCloudEnabled,
      setCloudEnabled,
      readdir: fs.readdir,
      readFile: fs.readFile,
      writeFile: fs.writeFile,
      mkdir: fs.mkdir,
      deleteItem: fs.deleteItem,
      restoreItem: fs.restoreItem,
      moveFile: fs.moveFile,
      updateFileMetadata: fs.updateFileMetadata,

      // Hardware
      serialStatus: hardware.serialStatus,
      sensorReadings: hardware.sensorReadings,
      connectSerial: hardware.connectSerial,
      disconnectSerial: hardware.disconnectSerial,
      sendSerialCommand: hardware.sendSerialCommand,
      backendStatus: system.backendStatus,
      robotCameraFrame: hardware.robotCameraFrame, 
      slamMap: hardware.slamMap,
      navigationPath: hardware.navigationPath, // Export nav path
      setNavigationGoal: hardware.setNavigationGoal, // Export goal setter
      bluetoothDevices: hardware.bluetoothDevices,
      fileTransfers: hardware.fileTransfers,
      scanBluetooth: hardware.scanBluetooth,
      pairDevice: hardware.pairDevice,
      unpairDevice: hardware.unpairDevice,
      sendFileBluetooth: hardware.sendFileBluetooth,

      // AI Layers
      emotionState: ai.emotionState,
      setEmotionState: ai.setEmotionState,
      languageState: ai.languageState,
      setLanguageState: ai.setLanguageState,
      perceptionState: ai.perceptionState,
      processVisualFrame: ai.processVisualFrame,
      motivationState: ai.motivationState,
      addGoal: ai.addGoal,
      updateGoal: ai.updateGoal,
      completeGoal: ai.completeGoal,
      voiceState: ai.voiceState,
      isHandsFree: ai.isHandsFree,
      toggleHandsFree: ai.toggleHandsFree,
      voiceEnergy: ai.voiceEnergy,
      lastVoiceText: ai.lastVoiceText,
      startListening: ai.startListening,
      stopListening: ai.stopListening,
      speak: ai.speak,
      socialState: ai.socialState,
      updateIdentity: ai.updateIdentity,
      triggerSocialEvent: ai.triggerSocialEvent,
      creativityState: ai.creativityState,
      setCreativityState: ai.setCreativityState,
      learningState: ai.learningState,
      performanceState: ai.performanceState,
      setPerformanceMode: ai.setPerformanceMode,
      toggleAutoTuning: ai.toggleAutoTuning,
      runDiagnostics: ai.runDiagnostics,
      securityState: ai.securityState,
      environmentState: ai.environmentState,
      toggleIoTDevice: ai.toggleIoTDevice,
      updateIoTDevice: ai.updateIoTDevice,
      selfAwarenessState: ai.selfAwarenessState,
      coordinationState: ai.coordinationState,
      bridgeState: ai.bridgeState,
      sendBridgeCommand: ai.sendBridgeCommand,
      memoryState: ai.memoryState,
      addEpisodicMemory: ai.addEpisodicMemory,
      
      // Plugin Architecture
      availablePlugins: AVAILABLE_PLUGINS,
      pluginState: plugins.pluginState,
      installPlugin: plugins.installPlugin,
      uninstallPlugin: plugins.uninstallPlugin,
      togglePlugin: plugins.togglePlugin,

      // Local Intelligence
      aiMode: ai.aiMode,
      setAIMode: ai.setAIMode,
      localModelStatus: ai.localModelStatus,
      loadLocalModel: ai.loadLocalModel,
      modelLoadingProgress: ai.modelLoadingProgress,
      askAI: ai.askAI,

      // Policy Core
      policyState: ai.policyState,
      evaluateAction: ai.evaluateAction,
  }), [system, winMgr, fs, hardware, ai, isCloudEnabled, plugins, installedAppsMetadata, pinnedAppsMetadata]);

  return (
    <OSContext.Provider value={{ ...contextValue, playSound: playSystemSound }}>
      {children}
      {system.bootState === 'bsod' && <div className="fixed inset-0 z-[99999] bg-[#0078D7]" />}
    </OSContext.Provider>
  );
};

export const useOS = (): OSContextType => {
  const context = useContext(OSContext);
  if (!context) {
    throw new Error('useOS must be used within an OSProvider');
  }
  return context;
};
