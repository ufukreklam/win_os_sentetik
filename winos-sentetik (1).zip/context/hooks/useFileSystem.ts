
import { useState, useCallback, useEffect } from 'react';
import { FileSystemItem } from '../../types';
import { fileSystemService, INITIAL_FS } from '../../services/FileSystemService';
import { playSystemSound } from '../../utils/soundUtils';

export const useFileSystem = (
    currentUsername: string, 
    isAdmin: boolean, 
    timeOffset: number,
    isCloudEnabled: boolean,
    onNotify: (n: any) => void
) => {
    // Start with initial FS structure to prevent UI flash, then load real data
    const [fs, setFs] = useState<Record<string, FileSystemItem[]>>(INITIAL_FS);
    const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'error' | 'offline'>('synced');
    const [isLoaded, setIsLoaded] = useState(false);

    // Initial Load from IDB
    useEffect(() => {
        const init = async () => {
            try {
                const loadedFs = await fileSystemService.loadFileSystem();
                if (loadedFs) {
                    setFs(loadedFs);
                }
            } catch (e) {
                console.error("Failed to load FS", e);
            } finally {
                setIsLoaded(true);
            }
        };
        init();
    }, []);

    const persistFileSystem = useCallback(async (newFs: Record<string, FileSystemItem[]>) => {
        if (isCloudEnabled) {
            setSyncStatus('syncing');
        }
        
        try {
            await fileSystemService.saveState(newFs, isCloudEnabled);
            if (isCloudEnabled) {
                setSyncStatus('synced');
            }
        } catch (e) {
            console.error('Sync failed', e);
            if (isCloudEnabled) setSyncStatus('error');
        }
    }, [isCloudEnabled]);

    const readdir = useCallback((path: string) => {
        return fs[path] || [];
    }, [fs]);

    const readFile = useCallback((path: string, fileName: string) => {
        const dir = fs[path];
        if (!dir) return null;
        return dir.find(f => f.name === fileName) || null;
    }, [fs]);

    const writeFile = useCallback((path: string, file: FileSystemItem) => {
        const { newFs, success } = fileSystemService.writeFile(
            fs, 
            path, 
            file, 
            currentUsername || 'root',
            timeOffset
        );

        if (success) {
            setFs(newFs);
            persistFileSystem(newFs);
            onNotify({ title: 'File Saved', message: `${file.name} saved to ${path}`, type: 'success' });
        }
    }, [fs, currentUsername, timeOffset, persistFileSystem, onNotify]);

    const mkdir = useCallback((path: string, folderName: string) => {
        const { newFs, success } = fileSystemService.mkdir(
            fs, 
            path, 
            folderName, 
            currentUsername || 'root',
            timeOffset
        );
        if (success) {
            setFs(newFs);
            persistFileSystem(newFs);
        }
    }, [fs, currentUsername, timeOffset, persistFileSystem]);

    const deleteItem = useCallback((path: string, itemName: string) => {
        const { newFs, success, message } = fileSystemService.deleteItem(
            fs,
            path,
            itemName,
            { username: currentUsername || 'user', isAdmin }
        );

        if (success) {
            setFs(newFs);
            persistFileSystem(newFs);
            if (message) onNotify({ title: 'System', message, type: 'info' });
            playSystemSound('delete');
        } else {
            if (message) onNotify({ title: 'Error', message, type: 'error' });
        }
    }, [fs, currentUsername, isAdmin, persistFileSystem, onNotify]);

    const restoreItem = useCallback((itemName: string) => {
        const { newFs, success, message } = fileSystemService.restoreItem(fs, itemName);
        if (success) {
            setFs(newFs);
            persistFileSystem(newFs);
            onNotify({ title: 'Restored', message: message || 'Item restored', type: 'success' });
        } else {
            onNotify({ title: 'Restore Failed', message: message || 'Unknown error', type: 'error' });
        }
    }, [fs, persistFileSystem, onNotify]);

    const moveFile = useCallback((sourcePath: string, destPath: string, itemName: string) => {
        const { newFs, success, message } = fileSystemService.moveFile(fs, sourcePath, destPath, itemName);
        if (success) {
            setFs(newFs);
            persistFileSystem(newFs);
            onNotify({ title: 'Item Moved', message: `Moved ${itemName} to ${destPath}`, type: 'success' });
        } else {
            onNotify({ title: 'Move Failed', message: message || 'Operation failed', type: 'error' });
        }
    }, [fs, persistFileSystem, onNotify]);

    const updateFileMetadata = useCallback((path: string, fileName: string, updates: Partial<FileSystemItem>) => {
        setFs(prev => {
            const dir = prev[path] || [];
            const fileIndex = dir.findIndex(f => f.name === fileName);
            if (fileIndex === -1) return prev;
            
            const newDir = [...dir];
            newDir[fileIndex] = { ...newDir[fileIndex], ...updates };
            const newState = { ...prev, [path]: newDir };
            persistFileSystem(newState);
            return newState;
        });
    }, [persistFileSystem]);

    return {
        fs, syncStatus, isLoaded, readdir, readFile, writeFile, mkdir, deleteItem, restoreItem, moveFile, updateFileMetadata
    };
};
