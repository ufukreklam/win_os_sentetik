
import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children?: ReactNode;
  appName?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class AppErrorBoundary extends React.Component<Props, State> {
  public override state: State = {
    hasError: false,
    error: null
  };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error(`App Crash (${this.props.appName}):`, error, errorInfo);
  }

  handleRestart = () => {
    this.setState({ hasError: false, error: null });
  };

  override render() {
    if (this.state.hasError) {
      return (
        <div className="h-full w-full bg-slate-900 flex flex-col items-center justify-center p-6 text-center select-none relative z-50">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-4 border border-red-500/30">
             <AlertTriangle size={32} className="text-red-400" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Uygulama Hatası</h2>
          <p className="text-slate-400 text-sm mb-6 max-w-xs">
            {this.props.appName || 'Uygulama'} kritik bir hatayla karşılaştı ve kapatılması gerekiyor.
          </p>
          <div className="bg-black/30 p-3 rounded-lg border border-white/10 mb-6 max-w-full overflow-hidden w-full">
             <code className="text-xs text-red-300 font-mono block truncate" title={this.state.error?.message || ''}>
                 {this.state.error?.message || 'Bilinmeyen hata'}
             </code>
          </div>
          <button 
            onClick={this.handleRestart}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm font-medium transition-colors shadow-lg shadow-blue-500/20 active:scale-95"
          >
            <RefreshCw size={14} /> Uygulamayı Yeniden Başlat
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
