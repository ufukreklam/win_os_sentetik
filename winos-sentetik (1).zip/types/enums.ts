
export enum AppID {
  CHAT = 'chat',
  SETTINGS = 'settings',
  BROWSER = 'browser',
  PHOTOS = 'photos',
  FILES = 'files',
  TERMINAL = 'terminal',
  NOTEPAD = 'notepad',
  CALCULATOR = 'calculator',
  CAMERA = 'camera',
  CODE_EDITOR = 'code_editor',
  MEDIA = 'media',
  TASK_MANAGER = 'task_manager',
  APP_STORE = 'app_store',
  MIND = 'mind',
  MEMORY = 'memory',
  SPATIAL = 'spatial',
  GOALS = 'goals',
  SOCIAL = 'social',
  LEARNING = 'learning',
  SECURITY = 'security',
  CONNECT = 'connect',
  IDENTITY = 'identity',
  ORCHESTRATOR = 'orchestrator',
  BRIDGE = 'bridge',
  FACE = 'face',
  CHESS = 'chess',
  CREATIVITY = 'creativity',
  POLICY = 'policy',
  EXTENSIONS = 'extensions'
}

export type AppCategory = 'robot' | 'system' | 'productivity' | 'media' | 'development' | 'games' | 'utilities';
