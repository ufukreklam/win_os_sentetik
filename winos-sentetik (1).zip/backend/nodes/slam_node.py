
import logging
import base64
import time
import numpy as np
import cv2
from ..core.robot_system import RobotNode

logger = logging.getLogger("SlamNode")

class SlamNode(RobotNode):
    """
    Occupancy Grid Mapping (SLAM Frontend)
    - Listens to 'lidar_scan'
    - Updates a 800x800 Numpy Grid (5cm/pixel)
    - Publishes 'map_data' (Base64 JPEG) to UI
    """
    def __init__(self, bus):
        super().__init__("SlamNode", bus)
        self.map_size = 800
        self.resolution = 50 # mm per pixel (5cm)
        self.center = self.map_size // 2
        # Initialize map with Gray (127) = Unknown
        # 0 = Occupied (Black), 255 = Free (White)
        self.grid = np.full((self.map_size, self.map_size), 127, dtype=np.uint8)
        self.last_update = 0
        self.publish_interval = 0.5 # 2 Hz map update limit

    async def setup(self):
        self.bus.subscribe("lidar_scan", self.handle_scan)

    async def handle_scan(self, data):
        points = data.get("points", [])
        if not points:
            return

        # Robot Position (Center for now, Dead Reckoning later)
        rx, ry = self.center, self.center

        # 1. Process Rays using OpenCV drawing for speed
        # Iterate points and draw Free Space lines and Occupied dots
        for p in points:
            # Lidar points are relative to robot in mm
            # Map Coordinate System: X Right, Y Down (Image standard)
            # Lidar: X Forward, Y Left (Standard robotics)
            
            # Coordinate Transform:
            # Grid X = Center X + (Lidar Y / Res)
            # Grid Y = Center Y - (Lidar X / Res)
            
            px = int(rx + p["y"] / self.resolution) 
            py = int(ry - p["x"] / self.resolution)
            
            # Check bounds
            if 0 <= px < self.map_size and 0 <= py < self.map_size:
                # Ray Trace: Clear path (Free Space = 255)
                # We draw a line from robot to obstacle
                # Thickness 1 ensures we clear the path
                cv2.line(self.grid, (rx, ry), (px, py), 255, 1)
                
                # Mark Obstacle (Occupied = 0)
                # Draw a small circle to ensure coverage
                cv2.circle(self.grid, (px, py), 2, 0, -1)

        # 2. Publish Map Update
        now = time.time()
        if now - self.last_update > self.publish_interval:
            self.last_update = now
            await self.publish_map()

    async def publish_map(self):
        try:
            # Compress to JPEG for lightweight transmission
            ret, buffer = cv2.imencode('.jpg', self.grid, [int(cv2.IMWRITE_JPEG_QUALITY), 70])
            if ret:
                b64 = base64.b64encode(buffer).decode('utf-8')
                await self.bus.publish("map_data", {
                    "image": b64,
                    "timestamp": self.last_update,
                    "info": {
                        "width": self.map_size,
                        "height": self.map_size,
                        "res": self.resolution,
                        "origin_x": self.center,
                        "origin_y": self.center
                    }
                })
        except Exception as e:
            logger.error(f"Map publish error: {e}")

    async def loop(self):
        pass
