
# Faz 29: Özel SLAM ve Grid Haritalama Spesifikasyonu (No-ROS)

Bu döküman, WinOS Robotik Çekirdeği için ROS bağımlılığı olmayan, saf Python ve Numpy tabanlı bir **Occupancy Grid Mapping (Izgara Doluluk Haritalama)** algoritmasının tasarımını içerir.

## 1. Hedef
Robotun Lidar sensöründen gelen verileri ve (varsa) odometri verilerini kullanarak, bulunduğu ortamın 2D kuş bakışı haritasını çıkarmak.

## 2. Teknik Mimari

### 2.1 Veri Yapısı: Olasılık Izgarası (Occupancy Grid)
Harita, 2 boyutlu bir `numpy` dizisi olarak tutulacaktır.
*   **Hücre Değeri:** 0 ile 100 arası tamsayı (Int8).
    *   `0`: Boş alan (Free Space)
    *   `100`: Dolu alan / Engel (Occupied)
    *   `50`: Bilinmeyen alan (Unknown) - Başlangıç değeri.
*   **Çözünürlük:** 5 cm / piksel (0.05 metre).
*   **Boyut:** 800 x 800 hücre (40m x 40m alan).
*   **Merkez:** Robot başlangıçta haritanın tam ortasında (400, 400) kabul edilir.

### 2.2 Matematiksel Model (Log-Odds Update)
Bayes filtresi yerine, işlem yükünü azaltmak için **Log-Odds** yöntemi kullanılacaktır. Bu yöntem, olasılık çarpımlarını toplama işlemine dönüştürerek CPU verimliliği sağlar.

*   `L_occ` (Engel Log-Odd): +0.8 (Engel tespit edildiğinde eklenir)
*   `L_free` (Boşluk Log-Odd): -0.4 (Işın boyunca boşluklara eklenir)
*   `L_max`: 3.5 (~%97 doluluk ihtimali - Doygunluk sınırı)
*   `L_min`: -2.0 (~%12 doluluk ihtimali - Doygunluk sınırı)

### 2.3 Algoritma Akışı (`SlamNode`)

1.  **Giriş:** `lidar_scan` mesajı (Polar koordinatlar: açı, mesafe).
2.  **Odometri Tahmini:**
    *   Şu an için "Dead Reckoning" veya basit bir hız modeli kullanılacak.
    *   İleride encoder verisi ile birleştirilecek.
    *   Şimdilik robotun (0,0) noktasında sabit olduğu varsayımıyla haritalama test edilecek, sonra hareket eklenecek.
3.  **Raycasting (Işın İzleme):**
    *   Robotun merkezinden, Lidar'ın vurduğu noktaya kadar olan tüm pikseller **Bresenham Çizgi Algoritması** veya **Numpy Vectorization** ile bulunur.
    *   Bu pikseller "Boş" (`L_free`) olarak güncellenir.
    *   Vuruş noktasındaki piksel "Dolu" (`L_occ`) olarak güncellenir.
4.  **Çıkış:**
    *   Harita belirli aralıklarla (örn. her 1 saniyede bir veya %5 değişimde) sıkıştırılır (RLE veya Base64 PNG).
    *   `map_update` kanalı üzerinden Frontend'e gönderilir.

## 3. Bileşenler

### Backend (`backend/nodes/slam_node.py`)
*   `SlamNode` sınıfı `RobotNode`'dan türetilir.
*   `setup()`: Izgara dizisini (800x800) 50 değeriyle başlatır (Gri/Bilinmeyen).
*   `handle_lidar()`: Gelen tarama verisini işler ve ızgarayı günceller.
*   `publish_map()`: Haritayı görselleştirilebilir bir formata (örn. Base64 Image) dönüştürüp yayınlar.

### Frontend (`components/apps/SpatialApp.tsx`)
*   `useHardwareInterface` içine `mapData` state'i eklenir.
*   `SpatialApp` içindeki Canvas çizimi güncellenir:
    *   Önce Grid Haritası (Arkaplan) çizilir.
    *   Üzerine anlık Lidar noktaları (Kırmızı noktalar) çizilir.
    *   Üzerine Robot konumu çizilir.

## 4. Kısıtlamalar ve Optimizasyonlar
*   **Performans:** 800x800'lük bir matrisi her Lidar taramasında (10Hz) tamamen işlemek RPi 5'i yorabilir.
*   **Çözüm:**
    *   Harita güncellemesi her karede değil, her 3-5 karede bir yapılabilir.
    *   Frontend'e tüm harita yerine sadece değişen "chunk"lar veya sıkıştırılmış görüntü gönderilebilir.
    *   `cv2` veya `PIL` kullanarak numpy dizisini doğrudan JPEG'e çevirip göndermek en hızlı yöntemdir.

## 5. Faz 29 Başarı Kriterleri
1.  Backend'de `SlamNode` çalışır durumda olmalı.
2.  Lidar verisi gelince bellek içindeki harita güncellenmeli (duvarlar siyah, boşluklar beyaz, bilinmeyen gri).
3.  Frontend `SpatialApp` uygulamasında robotun çevresindeki duvarların yavaş yavaş haritaya işlendiği görülmeli.
