
import { useEffect } from 'react';
import { useAIMemory } from './ai/useAIMemory';
import { useAIEmotion } from './ai/useAIEmotion';
import { useAILanguage } from './ai/useAILanguage';
import { useAIInference } from './ai/useAIInference';
import { useAISubsystems } from './ai/useAISubsystems';
import { SensorReadings } from '../../types';

export const useArtificialIntelligence = (
    sensorReadings: SensorReadings,
    windows: any,
    timeOffset: number,
    serialStatus: string,
    openApp: any,
    closeApp: any,
    updateSimulationLoad: (type: 'motor' | 'cpu', value: number) => void
) => {
    
    // 1. Emotion Layer
    const { emotionState, setEmotionState, processEmotionTick } = useAIEmotion();

    // 2. Memory Layer
    const { memoryState, addEpisodicMemory } = useAIMemory(timeOffset, emotionState.primary);

    // 3. Inference Layer (Logic & LLM)
    const { 
        aiMode, setAIMode, localModelStatus, modelLoadingProgress, loadLocalModel, askAI 
    } = useAIInference(serialStatus, updateSimulationLoad, addEpisodicMemory);

    // 4. Language Layer (Voice & Text)
    const {
        languageState, setLanguageState, voiceState, lastVoiceText,
        isHandsFree, toggleHandsFree, voiceEnergy,
        startListening, stopListening, speak
    } = useAILanguage(
        aiMode, 
        openApp,
        async (text) => {
            // Speech Result Callback: Chain to Inference -> Speak
            const response = await askAI(text);
            speak(response.text);
        }
    );

    // 5. Subsystems Layer (Social, Motivation, Creativity, etc.)
    const subsystems = useAISubsystems(
        serialStatus,
        sensorReadings,
        updateSimulationLoad,
        addEpisodicMemory,
        memoryState // Pass memory state for dream logic
    );

    // --- Global Heartbeat / Tick ---
    // Connects sensor data to emotion engine
    useEffect(() => {
        const interval = setInterval(() => {
            processEmotionTick(sensorReadings.batteryVoltage);
        }, 1000);
        return () => clearInterval(interval);
    }, [sensorReadings.batteryVoltage, processEmotionTick]);

    return {
        // Emotion
        emotionState,
        setEmotionState,

        // Memory
        memoryState,
        addEpisodicMemory,

        // Language & Voice
        languageState,
        setLanguageState,
        voiceState,
        lastVoiceText,
        isHandsFree,
        toggleHandsFree,
        voiceEnergy,
        startListening,
        stopListening,
        speak,

        // Inference
        aiMode,
        setAIMode,
        localModelStatus,
        loadLocalModel,
        modelLoadingProgress,
        askAI,

        // Subsystems (Spread for easy access)
        ...subsystems
    };
};
