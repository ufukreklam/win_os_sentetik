
import React from 'react';
import { useOS } from '../../context/OSContext';
import { Mic, Activity, X } from 'lucide-react';

const VoiceOverlay: React.FC = () => {
  const { voiceState, lastVoiceText, stopListening } = useOS();

  if (voiceState === 'idle') return null;

  return (
    <div className="fixed bottom-16 left-1/2 -translate-x-1/2 z-[100] flex flex-col items-center gap-4 animate-in slide-in-from-bottom-10 fade-in duration-300">
        
        {/* Main Interface Bubble */}
        <div className="bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 shadow-2xl flex items-center gap-6 min-w-[300px] max-w-[600px]">
            {/* Visualizer / Icon */}
            <div className="relative shrink-0">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors duration-500 ${
                    voiceState === 'listening' ? 'bg-red-500/20 text-red-400' :
                    voiceState === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-green-500/20 text-green-400'
                }`}>
                    {voiceState === 'listening' ? <Mic size={32} /> : <Activity size={32} />}
                </div>
                {/* Pulse Animation Rings */}
                <div className={`absolute inset-0 rounded-full border-2 opacity-50 animate-ping ${
                     voiceState === 'listening' ? 'border-red-500' :
                     voiceState === 'processing' ? 'border-blue-500' :
                     'border-green-500'
                }`} />
                <div className={`absolute inset-0 rounded-full border border-white/20 animate-pulse delay-100`} />
            </div>

            {/* Text Output */}
            <div className="flex-1 min-w-0 flex flex-col justify-center">
                <span className="text-xs uppercase font-bold tracking-widest text-slate-400 mb-1">
                    {voiceState === 'listening' ? 'Listening...' : 
                     voiceState === 'processing' ? 'Processing...' : 
                     'Speaking...'}
                </span>
                <p className="text-lg font-light text-white leading-tight break-words">
                    {lastVoiceText || "..."}
                </p>
            </div>

            {/* Close Button */}
            <button 
                onClick={stopListening}
                className="shrink-0 p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white"
            >
                <X size={20} />
            </button>
        </div>

        {/* Audio Waveform Simulation (CSS Bars) */}
        {voiceState === 'speaking' && (
            <div className="flex items-center gap-1 h-8">
                {[...Array(10)].map((_, i) => (
                    <div 
                        key={i} 
                        className="w-1 bg-green-400/50 rounded-full animate-[bounce_1s_infinite]" 
                        style={{ 
                            height: `${Math.random() * 100}%`,
                            animationDelay: `${i * 0.1}s` 
                        }} 
                    />
                ))}
            </div>
        )}
    </div>
  );
};

export default VoiceOverlay;
