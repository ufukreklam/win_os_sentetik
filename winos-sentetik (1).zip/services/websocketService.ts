
const WS_URL = 'ws://localhost:8000/ws';

export type WSCallback = (data: any) => void;

class WebSocketService {
    private ws: WebSocket | null = null;
    private subscribers: WSCallback[] = [];
    private reconnectTimeout: any = null;
    private isConnected: boolean = false;
    private shouldReconnect: boolean = true;
    private retryCount: number = 0;
    private baseRetryDelay: number = 1000;

    connect() {
        if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
            return;
        }

        this.shouldReconnect = true;
        
        try {
            this.ws = new WebSocket(WS_URL);

            this.ws.onopen = () => {
                console.log('[WS] Connected');
                this.isConnected = true;
                this.retryCount = 0; // Başarılı bağlantıda sayacı sıfırla
                if (this.reconnectTimeout) {
                    clearTimeout(this.reconnectTimeout);
                    this.reconnectTimeout = null;
                }
            };

            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.notifySubscribers(data);
                } catch (e) {
                    // Sessizce geç, veri bozuk olabilir
                }
            };

            this.ws.onclose = (event) => {
                this.isConnected = false;
                if (this.shouldReconnect) {
                    this.scheduleReconnect();
                }
            };

            this.ws.onerror = (event) => {
                // Hata detayını sadece ilk denemelerde göster, konsolu kirletme
                if (this.retryCount < 2) {
                    console.warn('[WS] Bağlantı hatası. Backend çalışmıyor olabilir.');
                }
                this.ws?.close();
            };

        } catch (e) {
            console.warn("[WS] Bağlantı başlatılamadı.");
            if (this.shouldReconnect) {
                this.scheduleReconnect();
            }
        }
    }

    private scheduleReconnect() {
        if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
        
        // Exponential Backoff: Her hatada bekleme süresini artır (max 30sn)
        const delay = Math.min(30000, this.baseRetryDelay * Math.pow(1.5, this.retryCount));
        
        this.reconnectTimeout = setTimeout(() => {
            this.retryCount++;
            this.connect();
        }, delay);
    }

    disconnect() {
        this.shouldReconnect = false;
        if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout);
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
    }

    send(data: any) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(data));
        }
    }

    subscribe(callback: WSCallback) {
        this.subscribers.push(callback);
        return () => {
            this.subscribers = this.subscribers.filter(cb => cb !== callback);
        };
    }

    private notifySubscribers(data: any) {
        this.subscribers.forEach(cb => cb(data));
    }
    
    getConnectionStatus() {
        return this.isConnected;
    }
}

export const websocketService = new WebSocketService();
