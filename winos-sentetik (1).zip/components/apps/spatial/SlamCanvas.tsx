
import React, { useRef, useEffect } from 'react';
import { useOS } from '../../../context/OSContext';
import { ViewState } from './useSpatialControls';
import { SensorReadings, PerceptionState, SerialStatus } from '../../../types';

interface SlamCanvasProps {
    activeTab: 'slam_2d' | 'slam_3d';
    viewState: React.MutableRefObject<ViewState>;
    sensorReadings: SensorReadings;
    perceptionState: PerceptionState;
    serialStatus: SerialStatus;
    slamMap: string | null;
    onMouseDown: (e: React.MouseEvent) => void;
    onMouseMove: (e: React.MouseEvent) => void;
    onMouseUp: () => void;
    onWheel: (e: React.WheelEvent) => void;
}

export const SlamCanvas: React.FC<SlamCanvasProps> = ({
    activeTab,
    viewState,
    sensorReadings,
    perceptionState,
    serialStatus,
    slamMap,
    onMouseDown,
    onMouseMove,
    onMouseUp,
    onWheel
}) => {
    const { navigationPath, setNavigationGoal } = useOS();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const mapImageRef = useRef<HTMLImageElement>(null);

    // Load Map Image
    useEffect(() => {
        if (slamMap) {
            const img = new Image();
            img.src = slamMap;
            mapImageRef.current = img;
        }
    }, [slamMap]);

    // Handle Click for Navigation Goal
    const handleCanvasClick = (e: React.MouseEvent) => {
        if (viewState.current.isDragging) return; // Ignore drag end

        const canvas = canvasRef.current;
        if (!canvas) return;

        const rect = canvas.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const clickY = e.clientY - rect.top;

        // Inverse Transform Logic
        const width = canvas.width;
        const height = canvas.height;
        const currentScale = viewState.current.scale;
        const centerX = (width / 2) + viewState.current.offsetX;
        const centerY = (height / 2) + viewState.current.offsetY;

        if (activeTab === 'slam_2d') {
            const baseScale = 0.15;
            const finalScale = baseScale * currentScale;
            
            // Map logic in render:
            // imgX = centerX - (drawSize/2)
            // drawSize = 800 * finalScale
            // so pixel coordinate on screen corresponds to:
            // screenX = centerX - (400 * finalScale) + (mapIndexX * finalScale)
            // mapIndexX = (screenX - centerX) / finalScale + 400
            
            const gridX = Math.round((clickX - centerX) / finalScale + 400);
            const gridY = Math.round((centerY - clickY) / finalScale + 400); // Y axis inverted in render logic?
            // Re-checking render logic:
            // px = int(rx + p["y"] / self.resolution) -> map index
            // py = int(ry - p["x"] / self.resolution)
            // In render: ctx.drawImage(...)
            
            // Let's assume standard image mapping:
            // The image is 800x800.
            // ScreenX = centerX - (800*finalScale)/2 + (gridX * finalScale)
            // gridX = (ScreenX - centerX + 400*finalScale) / finalScale
            //       = (ScreenX - centerX)/finalScale + 400
            
            // Y Axis:
            // ScreenY = centerY - (800*finalScale)/2 + (gridY * finalScale)
            // gridY = (ScreenY - centerY)/finalScale + 400
            
            const calculatedX = Math.round((clickX - centerX) / finalScale + 400);
            const calculatedY = Math.round((clickY - centerY) / finalScale + 400);
            
            if (calculatedX >= 0 && calculatedX < 800 && calculatedY >= 0 && calculatedY < 800) {
                setNavigationGoal(calculatedX, calculatedY);
            }
        }
    };

    // Visualization Loop
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const resizeCanvas = () => {
            const parent = canvas.parentElement;
            if (parent) {
                canvas.width = parent.clientWidth;
                canvas.height = parent.clientHeight;
            }
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        let animationFrame: number;

        const render = () => {
            const width = canvas.width;
            const height = canvas.height;
            const currentScale = viewState.current.scale;
            
            // Dinamik merkez hesaplama
            const centerX = (width / 2) + viewState.current.offsetX;
            const centerY = (height / 2) + viewState.current.offsetY;

            // Arkaplan Temizle
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(0, 0, width, height);

            if (activeTab === 'slam_2d') {
                // --- 2D MODU ---
                const baseScale = 0.15; 
                const finalScale = baseScale * currentScale;

                // Draw Persistent SLAM Map (Underlay)
                if (mapImageRef.current) {
                    const mapSize = 800; // Backend'den gelen boyut (800x800)
                    const drawSize = mapSize * finalScale;
                    
                    ctx.globalAlpha = 0.5;
                    ctx.drawImage(
                        mapImageRef.current, 
                        centerX - (drawSize / 2), 
                        centerY - (drawSize / 2), 
                        drawSize, 
                        drawSize
                    );
                    ctx.globalAlpha = 1.0;
                }

                // Grid
                ctx.strokeStyle = '#1e293b';
                ctx.lineWidth = 1;
                ctx.beginPath();
                const gridSize = 50 * currentScale;
                const offsetX = centerX % gridSize;
                const offsetY = centerY % gridSize;

                for (let i = offsetX; i < width; i += gridSize) { ctx.moveTo(i, 0); ctx.lineTo(i, height); }
                for (let i = offsetY; i < height; i += gridSize) { ctx.moveTo(0, i); ctx.lineTo(width, i); }
                ctx.stroke();

                // Navigation Path (Green Line)
                if (navigationPath && navigationPath.length > 1) {
                    ctx.strokeStyle = '#22c55e';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    
                    navigationPath.forEach((pt, index) => {
                        // Map Grid Coords to Screen Coords
                        // screenX = (gridX - 400) * finalScale + centerX
                        const screenX = (pt.x - 400) * finalScale + centerX;
                        const screenY = (pt.y - 400) * finalScale + centerY;
                        
                        if (index === 0) ctx.moveTo(screenX, screenY);
                        else ctx.lineTo(screenX, screenY);
                    });
                    
                    ctx.stroke();
                    
                    // Draw Goal Point
                    const lastPt = navigationPath[navigationPath.length - 1];
                    const goalX = (lastPt.x - 400) * finalScale + centerX;
                    const goalY = (lastPt.y - 400) * finalScale + centerY;
                    
                    ctx.fillStyle = '#22c55e';
                    ctx.beginPath();
                    ctx.arc(goalX, goalY, 5 * currentScale, 0, 2 * Math.PI);
                    ctx.fill();
                }

                // Menzil Halkaları
                ctx.strokeStyle = '#334155';
                for (let r = 50; r < 500; r += 100) {
                    ctx.beginPath();
                    ctx.arc(centerX, centerY, r * currentScale, 0, 2 * Math.PI);
                    ctx.stroke();
                }

                // Robot
                ctx.fillStyle = '#3b82f6';
                ctx.beginPath();
                ctx.arc(centerX, centerY, 8 * currentScale, 0, 2 * Math.PI);
                ctx.fill();
                
                // Yön Oku
                ctx.strokeStyle = '#60a5fa';
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.lineTo(centerX, centerY - (15 * currentScale));
                ctx.stroke();

                // Lidar Noktaları
                if (sensorReadings.lidarMap && sensorReadings.lidarMap.length > 0) {
                    ctx.fillStyle = '#ef4444';
                    sensorReadings.lidarMap.forEach(point => {
                        const rad = (point.angle - 90) * (Math.PI / 180);
                        const x = centerX + Math.cos(rad) * point.distance * finalScale;
                        const y = centerY + Math.sin(rad) * point.distance * finalScale;
                        if (x > 0 && x < width && y > 0 && y < height) {
                            ctx.fillRect(x, y, 3 * currentScale, 3 * currentScale);
                        }
                    });
                }

                // Ultrasonik Koniler
                const drawCone = (dist: number, angleDeg: number, color: string) => {
                    const rad = (angleDeg - 90) * (Math.PI / 180);
                    const coneLen = Math.min(dist * finalScale, 200 * currentScale);
                    ctx.fillStyle = color;
                    ctx.beginPath();
                    ctx.moveTo(centerX, centerY);
                    ctx.arc(centerX, centerY, coneLen, rad - 0.2, rad + 0.2);
                    ctx.fill();
                };
                drawCone(sensorReadings.ultrasonic.front, 0, 'rgba(59, 130, 246, 0.2)');
                drawCone(sensorReadings.ultrasonic.left, -45, 'rgba(59, 130, 246, 0.1)');
                drawCone(sensorReadings.ultrasonic.right, 45, 'rgba(59, 130, 246, 0.1)');

            } else if (activeTab === 'slam_3d') {
                // --- 3D MODU ---
                if (viewState.current.autoRotate) {
                    viewState.current.rotationAngle += 0.002;
                }
                
                const rotationAngle = viewState.current.rotationAngle;
                const baseScale = 0.10;
                const finalScale = baseScale * currentScale;
                const isoAngle = Math.PI / 4; 

                const project = (x: number, y: number, z: number) => {
                    const rx = x * Math.cos(rotationAngle) - y * Math.sin(rotationAngle);
                    const ry = x * Math.sin(rotationAngle) + y * Math.cos(rotationAngle);
                    const screenX = centerX + (rx - ry) * Math.cos(isoAngle) * currentScale;
                    const screenY = centerY + (rx + ry) * Math.sin(isoAngle) * currentScale - (z * currentScale);
                    return { x: screenX, y: screenY };
                };

                // Zemin Izgarası
                ctx.strokeStyle = 'rgba(30, 41, 59, 0.5)';
                ctx.lineWidth = 1;
                const gridSize = 50; 
                const gridLimit = 10; 
                
                ctx.beginPath();
                for(let x = -gridLimit; x <= gridLimit; x++) {
                    const p1 = project(x * gridSize, -gridLimit * gridSize, 0);
                    const p2 = project(x * gridSize, gridLimit * gridSize, 0);
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                }
                for(let y = -gridLimit; y <= gridLimit; y++) {
                    const p1 = project(-gridLimit * gridSize, y * gridSize, 0);
                    const p2 = project(gridLimit * gridSize, y * gridSize, 0);
                    ctx.moveTo(p1.x, p1.y);
                    ctx.lineTo(p2.x, p2.y);
                }
                ctx.stroke();

                // 3D Kutu Çizimi
                const drawCube = (x: number, y: number, z: number, size: number, color: string) => {
                    const pBase = project(x, y, z);
                    const pTop = project(x, y, z + size);
                    ctx.fillStyle = color;
                    ctx.beginPath();
                    ctx.arc(pBase.x, pBase.y, 4 * currentScale, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.strokeStyle = color;
                    ctx.beginPath();
                    ctx.moveTo(pBase.x, pBase.y);
                    ctx.lineTo(pTop.x, pTop.y);
                    ctx.stroke();
                };

                // Robot Merkez
                drawCube(0, 0, 0, 20, '#3b82f6');

                // Lidar 3D Katmanı
                if (sensorReadings.lidarMap && sensorReadings.lidarMap.length > 0) {
                    sensorReadings.lidarMap.forEach(point => {
                        const rad = (point.angle - 90) * (Math.PI / 180);
                        const lx = Math.cos(rad) * point.distance * finalScale * 5; 
                        const ly = Math.sin(rad) * point.distance * finalScale * 5;
                        if (point.distance > 0 && point.distance < 4000) {
                            drawCube(lx, ly, 0, 25, '#ef4444');
                        }
                    });
                }
            }

            // Tespit Edilen Nesneler (Her iki mod için ortak)
            perceptionState.detectedObjects.forEach(obj => {
                let screenX, screenY;
                if (activeTab === 'slam_2d') {
                    screenX = centerX + obj.position.x * 100 * currentScale;
                    screenY = centerY - obj.position.y * 100 * currentScale;
                } else {
                    const p = { x: obj.position.x * 200, y: obj.position.y * 200 }; 
                    const rad = viewState.current.rotationAngle;
                    const rx = p.x * Math.cos(rad) - p.y * Math.sin(rad);
                    const ry = p.x * Math.sin(rad) + p.y * Math.cos(rad);
                    screenX = centerX + (rx - ry) * Math.cos(Math.PI/4) * currentScale;
                    screenY = centerY + (rx + ry) * Math.sin(Math.PI/4) * currentScale;
                }

                ctx.strokeStyle = obj.type === 'living' ? '#22c55e' : '#eab308';
                ctx.strokeRect(screenX - 10, screenY - 10, 20, 20);
                ctx.fillStyle = '#fff';
                ctx.font = '10px Inter';
                ctx.fillText(obj.label, screenX + 12, screenY);
            });

            animationFrame = requestAnimationFrame(render);
        };

        render();

        return () => {
            window.removeEventListener('resize', resizeCanvas);
            cancelAnimationFrame(animationFrame);
        };
    }, [activeTab, sensorReadings, perceptionState, serialStatus, slamMap, navigationPath]); 

    return (
        <canvas 
            ref={canvasRef} 
            className="block w-full h-full cursor-crosshair"
            onMouseDown={onMouseDown}
            onMouseMove={(e) => onMouseMove(e)}
            onMouseUp={onMouseUp}
            onMouseLeave={onMouseUp}
            onWheel={onWheel}
            onClick={handleCanvasClick}
        />
    );
};
