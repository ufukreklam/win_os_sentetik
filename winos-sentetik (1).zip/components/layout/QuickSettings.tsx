import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { AppID } from '../../types';
import { Wifi, Bluetooth, Plane, Moon, Sun, Volume2, Battery, Settings, ChevronRight, Mic, Camera } from 'lucide-react';

interface QuickSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

const QuickSettingsToggle: React.FC<{ 
  icon: React.ElementType; 
  label: string; 
  isActive: boolean; 
  onClick: () => void 
}> = ({ icon: Icon, label, isActive, onClick }) => (
  <button 
    onClick={onClick}
    className={`
      flex flex-col items-start p-3 rounded-xl transition-all duration-200 border
      ${isActive 
        ? 'bg-blue-600 border-blue-500 text-white' 
        : 'bg-slate-800/50 border-white/5 text-slate-300 hover:bg-slate-700/50'
      }
    `}
  >
    <div className="flex items-center justify-between w-full mb-1">
      <Icon size={18} />
      {label === 'Wi-Fi' && <ChevronRight size={14} className="opacity-50" />}
    </div>
    <span className="text-xs font-medium">{label}</span>
  </button>
);

const QuickSettings: React.FC<QuickSettingsProps> = ({ isOpen, onClose }) => {
  const { openApp } = useOS();
  const [wifi, setWifi] = useState(true);
  const [bluetooth, setBluetooth] = useState(true);
  const [airplane, setAirplane] = useState(false);
  const [nightMode, setNightMode] = useState(false);
  const [microphone, setMicrophone] = useState(true);
  const [camera, setCamera] = useState(true);
  const [volume, setVolume] = useState(75);
  const [brightness, setBrightness] = useState(100);

  if (!isOpen) return null;

  const handleOpenSettings = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Prevent event bubbling
    openApp(AppID.SETTINGS);
    onClose();
  };

  return (
    <div 
      className="fixed bottom-14 right-4 z-50 w-80 
                 bg-slate-900/90 backdrop-blur-2xl 
                 border border-white/10 rounded-xl shadow-2xl p-4
                 animate-in slide-in-from-bottom-5 fade-in duration-200"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Toggles Grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <QuickSettingsToggle 
          icon={Wifi} 
          label="Wi-Fi" 
          isActive={wifi} 
          onClick={() => setWifi(!wifi)} 
        />
        <QuickSettingsToggle 
          icon={Bluetooth} 
          label="Bluetooth" 
          isActive={bluetooth} 
          onClick={() => setBluetooth(!bluetooth)} 
        />
        <QuickSettingsToggle 
          icon={Plane} 
          label="Airplane Mode" 
          isActive={airplane} 
          onClick={() => setAirplane(!airplane)} 
        />
        <QuickSettingsToggle 
          icon={Moon} 
          label="Night Light" 
          isActive={nightMode} 
          onClick={() => setNightMode(!nightMode)} 
        />
        <QuickSettingsToggle 
          icon={Mic} 
          label="Mic Access" 
          isActive={microphone} 
          onClick={() => setMicrophone(!microphone)} 
        />
        <QuickSettingsToggle 
          icon={Camera} 
          label="Cam Access" 
          isActive={camera} 
          onClick={() => setCamera(!camera)} 
        />
      </div>

      {/* Sliders */}
      <div className="space-y-4 mb-4">
        <div className="flex items-center gap-3">
          <Sun size={18} className="text-slate-400" />
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={brightness}
            onChange={(e) => setBrightness(parseInt(e.target.value))}
            className="flex-1 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>
        <div className="flex items-center gap-3">
          <Volume2 size={18} className="text-slate-400" />
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={volume}
            onChange={(e) => setVolume(parseInt(e.target.value))}
            className="flex-1 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-white/10">
        <div className="flex items-center gap-2 text-xs text-slate-400">
           <div className="flex items-center gap-1">
              <Battery size={14} />
              <span>100%</span>
           </div>
        </div>
        <button 
          type="button"
          onClick={handleOpenSettings}
          className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white active:bg-white/20"
          aria-label="All Settings"
        >
          <Settings size={16} />
        </button>
      </div>
    </div>
  );
};

export default QuickSettings;