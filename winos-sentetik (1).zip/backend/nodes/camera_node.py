
import asyncio
import logging
import base64
import time
from ..core.robot_system import RobotNode

# Robust import for CV2/Numpy
try:
    import cv2
    import numpy as np
    LIBRARIES_AVAILABLE = True
except ImportError:
    cv2 = None
    np = None
    LIBRARIES_AVAILABLE = False

logger = logging.getLogger("CameraNode")

class CameraNode(RobotNode):
    """
    Raspberry Pi kamerasından (veya USB webcam) görüntü alır.
    Görüntüyü küçültür, JPEG'e sıkıştırır ve Base64 olarak yayınlar.
    Kamera yoksa simülasyon görüntüsü üretir.
    """
    def __init__(self, bus, camera_index=0):
        super().__init__("CameraNode", bus)
        self.camera_index = camera_index
        self.cap = None
        self.loop_interval = 0.066 # ~15 FPS (Bant genişliği tasarrufu için)
        self.simulation_mode = False
        self.frame_width = 320 # Düşük çözünürlük, hızlı transfer
        self.frame_height = 240
        self.jpeg_quality = 70

    async def setup(self):
        if not LIBRARIES_AVAILABLE:
            logger.warning("OpenCV or Numpy not found. CameraNode will be inactive (Simulation only).")
            self.simulation_mode = True
            return

        try:
            self.cap = cv2.VideoCapture(self.camera_index)
            # Kamera ayarlarını yap
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            
            if not self.cap.isOpened():
                logger.warning("Kamera açılamadı. Simülasyon moduna geçiliyor.")
                self.simulation_mode = True
            else:
                logger.info(f"Kamera başlatıldı: Index {self.camera_index}")
                
        except Exception as e:
            logger.error(f"Kamera hatası: {e}")
            self.simulation_mode = True

    async def loop(self):
        # Kütüphaneler yoksa bile simülasyon modunda çalışmaya devam et
        if not LIBRARIES_AVAILABLE and not self.simulation_mode:
            self.simulation_mode = True
            
        frame = None
        
        if not self.simulation_mode and self.cap:
            ret, raw_frame = self.cap.read()
            if ret:
                frame = cv2.resize(raw_frame, (self.frame_width, self.frame_height))
            else:
                # Kamera bağlantısı koptuysa
                self.simulation_mode = True
        
        if self.simulation_mode:
            # Simülasyon: Hareket eden bir daire ve parazit
            # Eğer numpy yoksa çok basit bir dummy data gönder veya hiçbir şey yapma
            if not LIBRARIES_AVAILABLE:
                # Numpy olmadan görüntü oluşturmak zor, bu yüzden boş geçiyoruz
                # veya basit bir text mesajı gönderebiliriz ama protokol bozulabilir.
                await asyncio.sleep(1) 
                return

            frame = np.zeros((self.frame_height, self.frame_width, 3), dtype=np.uint8)
            
            # Gürültü (Noise)
            noise = np.random.randint(0, 50, (self.frame_height, self.frame_width, 3), dtype=np.uint8)
            frame = cv2.add(frame, noise)
            
            # Hareket eden daire
            t = time.time()
            cx = int(self.frame_width/2 + 50 * np.sin(t))
            cy = int(self.frame_height/2 + 50 * np.cos(t))
            cv2.circle(frame, (cx, cy), 20, (0, 255, 0), -1)
            
            # Zaman damgası
            cv2.putText(frame, "NO SIGNAL - SIMULATION", (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        if frame is not None:
            # JPEG Sıkıştırma
            _, buffer = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality])
            
            # Base64 Kodlama
            jpg_as_text = base64.b64encode(buffer).decode('utf-8')
            
            # Yayınla
            await self.bus.publish("camera_frame", jpg_as_text)

    async def teardown(self):
        if self.cap:
            self.cap.release()
