
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { RefreshCw, Trophy, User, Cpu } from 'lucide-react';

const ChessApp: React.FC = () => {
  const [board, setBoard] = useState(initialBoard());
  const [turn, setTurn] = useState<'white' | 'black'>('white');
  const [status, setStatus] = useState('DeepBlue Engine Ready');

  function initialBoard() {
    const b = Array(8).fill(null).map(() => Array(8).fill(null));
    // Simple visual representation
    for(let i=0; i<8; i++) {
        b[1][i] = '♟'; b[6][i] = '♙';
    }
    const row0 = ['♜','♞','♝','♛','♚','♝','♞','♜'];
    const row7 = ['♖','♘','♗','♕','♔','♗','♘','♖'];
    for(let i=0; i<8; i++) {
        b[0][i] = row0[i]; b[7][i] = row7[i];
    }
    return b;
  }

  const handleSquareClick = (r: number, c: number) => {
      // Mock game logic
      setStatus(`Calculating move for ${turn === 'white' ? 'White' : 'Black'}...`);
      setTimeout(() => {
          setTurn(prev => prev === 'white' ? 'black' : 'white');
          setStatus(turn === 'white' ? "DeepBlue is thinking..." : "Your turn.");
      }, 500);
  };

  return (
    <div className="flex flex-col h-full bg-[#1a1a1a] text-slate-200 font-sans">
      <div className="h-12 bg-[#2a2a2a] border-b border-white/5 flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-2">
              <Cpu size={18} className="text-blue-400" />
              <span className="font-bold">DeepBlue Chess</span>
          </div>
          <div className="flex gap-2">
              <button onClick={() => setBoard(initialBoard())} className="p-1.5 hover:bg-white/10 rounded" title="Reset Game"><RefreshCw size={16} /></button>
              <button className="p-1.5 hover:bg-white/10 rounded" title="Leaderboard"><Trophy size={16} /></button>
          </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
          <div className="flex justify-between w-full max-w-[400px] mb-4 text-xs font-bold uppercase tracking-wider text-slate-500">
              <div className="flex items-center gap-2"><Cpu size={14} /> AI (Level 99)</div>
              <div className="flex items-center gap-2"><User size={14} /> Human</div>
          </div>

          <div className="bg-[#2a2a2a] p-1 rounded shadow-2xl">
              <div className="grid grid-cols-8 gap-0.5 border border-slate-600">
                  {board.map((row, r) => (
                      row.map((piece: string | null, c: number) => {
                          const isBlack = (r + c) % 2 === 1;
                          return (
                              <div 
                                key={`${r}-${c}`}
                                onClick={() => handleSquareClick(r, c)}
                                className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 flex items-center justify-center text-2xl sm:text-3xl cursor-pointer hover:opacity-80 transition-opacity
                                    ${isBlack ? 'bg-slate-600 text-slate-200' : 'bg-slate-300 text-slate-800'}
                                `}
                              >
                                  {piece}
                              </div>
                          );
                      })
                  ))}
              </div>
          </div>

          <div className="mt-6 bg-[#2a2a2a] px-4 py-2 rounded-full border border-white/5 text-sm text-blue-300 animate-pulse">
              {status}
          </div>
      </div>
    </div>
  );
};

export default ChessApp;
