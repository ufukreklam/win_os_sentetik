
import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';

interface HistoryItem {
  type: 'input' | 'output';
  content: string;
  path?: string;
}

const TerminalApp: React.FC = () => {
  const { readdir, readFile, mkdir, writeFile, deleteItem, updateFileMetadata, users } = useOS();
  const [history, setHistory] = useState<HistoryItem[]>([
    { type: 'output', content: 'Welcome to WinOS Hybrid Kernel v1.0.0' },
    { type: 'output', content: 'Type "help" for a list of commands.' },
    { type: 'output', content: '' },
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentPath, setCurrentPath] = useState('/home/user');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyPointer, setHistoryPointer] = useState(-1);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (cmdRaw: string) => {
    const cmd = cmdRaw.trim();
    if (!cmd) {
      setHistory(prev => [...prev, { type: 'input', content: '', path: currentPath }]);
      return;
    }

    setCommandHistory(prev => [...prev, cmd]);
    setHistoryPointer(-1);

    const parts = cmd.split(' ');
    const command = parts[0];
    const args = parts.slice(1);

    const newHistoryItem: HistoryItem = { type: 'input', content: cmd, path: currentPath };
    let outputItem: HistoryItem | null = null;

    switch (command) {
      case 'help':
        outputItem = { type: 'output', content: 'Available commands:\n  help         Show this help message\n  clear        Clear terminal screen\n  ls [-l]      List directory contents (use -l for details)\n  cd <dir>     Change directory\n  pwd          Print working directory\n  echo         Display a line of text\n  mkdir <dir>  Create directory\n  touch <file> Create empty file\n  rm <file>    Remove file/folder\n  cat <file>   Display file content\n  chmod <mod>  Change file mode (e.g., 777 script.sh)\n  chown <user> Change file owner\n  neofetch     Show system info' };
        break;
      
      case 'clear':
        setHistory([]);
        return;

      case 'pwd':
        outputItem = { type: 'output', content: currentPath };
        break;
      
      case 'ls':
        const files = readdir(currentPath);
        if (args[0] === '-l') {
            // Detailed List View
            const lines = files.map(f => {
                const typeChar = f.type === 'folder' ? 'd' : '-';
                const perms = f.permissions || 'rwxr-xr-x';
                const owner = (f.owner || 'root').padEnd(8);
                const size = (f.size || '0 B').padStart(6);
                const date = f.dateModified ? f.dateModified.toLocaleTimeString() : '00:00';
                const nameColor = f.type === 'folder' ? '\x1b[34m' : '';
                const reset = '\x1b[0m';
                return `${typeChar}${perms}  ${owner}  ${size}  ${date}  ${nameColor}${f.name}${reset}`;
            });
            outputItem = { type: 'output', content: lines.join('\n') };
        } else {
            // Simple Grid View
            const fileNames = files.map(f => {
                if (f.type === 'folder') return `\x1b[34m${f.name}/\x1b[0m`; // Blue for folders
                return f.name;
            });
            outputItem = { type: 'output', content: fileNames.join('  ') };
        }
        break;

      case 'cd':
        if (!args[0] || args[0] === '~') {
          setCurrentPath('/home/user');
        } else if (args[0] === '..') {
          const parts = currentPath.split('/');
          parts.pop();
          const parent = parts.length === 1 ? '/' : parts.join('/');
          setCurrentPath(parent || '/');
        } else {
          // Check if target exists and is directory
          const targetName = args[0].replace(/\/$/, '');
          const items = readdir(currentPath);
          const target = items.find(i => i.name === targetName);
          
          if (target && target.type === 'folder') {
             setCurrentPath(currentPath === '/' ? `/${targetName}` : `${currentPath}/${targetName}`);
          } else {
             outputItem = { type: 'output', content: `bash: cd: ${args[0]}: No such directory` };
          }
        }
        break;

      case 'mkdir':
        if (args[0]) {
            mkdir(currentPath, args[0]);
        } else {
            outputItem = { type: 'output', content: 'mkdir: missing operand' };
        }
        break;

      case 'touch':
        if (args[0]) {
            writeFile(currentPath, {
                name: args[0],
                type: 'file',
                fileType: 'text',
                size: '0 B',
                permissions: '-rw-r--r--',
                content: ''
            });
        } else {
            outputItem = { type: 'output', content: 'touch: missing operand' };
        }
        break;

      case 'rm':
        if (args[0]) {
            deleteItem(currentPath, args[0]);
        } else {
            outputItem = { type: 'output', content: 'rm: missing operand' };
        }
        break;

      case 'cat':
        if (args[0]) {
            const file = readFile(currentPath, args[0]);
            if (file && file.type === 'file') {
                outputItem = { type: 'output', content: file.content || '' };
            } else {
                outputItem = { type: 'output', content: `cat: ${args[0]}: No such file` };
            }
        }
        break;

      case 'chmod':
          if (args.length < 2) {
              outputItem = { type: 'output', content: 'chmod: missing operand' };
          } else {
              const mode = args[0];
              const fileName = args[1];
              const file = readFile(currentPath, fileName) || readdir(currentPath).find(f => f.name === fileName);
              
              if (!file) {
                   outputItem = { type: 'output', content: `chmod: cannot access '${fileName}': No such file` };
              } else {
                   // Simple mock conversion of 777 to rwxrwxrwx
                   let permString = '';
                   if (mode.length === 3) {
                       const map = ['---', '--x', '-w-', '-wx', 'r--', 'r-x', 'rw-', 'rwx'];
                       permString = mode.split('').map(d => map[parseInt(d)] || '---').join('');
                   } else {
                       permString = mode; // Allow direct string setting for flexibility
                   }
                   
                   updateFileMetadata(currentPath, fileName, { permissions: permString });
              }
          }
          break;
          
      case 'chown':
          if (args.length < 2) {
              outputItem = { type: 'output', content: 'chown: missing operand' };
          } else {
              const newOwner = args[0];
              const fileName = args[1];
              const file = readFile(currentPath, fileName) || readdir(currentPath).find(f => f.name === fileName);
              
              // Validate user exists (simple check against system users + root)
              const userExists = newOwner === 'root' || users.some(u => u.username === newOwner);
              
              if (!file) {
                  outputItem = { type: 'output', content: `chown: cannot access '${fileName}': No such file` };
              } else if (!userExists) {
                  outputItem = { type: 'output', content: `chown: invalid user: '${newOwner}'` };
              } else {
                  updateFileMetadata(currentPath, fileName, { owner: newOwner });
              }
          }
          break;

      case 'neofetch':
        outputItem = { type: 'output', content: `
       /\\        OS: WinOS Hybrid (Web)
      /  \\       Kernel: React 19.0
     / /\\ \\      Uptime: ${Math.floor(performance.now() / 60000)} mins
    / /  \\ \\     Shell: zsh (simulated)
   / /    \\ \\    Resolution: ${window.innerWidth}x${window.innerHeight}
  / /      \\ \\   DE: Glassmorphism
 / /        \\ \\  CPU: Simulated Virtual Core
/_/          \\_\\ GPU: WebGL Renderer
` };
        break;

      default:
        outputItem = { type: 'output', content: `bash: ${command}: command not found` };
    }

    setHistory(prev => {
      const next = [...prev, newHistoryItem];
      if (outputItem) next.push(outputItem);
      return next;
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCommand(currentInput);
      setCurrentInput('');
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyPointer + 1;
        if (newIndex < commandHistory.length) {
          setHistoryPointer(newIndex);
          setCurrentInput(commandHistory[commandHistory.length - 1 - newIndex]);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyPointer > 0) {
        const newIndex = historyPointer - 1;
        setHistoryPointer(newIndex);
        setCurrentInput(commandHistory[commandHistory.length - 1 - newIndex]);
      } else if (historyPointer === 0) {
        setHistoryPointer(-1);
        setCurrentInput('');
      }
    }
  };

  return (
    <div 
      className="h-full bg-slate-950/95 text-slate-200 font-mono text-sm p-2 overflow-y-auto" 
      onClick={() => inputRef.current?.focus()}
    >
      {history.map((item, idx) => (
        <div key={idx} className="mb-1 whitespace-pre-wrap">
          {item.type === 'input' && (
             <div className="flex gap-2">
                <span className="text-green-400 font-bold">user@winos</span>
                <span className="text-slate-400">:</span>
                <span className="text-blue-400 font-bold">{item.path === '/home/user' ? '~' : item.path}</span>
                <span className="text-slate-400">$</span>
                <span>{item.content}</span>
             </div>
          )}
          {item.type === 'output' && (
             <div className="text-slate-300 pl-0">
                {/* Basic ANSI color simulation for folders (Blue) */}
                {item.content.split('\n').map((line, lIdx) => (
                    <div key={lIdx}>
                         {line.split(/(?=\x1b)/).map((chunk, i) => (
                            <span key={i} className={chunk.startsWith('\x1b[34m') ? 'text-blue-400 font-bold' : ''}>
                                {chunk.replace(/\x1b\[[0-9;]*m/g, '')}
                            </span>
                        ))}
                    </div>
                ))}
             </div>
          )}
        </div>
      ))}

      <div className="flex gap-2">
         <span className="text-green-400 font-bold">user@winos</span>
         <span className="text-slate-400">:</span>
         <span className="text-blue-400 font-bold">{currentPath === '/home/user' ? '~' : currentPath}</span>
         <span className="text-slate-400">$</span>
         <input 
            ref={inputRef}
            type="text" 
            value={currentInput}
            onChange={(e) => setCurrentInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent border-none outline-none text-slate-200 p-0"
            autoFocus
            autoComplete="off"
         />
      </div>
      <div ref={bottomRef} />
    </div>
  );
};

export default TerminalApp;
