
import json
import logging
from ..core.robot_system import RobotNode

logger = logging.getLogger("ProtocolNode")

class ProtocolNode(RobotNode):
    """
    SerialNode'dan gelen ham (raw/compact) veriyi ayrıştırır (parse),
    anlamlandırır ve 'hardware_update' kanalına basar.
    
    Çeviri:
    'v' -> batteryVoltage
    'c' -> currentDraw
    'i' -> imu {pitch, roll, yaw}
    'u' -> ultrasonic {front, left, right}
    """
    def __init__(self, bus):
        super().__init__("ProtocolNode", bus)
        # Sadece event-driven çalışacak, loop'a ihtiyacı yok
        self.loop_interval = 1.0 

    async def setup(self):
        self.bus.subscribe("raw_serial", self.handle_raw_data)

    async def handle_raw_data(self, raw_data):
        try:
            # 1. JSON Çözümleme
            if isinstance(raw_data, str):
                # Bazen parça parça gelebilir, basit bir JSON check
                if not (raw_data.startswith('{') and raw_data.endswith('}')):
                    return # Eksik paket
                data = json.loads(raw_data)
            else:
                data = raw_data

            # 2. Veri Dönüştürme (Mapping)
            processed_data = {}

            if "v" in data:
                processed_data["batteryVoltage"] = data["v"]
            
            if "c" in data:
                processed_data["currentDraw"] = data["c"]
            
            if "i" in data:
                processed_data["imu"] = {
                    "pitch": data["i"].get("p", 0),
                    "roll": data["i"].get("r", 0),
                    "yaw": data["i"].get("y", 0)
                }

            if "u" in data and isinstance(data["u"], list) and len(data["u"]) >= 3:
                processed_data["ultrasonic"] = {
                    "front": data["u"][0],
                    "left": data["u"][1],
                    "right": data["u"][2]
                }
            
            if "l_stat" in data:
                processed_data["lidarStatus"] = data["l_stat"]

            # 3. İşlenmiş veriyi sisteme dağıt
            if processed_data:
                await self.bus.publish("hardware_update", processed_data)

        except json.JSONDecodeError:
            logger.debug(f"JSON Ayrıştırma Hatası: {raw_data}")
        except Exception as e:
            logger.error(f"Protokol Hatası: {e}")

    async def loop(self):
        # Bu node reaktif çalışır, periyodik işi yoktur.
        pass
