
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class SystemStatus(BaseModel):
    status: str  # 'nominal', 'warning', 'critical'
    uptime: int
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    temperature: float

class RobotCommand(BaseModel):
    command: str
    parameters: Optional[Dict[str, Any]] = None
    priority: int = 1

class OperationResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
