
import React, { useEffect, useState } from 'react';
import { useOS } from '../../context/OSContext';

interface BSODProps {
  error?: string;
}

const BSOD: React.FC<BSODProps> = ({ error }) => {
  const { setBootState } = useOS();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setBootState('posting'), 1000);
          return 100;
        }
        return prev + Math.floor(Math.random() * 5) + 1;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [setBootState]);

  return (
    <div className="fixed inset-0 bg-[#0078D7] text-white p-20 font-sans cursor-none select-none z-[99999] flex flex-col justify-center">
      <div className="text-[120px] mb-8">:(</div>
      <h1 className="text-3xl font-light mb-8">
        Your PC ran into a problem and needs to restart. We're just collecting some error info, and then we'll restart for you.
      </h1>
      
      <div className="text-3xl font-light mb-12">
        {progress}% complete
      </div>

      <div className="flex items-center gap-4 mt-auto">
        <div className="w-24 h-24 bg-white p-1">
           {/* Mock QR Code */}
           <div className="w-full h-full bg-black/10 flex flex-wrap content-start">
              {Array.from({length: 36}).map((_, i) => (
                  <div key={i} className={`w-1/6 h-1/6 ${Math.random() > 0.5 ? 'bg-black' : 'transparent'}`} />
              ))}
           </div>
        </div>
        <div className="text-sm font-light space-y-1">
          <p>For more information about this issue and possible fixes, visit https://www.windows.com/stopcode</p>
          <p>If you call a support person, give them this info:</p>
          <p>Stop code: {error || 'CRITICAL_PROCESS_DIED'}</p>
        </div>
      </div>
    </div>
  );
};

export default BSOD;
