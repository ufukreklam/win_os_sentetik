import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Target, Battery, Brain, Users, Shield, Plus, CheckCircle, XCircle, Clock, AlertTriangle, TrendingDown, TrendingUp, Minus } from 'lucide-react';
import { Goal, DriveType, Drive } from '../../types';

const GoalsApp: React.FC = () => {
  const { motivationState, addGoal, completeGoal, updateGoal } = useOS();
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [activeTab, setActiveTab] = useState<'mission' | 'history'>('mission');

  const drives = motivationState.drives;

  const handleAddGoal = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newGoalTitle.trim()) return;
      addGoal({
          title: newGoalTitle,
          description: 'Manually added by operator.',
          priority: 'medium',
          source: 'user'
      });
      setNewGoalTitle('');
  };

  const getDriveColor = (type: DriveType, value: number) => {
      if (type === 'energy') return value < 20 ? 'text-red-500' : value < 50 ? 'text-yellow-500' : 'text-green-500';
      return value > 80 ? 'text-green-500' : value > 40 ? 'text-blue-400' : 'text-slate-400';
  };

  const getDriveIcon = (type: DriveType) => {
      switch(type) {
          case 'energy': return <Battery size={20} />;
          case 'curiosity': return <Brain size={20} />;
          case 'social': return <Users size={20} />;
          case 'integrity': return <Shield size={20} />;
      }
  };

  const getPriorityColor = (p: string) => {
      switch(p) {
          case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
          case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
          case 'medium': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
          default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
      }
  };

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 font-sans overflow-hidden">
        {/* Left Column: Drives & Status */}
        <div className="w-64 bg-slate-950 border-r border-white/5 flex flex-col p-4 gap-6 overflow-y-auto">
            <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-blue-600/20 flex items-center justify-center mx-auto mb-2 border border-blue-500/30">
                    <Target size={32} className="text-blue-400" />
                </div>
                <h2 className="font-bold text-lg">Mission Control</h2>
                <div className="text-xs text-slate-500 font-mono">Layer 6: Motivation</div>
            </div>

            <div className="space-y-4">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Internal Drives</h3>
                {(Object.values(drives) as Drive[]).map(drive => (
                    <div key={drive.type} className="bg-white/5 rounded-xl p-3 border border-white/5 relative overflow-hidden group">
                        <div className={`absolute right-2 top-2 text-[10px] ${drive.trend === 'rising' ? 'text-green-400' : drive.trend === 'falling' ? 'text-red-400' : 'text-slate-500'}`}>
                            {drive.trend === 'rising' ? <TrendingUp size={12} /> : drive.trend === 'falling' ? <TrendingDown size={12} /> : <Minus size={12} />}
                        </div>
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                                <span className={getDriveColor(drive.type, drive.value)}>{getDriveIcon(drive.type)}</span>
                                <span className="capitalize text-sm font-medium">{drive.type}</span>
                            </div>
                            <span className="text-xs font-mono">{drive.value.toFixed(0)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div 
                                className={`h-full transition-all duration-500 ${getDriveColor(drive.type, drive.value).replace('text-', 'bg-')}`} 
                                style={{ width: `${drive.value}%` }} 
                            />
                        </div>
                        <div className="grid grid-cols-2 mt-2 gap-2 text-[9px] text-slate-500">
                            <div>Decay: {drive.decayRate}/min</div>
                            <div className="text-right">Weight: {drive.weight}</div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="mt-auto bg-slate-800/50 rounded-xl p-4 border border-white/5">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-slate-400">Dopamine (Reward)</span>
                    <span className={`text-xs font-bold ${motivationState.rewardSignal > 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {motivationState.rewardSignal.toFixed(2)}
                    </span>
                </div>
                <div className="flex h-2 bg-slate-900 rounded-full overflow-hidden relative">
                    <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-white/20" />
                    <div 
                        className={`absolute top-0 bottom-0 transition-all duration-300 ${motivationState.rewardSignal > 0 ? 'bg-green-500 left-1/2' : 'bg-red-500 right-1/2'}`}
                        style={{ width: `${Math.min(50, Math.abs(motivationState.rewardSignal) * 50)}%` }}
                    />
                </div>
            </div>
        </div>

        {/* Main Content: Goals */}
        <div className="flex-1 flex flex-col min-w-0 bg-slate-900">
            {/* Header / Tabs */}
            <div className="h-14 border-b border-white/5 flex items-center px-6 gap-6 bg-slate-900/50">
                <button 
                    onClick={() => setActiveTab('mission')}
                    className={`h-full border-b-2 px-2 text-sm font-medium transition-colors ${activeTab === 'mission' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
                >
                    Active Missions
                </button>
                <button 
                    onClick={() => setActiveTab('history')}
                    className={`h-full border-b-2 px-2 text-sm font-medium transition-colors ${activeTab === 'history' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
                >
                    Mission Logs
                </button>
                <div className="flex-1" />
                <form onSubmit={handleAddGoal} className="relative w-64">
                    <input 
                        type="text" 
                        value={newGoalTitle}
                        onChange={(e) => setNewGoalTitle(e.target.value)}
                        placeholder="Assign new objective..."
                        className="w-full bg-slate-800 border border-white/10 rounded-full py-1.5 pl-4 pr-10 text-sm focus:outline-none focus:border-blue-500"
                    />
                    <button type="submit" className="absolute right-1 top-1/2 -translate-y-1/2 p-1 bg-blue-600 rounded-full hover:bg-blue-500 text-white">
                        <Plus size={14} />
                    </button>
                </form>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {activeTab === 'mission' ? (
                    <>
                        {motivationState.activeGoals.length === 0 && (
                            <div className="flex flex-col items-center justify-center py-20 text-slate-500">
                                <CheckCircle size={48} className="mb-4 opacity-20" />
                                <p>All systems nominal. No active directives.</p>
                            </div>
                        )}
                        {motivationState.activeGoals.map(goal => (
                            <div key={goal.id} className="bg-white/5 border border-white/5 rounded-xl p-4 hover:border-white/10 transition-colors group">
                                <div className="flex items-start gap-4">
                                    <div className={`mt-1 p-2 rounded-lg ${goal.source === 'instinct' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                                        {goal.source === 'instinct' ? <Brain size={20} /> : <Users size={20} />}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-3 mb-1">
                                            <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${getPriorityColor(goal.priority)}`}>
                                                {goal.priority}
                                            </span>
                                            <h3 className="font-bold text-lg truncate">{goal.title}</h3>
                                        </div>
                                        <p className="text-sm text-slate-400 mb-3">{goal.description}</p>
                                        
                                        {/* Progress Bar (Interactive) */}
                                        <div className="flex items-center gap-3">
                                            <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden cursor-pointer group/progress" onClick={(e) => {
                                                const rect = e.currentTarget.getBoundingClientRect();
                                                const pct = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
                                                updateGoal(goal.id, { progress: pct });
                                            }}>
                                                <div className="h-full bg-blue-500 transition-all group-hover/progress:bg-blue-400" style={{ width: `${goal.progress}%` }} />
                                            </div>
                                            <span className="text-xs font-mono w-8 text-right">{Math.round(goal.progress)}%</span>
                                        </div>
                                    </div>
                                    <div className="flex flex-col gap-2">
                                        <button 
                                            onClick={() => completeGoal(goal.id, true)}
                                            className="p-2 hover:bg-green-500/20 rounded-lg text-green-400 transition-colors" 
                                            title="Complete"
                                        >
                                            <CheckCircle size={20} />
                                        </button>
                                        <button 
                                            onClick={() => completeGoal(goal.id, false)}
                                            className="p-2 hover:bg-red-500/20 rounded-lg text-red-400 transition-colors" 
                                            title="Fail/Abort"
                                        >
                                            <XCircle size={20} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </>
                ) : (
                    <div className="space-y-2">
                        {motivationState.completedGoals.map(goal => (
                            <div key={goal.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 border border-white/5 opacity-70 hover:opacity-100 transition-opacity">
                                <div className={goal.status === 'completed' ? 'text-green-400' : 'text-red-400'}>
                                    {goal.status === 'completed' ? <CheckCircle size={18} /> : <AlertTriangle size={18} />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="font-medium text-sm truncate">{goal.title}</div>
                                    <div className="text-xs text-slate-500 flex gap-2">
                                        <span>{goal.status.toUpperCase()}</span>
                                        <span>•</span>
                                        <span>{goal.source}</span>
                                    </div>
                                </div>
                                <div className="text-xs text-slate-500 font-mono flex items-center gap-1">
                                    <Clock size={12} />
                                    {new Date(goal.created).toLocaleTimeString()}
                                </div>
                            </div>
                        ))}
                        {motivationState.completedGoals.length === 0 && (
                            <div className="text-center text-slate-500 py-10 italic">No mission history.</div>
                        )}
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default GoalsApp;