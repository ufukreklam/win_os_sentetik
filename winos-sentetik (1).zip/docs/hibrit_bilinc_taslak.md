# 🧠 Hibrit Bilinç Sistemi - Developer Taslağı

Yapının Ana Avantajları:
🎯 Modüler ve Ölçeklenebilir: Her bileşen kendi dizininde, bağımsız geliştirilebilir
📊 Veri Yönetimi: Raw, processed, cache katmanları ile optimize edilmiş veri akışı
🧠 Esnek AI Mimarisi: MLP'den Transformer'a kadar farklı model desteği
🔒 Güvenlik ve İzleme: Kapsamlı logging, monitoring ve health check sistemi
🐳 DevOps Ready: Docker, Kubernetes, CI/CD altyapısı hazır
🔌 Plugin Sistemi: Gelecekte eklentilerle genişletilebilir mimari
Dikkat Çekici Özellikler:

Sensors klasörü: Farklı veri kaynaklarından modüler veri toplama
Plugins sistemi: Üçüncü parti geliştirici desteği
API katmanı: REST, WebSocket, gRPC ile dış entegrasyon
Monitoring: Gerçek zamanlı sistem izleme ve alerting
Benchmarks: Sürekli performans karşılaştırması

Bu yapı ile sistem sadece bir bilinç simülasyonu değil, enterprise-grade bir AI platformu haline geliyor!

## 📁 Genişletilmiş Proje Yapısı
```
hibrit_bilinc/
├── 📁 config/
│   ├── config.json                    # Ana sistem konfigürasyonu
│   ├── neural_config.json             # NN model hiperparametreleri
│   ├── rules/
│   │   ├── base_rules.json           # Temel davranış kuralları
│   │   ├── personality_rules.json    # Kişilik tabanlı kurallar
│   │   ├── emergency_rules.json      # Acil durum kuralları
│   │   └── custom_rules.json         # Kullanıcı tanımlı kurallar
│   ├── schemas/
│   │   ├── bilinc_schema.json       # JSONL kayıt şeması
│   │   ├── state_schema.json        # Durum vektörü şeması
│   │   └── output_schema.json       # Çıktı formatı şeması
│   └── presets/
│       ├── aggressive.json          # Agresif kişilik profili
│       ├── calm.json               # Sakin kişilik profili
│       ├── curious.json            # Meraklı kişilik profili
│       └── default.json            # Varsayılan profil
│
├── 📁 logs/
│   ├── bilinc/
│   │   ├── bilinc_2024_12.jsonl    # Aylık bilinç kayıtları
│   │   ├── bilinc_2025_01.jsonl
│   │   └── current.jsonl           # Aktif kayıt dosyası
│   ├── system/
│   │   ├── error.log               # Sistem hataları
│   │   ├── performance.log         # Performans metrikleri
│   │   ├── training.log            # Model eğitim logları
│   │   └── decision.log            # Karar verme süreci logları
│   ├── archive/
│   │   ├── 2024/                   # Yıllık arşiv
│   │   └── 2025/
│   ├── analytics/
│   │   ├── daily_stats.json        # Günlük istatistikler
│   │   ├── weekly_reports/
│   │   └── monthly_analysis/
│   └── debug/
│       ├── trace.log               # Detaylı izleme
│       └── state_dumps/            # Durum dökümü dosyaları
│
├── 📁 models/
│   ├── active/
│   │   ├── bilinc_v1.0.2.pt       # Aktif model
│   │   ├── metadata.json          # Model meta bilgileri
│   │   ├── scaler.pkl             # Özellik ölçekleyici
│   │   └── vocab.json             # Kelime dağarcığı (varsa)
│   ├── archive/
│   │   ├── v1.0.1/
│   │   ├── v1.0.0/
│   │   └── experimental/
│   ├── checkpoints/
│   │   ├── training_checkpoint_epoch_100.pt
│   │   └── best_model.pt
│   ├── exports/
│   │   ├── onnx/                   # ONNX formatında modeller
│   │   ├── tensorrt/              # TensorRT optimizasyonu
│   │   └── mobile/                # Mobil deployment
│   └── benchmarks/
│       ├── accuracy_tests/
│       ├── speed_tests/
│       └── comparison_reports/
│
├── 📁 data/
│   ├── raw/
│   │   ├── sensors/                # Ham sensör verileri
│   │   ├── user_interactions/      # Kullanıcı etkileşim verileri
│   │   └── external/               # Dış kaynaklardan gelen veri
│   ├── processed/
│   │   ├── features/               # İşlenmiş özellik vektörleri
│   │   ├── sequences/              # LSTM için sekanslar
│   │   └── normalized/             # Normalize edilmiş veriler
│   ├── datasets/
│   │   ├── train/
│   │   │   ├── features.npy
│   │   │   └── targets.npy
│   │   ├── validation/
│   │   └── test/
│   ├── cache/
│   │   ├── feature_cache/          # Özellik hesaplama önbelleği
│   │   └── model_cache/            # Model çıktı önbelleği
│   └── samples/
│       ├── synthetic/              # Sentetik veri örnekleri
│       └── reference/              # Referans veri setleri
│
├── 📁 src/
│   ├── 🧠 core/
│   │   ├── __init__.py
│   │   ├── bilinc_motoru.py        # Ana bilinç motor sınıfı
│   │   ├── durum_yoneticisi.py     # Durum ve sensör yönetimi
│   │   ├── karar_verici.py         # Hibrit karar verme sistemi
│   │   ├── kisilik_motoru.py       # Kişilik profili işleme
│   │   └── bilinc_dongusu.py       # Ana işlem döngüsü
│   │
│   ├── 📊 data/
│   │   ├── __init__.py
│   │   ├── jsonl_yoneticisi.py     # JSONL okuma/yazma
│   │   ├── veri_isleyici.py        # Veri ön işleme
│   │   ├── feature_extractor.py    # Özellik çıkarma
│   │   ├── data_validator.py       # Veri doğrulama
│   │   ├── augmentator.py          # Veri artırma
│   │   └── samplers.py             # Veri örnekleme strategileri
│   │
│   ├── 🧮 neural/
│   │   ├── __init__.py
│   │   ├── model_yoneticisi.py     # Model yükleme/kaydetme
│   │   ├── egitim_motoru.py        # Model eğitimi
│   │   ├── tahmin_motoru.py        # Tahmin yapma
│   │   ├── architectures/
│   │   │   ├── mlp_model.py        # Çok katmanlı algılayıcı
│   │   │   ├── lstm_model.py       # LSTM ağları
│   │   │   ├── transformer.py      # Transformer modeli
│   │   │   └── hybrid_model.py     # Hibrit mimari
│   │   ├── optimizers/
│   │   │   ├── custom_optimizers.py
│   │   │   └── lr_schedulers.py
│   │   ├── losses/
│   │   │   ├── custom_losses.py
│   │   │   └── multi_task_loss.py
│   │   └── metrics/
│   │       ├── consciousness_metrics.py
│   │       └── evaluation_metrics.py
│   │
│   ├── ⚖️ rules/
│   │   ├── __init__.py
│   │   ├── kural_motoru.py         # Kural işletme motoru
│   │   ├── kural_tanimlayici.py    # Kural tanımlama
│   │   ├── rule_parser.py          # Kural dosyası ayrıştırma
│   │   ├── priority_manager.py     # Kural öncelik yönetimi
│   │   ├── condition_evaluator.py  # Koşul değerlendirme
│   │   └── templates/
│   │       ├── basic_templates.py  # Temel kural şablonları
│   │       └── advanced_templates.py
│   │
│   ├── 💭 sensors/
│   │   ├── __init__.py
│   │   ├── base_sensor.py          # Temel sensör sınıfı
│   │   ├── time_sensor.py          # Zaman tabanlı sensör
│   │   ├── user_sensor.py          # Kullanıcı etkileşimi sensörü
│   │   ├── system_sensor.py        # Sistem durumu sensörü
│   │   ├── memory_sensor.py        # Bellek durumu sensörü
│   │   ├── external_sensor.py      # Dış API sensörleri
│   │   └── virtual_sensors.py      # Sanal sensörler
│   │
│   ├── 🔄 scheduler/
│   │   ├── __init__.py
│   │   ├── gorev_planlaici.py      # Ana görev planlaması
│   │   ├── arkaplan_gorevleri.py   # Arkaplanda çalışan görevler
│   │   ├── training_scheduler.py   # Eğitim planlaması
│   │   ├── maintenance_scheduler.py # Bakım görevleri
│   │   └── task_queue.py           # Görev kuyruğu yönetimi
│   │
│   ├── 🔧 utils/
│   │   ├── __init__.py
│   │   ├── config_yoneticisi.py    # Konfigürasyon yönetimi
│   │   ├── log_yoneticisi.py       # Log sistemi
│   │   ├── performans_izleyici.py  # Performans ölçümü
│   │   ├── file_manager.py         # Dosya işlemleri
│   │   ├── crypto_utils.py         # Şifreleme yardımcıları
│   │   ├── network_utils.py        # Ağ işlemleri
│   │   ├── math_utils.py           # Matematiksel yardımcılar
│   │   └── decorators.py           # Yardımcı dekoratörler
│   │
│   ├── 🌐 api/
│   │   ├── __init__.py
│   │   ├── rest_api.py             # REST API endpoints
│   │   ├── websocket_api.py        # WebSocket bağlantıları
│   │   ├── grpc_server.py          # gRPC sunucusu
│   │   ├── middleware.py           # API middleware
│   │   └── authentication.py       # Kimlik doğrulama
│   │
│   ├── 🎯 plugins/
│   │   ├── __init__.py
│   │   ├── plugin_manager.py       # Plugin yönetim sistemi
│   │   ├── base_plugin.py          # Temel plugin sınıfı
│   │   ├── consciousness_plugins/  # Bilinç genişletmeleri
│   │   ├── sensor_plugins/         # Ek sensörler
│   │   └── output_plugins/         # Çıktı genişletmeleri
│   │
│   └── 🔍 monitoring/
│       ├── __init__.py
│       ├── health_checker.py       # Sistem sağlık kontrolü
│       ├── metrics_collector.py    # Metrik toplama
│       ├── alerting.py            # Alarm sistemi
│       ├── dashboard.py           # İzleme paneli
│       └── profiler.py            # Kod profilleme
│
├── 📁 tests/
│   ├── __init__.py
│   ├── unit/                       # Birim testleri
│   │   ├── test_core/
│   │   ├── test_data/
│   │   ├── test_neural/
│   │   ├── test_rules/
│   │   └── test_utils/
│   ├── integration/                # Entegrasyon testleri
│   │   ├── test_full_system/
│   │   ├── test_hibrit_mode/
│   │   └── test_training_pipeline/
│   ├── performance/                # Performans testleri
│   │   ├── test_memory_usage/
│   │   ├── test_response_time/
│   │   └── test_throughput/
│   ├── fixtures/                   # Test verileri
│   │   ├── sample_data/
│   │   ├── mock_configs/
│   │   └── reference_outputs/
│   └── benchmarks/                 # Karşılaştırmalı testler
│       ├── accuracy_benchmarks/
│       └── speed_benchmarks/
│
├── 📁 docs/
│   ├── api/                        # API dokümantasyonu
│   ├── architecture/               # Mimari dokümantasyonu
│   ├── tutorials/                  # Kullanım kılavuzları
│   ├── examples/                   # Örnek kodlar
│   └── research/                   # Araştırma notları
│
├── 📁 scripts/
│   ├── setup/
│   │   ├── install.sh             # Kurulum scripti
│   │   ├── create_directories.py   # Dizin oluşturma
│   │   └── initial_config.py       # İlk konfigürasyon
│   ├── training/
│   │   ├── train_model.py         # Model eğitimi
│   │   ├── evaluate_model.py      # Model değerlendirme
│   │   └── hyperparameter_search.py
│   ├── data/
│   │   ├── data_migration.py      # Veri göçü
│   │   ├── cleanup_old_logs.py    # Log temizleme
│   │   └── backup_system.py       # Yedekleme
│   └── deployment/
│       ├── deploy.sh              # Deployment scripti
│       ├── health_check.py        # Sağlık kontrolü
│       └── rollback.py            # Geri alma
│
├── 📁 docker/
│   ├── Dockerfile                 # Ana Docker imajı
│   ├── docker-compose.yml         # Çoklu konteyner yapılandırması
│   ├── requirements.txt           # Python bağımlılıkları
│   └── entrypoint.sh             # Konteyner başlangıç scripti
│
├── 📁 kubernetes/
│   ├── deployment.yaml            # K8s deployment
│   ├── service.yaml              # K8s service
│   ├── configmap.yaml            # K8s config map
│   └── ingress.yaml              # K8s ingress
│
├── 📄 README.md                   # Proje ana dokümantasyonu
├── 📄 CHANGELOG.md               # Sürüm değişiklikleri
├── 📄 LICENSE                    # Lisans dosyası
├── 📄 requirements.txt           # Python bağımlılıkları
├── 📄 setup.py                   # Paket kurulum dosyası
├── 📄 pyproject.toml             # Modern Python proje yapılandırması
├── 📄 Makefile                   # Build ve deploy komutları
└── 📄 .gitignore                 # Git ignore kuralları
```

## 🔧 Ana Fonksiyon Listesi

### 📊 **CORE - Bilinç Motor Sistemi**

#### `BilinçMotoru` Sınıfı
- `__init__(config_path)` - Konfigürasyon yükleme, dizin kontrolü
- `başlat()` - Sistem başlatma, mod belirleme (kural/hibrit)
- `durum_güncelle(sensörler, içsel_durum)` - Anlık bilinç durumunu güncelle
- `karar_ver()` - Hibrit karar verme (NN + kural fallback)
- `jsonl_kaydet(bilinç_anı)` - JSONL formatında kayıt
- `mod_değiştir(yeni_mod)` - Çalışma modunu değiştir
- `durdur()` - Sistem güvenli kapatma

#### `DurumYöneticisi` Sınıfı
- `sensör_oku()` - Tüm sensör verilerini topla
- `içsel_durum_hesapla()` - Enerji, mood, motivasyon hesapla
- `kişilik_uygula(durum)` - Kişilik parametrelerini dahil et
- `durum_vektörü_oluştur()` - NN için durum vektörü hazırla

### 📝 **DATA - Veri Yönetimi**

#### `JsonlYöneticisi` Sınıfı
- `kayıt_ekle(bilinç_anı)` - Yeni JSONL satırı ekle
- `kayıt_oku(tarih_aralığı)` - Belirli dönem kayıtlarını oku
- `dosya_boyutu_kontrol()` - Log dosya boyutunu kontrol et
- `arşivle(tarih)` - Eski kayıtları arşivle
- `temizle(gün_sayısı)` - Eski kayıtları sil

#### `Veriİşleyici` Sınıfı
- `jsonl_to_dataset()` - JSONL'i ML dataset'e çevir
- `normalize_features()` - Özellik normalizasyonu
- `split_data(train_ratio, val_ratio)` - Train/val/test ayır
- `create_sequences()` - LSTM için sekans oluştur
- `augment_data()` - Veri artırma teknikleri

### 🧮 **NEURAL - Sinir Ağı Sistemi**

#### `ModelYöneticisi` Sınıfı
- `model_kontrol()` - Mevcut modelleri tara
- `en_güncel_model()` - En yeni model versiyonunu bul
- `model_yükle(model_path)` - Modeli hafızaya yükle
- `model_kaydet(model, versiyon)` - Eğitilmiş modeli kaydet
- `model_arşivle(eski_versiyon)` - Eski modeli arşivle

#### `EğitimMotoru` Sınıfı
- `eğitim_gerekli_mi()` - Yeterli veri var mı kontrol et
- `otomatik_eğitim_başlat()` - Arkaplanda eğitim süreci başlat
- `model_oluştur(mimari_tipi)` - MLP/LSTM model oluştur
- `eğit(dataset, epochs)` - Model eğitim süreci
- `değerlendir(test_data)` - Model performansı test et
- `hiperparametre_optimizasyonu()` - Otomatik parametre ayarı

#### `TahminMotoru` Sınıfı
- `tahmin_yap(durum_vektörü)` - NN ile tahmin
- `güven_skoru_hesapla()` - Tahminin güvenilirlik skoru
- `hibrit_karar(nn_tahmin, kural_çıktısı)` - İki sonucu birleştir
- `model_güncelle_kontrol()` - Yeni model var mı kontrol

### ⚖️ **RULES - Kural Tabanlı Sistem**

#### `KuralMotoru` Sınıfı
- `kuralları_yükle()` - Kural setini dosyadan oku
- `kural_değerlendir(durum)` - Duruma göre kuralları işlet
- `öncelik_sırala()` - Kural önceliklerini belirle
- `sonuç_döndür()` - Kural tabanlı karar ver
- `kural_ekle(yeni_kural)` - Dinamik kural ekleme

#### `KuralTanımlayıcı` Sınıfı
- `enerji_kuralları()` - Enerji seviyesi kuralları
- `duygu_kuralları()` - Duygu durumu kuralları
- `sosyal_kuralları()` - Kullanıcı etkileşimi kuralları
- `zaman_kuralları()` - Zaman tabanlı kurallar
- `acil_durum_kuralları()` - Kritik durumlar için kurallar

### 🔧 **UTILS - Yardımcı Fonksiyonlar**

#### `ConfigYöneticisi` Sınıfı
- `config_yükle()` - JSON config dosyasını oku
- `config_güncelle(anahtar, değer)` - Config değerini güncelle
- `varsayılan_config_oluştur()` - İlk kurulum için config
- `config_doğrula()` - Config dosyasını doğrula

#### `LogYöneticisi` Sınıfı
- `sistem_log(seviye, mesaj)` - Sistem loglarını yaz
- `hata_log(exception)` - Hata durumlarını kaydet
- `performans_log(metrik)` - Performans metriklerini kaydet
- `log_temizle()` - Eski logları temizle

#### `Performansİzleyici` Sınıfı
- `bellek_kullanımı()` - RAM kullanımını ölç
- `işlem_süresi(fonksiyon)` - Fonksiyon çalışma süresini ölç
- `model_doğruluğu()` - NN model başarı oranı
- `sistem_sağlığı()` - Genel sistem durumu

### 🔄 **SCHEDULER - Otomatik Görev Yönetimi**

#### `GörevPlanlaıcı` Sınıfı
- `eğitim_planla()` - Periyodik model eğitimi planla
- `veri_temizlik_planla()` - Log temizlik görevleri
- `model_güncelleme_kontrol()` - Yeni model kontrol görevi
- `sistem_bakım_planla()` - Otomatik bakım görevleri

#### `ArkaplanGörevleri` Sınıfı
- `sürekli_veri_toplama()` - Arkaplanda veri toplama
- `otomatik_yedekleme()` - Config ve model yedekleme
- `sistem_izleme()` - Sürekli sistem performansı izleme
- `hata_bildirimi()` - Kritik hatalar için alarm

## 🏁 **Ana Çalışma Akışı**

### Sistem Başlatma Sırası:
1. `ConfigYöneticisi.config_yükle()`
2. `BilinçMotoru.__init__()`
3. `ModelYöneticisi.model_kontrol()`
4. `BilinçMotoru.başlat()` → mod belirleme
5. `GörevPlanlaıcı` başlat

### Anlık Karar Verme Döngüsü:
1. `DurumYöneticisi.sensör_oku()`
2. `DurumYöneticisi.durum_vektörü_oluştur()`
3. `BilinçMotoru.karar_ver()` → hibrit sistem
4. `JsonlYöneticisi.kayıt_ekle()`
5. Aksiyonu uygula

### Otomatik Eğitim Döngüsü:
1. `EğitimMotoru.eğitim_gerekli_mi()`
2. `Veriİşleyici.jsonl_to_dataset()`
3. `EğitimMotoru.otomatik_eğitim_başlat()`
4. `ModelYöneticisi.model_kaydet()`
5. `BilinçMotoru.mod_değiştir("hibrit")`

## 🎯 **Geliştirme Öncelikleri**

### Faz 1: Temel Sistem
- `BilinçMotoru`, `DurumYöneticisi`, `JsonlYöneticisi`
- Sadece kural tabanlı çalışma
- Temel veri toplama

### Faz 2: ML Entegrasyonu
- `ModelYöneticisi`, `EğitimMotoru`, `TahminMotoru`
- Basit MLP model desteği
- Manuel eğitim tetiklemesi

### Faz 3: Otomasyon
- `GörevPlanlaıcı`, `ArkaplanGörevleri`
- Otomatik eğitim döngüsü
- Hibrit mod optimizasyonu

### Faz 4: Gelişmiş Özellikler
- LSTM/Transformer desteği
- Online learning
- Dağıtık eğitim desteği