
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Users, ScanFace, Activity, ShieldCheck, Heart, User, Clock, PlayCircle } from 'lucide-react';
import { CoreEmotion } from '../../types';

const SocialApp: React.FC = () => {
  const { socialState, triggerSocialEvent, serialStatus } = useOS();
  const [activeTab, setActiveTab] = useState<'live' | 'trust' | 'history'>('live');

  const getEmotionColor = (emotion: CoreEmotion) => {
      switch (emotion) {
          case 'happy': return 'text-yellow-400';
          case 'sad': return 'text-blue-400';
          case 'angry': return 'text-red-400';
          case 'fear': return 'text-purple-400';
          default: return 'text-slate-400';
      }
  };

  const getTrustColor = (score: number) => {
      if (score >= 80) return 'bg-green-500';
      if (score >= 50) return 'bg-blue-500';
      if (score >= 20) return 'bg-yellow-500';
      return 'bg-red-500';
  };

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('live')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'live' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <ScanFace size={20} />
                <span className="hidden md:inline text-sm font-medium">Live Feed</span>
            </button>
            <button 
                onClick={() => setActiveTab('trust')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'trust' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <ShieldCheck size={20} />
                <span className="hidden md:inline text-sm font-medium">Trust Matrix</span>
            </button>
            <button 
                onClick={() => setActiveTab('history')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'history' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <Activity size={20} />
                <span className="hidden md:inline text-sm font-medium">History</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
            {activeTab === 'live' && (
                <div className="flex-1 relative bg-black flex items-center justify-center overflow-hidden">
                    {/* Simulated Camera Feed Background */}
                    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=2576&auto=format&fit=crop')] bg-cover bg-center opacity-30 filter grayscale contrast-125" />
                    
                    <div className="absolute inset-0 flex flex-col p-4">
                        <div className="flex justify-between items-start">
                            <div className="bg-red-500/20 border border-red-500/50 text-red-400 px-3 py-1 rounded text-xs font-bold animate-pulse">
                                REC • LIVE
                            </div>
                            <div className="text-right text-[10px] font-mono text-green-400/80">
                                <div>FACE_RECOG_V2.1</div>
                                <div>FPS: 24.0</div>
                            </div>
                        </div>
                    </div>

                    {/* Detected Faces Overlay */}
                    {socialState.detectedFaces.map(face => {
                        const identity = socialState.identities.find(i => i.id === face.identityId);
                        const label = identity ? identity.name : 'Unknown';
                        const trust = identity ? identity.trustScore : 0;

                        return (
                            <div 
                                key={face.id}
                                className="absolute border-2 border-blue-500/80 shadow-[0_0_15px_rgba(59,130,246,0.5)] transition-all duration-300 animate-in zoom-in-95"
                                style={{
                                    left: `${face.boundingBox.x}%`,
                                    top: `${face.boundingBox.y}%`,
                                    width: `${face.boundingBox.w}%`,
                                    height: `${face.boundingBox.h}%`
                                }}
                            >
                                {/* HUD Labels */}
                                <div className="absolute -top-8 left-0 right-0 flex justify-between items-end">
                                    <span className="bg-blue-600 text-white text-[10px] px-2 py-0.5 font-bold uppercase tracking-wider">
                                        {label}
                                    </span>
                                    <span className="text-[10px] text-blue-300 font-mono bg-black/50 px-1">
                                        {(face.confidence * 100).toFixed(0)}%
                                    </span>
                                </div>
                                
                                <div className="absolute -bottom-14 left-0 bg-black/70 backdrop-blur-md p-2 rounded-b-lg border border-blue-500/30 text-xs w-full">
                                    <div className="flex justify-between mb-1">
                                        <span className="text-slate-400">Emotion</span>
                                        <span className={`font-bold uppercase ${getEmotionColor(face.emotion)}`}>
                                            {face.emotion}
                                        </span>
                                    </div>
                                    {identity && (
                                        <div className="flex justify-between">
                                            <span className="text-slate-400">Trust</span>
                                            <span className={`font-bold ${trust > 50 ? 'text-green-400' : 'text-red-400'}`}>
                                                {trust.toFixed(0)}/100
                                            </span>
                                        </div>
                                    )}
                                </div>

                                {/* Corner Markers */}
                                <div className="absolute -top-1 -left-1 w-2 h-2 border-t-2 border-l-2 border-white" />
                                <div className="absolute -top-1 -right-1 w-2 h-2 border-t-2 border-r-2 border-white" />
                                <div className="absolute -bottom-1 -left-1 w-2 h-2 border-b-2 border-l-2 border-white" />
                                <div className="absolute -bottom-1 -right-1 w-2 h-2 border-b-2 border-r-2 border-white" />
                            </div>
                        );
                    })}

                    {socialState.detectedFaces.length === 0 && (
                        <div className="absolute bottom-10 text-slate-500 text-xs animate-pulse">
                            SCANNING FOR TARGETS...
                        </div>
                    )}

                    {/* Simulation Controls (Only if not connected to hardware) */}
                    {serialStatus !== 'connected' && (
                        <div className="absolute bottom-4 right-4 flex gap-2">
                            <button 
                                onClick={() => triggerSocialEvent('detect')}
                                className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors"
                            >
                                <PlayCircle size={16} /> Simulate Encounter
                            </button>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'trust' && (
                <div className="flex-1 overflow-y-auto p-6">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Users className="text-blue-400" />
                        Known Identities
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {socialState.identities.map(person => (
                            <div key={person.id} className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-colors">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border border-white/10">
                                            <User size={20} className="text-slate-400" />
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-sm">{person.name}</h3>
                                            <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                                                person.relationship === 'admin' ? 'bg-purple-500/20 text-purple-300' :
                                                person.relationship === 'friend' ? 'bg-green-500/20 text-green-300' :
                                                'bg-slate-500/20 text-slate-300'
                                            }`}>
                                                {person.relationship}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="text-right text-[10px] text-slate-500">
                                        <div>ID: {person.id}</div>
                                        <div>INT: {person.interactions}</div>
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-400">
                                            <span>Trust Score</span>
                                            <span>{person.trustScore.toFixed(0)}%</span>
                                        </div>
                                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full ${getTrustColor(person.trustScore)} transition-all duration-500`}
                                                style={{ width: `${person.trustScore}%` }}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex justify-between text-xs mb-1 text-slate-400">
                                            <span className="flex items-center gap-1"><Heart size={10} /> Affinity</span>
                                            <span>{person.affinity.toFixed(0)}%</span>
                                        </div>
                                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-pink-500 transition-all duration-500"
                                                style={{ width: `${person.affinity}%` }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'history' && (
                <div className="flex-1 overflow-y-auto p-6">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Clock className="text-blue-400" />
                        Interaction Log
                    </h2>
                    <div className="relative border-l border-white/10 ml-3 space-y-6">
                        {socialState.identities.sort((a, b) => new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime()).map(person => (
                            <div key={person.id} className="ml-6 relative animate-in slide-in-from-left-2 duration-300">
                                <div className="absolute -left-[31px] top-0 w-4 h-4 rounded-full bg-slate-900 border-2 border-blue-500" />
                                <div className="bg-white/5 rounded-lg p-3 border border-white/5">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="font-bold text-sm text-blue-300">Interaction Detected</span>
                                        <span className="text-xs text-slate-500 font-mono">
                                            {new Date(person.lastSeen).toLocaleTimeString()}
                                        </span>
                                    </div>
                                    <p className="text-xs text-slate-300">
                                        Encountered <strong className="text-white">{person.name}</strong>. 
                                        Trust level is currently <strong className={person.trustScore > 50 ? 'text-green-400' : 'text-red-400'}>{person.trustScore.toFixed(0)}%</strong>.
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default SocialApp;
