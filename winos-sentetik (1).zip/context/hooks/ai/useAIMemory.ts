
import { useState, useCallback } from 'react';
import { MemoryState, EpisodicMemory } from '../../../types';
import { INITIAL_MEMORY } from '../../initialStates';
import { vectorStore } from '../../../services/vectorStore';
import { getEmbedding } from '../../../services/geminiService';
import { personalityService } from '../../../services/personalityService';

export const useAIMemory = (timeOffset: number, emotionPrimary: string) => {
    const [memoryState, setMemoryState] = useState<MemoryState>(INITIAL_MEMORY);

    const addEpisodicMemory = useCallback(async (event: string, category: EpisodicMemory['category']) => {
        const memoryId = `mem_${Date.now()}`;
        
        // 1. State Güncelleme (UI için)
        setMemoryState(prev => {
            // Tekrarlanan logları engelle (Son 5 saniye içinde aynı olay varsa)
            if (prev.episodicLog.length > 0 && prev.episodicLog[0].event === event && (Date.now() - prev.episodicLog[0].timestamp.getTime() < 5000)) {
                return prev;
            }
            const newMemory: EpisodicMemory = {
                id: memoryId,
                timestamp: new Date(Date.now() + timeOffset),
                event,
                category,
                emotion: emotionPrimary
            };
            return {
                ...prev,
                episodicLog: [newMemory, ...prev.episodicLog].slice(0, 100)
            };
        });

        // 2. Vektör Veritabanına Kayıt (RAG için)
        try {
            const embedding = await getEmbedding(event);
            if (embedding) {
                await vectorStore.addDocument({
                    id: memoryId,
                    content: event,
                    embedding: embedding,
                    metadata: { category, timestamp: new Date() }
                });
            }
        } catch (e) {
            console.error("Memory Vectorization Failed:", e);
        }
        
        // 3. Kişilik Evrimi Tetikleme
        if (category === 'conversation' || category === 'social') {
             personalityService.evolve('social_success', 0.5);
        } else if (category === 'error') {
             personalityService.evolve('stress', 0.5);
        } else if (category === 'achievement') {
             personalityService.evolve('achievement', 0.8);
        }

    }, [timeOffset, emotionPrimary]);

    return {
        memoryState,
        setMemoryState,
        addEpisodicMemory
    };
};
