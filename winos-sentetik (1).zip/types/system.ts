
import { AppID, AppCategory } from './enums';

// --- Window & UI Types ---
export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface WindowState {
  id: AppID;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  icon?: any; // Lucide icon component
  x?: number;
  y?: number;
  width?: number;
  height?: number;
}

export interface AppMetadata {
  id: AppID;
  name: string;
  icon: any;
  version: string;
  size: string;
  isSystem: boolean; // System apps cannot be uninstalled
  description?: string;
  category?: AppCategory;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  showToast?: boolean; // Controls toast visibility vs history
}

// --- User System Types ---
export interface UserProfile {
  id: string;
  username: string;
  pin: string; // "1234" or empty for no pin
  avatarColor: string; // Tailwind class e.g., 'bg-blue-600'
  wallpaper: string;
  installedAppIds: AppID[];
  pinnedAppIds: AppID[]; // Apps pinned to start menu
  isAdmin: boolean;
}

// --- Boot & Hardware Config Types ---
export interface HardwareConfig {
  bootOrder: string;
  fastBoot: boolean;
  overclock: boolean;
  ramSize: string;
  uuid: string;
}

export type BootState = 'posting' | 'bios' | 'os' | 'bsod';
export type BootMode = 'normal' | 'safe';

// --- Plugin Architecture (Layer 16) ---
export type PluginLifecycle = 'unloaded' | 'validating' | 'loading' | 'initializing' | 'active' | 'error';

export interface PluginMetadata {
    id: string;
    name: string;
    version: string;
    author: string;
    description: string;
    type: 'skill' | 'driver' | 'theme';
    permissions: string[];
    downloadSize: string;
}

export interface PluginStatus {
    id: string;
    isEnabled: boolean;
    lifecycle: PluginLifecycle; // Detailed state
    loadTime: number; // ms
    memoryUsage: number; // MB (estimated)
    securityCheck: 'passed' | 'failed' | 'pending';
    metadata: PluginMetadata;
    resources?: {
        cpu: number; // %
        ram: number; // MB
    };
}
