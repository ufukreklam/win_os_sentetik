
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Lightbulb, Zap, TrendingUp, RefreshCw, PenTool, Sparkles, Filter, Brain, Eye, Heart, Target } from 'lucide-react';
import { Idea } from '../../types';

const CreativityApp: React.FC = () => {
  const { creativityState, setCreativityState } = useOS();
  const [activeTab, setActiveTab] = useState<'stream' | 'dream' | 'settings'>('stream');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // --- Dream Mode Canvas Logic ---
  useEffect(() => {
    if (activeTab !== 'dream' || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
        if (canvas.parentElement) {
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
        }
    };
    resize();
    window.addEventListener('resize', resize);

    let t = 0;
    let frameId: number;

    const draw = () => {
        // Semi-clear for trails
        ctx.fillStyle = 'rgba(10, 10, 10, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const temp = creativityState.parameters.temperature; // Controls chaos

        // Procedural Art Generation (Spirographs)
        ctx.beginPath();
        for (let i = 0; i < 360; i += 2) {
            const rad = i * Math.PI / 180;
            const r = 100 + Math.sin(t * 0.05 + rad * 5) * 50 * temp;
            const x = cx + Math.cos(rad + t * 0.02) * r;
            const y = cy + Math.sin(rad + t * 0.03) * r;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = `hsl(${(t * 20) % 360}, 70%, 50%)`;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Secondary layer
        ctx.beginPath();
        for (let i = 0; i < 360; i += 5) {
            const rad = i * Math.PI / 180;
            const r = 200 + Math.cos(t * 0.02 + rad * 3) * 30;
            const x = cx + Math.cos(rad - t * 0.01) * r;
            const y = cy + Math.sin(rad - t * 0.01) * r;
            
            ctx.fillStyle = `hsla(${(t * 15 + 180) % 360}, 80%, 60%, 0.5)`;
            ctx.fillRect(x, y, 2, 2);
        }

        t += 0.05;
        frameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(frameId);
    };
  }, [activeTab, creativityState.parameters]);

  const getSourceIcon = (source: Idea['source']) => {
      switch(source) {
          case 'perception': return <Eye size={14} className="text-cyan-400" />;
          case 'memory': return <Heart size={14} className="text-pink-400" />; // Emotion usually stored in memory
          case 'goal': return <Target size={14} className="text-red-400" />;
          case 'random': default: return <Sparkles size={14} className="text-purple-400" />;
      }
  };

  const IdeaCard: React.FC<{ idea: Idea }> = ({ idea }) => (
      <div className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-all cursor-default group relative overflow-hidden">
          <div className={`absolute top-0 left-0 w-1 h-full ${idea.type === 'innovation' ? 'bg-purple-500' : 'bg-blue-500'}`} />
          <div className="flex justify-between items-start mb-2 pl-3">
              <div className="flex items-center gap-2">
                  {getSourceIcon(idea.source)}
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">{idea.type}</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">{idea.timestamp.toLocaleTimeString()}</span>
          </div>
          <h3 className="text-sm font-medium text-slate-200 pl-3 mb-3">{idea.content}</h3>
          
          <div className="flex gap-4 pl-3">
              <div className="flex flex-col gap-1">
                  <span className="text-[10px] text-slate-500 uppercase">Novelty</span>
                  <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-pink-500" style={{ width: `${idea.novelty}%` }} />
                  </div>
              </div>
              <div className="flex flex-col gap-1">
                  <span className="text-[10px] text-slate-500 uppercase">Logic</span>
                  <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-cyan-500" style={{ width: `${idea.feasibility}%` }} />
                  </div>
              </div>
          </div>
          <div className="absolute bottom-1 right-2 text-[9px] text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity uppercase">
              Source: {idea.source}
          </div>
      </div>
  );

  return (
    <div className="flex h-full bg-[#0F0518] text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/50 border-r border-white/10 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('stream')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'stream' ? 'bg-purple-900/30 text-purple-400 border-l-2 border-purple-500' : 'text-slate-500'}`}
            >
                <Lightbulb size={20} />
                <span className="hidden md:inline text-sm font-medium">Idea Stream</span>
            </button>
            <button 
                onClick={() => setActiveTab('dream')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'dream' ? 'bg-pink-900/30 text-pink-400 border-l-2 border-pink-500' : 'text-slate-500'}`}
            >
                <Brain size={20} />
                <span className="hidden md:inline text-sm font-medium">Dream Mode</span>
            </button>
            <button 
                onClick={() => setActiveTab('settings')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'settings' ? 'bg-blue-900/30 text-blue-400 border-l-2 border-blue-500' : 'text-slate-500'}`}
            >
                <Filter size={20} />
                <span className="hidden md:inline text-sm font-medium">Parameters</span>
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'stream' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="mb-6 flex justify-between items-end">
                        <div>
                            <h2 className="text-2xl font-light text-white mb-1 flex items-center gap-2">
                                <Sparkles className="text-purple-400" /> Innovation Engine
                            </h2>
                            <p className="text-sm text-slate-400">Contextual synthesis from Perception, Emotion, and Goals.</p>
                        </div>
                        <div className="text-right">
                            <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">Total Generated</div>
                            <div className="text-xl font-mono text-purple-400">{creativityState.ideas.length}</div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {creativityState.ideas.map(idea => (
                            <IdeaCard key={idea.id} idea={idea} />
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'dream' && (
                <div className="flex-1 relative flex flex-col">
                    <canvas ref={canvasRef} className="absolute inset-0 block" />
                    
                    {/* Controls */}
                    <div className="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl max-w-xs">
                        <div className="flex justify-between items-center mb-2">
                            <h3 className="font-bold text-sm text-pink-300">Generative State</h3>
                            <div className={`w-2 h-2 rounded-full ${creativityState.isDreaming ? 'bg-green-500 animate-pulse' : 'bg-slate-500'}`} />
                        </div>
                        <p className="text-xs text-slate-300 mb-4">
                            Allowing the neural network to hallucinate patterns based on episodic memory logs (Memory Consolidation).
                        </p>
                        <button 
                            onClick={() => setCreativityState({ isDreaming: !creativityState.isDreaming })}
                            className={`w-full py-2 rounded-lg text-xs font-bold transition-colors ${creativityState.isDreaming ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'}`}
                        >
                            {creativityState.isDreaming ? 'WAKE UP' : 'START DREAMING'}
                        </button>
                    </div>

                    {/* Active Dream Content */}
                    {creativityState.isDreaming && creativityState.activeDream && (
                        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 w-[90%] max-w-lg bg-black/40 backdrop-blur-xl border border-white/10 p-6 rounded-2xl animate-in slide-in-from-bottom-10 fade-in duration-1000">
                             <div className="text-[10px] text-pink-400 font-bold uppercase tracking-widest mb-2 flex justify-between">
                                 <span>Processing Memory Loop</span>
                                 <span>Emotion: {creativityState.activeDream.emotion}</span>
                             </div>
                             <p className="text-lg font-light text-slate-100 leading-relaxed italic">
                                 "{creativityState.activeDream.narrative}"
                             </p>
                             <div className="mt-4 pt-4 border-t border-white/5 flex gap-2">
                                 <span className="text-[10px] text-slate-500">Visual Keywords:</span>
                                 <span className="text-[10px] text-slate-400">{creativityState.activeDream.visualPrompt}</span>
                             </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'settings' && (
                <div className="flex-1 p-8 overflow-y-auto">
                    <h2 className="text-xl font-bold mb-6">Generation Parameters</h2>
                    
                    <div className="bg-white/5 border border-white/5 rounded-xl p-6 space-y-8 max-w-2xl">
                        <div>
                            <div className="flex justify-between mb-2">
                                <label className="text-sm font-medium text-slate-300">Temperature (Randomness)</label>
                                <span className="text-xs font-mono text-purple-400">{creativityState.parameters.temperature.toFixed(2)}</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" max="1" step="0.01"
                                value={creativityState.parameters.temperature}
                                onChange={(e) => setCreativityState({ parameters: { ...creativityState.parameters, temperature: parseFloat(e.target.value) } })}
                                className="w-full accent-purple-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                            />
                            <p className="text-xs text-slate-500 mt-2">Higher values produce more chaotic and novel ideas.</p>
                        </div>

                        <div>
                            <div className="flex justify-between mb-2">
                                <label className="text-sm font-medium text-slate-300">Logic Bias</label>
                                <span className="text-xs font-mono text-blue-400">{creativityState.parameters.logicBias.toFixed(2)}</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" max="1" step="0.01"
                                value={creativityState.parameters.logicBias}
                                onChange={(e) => setCreativityState({ parameters: { ...creativityState.parameters, logicBias: parseFloat(e.target.value) } })}
                                className="w-full accent-blue-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                            />
                            <p className="text-xs text-slate-500 mt-2">Weighting towards feasible and structured solutions.</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default CreativityApp;
