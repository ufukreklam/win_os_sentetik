
import math
import logging
from ..core.robot_system import RobotNode

logger = logging.getLogger("LidarNode")

class LidarNode(RobotNode):
    """
    Lidar sensöründen gelen ham Polar (Açı, Mesafe) verisini işler.
    1. Gürültü filtreleme (Kalite kontrolü)
    2. Polar -> Kartezyen (X, Y) dönüşümü
    3. Frontend için optimize edilmiş 'scan_frame' yayını
    
    NOT: Bu sistem ROS kullanmaz. Tüm hesaplamalar saf Python ile yapılır.
    """
    def __init__(self, bus):
        super().__init__("LidarNode", bus)
        self.loop_interval = 0.1 # 10Hz işlem hızı
        self.max_distance = 12000 # mm (12 metre)
        self.min_distance = 150   # mm (15 cm)

    async def setup(self):
        # ProtocolNode'dan gelen işlenmiş donanım verisini dinle
        self.bus.subscribe("hardware_update", self.handle_hardware_update)

    async def handle_hardware_update(self, data):
        """Lidar verisi geldiğinde tetiklenir"""
        if "lidarMap" not in data:
            return

        raw_points = data["lidarMap"]
        processed_points = []

        # İşlem: Polar to Cartesian
        for point in raw_points:
            angle = point.get("angle", 0)
            dist = point.get("distance", 0)
            quality = point.get("quality", 0)

            # 1. Filtreleme (Gürültü ve Geçersiz Aralıklar)
            if dist < self.min_distance or dist > self.max_distance or quality < 10:
                continue

            # 2. Koordinat Dönüşümü
            # Lidar açısı genelde saat yönünde veya tersi olabilir, donanıma göre ayarlanır.
            # Radyan cinsinden açı:
            angle_rad = math.radians(angle)
            
            # X = d * cos(a), Y = d * sin(a)
            # Robotun önü genelde X eksenidir.
            x = dist * math.cos(angle_rad)
            y = dist * math.sin(angle_rad)

            processed_points.append({
                "x": round(x, 1),
                "y": round(y, 1),
                "q": quality
            })

        # 3. İşlenmiş tarama verisini yayınla
        # Frontend bu veriyi alıp Canvas üzerinde çizecek
        if processed_points:
            await self.bus.publish("lidar_scan", {
                "timestamp": data.get("timestamp", 0),
                "count": len(processed_points),
                "points": processed_points
            })

    async def loop(self):
        # Bu node olay tabanlı (event-driven) çalışır.
        # Loop içinde periyodik temizlik veya durum kontrolü yapılabilir.
        pass
