# Project Memory: Windows11-iOS Hybrid React Theme

This project uses a hybrid UI system combining:
- Windows 11 desktop metaphors
- iOS topbar minimalism
- Modern web app behavior

## CORE PRINCIPLES

1. **Desktop Metaphor**
   - The app behaves like an OS shell
   - MainContent is treated as a workspace
   - Floating windows and panels are expected

2. **Start Menu Logic**
   - Centered, Windows 11 style
   - Acts as an overlay, not a page
   - Contains apps, search, system actions

3. **TopBar Philosophy (iOS)**
   - Fixed at top
   - Displays:
     - Time
     - Network / system icons
     - User actions
   - Always minimal and distraction-free

4. **StatusBar Philosophy (Windows)**
   - Fixed bottom
   - Shows:
     - App states
     - Notifications
     - System indicators

5. **Theme Tokens**
   - Colors, blur strength, radius, spacing are tokenized
   - No hardcoded UI values in components

6. **UX Consistency Rule**
   - If a behavior exists in Windows 11 or iOS, replicate its intent, not its exact look

7. **Long-Term Memory**
   - This theme is expandable into:
     - Window manager
     - App launcher
     - System-level UI simulation

## Component Hierarchy Strategy

```text
<App>
 └─ <DesktopLayout>
     ├─ <TopBar />
     ├─ <MainContent (Desktop)>
     │    └─ <AppRegistry> (Iterates and renders windows)
     │         ├─ <Window><GeminiChat /></Window>
     │         ├─ <Window><SettingsApp /></Window>
     │         └─ ...
     ├─ <StatusBar />
     └─ <StartMenu />
```