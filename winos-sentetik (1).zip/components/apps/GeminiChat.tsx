
import React, { useState, useRef, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { AppID } from '../../types';
import { WALLPAPER_PRESETS } from '../../constants';
import { Send, Bot, User, Sparkles, Trash2, Mic, StopCircle, CloudLightning, Cpu, Brain, Activity, MessageSquare, Zap } from 'lucide-react';
import { Message } from '../../types';

const GeminiChat: React.FC = () => {
  const { openApp, closeApp, setWallpaper, startListening, stopListening, voiceState, speak, askAI, aiMode, addEpisodicMemory, languageState } = useOS();
  const [input, setInput] = useState('');
  const [showCortex, setShowCortex] = useState(false);
  
  // Persisted Chat History
  const [messages, setMessages] = useState<Message[]>(() => {
      if (typeof window !== 'undefined') {
          try {
              const saved = localStorage.getItem('winos_chat_history');
              if (saved) {
                  return JSON.parse(saved).map((m: any) => ({
                      ...m,
                      timestamp: new Date(m.timestamp)
                  }));
              }
          } catch (e) {
              console.error("Failed to load chat history", e);
          }
      }
      return [
        { role: 'model', text: 'Hello! I am your AI assistant. I operate in hybrid mode, using Cloud (Gemini) or Local intelligence based on your needs.', timestamp: new Date(), provider: 'cloud' }
      ];
  });

  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Save history on change
  useEffect(() => {
      localStorage.setItem('winos_chat_history', JSON.stringify(messages));
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    
    // Log to Episodic Memory (Layer 2)
    addEpisodicMemory(`User Query: ${input.substring(0, 50)}...`, 'conversation');

    setInput('');
    setIsLoading(true);

    try {
      const response = await askAI(userMsg.text);
      
      const aiMsg: Message = { 
        role: 'model', 
        text: response.text, 
        timestamp: new Date(),
        provider: response.provider,
        analysis: response.analysis // Attach Layer 4 data to message
      };
      setMessages(prev => [...prev, aiMsg]);
      speak(response.text); // Voice Output

    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error processing your request.", timestamp: new Date(), provider: 'local' }]);
      addEpisodicMemory(`AI Error in Chat`, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearHistory = () => {
      if (confirm('Clear chat history?')) {
          setMessages([{ role: 'model', text: 'History cleared. How can I help you?', timestamp: new Date(), provider: 'local' }]);
          addEpisodicMemory('Chat history cleared by user', 'system');
      }
  };

  const getSentimentColor = (val: number) => {
      if (val > 0.2) return 'text-green-400';
      if (val < -0.2) return 'text-red-400';
      return 'text-slate-400';
  };

  return (
    <div className="h-full flex bg-slate-900 text-slate-100 overflow-hidden">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <div className="h-12 border-b border-white/5 flex items-center justify-between px-4 bg-slate-800/50 shrink-0">
              <div className="flex items-center gap-3">
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Bot size={16} /> AI Assistant
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${aiMode === 'cloud' ? 'border-blue-500/50 text-blue-400' : aiMode === 'local' ? 'border-green-500/50 text-green-400' : 'border-purple-500/50 text-purple-400'}`}>
                      {aiMode.toUpperCase()}
                  </span>
              </div>
              <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setShowCortex(!showCortex)} 
                    className={`p-1.5 rounded transition-colors ${showCortex ? 'bg-purple-600/20 text-purple-300' : 'hover:bg-white/10 text-slate-400'}`}
                    title="Toggle Cortex View"
                  >
                      <Brain size={16} />
                  </button>
                  <div className="w-[1px] h-4 bg-white/10 mx-1" />
                  <button onClick={clearHistory} className="p-1.5 hover:bg-white/10 rounded text-slate-400 hover:text-red-400 transition-colors" title="Clear History">
                      <Trash2 size={16} />
                  </button>
              </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex flex-col max-w-[85%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`
                    rounded-2xl p-4 text-sm leading-relaxed shadow-lg relative group
                    ${msg.role === 'user' 
                        ? 'bg-blue-600 text-white rounded-br-none' 
                        : 'bg-slate-800 text-slate-200 rounded-bl-none border border-white/5'}
                    `}>
                        <div className="whitespace-pre-wrap">{msg.text}</div>
                    </div>
                    
                    {/* Metadata Row */}
                    <div className="flex items-center gap-2 mt-1 px-1 opacity-60">
                        {msg.role === 'model' && (
                            <span className="flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider" title={msg.provider === 'cloud' ? 'Processed in Cloud' : 'Processed Locally'}>
                                {msg.provider === 'cloud' ? <CloudLightning size={10} className="text-blue-400" /> : <Cpu size={10} className="text-green-400" />}
                                {msg.provider}
                            </span>
                        )}
                        <span className="text-[10px] text-slate-500">{msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        
                        {/* Analysis Chips (for previous messages) */}
                        {msg.analysis && showCortex && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded bg-white/5 border border-white/5 ${getSentimentColor(msg.analysis.sentiment)}`}>
                                {msg.analysis.intent} • {(msg.analysis.sentiment * 100).toFixed(0)}%
                            </span>
                        )}
                    </div>
                </div>
              </div>
            ))}
            {isLoading && (
                <div className="flex justify-start">
                    <div className="bg-slate-800 rounded-2xl p-4 rounded-bl-none border border-white/5 flex items-center gap-3">
                        <Sparkles size={16} className="animate-spin text-purple-400" />
                        <span className="text-xs text-slate-400 animate-pulse font-mono uppercase tracking-widest">
                            {languageState.processingStage === 'analyzing' ? 'Analyzing Context...' : 
                             languageState.processingStage === 'generating' ? 'Synthesizing Response...' : 
                             'Thinking...'}
                        </span>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-slate-900/50 border-t border-white/10 shrink-0">
            <div className="relative flex items-center gap-3">
              <button 
                onClick={voiceState === 'listening' ? stopListening : startListening}
                className={`p-3 rounded-full transition-all shadow-lg active:scale-95 shrink-0 ${voiceState === 'listening' ? 'bg-red-500 text-white animate-pulse shadow-red-500/30' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
                title="Voice Input"
              >
                {voiceState === 'listening' ? <StopCircle size={20} /> : <Mic size={20} />}
              </button>

              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={voiceState === 'listening' ? 'Listening...' : 'Type a message...'}
                className="flex-1 bg-slate-800 border border-slate-700 rounded-full py-3 pl-5 pr-12 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50 transition-all text-sm placeholder:text-slate-500"
                autoFocus
                disabled={voiceState === 'listening'}
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-600 hover:bg-blue-500 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={16} className="text-white" />
              </button>
            </div>
          </div>
      </div>

      {/* Cortex Side Panel (Layer 4 Visualizer) */}
      {showCortex && (
          <div className="w-72 bg-black/40 backdrop-blur-xl border-l border-white/10 flex flex-col animate-in slide-in-from-right-10 duration-300">
              <div className="h-12 border-b border-white/5 flex items-center px-4 bg-slate-800/80">
                  <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase tracking-widest">
                      <Brain size={14} />
                      Cortex Trace
                  </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {/* Processing Stage */}
                  <div className="space-y-2">
                      <h4 className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Processing Pipeline</h4>
                      <div className="flex gap-1 h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                          {['listening', 'analyzing', 'generating', 'speaking'].map((stage, i) => {
                              const isActive = languageState.processingStage === stage;
                              const isPast = ['listening', 'analyzing', 'generating', 'speaking'].indexOf(languageState.processingStage) > i;
                              return (
                                  <div 
                                    key={stage} 
                                    className={`flex-1 transition-colors duration-300 ${isActive ? 'bg-purple-500 animate-pulse' : isPast ? 'bg-purple-900' : 'bg-transparent'}`} 
                                  />
                              );
                          })}
                      </div>
                      <div className="text-xs text-center font-mono text-purple-300 uppercase">
                          {languageState.processingStage}
                      </div>
                  </div>

                  {/* Intent Analysis */}
                  <div className="space-y-2">
                      <h4 className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Intent Classification</h4>
                      <div className="bg-white/5 rounded-lg p-3 border border-white/5">
                          <div className="flex justify-between items-center mb-1">
                              <span className="text-xs text-slate-300">Type</span>
                              <span className={`text-xs font-bold uppercase ${languageState.currentIntent === 'command' ? 'text-green-400' : 'text-blue-400'}`}>
                                  {languageState.currentIntent}
                              </span>
                          </div>
                          <div className="flex justify-between items-center">
                              <span className="text-xs text-slate-300">Confidence</span>
                              <span className="text-xs font-mono text-slate-500">98.2%</span>
                          </div>
                      </div>
                  </div>

                  {/* Sentiment Analysis */}
                  <div className="space-y-2">
                      <h4 className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Sentiment Analysis</h4>
                      <div className="bg-white/5 rounded-lg p-3 border border-white/5">
                          <div className="flex justify-between text-xs mb-2">
                              <span>Negative</span>
                              <span>Neutral</span>
                              <span>Positive</span>
                          </div>
                          <div className="relative h-2 bg-slate-800 rounded-full overflow-hidden">
                              <div 
                                  className={`absolute top-0 bottom-0 w-2 rounded-full transition-all duration-500 ${getSentimentColor(languageState.userSentiment).replace('text-', 'bg-')}`}
                                  style={{ left: `${((languageState.userSentiment + 1) / 2) * 100}%` }}
                              />
                          </div>
                          <div className="text-center mt-2 text-xs font-mono text-slate-400">
                              Score: {languageState.userSentiment.toFixed(2)}
                          </div>
                      </div>
                  </div>

                  {/* Context Summary */}
                  <div className="space-y-2">
                      <h4 className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Active Context</h4>
                      <div className="bg-purple-900/10 border border-purple-500/20 rounded-lg p-3 text-xs text-purple-200 leading-relaxed">
                          {languageState.activeContextSummary}
                      </div>
                  </div>

                  {/* Live Signal */}
                  <div className="mt-auto border-t border-white/5 pt-4">
                      <div className="flex items-center gap-2 justify-center opacity-50">
                          <Activity size={14} className="animate-pulse" />
                          <span className="text-[10px] font-mono">NLP ENGINE: ONLINE</span>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default GeminiChat;
