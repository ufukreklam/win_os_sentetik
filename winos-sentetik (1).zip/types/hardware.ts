
// --- Robotics & Serial Types ---
export type SerialStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface LidarPoint {
  angle: number;    // 0-360 degrees
  distance: number; // mm
  quality: number;  // signal strength
}

export interface SensorReadings {
  batteryVoltage: number; // Volts
  currentDraw: number;    // Amps
  lidarStatus: string;    // e.g., "Scanning", "Idle"
  lidarMap: LidarPoint[]; 
  imu: {
    pitch: number;
    roll: number;
    yaw: number;
    accelX: number;
    accelY: number;
    accelZ: number;
  };
  ultrasonic: {
    front: number;
    left: number;
    right: number;
  };
  lineTracking: number[]; // [1, 1, 0, 1, 1]
  gps: {
    lat: number;
    lng: number;
    satellites: number;
    fix: boolean;
  };
  env: {
    temp: number;
    humidity: number;
    airQuality: number; // MQ-135 value
  };
}

// --- Power System Types ---
export interface PowerRail {
    id: string;
    voltage: number; // Current voltage
    nominalVoltage: number; // Target (12V, 5V, 3.3V)
    current: number; // Amps
    load: number; // Percentage
    status: 'stable' | 'sag' | 'surge' | 'critical';
}

export interface BMSCell {
    id: number;
    voltage: number;
    balance: boolean; // Is balancing active?
}

export interface BMSStatus {
    id: string;
    totalVoltage: number;
    current: number;
    cells: BMSCell[];
    temp: number;
    protectionTriggered: boolean;
}

export interface MosfetChannel {
    id: string;
    name: string;
    state: 'on' | 'off';
    pwm: number; // 0-100
    load: string; // Description of connected load
}

export interface PowerSystemState {
  rails: PowerRail[];
  bms: BMSStatus[];
  mosfets: MosfetChannel[];
}

// --- Network & Connectivity ---
export interface BluetoothDevice {
  id: string;
  name: string;
  type: 'phone' | 'laptop' | 'tablet' | 'headphones' | 'misc';
  status: 'disconnected' | 'pairing' | 'connected';
  signal: number; // 1-100
}

export interface FileTransfer {
  id: string;
  fileName: string;
  direction: 'incoming' | 'outgoing';
  progress: number; // 0-100
  status: 'pending' | 'transferring' | 'completed' | 'failed';
  deviceId: string;
}

// --- Hybrid Bridge HAL (Layer 15) ---
export interface BridgePacket {
  id: string;
  timestamp: Date;
  direction: 'TX' | 'RX';
  type: 'telemetry' | 'command' | 'log' | 'error';
  size: number; // bytes
  payload: string; // JSON or Hex string
  latency: number; // ms
  rawHex?: string; // e.g. "FF 01 A2"
}

export interface SubsystemStatus {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'error' | 'calibrating';
  voltage: number;
  uptime: number;
  details?: string;
}

export interface HardwareDriver {
    id: string;
    name: string;
    type: 'motor' | 'sensor' | 'display' | 'audio' | 'power';
    status: 'active' | 'inactive' | 'error';
    version: string;
    targetPico: 'pico1' | 'pico2' | 'pico3' | 'pico4' | 'pico5';
}

export interface ProtocolStats {
    totalPackets: number;
    errorRate: number;
    lastPing: number; // ms latency
    busLoad: number; // %
}

export interface BridgeState {
  connectionQuality: number; // 0-100%
  packets: BridgePacket[];
  subsystems: SubsystemStatus[];
  rxRate: number; // bytes/sec
  txRate: number; // bytes/sec
  activeDrivers: HardwareDriver[]; 
  protocolStats: ProtocolStats; 
  power: PowerSystemState; 
}
