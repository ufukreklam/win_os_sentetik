
import time
import logging
from ..core.robot_system import RobotNode

logger = logging.getLogger("ControlNode")

class ControlNode(RobotNode):
    """
    Kullanıcı girdilerini (Joystick, Otonom Komutlar) fiziksel motor komutlarına çevirir.
    Diferansiyel sürüş (Differential Drive) kinematiğini uygular.
    """
    def __init__(self, bus):
        super().__init__("ControlNode", bus)
        self.loop_interval = 0.05 # 20Hz Kontrol Döngüsü
        self.last_command_time = 0
        self.max_speed = 100 # PWM yüzdesi (0-100)
        self.safety_timeout = 0.5 # 500ms veri gelmezse dur

    async def setup(self):
        # WebSocket veya API'den gelen kullanıcı girdilerini dinle
        self.bus.subscribe("user_input", self.handle_input)

    async def handle_input(self, data):
        """Gelen veriyi işle ve motor komutu üret"""
        self.last_command_time = time.time()
        
        command_type = data.get("action")
        
        if command_type == "move":
            # Joystick verisi: x (dönüş), y (hız) -> -1.0 ile 1.0 arası
            x = float(data.get("x", 0))
            y = float(data.get("y", 0))
            await self.process_differential_drive(x, y)
        
        elif command_type == "stop":
            await self.stop_motors()

    async def process_differential_drive(self, x, y):
        """
        Arcade Drive Algoritması:
        Y ekseni: İleri/Geri hız
        X ekseni: Sağa/Sola dönüş
        """
        # Hız ve dönüşü karıştır
        # Basit Arcade Drive formülü
        left_motor = y + x
        right_motor = y - x

        # Değerleri -1.0 ile 1.0 arasına sıkıştır (Clamp)
        left_motor = max(-1.0, min(1.0, left_motor))
        right_motor = max(-1.0, min(1.0, right_motor))

        # PWM'e dönüştür (-100 ile 100 arası)
        left_pwm = int(left_motor * self.max_speed)
        right_pwm = int(right_motor * self.max_speed)

        # Pico için kompakt komut paketi oluştur
        # m: motors, [Sol, Sağ]
        motor_packet = {
            "m": [left_pwm, right_pwm]
        }

        # SerialNode'a gönderilmek üzere yayınla
        await self.bus.publish("serial_write", motor_packet)

    async def stop_motors(self):
        stop_packet = {"m": [0, 0]}
        await self.bus.publish("serial_write", stop_packet)

    async def loop(self):
        """Güvenlik Döngüsü: Veri akışı kesilirse robotu durdur"""
        if time.time() - self.last_command_time > self.safety_timeout:
            # Eğer son komuttan bu yana safety_timeout kadar süre geçtiyse
            # ve motorlar hala çalışıyorsa durdur (basit bir state check eklenebilir)
            # Şimdilik sürekli dur komutu basmamak için burayı boş bırakıyoruz
            # İleride 'active' state takibi yapılabilir.
            pass
