
import { useState, useCallback, useEffect } from 'react';
import { UserProfile, BootState, BootMode, HardwareConfig, Notification, AppID, BackendConnectionStatus } from '../../types';
import { WALLPAPERS } from '../../constants';
import { DEFAULT_USER, DEFAULT_INSTALLED_IDS } from '../initialStates';
import { playSystemSound } from '../../utils/soundUtils';
import { apiService } from '../../services/apiService';

export const useSystemOperations = () => {
    // --- User System ---
    const [users, setUsers] = useState<UserProfile[]>(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('winos_users');
            if (saved) return JSON.parse(saved);
        }
        return [DEFAULT_USER];
    });
    
    const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
    const [isLocked, setLocked] = useState(true);
    const [wallpaper, setWallpaperState] = useState(WALLPAPERS.DEFAULT);
    const [installedAppIds, setInstalledAppIds] = useState<AppID[]>(DEFAULT_INSTALLED_IDS);
    const [pinnedAppIds, setPinnedAppIds] = useState<AppID[]>(DEFAULT_USER.pinnedAppIds);

    // --- Time System ---
    const [timeOffset, setTimeOffsetState] = useState(0);
    const [isAutoTime, setIsAutoTime] = useState(true);

    // --- Boot System ---
    const [bootState, setBootState] = useState<BootState>('posting');
    const [bootMode, setBootMode] = useState<BootMode>('normal');
    const [hardwareConfig, setHardwareConfig] = useState<HardwareConfig>({
        bootOrder: '0xf41 (SD -> NVMe -> USB)',
        fastBoot: false,
        overclock: false,
        ramSize: '4096 MB',
        uuid: 'UUID-550e8400-e29b-41d4-a716-446655440000'
    });
    
    // --- Backend Status ---
    const [backendStatus, setBackendStatus] = useState<BackendConnectionStatus>('disconnected');

    // --- Notifications ---
    const [notifications, setNotifications] = useState<Notification[]>([]);

    // --- Network & PWA ---
    const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
    const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

    // --- Effects ---
    useEffect(() => {
        localStorage.setItem('winos_users', JSON.stringify(users));
    }, [users]);

    useEffect(() => {
        if (currentUser) {
            setWallpaperState(currentUser.wallpaper);
            setInstalledAppIds(currentUser.installedAppIds);
            setPinnedAppIds(currentUser.pinnedAppIds || []);
        } else {
            setWallpaperState(WALLPAPERS.DEFAULT);
        }
    }, [currentUser]);

    // Network Status Listeners
    useEffect(() => {
        const handleOnline = () => {
            setIsOnline(true);
            addNotification({ title: 'System Online', message: 'Network connection restored.', type: 'success' });
        };
        const handleOffline = () => {
            setIsOnline(false);
            addNotification({ title: 'System Offline', message: 'Operating in local mode.', type: 'warning' });
        };

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);
    
    // Check Backend Connectivity periodically
    useEffect(() => {
        const checkBackend = async () => {
            setBackendStatus('connecting');
            const isConnected = await apiService.checkConnection();
            setBackendStatus(isConnected ? 'connected' : 'error');
        };
        
        checkBackend();
        const interval = setInterval(checkBackend, 10000); // Check every 10 seconds
        return () => clearInterval(interval);
    }, []);

    // PWA Install Prompt Listener
    useEffect(() => {
        const handleBeforeInstallPrompt = (e: any) => {
            e.preventDefault();
            setDeferredPrompt(e);
        };
        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    }, []);

    // --- Actions ---
    const login = useCallback((userId: string, pin: string) => {
        const user = users.find(u => u.id === userId);
        if (user && (user.pin === pin || user.pin === '')) {
            setCurrentUser(user);
            setLocked(false);
            return true;
        }
        return false;
    }, [users]);

    const logout = useCallback(() => {
        setCurrentUser(null);
        setLocked(true);
    }, []);

    const addUser = useCallback((newUser: Omit<UserProfile, 'id' | 'wallpaper' | 'installedAppIds' | 'pinnedAppIds'>) => {
        const id = `u_${Date.now()}`;
        const user: UserProfile = {
            ...newUser,
            id,
            wallpaper: WALLPAPERS.DEFAULT,
            installedAppIds: DEFAULT_INSTALLED_IDS,
            pinnedAppIds: []
        };
        setUsers(prev => [...prev, user]);
    }, []);

    const removeUser = useCallback((userId: string) => {
        setUsers(prev => prev.filter(u => u.id !== userId));
        if (currentUser?.id === userId) {
            logout();
        }
    }, [currentUser, logout]);

    const updateUser = useCallback((userId: string, updates: Partial<UserProfile>) => {
        setUsers(prev => prev.map(u => {
            if (u.id === userId) return { ...u, ...updates };
            return u;
        }));
        if (currentUser?.id === userId) {
            setCurrentUser(prev => prev ? { ...prev, ...updates } : null);
        }
    }, [currentUser]);

    const setWallpaper = useCallback((url: string) => {
        setWallpaperState(url);
        if (currentUser) {
            updateUser(currentUser.id, { wallpaper: url });
        }
        addNotification({ title: 'Wallpaper Updated', message: 'Your desktop background has been changed.', type: 'success' });
    }, [currentUser, updateUser]);

    const setTimeConfig = useCallback((config: { isAuto: boolean, offset: number }) => {
        setIsAutoTime(config.isAuto);
        setTimeOffsetState(config.offset);
    }, []);

    const addNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp'>) => {
        const id = Math.random().toString(36).substr(2, 9);
        const newNotification: Notification = {
            ...notification,
            id,
            timestamp: new Date(Date.now() + timeOffset),
            showToast: true,
        };
        
        if (notification.type === 'error') playSystemSound('error');
        else playSystemSound('notification');

        setNotifications(prev => [newNotification, ...prev]);
        
        setTimeout(() => {
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, showToast: false } : n));
        }, 5000);
    }, [timeOffset]);

    const removeNotification = useCallback((id: string) => {
        setNotifications(prev => prev.filter(n => n.id !== id));
    }, []);

    const clearNotifications = useCallback(() => {
        setNotifications([]);
    }, []);

    const crashSystem = useCallback((error?: string) => {
        setBootState('bsod');
        setCurrentUser(null);
        setLocked(true);
    }, []);

    const factoryReset = useCallback(() => {
        if (confirm('WARNING: This will delete all user data and reset the system. Continue?')) {
            localStorage.clear();
            window.location.reload();
        }
    }, []);

    const installApp = useCallback((appId: AppID) => {
        if (!installedAppIds.includes(appId)) {
            const newApps = [...installedAppIds, appId];
            setInstalledAppIds(newApps);
            if (currentUser) {
                updateUser(currentUser.id, { installedAppIds: newApps });
            }
            addNotification({ title: 'App Installed', message: 'App is now ready to use.', type: 'success' });
        }
    }, [installedAppIds, currentUser, updateUser, addNotification]);
  
    const uninstallApp = useCallback((appId: AppID) => {
        const newApps = installedAppIds.filter(id => id !== appId);
        const newPinned = pinnedAppIds.filter(id => id !== appId);
        setInstalledAppIds(newApps);
        setPinnedAppIds(newPinned);
        if (currentUser) {
            updateUser(currentUser.id, { installedAppIds: newApps, pinnedAppIds: newPinned });
        }
        addNotification({ title: 'App Uninstalled', message: 'App has been removed.', type: 'info' });
    }, [installedAppIds, pinnedAppIds, currentUser, updateUser, addNotification]);

    const togglePin = useCallback((appId: AppID) => {
        let newPinned;
        if (pinnedAppIds.includes(appId)) {
            newPinned = pinnedAppIds.filter(id => id !== appId);
        } else {
            newPinned = [...pinnedAppIds, appId];
        }
        setPinnedAppIds(newPinned);
        if (currentUser) {
            updateUser(currentUser.id, { pinnedAppIds: newPinned });
        }
    }, [pinnedAppIds, currentUser, updateUser]);

    const installPWA = useCallback(() => {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult: any) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('User accepted the install prompt');
                }
                setDeferredPrompt(null);
            });
        }
    }, [deferredPrompt]);

    return {
        users, currentUser, isLocked, setLocked, wallpaper, setWallpaper,
        installedApps: installedAppIds, installApp, uninstallApp,
        pinnedApps: pinnedAppIds, togglePin,
        login, logout, addUser, removeUser, updateUser,
        timeOffset, isAutoTime, setTimeConfig,
        bootState, setBootState, bootMode, setBootMode, hardwareConfig, setHardwareConfig,
        notifications, addNotification, removeNotification, clearNotifications,
        crashSystem, factoryReset,
        isOnline, installPWA, canInstallPWA: !!deferredPrompt,
        backendStatus
    };
};
