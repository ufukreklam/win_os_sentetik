
// --- AI & Intelligence Types ---
export type AIMode = 'cloud' | 'local' | 'hybrid';
export type LocalModelStatus = 'unloaded' | 'loading' | 'ready' | 'error';
export type BackendConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface LocalModelProgress {
    progress: number; // 0-100 (percentage)
    text: string;     // e.g. "Loading shards 1/32..."
    timeElapsed: number;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  attachment?: {
      type: 'image' | 'audio';
      content: string; // Base64 or URL
  };
  provider?: 'cloud' | 'local'; // Track source of message
  analysis?: {
      intent: string;
      sentiment: number;
      keywords: string[];
  };
}

// --- Layer 2: Memory System ---
export interface EpisodicMemory {
  id: string;
  timestamp: Date;
  event: string;
  category: 'system' | 'user' | 'error' | 'achievement' | 'conversation' | 'emotion' | 'perception' | 'social';
  emotion?: string; // Snapshot of emotion at time of event
}

export interface WorkingMemoryItem {
  id: string;
  content: string;
  type: 'entity' | 'intent' | 'context' | 'perception' | 'state';
  activation: number; // 0.0 - 1.0 (Decays over time)
}

export interface MemoryState {
  episodicLog: EpisodicMemory[];
  workingContext: WorkingMemoryItem[];
}

// --- Layer 3: Emotion & Consciousness ---
export type CoreEmotion = 'neutral' | 'happy' | 'angry' | 'sad' | 'surprised' | 'fear' | 'curious';

export interface EmotionInfluencer {
    source: string; // e.g., "Battery", "Security", "Goal"
    impact: number; // -1.0 to 1.0 (Negative to Positive)
    description: string;
}

export interface EmotionState {
  primary: CoreEmotion;
  intensity: number; // 0.0 to 1.0
  pad: {
    pleasure: number; // -1.0 to 1.0 (Unhappy vs Happy)
    arousal: number;  // -1.0 to 1.0 (Calm vs Excited)
    dominance: number; // -1.0 to 1.0 (Submissive vs Dominant)
  };
  influencers: EmotionInfluencer[];
}

// --- Layer 4: Language & Communication ---
export interface LanguageState {
    currentIntent: 'idle' | 'query' | 'command' | 'chat' | 'unknown';
    userSentiment: number; // -1 to 1
    detectedLanguage: string;
    activeContextSummary: string;
    isTranslatorActive: boolean;
    processingStage: 'idle' | 'listening' | 'analyzing' | 'generating' | 'speaking';
}

export type VoiceState = 'idle' | 'listening' | 'processing' | 'speaking';

// --- Layer 5: Perception & Reality ---
export interface DetectedObject {
    id: string;
    label: string;
    confidence: number; // 0-1
    position: { x: number, y: number, z: number }; // Relative coordinates in meters
    dimensions?: { w: number, h: number, d: number };
    velocity?: { x: number, y: number };
    type: 'static' | 'dynamic' | 'living';
    lastSeen: Date;
}

export interface PerceptionState {
    detectedObjects: DetectedObject[];
    visualAttention: { x: number, y: number } | null; // Focus point on image plane (0-1)
    sensorFusionHealth: number; // 0-100 (Consistency between Lidar/Camera/Ultrasonic)
    environmentalHazard: boolean;
    nearestObstacleDistance: number; // mm
    motionActivity: number; // 0-100, Detected motion level
}

// --- Layer 6: Motivation & Goals ---
export type DriveType = 'energy' | 'integrity' | 'curiosity' | 'social';
export type GoalStatus = 'pending' | 'active' | 'completed' | 'failed';

export interface Drive {
  type: DriveType;
  value: number; // 0-100
  threshold: number; // Level at which it triggers a goal
  decayRate: number;
  weight: number;
  trend: 'stable' | 'rising' | 'falling';
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: GoalStatus;
  progress: number; // 0-100
  source: 'user' | 'system' | 'instinct'; // Who created it
  created: Date;
}

export interface MotivationState {
  drives: Record<DriveType, Drive>;
  activeGoals: Goal[];
  completedGoals: Goal[]; // History
  rewardSignal: number; // -1.0 to 1.0 (Punishment vs Reward)
}

// --- Layer 7: Social Cognition ---
export type RelationshipType = 'stranger' | 'acquaintance' | 'friend' | 'admin' | 'blocked';

export interface Identity {
  id: string;
  name: string;
  relationship: RelationshipType;
  trustScore: number; // 0-100
  affinity: number; // 0-100 (Emotional connection)
  interactions: number;
  lastSeen: Date;
  faceEmbeddings?: string; // Mock hash
}

export interface DetectedFace {
  id: string;
  boundingBox: { x: number; y: number; w: number; h: number }; // Percentages
  emotion: CoreEmotion;
  identityId: string | null; // Null if unknown
  confidence: number;
}

export interface SocialState {
  identities: Identity[];
  detectedFaces: DetectedFace[];
}

// --- Layer 8: Creativity & Problem Solving ---
export interface Idea {
    id: string;
    content: string;
    type: 'synthesis' | 'analogy' | 'innovation';
    source: 'perception' | 'memory' | 'random' | 'goal';
    novelty: number; // 0-100
    feasibility: number; // 0-100
    timestamp: Date;
}

export interface DreamContent {
    id: string;
    narrative: string; // The "story" of the dream
    visualPrompt: string; // Keywords for the visualizer
    memoriesProcessed: string[]; // IDs of memories involved
    emotion: CoreEmotion; // Emotional tone of the dream
}

export interface CreativityState {
    isDreaming: boolean; // Generative visual mode
    activeDream: DreamContent | null; // Current dream being experienced
    ideas: Idea[];
    currentProblem: string | null;
    parameters: {
        temperature: number; // Randomness (0.0 - 1.0)
        logicBias: number; // Feasibility weight (0.0 - 1.0)
    };
}

// --- Layer 9: Learning & Adaptation ---
export interface Skill {
  id: string;
  name: string;
  category: 'cognitive' | 'motor' | 'social';
  level: number; // 1-100
  experience: number; // 0-100%
  progressRate: number; // How fast it's improving (simulated)
}

export interface KnowledgeNode {
  id: string;
  label: string;
  type: 'concept' | 'object' | 'action' | 'context';
  connections: string[]; // IDs of connected nodes
  activation: number; // 0.0 - 1.0 (Current relevance)
  x?: number; // Physics position for visualization
  y?: number;
  vx?: number;
  vy?: number;
}

export interface LearningState {
  skills: Skill[];
  knowledgeGraph: KnowledgeNode[];
  learningRate: number; // Global learning efficiency
  adaptationScore: number; // 0-100
}

// --- Layer 10: Performance & Optimization ---
export interface CoreStatus {
  id: number;
  usage: number; // 0-100%
  frequency: number; // GHz
  temp: number; // Celsius
}

export type PerformanceMode = 'eco' | 'balanced' | 'high_perf';

export interface OptimizationEvent {
  id: string;
  timestamp: Date;
  action: string; // e.g., "Cleared Cache", "Throttled CPU"
  impact: string; // e.g., "-5% RAM Usage"
  type: 'auto' | 'manual';
}

export interface DiagnosticResult {
  id: string;
  component: string; // "CPU", "Memory", "Neural Engine"
  status: 'healthy' | 'warning' | 'critical';
  message: string;
  lastCheck: Date;
}

export interface PerformanceState {
  cores: CoreStatus[]; // 4 Cores for RPi 5
  npuLoad: number; // 0-100%
  gpuLoad: number; // 0-100%
  ramUsage: number; // MB
  swapUsage: number; // MB
  systemHealth: number; // 0-100
  mode: PerformanceMode;
  fanSpeed: number; // 0-100%
  uptime: number; // Seconds
  
  autoTuningEnabled: boolean;
  predictedLoad: number; // Predicted global load for next minute
  optimizationLog: OptimizationEvent[];
  diagnostics: DiagnosticResult[];
}

// --- Layer 11: Security & Ethics ---
export type ThreatLevel = 'low' | 'elevated' | 'high' | 'critical';

export interface EthicsRule {
  id: string;
  directive: string;
  priority: number; // 1 is highest
  status: 'active' | 'override' | 'evaluating';
  lastCheck: Date;
}

export interface AccessLog {
  id: string;
  timestamp: Date;
  actor: string; // e.g., "Gemini AI", "User", "System Kernel"
  action: string; // e.g., "Camera Access", "File Write", "Motor Control"
  status: 'allowed' | 'denied' | 'flagged';
}

export interface SecurityState {
  threatLevel: ThreatLevel;
  encryptionStatus: 'secure' | 'decrypting' | 'vulnerable';
  activeShields: number; // Percentage
  ethicsRules: EthicsRule[];
  accessLogs: AccessLog[];
}

// --- Layer 12: Environmental Interaction ---
export type ContextType = 'indoor_home' | 'indoor_public' | 'outdoor_urban' | 'outdoor_nature' | 'unknown';
export type IoTDeviceType = 'light' | 'thermostat' | 'lock' | 'camera' | 'outlet';

export interface IoTDevice {
  id: string;
  name: string;
  type: IoTDeviceType;
  status: 'on' | 'off' | 'offline';
  value?: number; // e.g. temperature or brightness
  room: string;
}

export interface EnvironmentState {
  currentContext: ContextType;
  realitySync: number; // 0-100% (Alignment between internal map and sensor data)
  iotDevices: IoTDevice[];
  lastContextUpdate: Date;
  ambientNoiseLevel: number; // dB
  lightLevel: number; // Lux
}

// --- Layer 13: Self-Awareness ---
export type ConsciousnessMode = 'sleep' | 'dreaming' | 'waking' | 'aware' | 'hyper_focus';

export interface Thought {
  id: string;
  timestamp: Date;
  content: string;
  intensity: number; // 0-1
  tags: string[]; // e.g., ["safety", "energy", "social"]
}

export interface IdentityTrait {
  name: string;
  value: number; // 0-100 (Static base personality)
  modifier: number; // -50 to +50 (Dynamic shift based on context)
}

export interface SelfAwarenessState {
  mode: ConsciousnessMode;
  awarenessLevel: number; // 0-100%
  internalMonologue: Thought[];
  traits: IdentityTrait[];
  selfModelConsistency: number; // 0-100% (How much the robot "knows" it's a robot)
}

// --- Layer 14: Coordination ---
export interface SystemConflict {
  id: string;
  timestamp: Date;
  sourceLayer: string; // e.g., "Motivation"
  targetLayer: string; // e.g., "Security"
  description: string;
  resolution: string; // "Target Override"
  status: 'active' | 'resolved';
}

export interface ModuleStatus {
  id: string;
  name: string;
  layer: number;
  status: 'nominal' | 'warning' | 'error' | 'sleep';
  load: number; // 0-100
  latency: number; // ms
  level?: number;
  levelIndex?: number;
  levelTotal?: number;
  angle?: number;
}

export interface ExecutionLog {
    id: string;
    timestamp: Date;
    actionType: string;
    target: string;
    status: 'pending' | 'success' | 'failed';
    details: string;
}

export interface CoordinationState {
  modules: ModuleStatus[];
  conflicts: SystemConflict[];
  globalSystemLoad: number; // 0-100%
  coherenceScore: number; // 0-100% (How well parts work together)
  executionQueue: ExecutionLog[]; // Track active/past executions
}

// --- Policy Core (Decision Making) ---
export type ActionType = 'MOVE' | 'SPEAK' | 'CHARGE' | 'WAIT' | 'EMERGENCY' | 'LONG_TASK' | 'CALCULATE' | 'SCAN' | 'IDLE';

export interface Action {
    id: string;
    name: string;
    type: ActionType;
    cost: number; // Energy/Time cost
    risk: number; // 0-10
    priority: number;
    reason: string;
}

export interface PolicyLog {
    id: string;
    timestamp: Date;
    proposedAction: Action;
    outcome: 'APPROVED' | 'BLOCKED' | 'MODIFIED';
    layer: 'SAFETY' | 'AWARENESS' | 'ETHICS' | 'STRATEGY';
    description: string;
}

export interface PolicyState {
    activePolicy: 'STANDARD' | 'CAUTIOUS' | 'AGGRESSIVE' | 'SURVIVAL';
    lastDecision: PolicyLog | null;
    decisionLog: PolicyLog[];
    blockedActions: number;
}
