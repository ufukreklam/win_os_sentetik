
import { useState, useCallback, useEffect } from 'react';
import { 
    PerceptionState, MotivationState, SocialState, LearningState, 
    PerformanceState, SecurityState, EnvironmentState, SelfAwarenessState, 
    CoordinationState, BridgeState, CreativityState, PolicyState,
    Goal, Identity, IoTDevice, Action, PerformanceMode, EpisodicMemory, PolicyLog
} from '../../../types';
import { 
    INITIAL_PERCEPTION, INITIAL_MOTIVATION, INITIAL_SOCIAL, INITIAL_LEARNING, 
    INITIAL_PERFORMANCE, INITIAL_SECURITY, INITIAL_ENVIRONMENT, 
    INITIAL_SELF_AWARENESS, INITIAL_COORDINATION, INITIAL_BRIDGE,
    INITIAL_CREATIVITY, INITIAL_POLICY
} from '../../initialStates';
import { playSystemSound } from '../../../utils/soundUtils';
import { visionService } from '../../../services/visionService';
import { securityService } from '../../../services/securityService';
import { personalityService } from '../../../services/personalityService';
import { dreamService } from '../../../services/dreamService';
import { emotionService } from '../../../services/emotionService';

export const useAISubsystems = (
    serialStatus: string, 
    sensorReadings: any,
    updateSimulationLoad: (type: 'motor' | 'cpu', value: number) => void,
    addEpisodicMemory: (event: string, category: EpisodicMemory['category']) => void,
    memoryState: any // Needed for dreaming
) => {
    // States
    const [perceptionState, setPerceptionState] = useState<PerceptionState>(INITIAL_PERCEPTION);
    const [motivationState, setMotivationState] = useState<MotivationState>(INITIAL_MOTIVATION);
    const [socialState, setSocialState] = useState<SocialState>(INITIAL_SOCIAL);
    const [learningState, setLearningState] = useState<LearningState>(INITIAL_LEARNING);
    const [performanceState, setPerformanceState] = useState<PerformanceState>(INITIAL_PERFORMANCE);
    const [securityState, setSecurityState] = useState<SecurityState>(INITIAL_SECURITY);
    const [environmentState, setEnvironmentState] = useState<EnvironmentState>(INITIAL_ENVIRONMENT);
    const [selfAwarenessState, setSelfAwarenessState] = useState<SelfAwarenessState>(INITIAL_SELF_AWARENESS);
    const [coordinationState, setCoordinationState] = useState<CoordinationState>(INITIAL_COORDINATION);
    const [bridgeState, setBridgeState] = useState<BridgeState>(INITIAL_BRIDGE);
    const [creativityState, setCreativityState] = useState<CreativityState>(INITIAL_CREATIVITY);
    const [policyState, setPolicyState] = useState<PolicyState>(INITIAL_POLICY);

    // --- Actions ---
    
    // Perception
    const processVisualFrame = useCallback((source: CanvasImageSource) => {
        const motionScore = visionService.processFrame(source);
        setPerceptionState(prev => ({ ...prev, motionActivity: motionScore }));
    }, []);

    // Motivation
    const addGoal = useCallback((goal: any) => {
        setMotivationState(prev => {
            if (prev.activeGoals.some(g => g.title === goal.title)) return prev;
            return {
                ...prev,
                activeGoals: [...prev.activeGoals, { ...goal, id: `g_${Date.now()}`, status: 'pending', progress: 0, created: new Date() }]
            };
        });
        addEpisodicMemory(`New Goal Assigned: ${goal.title}`, 'system');
    }, [addEpisodicMemory]);

    const updateGoal = useCallback((id: string, updates: Partial<Goal>) => {
        setMotivationState(prev => ({
            ...prev,
            activeGoals: prev.activeGoals.map(g => g.id === id ? { ...g, ...updates } : g)
        }));
    }, []);

    const completeGoal = useCallback((id: string, success: boolean) => {
        setMotivationState(prev => {
            const goal = prev.activeGoals.find(g => g.id === id);
            if (!goal) return prev;
            const updatedGoal = { ...goal, status: success ? 'completed' : 'failed' } as Goal;
            return {
                ...prev,
                activeGoals: prev.activeGoals.filter(g => g.id !== id),
                completedGoals: [updatedGoal, ...prev.completedGoals],
                rewardSignal: success ? Math.min(1, prev.rewardSignal + 0.3) : Math.max(-1, prev.rewardSignal - 0.2)
            };
        });
        playSystemSound(success ? 'notification' : 'error');
    }, []);

    // Social
    const updateIdentity = useCallback((id: string, updates: Partial<Identity>) => {
        setSocialState(prev => ({
            ...prev,
            identities: prev.identities.map(i => i.id === id ? { ...i, ...updates } : i)
        }));
    }, []);

    const triggerSocialEvent = useCallback((type: 'meet' | 'detect', identityId?: string) => {
        setSocialState(prev => {
            if (type === 'detect') {
                const targetId = identityId || prev.identities[Math.floor(Math.random() * prev.identities.length)].id;
                const updatedIdentities = prev.identities.map(i => 
                    i.id === targetId ? { ...i, lastSeen: new Date(), interactions: i.interactions + 1, trustScore: Math.min(100, i.trustScore + 2) } : i
                );
                return {
                    ...prev,
                    identities: updatedIdentities,
                    detectedFaces: [{
                        id: `f_${Date.now()}`,
                        boundingBox: { x: 20 + Math.random() * 40, y: 20 + Math.random() * 30, w: 20, h: 25 },
                        emotion: 'neutral',
                        identityId: targetId,
                        confidence: 0.9
                    }] 
                };
            }
            return prev;
        });
    }, []);

    // Performance
    const setPerformanceMode = useCallback((mode: PerformanceMode) => {
        setPerformanceState(prev => ({ ...prev, mode }));
        addEpisodicMemory(`Performance Mode changed to ${mode}`, 'system');
    }, [addEpisodicMemory]);

    const toggleAutoTuning = useCallback(() => {
        setPerformanceState(prev => ({ ...prev, autoTuningEnabled: !prev.autoTuningEnabled }));
    }, []);

    const runDiagnostics = useCallback(() => {
        setPerformanceState(prev => {
            const newDiagnostics = prev.diagnostics.map(diag => ({...diag, lastCheck: new Date()}));
            return { ...prev, diagnostics: newDiagnostics };
        });
        addEpisodicMemory('System Diagnostics Scan Completed', 'system');
    }, [addEpisodicMemory]);

    // Environment
    const toggleIoTDevice = useCallback((id: string) => {
        setEnvironmentState(prev => {
            const newDevices = prev.iotDevices.map(d => d.id === id ? { ...d, status: d.status === 'on' ? 'off' : 'on' as any } : d);
            return { ...prev, iotDevices: newDevices };
        });
        playSystemSound('click');
    }, []);

    const updateIoTDevice = useCallback((id: string, updates: Partial<IoTDevice>) => {
        setEnvironmentState(prev => ({
            ...prev,
            iotDevices: prev.iotDevices.map(d => d.id === id ? { ...d, ...updates } : d)
        }));
    }, []);

    // Bridge
    const sendBridgeCommand = useCallback((type: string, payload: any) => {
         setBridgeState(prev => ({...prev, txRate: prev.txRate + 128}));
    }, []);

    // Creativity
    const setCreativityStateHandler = useCallback((state: Partial<CreativityState>) => {
        setCreativityState(prev => ({ ...prev, ...state }));
    }, []);

    // Policy
    const executeAction = useCallback((action: Action) => {
        const securityCheck = securityService.evaluateAction(action);
        if (!securityCheck.safe) {
            addEpisodicMemory(`ACTION BLOCKED: ${action.name} - ${securityCheck.reason}`, 'error');
            playSystemSound('error');
            setPolicyState(prev => ({ ...prev, blockedActions: prev.blockedActions + 1 }));
            return;
        }

        if (serialStatus !== 'connected') {
            if (action.type === 'MOVE') {
                updateSimulationLoad('motor', 100);
                setTimeout(() => updateSimulationLoad('motor', 0), 2000);
            }
        }
    }, [serialStatus, updateSimulationLoad, addEpisodicMemory]);

    const evaluateAction = useCallback((action: Omit<Action, 'id'>) => {
        const fullAction = { ...action, id: 'temp' } as Action;
        const securityCheck = securityService.evaluateAction(fullAction);
        
        // Log decision attempt
        setPolicyState(prev => {
            const newLog: PolicyLog = {
                id: `dec_${Date.now()}`,
                timestamp: new Date(),
                proposedAction: fullAction,
                outcome: securityCheck.safe ? 'APPROVED' : 'BLOCKED',
                layer: 'SAFETY',
                description: securityCheck.safe ? 'Safety checks passed.' : (securityCheck.reason || 'Safety violation.')
            };

            return {
                ...prev,
                decisionLog: [...prev.decisionLog, newLog].slice(-50), // Keep last 50 logs
                blockedActions: !securityCheck.safe ? prev.blockedActions + 1 : prev.blockedActions
            };
        });

        if (securityCheck.safe) {
            executeAction(fullAction);
        }

        return securityCheck.safe;
    }, [executeAction]);

    // --- Background Loops ---
    useEffect(() => {
        const interval = setInterval(() => {
            // Dream Mode
            if (creativityState.isDreaming) {
                 if (Math.random() > 0.8) {
                    const newDream = dreamService.generateDream(memoryState.episodicLog);
                    setCreativityState(prev => ({ ...prev, activeDream: newDream }));
                    if (newDream.emotion !== 'neutral') {
                        // Inject slight emotion from dream
                        emotionService.injectEmotion(0.1, 0.1, 0);
                    }
                    personalityService.evolve('creativity', 0.2);
                 }
            }
            
            // Update Self Awareness Traits
            setSelfAwarenessState(prev => ({
                ...prev,
                traits: personalityService.getTraits()
            }));

            // Sync Security State
            setSecurityState(prev => ({
                ...prev,
                ...securityService.getSecurityState()
            }));

            // Bridge Simulation (if disconnected)
            if (serialStatus !== 'connected') {
                // Simulate packets
                // (Logic moved from useArtificialIntelligence to here or handled by useHardwareInterface mocks)
            }

        }, 1000);
        return () => clearInterval(interval);
    }, [creativityState.isDreaming, memoryState.episodicLog, serialStatus]);

    return {
        perceptionState, processVisualFrame,
        motivationState, addGoal, updateGoal, completeGoal,
        socialState, updateIdentity, triggerSocialEvent,
        learningState, setLearningState,
        performanceState, setPerformanceMode, toggleAutoTuning, runDiagnostics,
        securityState,
        environmentState, toggleIoTDevice, updateIoTDevice,
        selfAwarenessState,
        coordinationState,
        bridgeState, sendBridgeCommand,
        creativityState, setCreativityState: setCreativityStateHandler,
        policyState, evaluateAction
    };
};
