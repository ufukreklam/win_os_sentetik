
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { Save, Plus, X, MoreHorizontal } from 'lucide-react';

interface Tab {
  id: string;
  name: string;
  content: string;
  isSaved: boolean;
}

const NotepadApp: React.FC = () => {
  const { writeFile } = useOS();
  
  const [tabs, setTabs] = useState<Tab[]>([
      { id: '1', name: 'Untitled.txt', content: '', isSaved: true }
  ]);
  const [activeTabId, setActiveTabId] = useState('1');

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    setTabs(prev => prev.map(tab => {
        if (tab.id === activeTabId) {
            return { ...tab, content: newContent, isSaved: false };
        }
        return tab;
    }));
  };

  const handleSave = () => {
    // Save active tab
    const name = activeTab.name === 'Untitled.txt' ? `Note_${Date.now()}.txt` : activeTab.name;
    
    writeFile('/home/user/Documents', {
        name: name,
        type: 'file',
        fileType: 'text',
        size: `${activeTab.content.length} B`,
        permissions: '-rw-r--r--',
        content: activeTab.content
    });
    
    setTabs(prev => prev.map(tab => {
        if (tab.id === activeTabId) {
            return { ...tab, name: name, isSaved: true };
        }
        return tab;
    }));
  };

  const newTab = () => {
      const newId = Date.now().toString();
      const newTab: Tab = { id: newId, name: 'Untitled.txt', content: '', isSaved: true };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newId);
  };

  const closeTab = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      if (tabs.length === 1) {
          // If closing last tab, just reset it
          setTabs([{ id: Date.now().toString(), name: 'Untitled.txt', content: '', isSaved: true }]);
          return;
      }

      const tabIndex = tabs.findIndex(t => t.id === id);
      const newTabs = tabs.filter(t => t.id !== id);
      setTabs(newTabs);
      
      // If we closed the active tab, switch to another
      if (id === activeTabId) {
          const nextTab = newTabs[tabIndex - 1] || newTabs[0];
          setActiveTabId(nextTab.id);
      }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-100 font-mono">
      {/* Tab Bar */}
      <div className="h-9 bg-black/40 flex items-end px-2 gap-1 select-none border-b border-white/5 pt-1 overflow-x-auto no-scrollbar">
        {tabs.map(tab => (
            <div 
                key={tab.id}
                onClick={() => setActiveTabId(tab.id)}
                className={`
                    group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs min-w-[120px] max-w-[160px] cursor-pointer border-t border-x transition-colors
                    ${activeTabId === tab.id 
                        ? 'bg-slate-800 border-white/10 text-white' 
                        : 'bg-transparent border-transparent text-slate-400 hover:bg-white/5'}
                `}
            >
                <span className="truncate flex-1">{tab.name}</span>
                {!tab.isSaved && <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />}
                <button 
                    onClick={(e) => closeTab(e, tab.id)}
                    className={`p-0.5 rounded-md hover:bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity ${activeTabId === tab.id ? 'text-slate-300' : ''}`}
                >
                    <X size={10} />
                </button>
                {activeTabId === tab.id && <div className="absolute bottom-[-1px] left-0 right-0 h-0.5 bg-blue-500 rounded-full" />}
            </div>
        ))}
        <button 
            onClick={newTab}
            className="p-1.5 hover:bg-white/10 rounded mb-1 text-slate-400 transition-colors"
            title="New Tab"
        >
            <Plus size={14} />
        </button>
      </div>

      {/* Toolbar */}
      <div className="h-8 bg-slate-800 border-b border-white/5 flex items-center px-4 gap-4 text-xs select-none shrink-0">
        <div className="flex gap-2 text-slate-300">
            <button className="hover:text-white transition-colors">File</button>
            <button className="hover:text-white transition-colors">Edit</button>
            <button className="hover:text-white transition-colors">View</button>
        </div>
        <div className="flex-1" />
        <button 
            onClick={handleSave}
            className={`flex items-center gap-1 px-2 py-0.5 rounded hover:bg-white/10 transition-colors ${!activeTab.isSaved ? 'text-blue-400' : 'text-slate-400'}`}
            title="Save to Documents"
        >
            <Save size={12} />
            <span>Save</span>
        </button>
        <button className="p-1 rounded hover:bg-white/10 transition-colors text-slate-400">
            <MoreHorizontal size={14} />
        </button>
      </div>

      {/* Editor Area */}
      <div className="flex-1 relative">
        <textarea
            value={activeTab.content}
            onChange={handleContentChange}
            className="absolute inset-0 w-full h-full bg-slate-900 text-slate-200 p-4 resize-none focus:outline-none focus:ring-0 leading-relaxed custom-scrollbar"
            spellCheck={false}
            placeholder="Start typing..."
        />
      </div>

      {/* Status Bar */}
      <div className="h-6 bg-slate-950 border-t border-white/5 flex items-center justify-end px-3 gap-4 text-[10px] text-slate-500 select-none shrink-0">
        <span>UTF-8</span>
        <span>{activeTab.content.length} characters</span>
        <span>{activeTab.content.split('\n').length} lines</span>
      </div>
    </div>
  );
};

export default NotepadApp;
