
import React from 'react';
import { OSProvider, useOS } from './context/OSContext';
import TopBar from './components/layout/TopBar';
import StatusBar from './components/layout/StatusBar';
import StartMenu from './components/layout/StartMenu';
import Desktop from './components/layout/Desktop';
import Toaster from './components/ui/Toaster';
import LockScreen from './components/layout/LockScreen';
import PostScreen from './components/system/PostScreen';
import BiosScreen from './components/system/BiosScreen';
import BSOD from './components/system/BSOD';
import VoiceOverlay from './components/system/VoiceOverlay';
import { EMOTION_COLORS } from './constants';

const OSLayout: React.FC = () => {
  const { wallpaper, isLocked, bootState, bootMode, emotionState } = useOS();

  // Boot Sequence Handling
  if (bootState === 'posting') {
    return <PostScreen />;
  }

  if (bootState === 'bios') {
    return <BiosScreen />;
  }

  if (bootState === 'bsod') {
    return <BSOD />;
  }

  // Determine Emotion Ambient Color
  const ambientClass = EMOTION_COLORS[emotionState.primary] || 'bg-transparent';

  // OS Running State
  return (
    <div 
      className="relative w-full h-full flex flex-col overflow-hidden bg-cover bg-center transition-all duration-500"
      style={{ backgroundImage: bootMode === 'safe' ? 'none' : `url(${wallpaper})`, backgroundColor: bootMode === 'safe' ? '#000' : 'transparent' }}
    >
      {/* Emotion Ambient Overlay (Subtle) */}
      <div className={`absolute inset-0 pointer-events-none transition-colors duration-1000 z-0 ${ambientClass}`} style={{ opacity: 0.15 }} />

      {/* Safe Mode Watermark */}
      {bootMode === 'safe' && (
        <div className="absolute inset-0 pointer-events-none z-[1000] flex flex-col justify-between p-2 text-white/50 font-bold font-mono">
            <div className="flex justify-between">
                <span>Safe Mode</span>
                <span>Safe Mode</span>
            </div>
            <div className="flex justify-between">
                <span>Safe Mode</span>
                <span>Safe Mode</span>
            </div>
        </div>
      )}

      {/* iOS Style Top Bar */}
      <TopBar />

      {/* Main Desktop Workspace */}
      <Desktop />

      {/* Windows 11 Style Status/Task Bar */}
      <StatusBar />

      {/* Overlays */}
      <StartMenu />
      <Toaster />
      <VoiceOverlay />
      
      {/* Lock Screen Overlay (Highest Z-Index) */}
      {isLocked && <LockScreen />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <OSProvider>
      <OSLayout />
    </OSProvider>
  );
};

export default App;
