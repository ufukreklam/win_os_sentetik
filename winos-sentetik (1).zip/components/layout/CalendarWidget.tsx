
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarWidgetProps {
  isOpen: boolean;
  onClose: () => void;
}

const CalendarWidget: React.FC<CalendarWidgetProps> = ({ isOpen, onClose }) => {
  const { timeOffset } = useOS();
  const [currentDate, setCurrentDate] = useState(new Date(Date.now() + timeOffset));
  
  // Sync with system time changes (e.g. date rollover)
  useEffect(() => {
      if (isOpen) {
          setCurrentDate(new Date(Date.now() + timeOffset));
      }
  }, [isOpen, timeOffset]);

  if (!isOpen) return null;

  // Helper functions to replace date-fns
  const getStartOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1);
  const getEndOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0);
  
  const getStartOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay(); // 0 is Sunday
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const getEndOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() + (6 - day);
    return new Date(d.setDate(diff));
  };

  const addMonths = (date: Date, amount: number) => {
      const newDate = new Date(date);
      newDate.setMonth(newDate.getMonth() + amount);
      return newDate;
  };

  const isSameDay = (d1: Date, d2: Date) => {
      return d1.getFullYear() === d2.getFullYear() &&
             d1.getMonth() === d2.getMonth() &&
             d1.getDate() === d2.getDate();
  };

  const isSameMonth = (d1: Date, d2: Date) => {
      return d1.getFullYear() === d2.getFullYear() &&
             d1.getMonth() === d2.getMonth();
  };
  
  const formatDate = (date: Date, formatStr: string) => {
      if (formatStr === 'MMMM yyyy') {
          return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      }
      if (formatStr === 'd') {
          return date.getDate().toString();
      }
      if (formatStr === 'EEEE, MMMM do') {
          const day = date.getDate();
          const suffix = ["th", "st", "nd", "rd"][((day % 100 > 10 && day % 100 < 20) || (day % 10 > 3)) ? 0 : day % 10];
          return `${date.toLocaleDateString('en-US', { weekday: 'long' })}, ${date.toLocaleDateString('en-US', { month: 'long' })} ${day}${suffix}`;
      }
      return date.toDateString();
  };

  const monthStart = getStartOfMonth(currentDate);
  const monthEnd = getEndOfMonth(monthStart);
  const startDate = getStartOfWeek(monthStart);
  const endDate = getEndOfWeek(monthEnd);

  const calendarDays: Date[] = [];
  let day = new Date(startDate);
  
  while (day <= endDate) {
      calendarDays.push(new Date(day));
      day.setDate(day.getDate() + 1);
  }

  const weekDays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const prevMonth = () => setCurrentDate(addMonths(currentDate, -1));

  const systemToday = new Date(Date.now() + timeOffset);

  return (
    <div 
      className="fixed bottom-14 right-4 z-50 w-80 
                 bg-slate-900/90 backdrop-blur-2xl 
                 border border-white/10 rounded-xl shadow-2xl p-4
                 animate-in slide-in-from-bottom-5 fade-in duration-200 origin-bottom-right"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Date Header */}
      <div className="mb-4 flex justify-between items-center text-slate-100">
        <h2 className="text-sm font-semibold pl-2">
            {formatDate(currentDate, 'MMMM yyyy')}
        </h2>
        <div className="flex gap-1">
            <button onClick={prevMonth} className="p-1 hover:bg-white/10 rounded-md transition-colors">
                <ChevronLeft size={16} />
            </button>
            <button onClick={nextMonth} className="p-1 hover:bg-white/10 rounded-md transition-colors">
                <ChevronRight size={16} />
            </button>
        </div>
      </div>

      {/* Days of Week */}
      <div className="grid grid-cols-7 mb-2 text-center">
        {weekDays.map(day => (
          <div key={day} className="text-xs font-medium text-slate-500 py-1">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 text-center">
        {calendarDays.map((day, idx) => {
           const isCurrentMonthVal = isSameMonth(day, monthStart);
           const isTodayVal = isSameDay(day, systemToday);
           
           return (
             <div 
                key={idx}
                className={`
                    text-xs py-2 rounded-full cursor-default transition-all
                    ${!isCurrentMonthVal ? 'text-slate-600' : 'text-slate-200 hover:bg-white/10'}
                    ${isTodayVal ? 'bg-blue-600 text-white font-bold hover:bg-blue-500 shadow-lg shadow-blue-500/20' : ''}
                `}
             >
                {formatDate(day, 'd')}
             </div>
           );
        })}
      </div>

      {/* Footer / Today's Details */}
      <div className="mt-4 pt-4 border-t border-white/10">
         <div className="text-xs text-slate-400">
             {formatDate(systemToday, 'EEEE, MMMM do')}
         </div>
      </div>
    </div>
  );
};

export default CalendarWidget;
