import { useState, useCallback, useEffect } from 'react';
import { AppID, WindowState, Rect } from '../../types';
import { APP_CONFIGS } from '../../constants';
import { playSystemSound } from '../../utils/soundUtils';

export const useWindowManager = (installedAppIds: AppID[], logoutTrigger: any) => {
    const [isStartMenuOpen, setIsStartMenuOpen] = useState(false);
    const [activeZIndex, setActiveZIndex] = useState(10);
    const [isMovingWindow, setMovingWindow] = useState(false);
    const [snapPreview, setSnapPreview] = useState<Rect | null>(null);

    const [windows, setWindows] = useState<Record<AppID, WindowState>>(() => {
        const screenW = typeof window !== 'undefined' ? window.innerWidth : 1024;
        const screenH = typeof window !== 'undefined' ? window.innerHeight : 768;
        const topBarHeight = 32;
        const statusBarHeight = 48;
        const desktopHeight = screenH - topBarHeight - statusBarHeight;
        const margin = 25;
        const startX = margin;
        const startY = margin;
        const startWidth = screenW - (margin * 2);
        const startHeight = desktopHeight - (margin * 2);

        let savedWindows: Record<string, Partial<WindowState>> = {};
        if (typeof window !== 'undefined') {
            try {
                const saved = localStorage.getItem('winos_window_state');
                if (saved) savedWindows = JSON.parse(saved);
            } catch (e) {
                console.error("Failed to parse window state", e);
            }
        }

        const initialWindows: Partial<Record<AppID, WindowState>> = {};

        Object.values(AppID).forEach((appIdValue) => {
            const appId = appIdValue as AppID;
            const metadata = APP_CONFIGS[appId];
            let width = Math.max(400, startWidth);
            let height = Math.max(300, startHeight);
            let x = startX;
            let y = startY;

            // Default dimensions overrides
            if (appId === AppID.CALCULATOR) { width = 320; height = 480; x = startX + 100; y = startY + 50; }
            else if (appId === AppID.NOTEPAD) { width = 600; height = 500; }
            else if (appId === AppID.TERMINAL) { width = 700; height = 500; }
            else if (appId === AppID.MEDIA) { width = 900; height = 600; }
            else if (appId === AppID.TASK_MANAGER) { width = 900; height = 650; }
            else if (appId === AppID.APP_STORE) { width = 900; height = 650; }
            else if (appId === AppID.MIND) { width = 800; height = 600; x = startX + 50; y = startY + 50; }
            else if (appId === AppID.SPATIAL) { width = 900; height = 650; }
            else if (appId === AppID.GOALS) { width = 900; height = 650; x = startX + 100; y = startY + 20; }
            else if (appId === AppID.SOCIAL) { width = 900; height = 600; }
            else if (appId === AppID.LEARNING) { width = 950; height = 650; }
            else if (appId === AppID.SECURITY) { width = 900; height = 600; }
            else if (appId === AppID.CONNECT) { width = 950; height = 650; }
            else if (appId === AppID.IDENTITY) { width = 900; height = 600; }
            else if (appId === AppID.ORCHESTRATOR) { width = 950; height = 700; }
            else if (appId === AppID.BRIDGE) { width = 950; height = 700; }
            else if (appId === AppID.FACE) { width = 450; height = 650; x = (screenW - 450) / 2; y = (desktopHeight - 650) / 2 > 0 ? (desktopHeight - 650) / 2 : startY; }

            const saved = savedWindows[appId];
            if (saved) {
                if (saved.x !== undefined && saved.x < screenW - 50 && saved.x > -width + 50) x = saved.x;
                if (saved.y !== undefined && saved.y < screenH - 50 && saved.y > 0) y = saved.y;
                if (saved.width) width = saved.width;
                if (saved.height) height = saved.height;
            }

            initialWindows[appId] = {
                id: appId,
                title: metadata.name,
                isOpen: saved?.isOpen ?? false,
                isMinimized: saved?.isMinimized ?? false,
                isMaximized: saved?.isMaximized ?? false,
                zIndex: saved?.zIndex ?? 1,
                icon: metadata.icon,
                x, y, width, height
            };
        });

        return initialWindows as Record<AppID, WindowState>;
    });

    // Close all windows on logout (triggered by changing currentUser in parent)
    useEffect(() => {
        if (logoutTrigger === null) { // User logged out
             setWindows(prev => {
                const next = { ...prev };
                Object.keys(next).forEach(key => {
                    next[key as AppID].isOpen = false;
                });
                return next;
            });
        }
    }, [logoutTrigger]);

    // Persist Window State
    useEffect(() => {
        const timeout = setTimeout(() => {
            const stateToSave: Record<string, Partial<WindowState>> = {};
            // Add comment above fix: explicitly cast Object.values to WindowState[] to ensure proper type inference during destructuring
            (Object.values(windows) as WindowState[]).forEach(win => {
                const { icon, ...rest } = win;
                stateToSave[win.id] = rest;
            });
            localStorage.setItem('winos_window_state', JSON.stringify(stateToSave));
        }, 500);
        return () => clearTimeout(timeout);
    }, [windows]);

    const toggleStartMenu = useCallback(() => {
        setIsStartMenuOpen(prev => {
            if (!prev) playSystemSound('click');
            return !prev;
        });
    }, []);

    const focusApp = useCallback((appId: AppID) => {
        setWindows(prev => {
            const newZ = activeZIndex + 1;
            setActiveZIndex(newZ);
            return {
                ...prev,
                [appId]: { ...prev[appId], zIndex: newZ, isMinimized: false }
            };
        });
        setIsStartMenuOpen(false);
    }, [activeZIndex]);

    const openApp = useCallback((appId: AppID) => {
        // Assume installedAppIds is checked by the caller or UI
        setWindows(prev => {
            const isOpen = prev[appId].isOpen;
            const newZ = activeZIndex + 1;
            setActiveZIndex(newZ);

            if (!isOpen) playSystemSound('window-open');

            if (isOpen && prev[appId].isMinimized) {
                return {
                    ...prev,
                    [appId]: { ...prev[appId], isMinimized: false, zIndex: newZ }
                };
            }

            return {
                ...prev,
                [appId]: { ...prev[appId], isOpen: true, zIndex: newZ, isMinimized: false }
            };
        });
        setIsStartMenuOpen(false);
    }, [activeZIndex]);

    const closeApp = useCallback((appId: AppID) => {
        playSystemSound('window-close');
        setWindows(prev => ({
            ...prev,
            [appId]: { ...prev[appId], isOpen: false }
        }));
    }, []);

    const minimizeApp = useCallback((appId: AppID) => {
        playSystemSound('window-close');
        setWindows(prev => ({
            ...prev,
            [appId]: { ...prev[appId], isMinimized: true }
        }));
    }, []);

    const maximizeApp = useCallback((appId: AppID) => {
        setWindows(prev => ({
            ...prev,
            [appId]: { ...prev[appId], isMaximized: !prev[appId].isMaximized, isMinimized: false }
        }));
    }, []);

    const updateWindow = useCallback((appId: AppID, updates: Partial<WindowState>) => {
        setWindows(prev => ({
            ...prev,
            [appId]: { ...prev[appId], ...updates }
        }));
    }, []);

    return {
        windows, isStartMenuOpen, toggleStartMenu, activeZIndex,
        openApp, closeApp, minimizeApp, maximizeApp, focusApp, updateWindow,
        isMovingWindow, setMovingWindow, snapPreview, setSnapPreview, setWindows
    };
};