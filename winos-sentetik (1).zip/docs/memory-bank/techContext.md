
# Teknoloji Bağlamı

## Mimari Ayrımı
Bu proje **Frontend (Arayüz)** ve **Backend (Robot Beyni)** olmak üzere iki ayrı ana parçadan oluşur.

### 1. Frontend Stack
*   **Framework**: React 19
*   **Dil**: TypeScript
*   **Stil**: Tailwind CSS
*   **Durum Yönetimi**: React Context API (OSContext)
*   **İletişim**: WebSocket (Real-time telemetri için).

### 2. Backend Stack (WinOS Core)
**ÖNEMLİ: Bu projede ROS (Robot Operating System) KULLANILMAZ.**
Bunun yerine saf Python ile yazılmış özel bir olay güdümlü (event-driven) mimari kullanılır.

*   **Platform**: Raspberry Pi 5 (Linux/Debian)
*   **Dil**: Python 3.11+
*   **Web Sunucusu**: FastAPI + Uvicorn
*   **Asenkron Yapı**: `asyncio` (Node yönetimi için)
*   **Donanım İletişimi**: `pyserial` (Pico ile UART haberleşmesi)
*   **Veri Formatı**: JSON (Sistem içi ve dışı tüm haberleşme)

## Entegrasyon Yöntemleri
1.  **WebSocket**: Frontend ve Backend arasındaki ana veri borusu. Telemetri (sensörler) ve Komutlar (hareket) buradan akar.
2.  **UART (Seri Port)**: Backend (RPi 5) ve Alt Kontrolcüler (Pico Cluster) arasındaki fiziksel bağlantı.
3.  **Local Simulation**: Donanım yokluğunda, Backend içindeki `SerialNode` rastgele ama tutarlı veriler üreterek donanımı taklit eder (Mocking).

## Teknik Kısıtlamalar
- **Gerçek Zamanlılık**: Python `asyncio` "soft real-time" çalışır. Milisaniye hassasiyetindeki motor kontrol döngüleri (PID vb.) RPi 5'te değil, **RPi Pico** (C++/MicroPython) üzerinde çalışmalıdır. RPi 5 sadece üst seviye komut gönderir.
- **Performans**: Görüntü işleme ve Lidar haritalama işlemleri ana thread'i bloklamamalıdır.
