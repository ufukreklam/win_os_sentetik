
import { useState, useRef, useEffect, useCallback } from 'react';
import { LanguageState, VoiceState, AIMode } from '../../../types';
import { INITIAL_LANGUAGE } from '../../initialStates';
import { ttsService } from '../../../services/ttsService';
import { vadService } from '../../../services/vadService';
import { playSystemSound } from '../../../utils/soundUtils';

export const useAILanguage = (
    aiMode: AIMode, 
    openApp: (id: any) => void,
    onSpeechResult: (text: string) => void
) => {
    const [languageState, setLanguageState] = useState<LanguageState>(INITIAL_LANGUAGE);
    const [voiceState, setVoiceState] = useState<VoiceState>('idle');
    const [lastVoiceText, setLastVoiceText] = useState('');
    const [isHandsFree, setIsHandsFree] = useState(false);
    const [voiceEnergy, setVoiceEnergy] = useState(0);
    
    const recognitionRef = useRef<any>(null);

    // Partial update helper to match context interface
    const updateLanguageState = useCallback((updates: Partial<LanguageState>) => {
        setLanguageState(prev => ({ ...prev, ...updates }));
    }, []);

    // --- TTS Lifecycle ---
    useEffect(() => {
        ttsService.onStart = () => {
            setVoiceState('speaking');
            setLanguageState(prev => ({ ...prev, processingStage: 'speaking' }));
        };
        ttsService.onEnd = () => {
            setVoiceState('idle');
            setLanguageState(prev => ({ ...prev, processingStage: 'idle' }));
        };
        return () => { ttsService.stop(); };
    }, []);

    // --- VAD Integration ---
    useEffect(() => {
        if (isHandsFree) {
            vadService.start();
            vadService.onEnergy = setVoiceEnergy;
            vadService.onSpeechStart = () => {
                if (voiceState === 'idle') startListening();
            };
        } else {
            vadService.stop();
            setVoiceEnergy(0);
        }
        return () => { if(!isHandsFree) vadService.stop(); };
    }, [isHandsFree, voiceState]);

    const toggleHandsFree = useCallback(() => {
        setIsHandsFree(prev => !prev);
        playSystemSound(isHandsFree ? 'click' : 'startup');
    }, [isHandsFree]);

    const processSystemCommand = useCallback((text: string) => {
        const lower = text.toLowerCase();
        if (lower.includes('open calculator')) openApp('calculator');
        // Diğer sistem komutları buraya eklenebilir
    }, [openApp]);

    const startListening = useCallback(() => {
        if (!('webkitSpeechRecognition' in window)) {
            alert("Web Speech API not supported");
            return;
        }

        if (voiceState === 'listening') return;

        const recognition = new (window as any).webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => setVoiceState('listening');

        recognition.onresult = (event: any) => {
            const text = event.results[0][0].transcript;
            setLastVoiceText(text);
            processSystemCommand(text);
            
            setVoiceState('processing');
            // Sonucu üst katmana ilet (Inference için)
            onSpeechResult(text);
        };

        recognition.onerror = (event: any) => {
            console.error("Speech Recognition Error", event.error);
            setVoiceState('idle');
        };

        recognition.onend = () => {
            if (voiceState !== 'processing' && voiceState !== 'speaking') {
                setVoiceState('idle');
            }
        };

        recognitionRef.current = recognition;
        recognition.start();

    }, [voiceState, processSystemCommand, onSpeechResult]);

    const stopListening = useCallback(() => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
            setVoiceState('idle');
            setLanguageState(prev => ({ ...prev, processingStage: 'idle' }));
        }
    }, []);

    const speak = useCallback((text: string) => {
        ttsService.speak(text, aiMode === 'cloud' || aiMode === 'hybrid');
    }, [aiMode]);

    return {
        languageState,
        setLanguageState: updateLanguageState,
        voiceState,
        lastVoiceText,
        isHandsFree,
        toggleHandsFree,
        voiceEnergy,
        startListening,
        stopListening,
        speak
    };
};
