
import React from 'react';
import { Map, Cuboid, Eye, Layers } from 'lucide-react';

interface SpatialSidebarProps {
    activeTab: string;
    setActiveTab: (tab: 'slam_2d' | 'slam_3d' | 'vision' | 'fusion') => void;
}

export const SpatialSidebar: React.FC<SpatialSidebarProps> = ({ activeTab, setActiveTab }) => {
    const buttons = [
        { id: 'slam_2d', label: '2D Haritalama', icon: Map, color: 'blue' },
        { id: 'slam_3d', label: '3D SLAM (RGB-D)', icon: Cuboid, color: 'indigo' },
        { id: 'vision', label: 'Sanal Korteks', icon: Eye, color: 'purple' },
        { id: 'fusion', label: 'Sensör Füzyonu', icon: Layers, color: 'teal' },
    ];

    return (
        <div className="w-16 md:w-60 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            {buttons.map((btn) => (
                <button 
                    key={btn.id}
                    onClick={() => setActiveTab(btn.id as any)}
                    className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${
                        activeTab === btn.id ? `bg-${btn.color}-600 text-white` : 'text-slate-400'
                    }`}
                >
                    <btn.icon size={20} />
                    <span className="hidden md:inline text-sm font-medium">{btn.label}</span>
                </button>
            ))}
        </div>
    );
};
