
import logging
import time
import random
from ..core.robot_system import RobotNode

logger = logging.getLogger("HeadNode")

class PIDController:
    def __init__(self, kp, ki, kd, min_val, max_val):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.min_val = min_val
        self.max_val = max_val
        self.last_error = 0
        self.integral = 0
        self.last_time = time.time()

    def update(self, target, current):
        now = time.time()
        dt = now - self.last_time if now - self.last_time > 0 else 0.001
        
        error = target - current
        self.integral += error * dt
        derivative = (error - self.last_error) / dt
        
        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        
        self.last_error = error
        self.last_time = now
        
        return max(self.min_val, min(self.max_val, output))

class HeadNode(RobotNode):
    """
    Kafa (Pan/Tilt) Kontrol Düğümü.
    - Yüz takibi veya rastgele bakınma hareketleri yapar.
    """
    def __init__(self, bus):
        super().__init__("HeadNode", bus)
        self.loop_interval = 0.05 # 20Hz
        
        # Servo State (Degrees)
        self.pan_angle = 90
        self.tilt_angle = 90
        
        # Limits
        self.PAN_LIMITS = (0, 180)
        self.TILT_LIMITS = (10, 140) # Genelde aşağı çok eğilemez
        
        # Mode
        self.mode = "IDLE" # IDLE, TRACKING, MANUAL
        self.last_action_time = time.time()
        self.idle_move_delay = 3.0
        
        # Tracking Targets (Normalized coordinates 0.0 - 1.0)
        # Center is (0.5, 0.5)
        self.target_x = 0.5
        self.target_y = 0.5
        
        # PID Controllers for smooth tracking
        # Kp, Ki, Kd değerleri donanıma göre tune edilmelidir.
        self.pid_pan = PIDController(kp=20.0, ki=0.5, kd=1.0, min_val=-10, max_val=10)
        self.pid_tilt = PIDController(kp=20.0, ki=0.5, kd=1.0, min_val=-10, max_val=10)

    async def setup(self):
        self.bus.subscribe("perception_state", self.handle_perception)
        self.bus.subscribe("user_input", self.handle_manual_command)

    async def handle_perception(self, data):
        """Görsel algıdan gelen verileri işle"""
        # Eğer manuel moddaysak takibi yoksay
        if self.mode == "MANUAL":
            return

        # Yüz veya önemli nesne var mı?
        if data.get("visualAttention"):
            self.mode = "TRACKING"
            self.target_x = data["visualAttention"]["x"]
            self.target_y = data["visualAttention"]["y"]
            self.last_action_time = time.time()
        else:
            # Hedef kaybolduysa bir süre bekle sonra IDLE'a dön
            if time.time() - self.last_action_time > 2.0:
                self.mode = "IDLE"

    async def handle_manual_command(self, data):
        """Kullanıcıdan gelen manuel kafa kontrolü"""
        if data.get("action") == "head_move":
            self.mode = "MANUAL"
            self.last_action_time = time.time()
            
            if "pan" in data:
                self.pan_angle = max(self.PAN_LIMITS[0], min(self.PAN_LIMITS[1], data["pan"]))
            if "tilt" in data:
                self.tilt_angle = max(self.TILT_LIMITS[0], min(self.TILT_LIMITS[1], data["tilt"]))

    async def loop(self):
        """Ana kontrol döngüsü"""
        
        if self.mode == "TRACKING":
            # PID ile açı güncelleme
            # Hedef (0.5) ile mevcut konum (target_x) arasındaki farka göre hareket et
            # Pan için: Hedef X sağdaysa (>0.5), açıyı azalt (veya artır, montaja bağlı)
            # Burada varsayım: 0 derece sağ, 180 derece sol.
            
            delta_pan = self.pid_pan.update(0.5, self.target_x)
            delta_tilt = self.pid_tilt.update(0.5, self.target_y)
            
            # Görüntü koordinatları ile servo yönü ters olabilir, deneme/yanılma ile işaret değişebilir.
            self.pan_angle += delta_pan 
            self.tilt_angle -= delta_tilt # Y ekseni genelde terstir
            
        elif self.mode == "IDLE":
            # Rastgele "canlılık" hareketleri
            if time.time() - self.last_action_time > self.idle_move_delay:
                # Küçük rastgele hareketler
                self.pan_angle += random.uniform(-10, 10)
                self.tilt_angle += random.uniform(-5, 5)
                
                # Merkeze dönüş eğilimi (Drift prevention)
                self.pan_angle = (self.pan_angle * 0.8) + (90 * 0.2)
                self.tilt_angle = (self.tilt_angle * 0.8) + (90 * 0.2)
                
                self.last_action_time = time.time()
                self.idle_move_delay = random.uniform(2.0, 6.0)

        # 1. Sınırları Uygula
        self.pan_angle = max(self.PAN_LIMITS[0], min(self.PAN_LIMITS[1], self.pan_angle))
        self.tilt_angle = max(self.TILT_LIMITS[0], min(self.TILT_LIMITS[1], self.tilt_angle))

        # 2. Komutu Hazırla ve Gönder
        cmd = {
            "s": [int(self.pan_angle), int(self.tilt_angle)]
        }
        await self.bus.publish("serial_write", cmd)
