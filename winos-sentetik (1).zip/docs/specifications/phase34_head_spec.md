
# Faz 34: Servo Kafa Kontrolü ve Takip Spesifikasyonu

Bu döküman, WinOS Robotik Çekirdeği için **Kafa Kontrol Sistemi (HeadNode)** tasarımını içerir.

## 1. Hedef
Robotun boyun mekanizmasını (Pan/Tilt) kontrol ederek; çevresel farkındalık (tarama), sosyal etkileşim (göz teması) ve nesne/yüz takibi yeteneklerini kazandırmak.

## 2. Donanım Mimarisi

*   **Mekanizma**: 2 Serbestlik Dereceli (2-DOF) Pan/Tilt kiti.
*   **Eyleyiciler**: 2x SG90 veya MG996R Servo Motor.
*   **Sürücü**: RPi Pico PWM çıkışları (veya PCA9685 I2C sürücü).
*   **Açı Sınırları**:
    *   **Pan (Yatay):** 0° (Sağ) - 180° (Sol). Merkez: 90°.
    *   **Tilt (Dikey):** 0° (Aşağı) - 180° (Yukarı). Merkez: 90° (veya ufuk çizgisi).

## 3. Protokol Genişletmesi

Master -> Slave komut setine servo açıları eklenir.

```json
{
  "s": [90, 45] // [Pan, Tilt] (Derece cinsinden)
}
```

## 4. Yazılım Mimarisi (HeadNode)

### 4.1 Çalışma Modları

1.  **IDLE (Boşta):**
    *   Robot "canlı" görünmek için rastgele aralıklarla küçük kafa hareketleri yapar (Micro-saccades).
    *   Bazen geniş bir açıyla çevreyi tarar.
2.  **TRACKING (Takip):**
    *   `perception_state` veya `face_detection` verisinden gelen hedef koordinatlara (X, Y) kilitlenir.
    *   PID algoritması kullanılarak hedefin görüntü merkezinde kalması sağlanır.
3.  **MANUAL (Manuel):**
    *   Kullanıcı arayüzünden gelen doğrudan açı komutlarını uygular.
4.  **EMOTION (Duygu):**
    *   Duygu durumuna göre baş pozisyonu alır (Örn: Üzgünse başı öne eğer).

### 4.2 PID Kontrol Algoritması

Kamera görüntüsündeki bir nesneyi takip etmek için:

*   **Hata (Error):** `(Görüntü Merkezi) - (Hedef Merkezi)`
*   **Çıktı (Output):** `Kp*Error + Ki*Integral + Kd*Derivative`
*   **Yeni Açı:** `Mevcut Açı + Çıktı`

Bu yöntem, servoların hedefe yumuşak ve kararlı bir şekilde yaklaşmasını sağlar, titremeyi önler.

## 5. Güvenlik
*   **Açı Sınırlandırma (Clamping):** Yazılımsal olarak servoların mekanik sınırları zorlaması engellenir (örn. Min 10°, Max 170°).
*   **Hız Limiti:** Ani ve sert hareketler engellenerek dişli kutusu korunur.
