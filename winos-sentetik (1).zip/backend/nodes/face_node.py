
import logging
import time
import random
import asyncio
from ..core.robot_system import RobotNode

logger = logging.getLogger("FaceNode")

class FaceNode(RobotNode):
    """
    Yüz İfadesi Kontrol Düğümü
    - Duygu durumunu dinler.
    - Fiziksel OLED ve LED'leri yönetir.
    - Otomatik göz kırpma (blink) ve canlılık efektleri üretir.
    """
    def __init__(self, bus):
        super().__init__("FaceNode", bus)
        self.loop_interval = 0.1 # 10Hz (Animasyonlar için)
        
        self.current_emotion = "neutral"
        self.last_blink_time = time.time()
        self.next_blink_delay = random.uniform(2.0, 6.0)
        self.is_blinking = False
        self.blink_duration = 0.2
        
        # Duygu -> Donanım Konfigürasyonu Haritası
        self.emotion_map = {
            "neutral":  {"eyes": "normal", "mouth": "line",    "color": [0, 0, 255],    "mode": "breathe"},
            "happy":    {"eyes": "happy",  "mouth": "smile",   "color": [255, 200, 0],  "mode": "solid"},
            "sad":      {"eyes": "sad",    "mouth": "frown",   "color": [0, 0, 100],    "mode": "breathe"},
            "angry":    {"eyes": "angry",  "mouth": "line",    "color": [255, 0, 0],    "mode": "pulse"},
            "fear":     {"eyes": "wide",   "mouth": "open",    "color": [100, 0, 200],  "mode": "shiver"},
            "surprised":{"eyes": "wide",   "mouth": "circle",  "color": [255, 100, 200],"mode": "blink"},
            "curious":  {"eyes": "normal", "mouth": "smirk",   "color": [0, 255, 100],  "mode": "solid"}
        }

    async def setup(self):
        self.bus.subscribe("emotion_state", self.handle_emotion_update)
        self.bus.subscribe("user_input", self.handle_manual_command)

    async def handle_emotion_update(self, data):
        """AI veya Frontend'den gelen duygu değişimini işle"""
        if "primary" in data:
            new_emotion = data["primary"]
            if new_emotion in self.emotion_map and new_emotion != self.current_emotion:
                self.current_emotion = new_emotion
                logger.info(f"Yüz İfadesi Değişti: {self.current_emotion}")
                await self.update_hardware()

    async def handle_manual_command(self, data):
        """Manuel test komutları"""
        if data.get("action") == "set_face":
            emotion = data.get("expression")
            if emotion in self.emotion_map:
                self.current_emotion = emotion
                await self.update_hardware()

    async def update_hardware(self, override_eyes=None):
        """Donanıma seri port üzerinden komut gönder"""
        config = self.emotion_map.get(self.current_emotion, self.emotion_map["neutral"])
        
        # Göz durumunu belirle (Normal veya Blink)
        eye_state = override_eyes if override_eyes else config["eyes"]
        
        packet = {
            "d": {
                "l": eye_state,
                "r": eye_state,
                "m": config["mouth"]
            },
            "l": {
                "c": config["color"],
                "m": config["mode"],
                "i": 100
            }
        }
        
        await self.bus.publish("serial_write", packet)

    async def loop(self):
        """Otomatik Göz Kırpma Döngüsü"""
        now = time.time()
        
        # Blink Başlat
        if not self.is_blinking and (now - self.last_blink_time > self.next_blink_delay):
            self.is_blinking = True
            self.last_blink_time = now
            # Gözleri kapat
            await self.update_hardware(override_eyes="closed")
            
        # Blink Bitir
        elif self.is_blinking and (now - self.last_blink_time > self.blink_duration):
            self.is_blinking = False
            self.next_blink_delay = random.uniform(2.0, 6.0)
            # Gözleri aç (mevcut duyguya dön)
            await self.update_hardware()
