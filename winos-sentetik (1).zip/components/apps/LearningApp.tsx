
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { BookOpen, Share2, TrendingUp, Zap, Circle, GitMerge, Brain } from 'lucide-react';
import { Skill, KnowledgeNode } from '../../types';

const LearningApp: React.FC = () => {
  const { learningState } = useOS();
  const [activeTab, setActiveTab] = useState<'skills' | 'knowledge' | 'adaptation'>('skills');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Knowledge Graph Visualization (Physics Simulation)
  useEffect(() => {
    if (activeTab !== 'knowledge' || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas
    const resize = () => {
        if (canvas.parentElement) {
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
        }
    };
    resize();
    window.addEventListener('resize', resize);

    // Initialize random positions if not set
    const nodes = learningState.knowledgeGraph.map(node => ({
        ...node,
        x: node.x || Math.random() * canvas.width,
        y: node.y || Math.random() * canvas.height,
        vx: 0,
        vy: 0
    }));

    let animationFrame: number;

    const animate = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Physics Update
        nodes.forEach(node => {
            // Repulsion (Coulomb's Law-ish)
            nodes.forEach(other => {
                if (node.id === other.id) return;
                const dx = node.x - other.x;
                const dy = node.y - other.y;
                const dist = Math.sqrt(dx*dx + dy*dy) || 1;
                if (dist < 200) {
                    const force = 100 / (dist * dist);
                    node.vx += (dx / dist) * force;
                    node.vy += (dy / dist) * force;
                }
            });

            // Attraction (Springs)
            node.connections.forEach(targetId => {
                const target = nodes.find(n => n.id === targetId);
                if (target) {
                    const dx = target.x - node.x;
                    const dy = target.y - node.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const force = (dist - 100) * 0.005; // Spring constant
                    node.vx += (dx / dist) * force;
                    node.vy += (dy / dist) * force;
                }
            });

            // Center Gravity
            const cx = canvas.width / 2;
            const cy = canvas.height / 2;
            node.vx += (cx - node.x) * 0.0005;
            node.vy += (cy - node.y) * 0.0005;

            // Damping & Update
            node.vx *= 0.9;
            node.vy *= 0.9;
            node.x += node.vx;
            node.y += node.vy;

            // Bounds
            node.x = Math.max(20, Math.min(canvas.width - 20, node.x));
            node.y = Math.max(20, Math.min(canvas.height - 20, node.y));
        });

        // Draw Connections
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.3)';
        ctx.lineWidth = 1;
        nodes.forEach(node => {
            node.connections.forEach(targetId => {
                const target = nodes.find(n => n.id === targetId);
                if (target) {
                    ctx.beginPath();
                    ctx.moveTo(node.x, node.y);
                    ctx.lineTo(target.x, target.y);
                    ctx.stroke();
                }
            });
        });

        // Draw Nodes
        nodes.forEach(node => {
            ctx.beginPath();
            ctx.arc(node.x, node.y, 6 + (node.activation * 4), 0, Math.PI * 2);
            
            // Color based on type
            if (node.type === 'concept') ctx.fillStyle = '#60a5fa'; // blue
            else if (node.type === 'action') ctx.fillStyle = '#f472b6'; // pink
            else if (node.type === 'object') ctx.fillStyle = '#facc15'; // yellow
            else ctx.fillStyle = '#94a3b8'; // grey

            ctx.fill();
            ctx.strokeStyle = '#1e293b';
            ctx.stroke();

            // Label
            ctx.fillStyle = '#e2e8f0';
            ctx.font = '10px Inter';
            ctx.fillText(node.label, node.x + 12, node.y + 3);
        });

        animationFrame = requestAnimationFrame(animate);
    };

    animate();

    return () => {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(animationFrame);
    };
  }, [activeTab, learningState.knowledgeGraph]);

  const SkillBar: React.FC<{ skill: Skill }> = ({ skill }) => (
      <div className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-colors">
          <div className="flex justify-between items-start mb-2">
              <div>
                  <h4 className="font-bold text-sm">{skill.name}</h4>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider ${
                      skill.category === 'cognitive' ? 'bg-blue-500/20 text-blue-300' :
                      skill.category === 'motor' ? 'bg-orange-500/20 text-orange-300' :
                      'bg-green-500/20 text-green-300'
                  }`}>
                      {skill.category}
                  </span>
              </div>
              <div className="text-right">
                  <div className="text-xl font-light">Lvl {skill.level}</div>
                  <div className="text-[10px] text-slate-400">+{skill.progressRate.toFixed(2)} XP/s</div>
              </div>
          </div>
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
                  style={{ width: `${skill.experience}%` }}
              />
          </div>
      </div>
  );

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('skills')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'skills' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <Zap size={20} />
                <span className="hidden md:inline text-sm font-medium">Skill Tree</span>
            </button>
            <button 
                onClick={() => setActiveTab('knowledge')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'knowledge' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <Share2 size={20} />
                <span className="hidden md:inline text-sm font-medium">Knowledge Graph</span>
            </button>
            <button 
                onClick={() => setActiveTab('adaptation')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'adaptation' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
                <TrendingUp size={20} />
                <span className="hidden md:inline text-sm font-medium">Adaptation</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'skills' && (
                <div className="flex-1 overflow-y-auto p-6">
                    <div className="mb-6 flex justify-between items-end">
                        <div>
                            <h2 className="text-2xl font-light mb-1">Acquired Capabilities</h2>
                            <p className="text-sm text-slate-400">Continuous learning modules active.</p>
                        </div>
                        <div className="text-right">
                            <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">Global Learning Rate</div>
                            <div className="text-xl font-mono text-green-400">{learningState.learningRate} <span className="text-xs">η</span></div>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {learningState.skills.map(skill => (
                            <SkillBar key={skill.id} skill={skill} />
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'knowledge' && (
                <div className="flex-1 relative bg-[#0f172a]">
                    <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur border border-white/10 p-3 rounded-lg text-xs">
                        <h3 className="font-bold mb-2 flex items-center gap-2"><Brain size={14} /> Semantic Memory</h3>
                        <div className="space-y-1">
                            <div className="flex items-center gap-2"><Circle size={8} className="fill-blue-400 text-blue-400" /> Concept</div>
                            <div className="flex items-center gap-2"><Circle size={8} className="fill-pink-400 text-pink-400" /> Action</div>
                            <div className="flex items-center gap-2"><Circle size={8} className="fill-yellow-400 text-yellow-400" /> Object</div>
                        </div>
                        <div className="mt-2 pt-2 border-t border-white/5 text-slate-400">
                            Nodes: {learningState.knowledgeGraph.length}
                        </div>
                    </div>
                    <canvas ref={canvasRef} className="w-full h-full block" />
                </div>
            )}

            {activeTab === 'adaptation' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <h2 className="text-xl font-bold mb-6">System Adaptation Metrics</h2>
                    
                    <div className="bg-slate-800/50 rounded-xl p-6 border border-white/5 mb-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-sm font-semibold">Adaptation Score</h3>
                            <span className={`text-2xl font-bold ${learningState.adaptationScore > 80 ? 'text-green-400' : 'text-blue-400'}`}>
                                {learningState.adaptationScore.toFixed(1)}/100
                            </span>
                        </div>
                        <div className="w-full h-4 bg-slate-900 rounded-full overflow-hidden relative">
                            <div 
                                className="h-full bg-gradient-to-r from-blue-600 to-green-500 transition-all duration-700"
                                style={{ width: `${learningState.adaptationScore}%` }}
                            />
                        </div>
                        <p className="mt-2 text-xs text-slate-400">
                            Measures the system's ability to adjust to new environmental variables and recover from errors.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                            <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Error Rate (Last 1hr)</h4>
                            <div className="flex items-end h-32 gap-1">
                                {[...Array(20)].map((_, i) => (
                                    <div 
                                        key={i} 
                                        className="flex-1 bg-red-500/20 rounded-t-sm" 
                                        style={{ height: `${Math.random() * 40 + 10}%` }} 
                                    />
                                ))}
                            </div>
                        </div>
                        <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                            <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Prediction Accuracy</h4>
                            <div className="flex items-end h-32 gap-1">
                                {[...Array(20)].map((_, i) => (
                                    <div 
                                        key={i} 
                                        className="flex-1 bg-green-500/20 rounded-t-sm" 
                                        style={{ height: `${Math.min(100, 60 + (i * 2) + (Math.random() * 10))}%` }} 
                                    />
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default LearningApp;
