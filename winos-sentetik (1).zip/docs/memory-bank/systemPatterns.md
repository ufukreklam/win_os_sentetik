
# Sistem Desenleri

## Mimari: Saf Python Mikro-Kernel (No-ROS)
Bu proje, robotik kontrol için endüstri standardı olan ancak yüksek kaynak tüketen ve karmaşık kurulum gerektiren **ROS (Robot Operating System) veya ROS2'yi KULLANMAZ**.

Bunun yerine, Raspberry Pi 5 üzerinde çalışan, Python `asyncio` tabanlı, hafif ve optimize edilmiş bir **Özel Robotik Çekirdek (Custom Robotic Core)** geliştirilmiştir.

### 🛠️ WinOS Core Mimarisi (Custom Middleware)
Sistem, `RobotNode` sınıflarının bağımsız `asyncio` görevleri (tasks) olarak çalıştığı bir **Pub/Sub (Yayınla/Abone Ol)** modeline dayanır.

*   **SlamNode (Yeni)**: Lidar verilerini (Polar koordinat) alır, robotun konumuna göre Kartezyen koordinata çevirir ve bir ızgara haritası (Occupancy Grid) üzerine işler. Çıktı olarak sıkıştırılmış bir görüntü (Base64 JPEG) üretir.

```mermaid
graph TD
    Lidar[Lidar Sensor] -->|Serial/UART| SerialNode
    SerialNode -->|Raw Data| ProtocolNode
    ProtocolNode -->|JSON| LidarNode
    LidarNode -->|XY Points| SlamNode
    SlamNode -->|Occupancy Grid (Image)| WebSocket
    WebSocket -->|Base64 Map| ReactFrontend
```

### 🎨 Spatial Uygulama ve SLAM Görselleştirme
Frontend tarafında haritalama performansı için **HTML5 Canvas** API'si doğrudan kullanılmaktadır (React Virtual DOM bypass edilerek).

1.  **Katmanlı Çizim (Layered Rendering)**:
    *   **Katman 0 (Zemin)**: `mapImageRef` ile Backend'den gelen statik/yavaş güncellenen SLAM haritası çizilir.
    *   **Katman 1 (Dinamik)**: `lidarMap` verisi ile anlık sensör taraması (Kırmızı noktalar) haritanın üzerine çizilir. Bu, harita gecikse bile robotun anlık engelleri görmesini sağlar.
    *   **Katman 2 (UI)**: Robot ikonu, yön oku ve ultrasonik sensör konileri en üste çizilir.

2.  **Veri Akış Optimizasyonu**:
    *   Lidar verisi yüksek frekansta (10Hz) nokta bulutu olarak gelir.
    *   Harita verisi düşük frekansta (1-2Hz) sıkıştırılmış görüntü olarak gelir.
    *   Bu hibrit yapı, ağ trafiğini şişirmeden akıcı bir görselleştirme sağlar.

### Veri Akış Desenleri
1.  **Algı Hattı (Perception Pipeline)**:
    `SerialNode` (Ham Bayt) -> `ProtocolNode` (JSON) -> `LidarNode` (XY Points) -> `SlamNode` (Map Image) -> `WebSocket` -> `SpatialApp`.
2.  **Kontrol Hattı (Control Pipeline)**:
    `UI` (Joystick) -> `WebSocket` -> `ControlNode` (Kinematik Hesap) -> `SerialNode` (Paketleme) -> `Donanım`.
