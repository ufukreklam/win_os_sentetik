
import logging
import time
from ..core.robot_system import RobotNode

logger = logging.getLogger("PowerNode")

class PowerNode(RobotNode):
    """
    Güç Yönetim Düğümü
    - Batarya voltajını izler ve yüzdeye çevirir.
    - Anlık güç tüketimini hesaplar.
    - Kritik seviyelerde uyarı üretir.
    """
    def __init__(self, bus):
        super().__init__("PowerNode", bus)
        self.loop_interval = 1.0 # 1Hz (Güç verisi çok sık değişmez)
        
        # Batarya Konfigürasyonu (3S Li-ion)
        self.max_voltage = 12.6
        self.min_voltage = 9.0
        self.capacity_ah = 2.5 # 2500mAh
        
        # Durum Değişkenleri
        self.voltage = 0.0
        self.current = 0.0
        self.percentage = 0
        self.power_usage = 0.0
        self.avg_power_window = []
        
        # Uyarı durumu
        self.low_battery_alert_sent = False

    async def setup(self):
        self.bus.subscribe("hardware_update", self.handle_hardware)

    async def handle_hardware(self, data):
        """Donanımdan gelen ham voltaj/akım verisini al"""
        if "batteryVoltage" in data:
            self.voltage = float(data["batteryVoltage"])
        
        if "currentDraw" in data:
            self.current = float(data["currentDraw"])

        # Analizi hemen yap
        await self.analyze_power()

    def calculate_percentage(self, voltage):
        """3S Li-ion için yaklaşık yüzde hesabı"""
        if voltage >= 12.6: return 100
        if voltage <= 9.0: return 0
        
        # Basit lineer olmayan haritalama (Map)
        # (Voltaj, Yüzde)
        points = [
            (12.6, 100), (12.3, 90), (12.0, 80), (11.7, 70),
            (11.4, 60), (11.1, 50), (10.8, 40), (10.5, 30),
            (10.2, 20), (9.6, 10), (9.0, 0)
        ]
        
        for i in range(len(points) - 1):
            v_high, p_high = points[i]
            v_low, p_low = points[i+1]
            
            if voltage <= v_high and voltage > v_low:
                # Aralığı bulduk, interpolasyon yap
                ratio = (voltage - v_low) / (v_high - v_low)
                return int(p_low + ratio * (p_high - p_low))
                
        return 0

    async def analyze_power(self):
        # 1. Yüzde Hesabı
        self.percentage = self.calculate_percentage(self.voltage)
        
        # 2. Güç Hesabı (Watt)
        self.power_usage = self.voltage * self.current
        
        # Ortalama Güç (Son 10 örnek)
        self.avg_power_window.append(self.power_usage)
        if len(self.avg_power_window) > 10:
            self.avg_power_window.pop(0)
        avg_power = sum(self.avg_power_window) / len(self.avg_power_window) if self.avg_power_window else 0

        # 3. Kalan Süre Tahmini (Saat) = (Kapasite (Ah) / Akım (A)) * (Kalan Yüzde)
        # Basitleştirilmiş:
        time_remaining_sec = 0
        if self.current > 0.1:
            time_remaining_sec = int(((self.capacity_ah * (self.percentage / 100)) / self.current) * 3600)

        # 4. Veri Paketi Hazırla
        power_info = {
            "battery": {
                "voltage": round(self.voltage, 2),
                "percentage": self.percentage,
                "status": "critical" if self.percentage < 20 else "nominal"
            },
            "consumption": {
                "current": round(self.current, 2),
                "power": round(self.power_usage, 2),
                "avg_power": round(avg_power, 2)
            },
            "estimation": {
                "time_remaining_seconds": time_remaining_sec
            }
        }
        
        # 5. Telemetri Node'una gönderilmek üzere yayınla
        # (TelemetryNode bunu alıp ana pakete ekleyecek)
        await self.bus.publish("power_analysis", power_info)

        # 6. Kritik Uyarılar
        if self.percentage < 20 and not self.low_battery_alert_sent:
            logger.warning(f"DÜŞÜK BATARYA: %{self.percentage}")
            await self.bus.publish("system_alert", {
                "level": "warning",
                "message": "Batarya seviyesi kritik (%20)",
                "source": "PowerNode"
            })
            self.low_battery_alert_sent = True
        elif self.percentage > 25:
            self.low_battery_alert_sent = False

    async def loop(self):
        # Olay tabanlı çalıştığı için loop boş kalabilir veya 
        # periyodik loglama yapılabilir.
        pass
