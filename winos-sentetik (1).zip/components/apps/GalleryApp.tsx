import React, { useState, useEffect } from 'react';
import { 
  Image as ImageIcon, Heart, Clock, MapPin, Info, 
  ChevronLeft, Grid, Maximize2, Share2, Trash2, Sliders, HardDrive, Menu, X
} from 'lucide-react';

// Mock Photo Data
const PHOTOS = [
  {
    id: 1,
    url: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?q=80&w=1000&auto=format&fit=crop',
    title: 'Mountain Expedition',
    date: 'Oct 24, 2023',
    size: '4.2 MB',
    dimensions: '4000 x 3000',
    location: 'Swiss Alps'
  },
  {
    id: 2,
    url: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?q=80&w=1000&auto=format&fit=crop',
    title: 'Alpine Lake',
    date: 'Sep 15, 2023',
    size: '3.8 MB',
    dimensions: '3800 x 2500',
    location: 'Banff, Canada'
  },
  {
    id: 3,
    url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=1000&auto=format&fit=crop',
    title: 'Neon City',
    date: 'Aug 02, 2023',
    size: '5.1 MB',
    dimensions: '4200 x 2800',
    location: 'Tokyo, Japan'
  },
  {
    id: 4,
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?q=80&w=1000&auto=format&fit=crop',
    title: 'Misty Forest',
    date: 'Jul 10, 2023',
    size: '2.9 MB',
    dimensions: '3000 x 2000',
    location: 'Oregon, USA'
  },
  {
    id: 5,
    url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1000&auto=format&fit=crop',
    title: 'Sunlight Path',
    date: 'Jun 20, 2023',
    size: '4.5 MB',
    dimensions: '3600 x 2400',
    location: 'Black Forest, Germany'
  },
  {
    id: 6,
    url: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=1000&auto=format&fit=crop',
    title: 'Coastal Rocks',
    date: 'May 05, 2023',
    size: '6.0 MB',
    dimensions: '5000 x 3300',
    location: 'Big Sur, CA'
  },
  {
    id: 7,
    url: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=80&w=1000&auto=format&fit=crop',
    title: 'Blue Lagoon',
    date: 'Apr 12, 2023',
    size: '3.2 MB',
    dimensions: '3200 x 2100',
    location: 'Iceland'
  },
  {
    id: 8,
    url: 'https://images.unsplash.com/photo-1519681393798-3828fb4090bb?q=80&w=1000&auto=format&fit=crop',
    title: 'Night Sky',
    date: 'Mar 28, 2023',
    size: '8.1 MB',
    dimensions: '6000 x 4000',
    location: 'Atacama Desert'
  }
];

const GalleryApp: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<typeof PHOTOS[0] | null>(null);
  const [activeTab, setActiveTab] = useState('all');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const sidebarItems = [
    { id: 'all', label: 'All Photos', icon: ImageIcon },
    { id: 'favorites', label: 'Favorites', icon: Heart },
    { id: 'recent', label: 'Recent', icon: Clock },
    { id: 'albums', label: 'Albums', icon: Grid },
  ];

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 relative overflow-hidden">
      {/* Sidebar - Desktop & Mobile Overlay */}
      <div className={`
        w-48 bg-slate-900/90 backdrop-blur-xl border-r border-white/5 flex flex-col pt-4
        transition-transform duration-300 z-50
        ${isMobile ? 'absolute h-full' : 'relative'}
        ${isMobile && !isSidebarOpen ? '-translate-x-full' : 'translate-x-0'}
      `}>
        <div className="flex items-center justify-between px-4 mb-4">
            <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Library</h2>
            {isMobile && (
              <button onClick={() => setIsSidebarOpen(false)} className="p-1 hover:bg-white/10 rounded">
                <X size={16} />
              </button>
            )}
        </div>
        <div className="space-y-1 px-2">
            {sidebarItems.map(item => (
                <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      if (isMobile) setIsSidebarOpen(false);
                    }}
                    className={`
                        w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors
                        ${activeTab === item.id ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-white/10'}
                    `}
                >
                    <item.icon size={16} />
                    <span>{item.label}</span>
                </button>
            ))}
        </div>
        
        <div className="px-4 mt-6 mb-2">
            <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider">On This Device</h2>
        </div>
        <div className="px-2">
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-slate-300 hover:bg-white/10">
                <span className="w-4 h-4 bg-purple-500 rounded text-[10px] flex items-center justify-center font-bold">S</span>
                <span>Screenshots</span>
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-slate-300 hover:bg-white/10">
                <span className="w-4 h-4 bg-green-500 rounded text-[10px] flex items-center justify-center font-bold">D</span>
                <span>Downloads</span>
            </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {selectedPhoto ? (
          // Single Photo View
          <div className="absolute inset-0 z-10 bg-slate-950 flex flex-col animate-in fade-in zoom-in-95 duration-200">
            {/* Toolbar */}
            <div className="h-12 border-b border-white/10 flex items-center justify-between px-4 bg-slate-900/50 shrink-0">
                <button 
                    onClick={() => setSelectedPhoto(null)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-white/10 text-xs sm:text-sm font-medium"
                >
                    <ChevronLeft size={16} />
                    <span className="hidden sm:inline">Back to Library</span>
                    <span className="sm:hidden">Back</span>
                </button>
                <div className="flex items-center gap-1">
                    <button className="p-2 hover:bg-white/10 rounded-full" title="Add to Favorites"><Heart size={16} /></button>
                    <button className="p-2 hover:bg-white/10 rounded-full hidden sm:block" title="Edit"><Sliders size={16} /></button>
                    <button className="p-2 hover:bg-white/10 rounded-full" title="Share"><Share2 size={16} /></button>
                    <button className="p-2 hover:bg-white/10 rounded-full text-red-400" title="Delete"><Trash2 size={16} /></button>
                </div>
            </div>

            {/* Image Container */}
            <div className="flex-1 flex items-center justify-center p-4 overflow-hidden relative group">
                <img 
                    src={selectedPhoto.url} 
                    alt={selectedPhoto.title} 
                    className="max-w-full max-h-full object-contain shadow-2xl rounded-sm"
                />
                
                {/* Overlay Info on Hover */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-4 py-2 bg-black/60 backdrop-blur-md rounded-full text-xs sm:text-sm text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 border border-white/10 text-center truncate max-w-[90%]">
                    {selectedPhoto.title}
                </div>
            </div>

            {/* Info Sidebar (Optional, represented as bottom bar here for simplicity) */}
            <div className="h-10 bg-slate-900 border-t border-white/10 flex items-center justify-center gap-3 sm:gap-6 text-[10px] sm:text-xs text-slate-400 shrink-0 px-2 overflow-x-auto whitespace-nowrap">
                <span className="flex items-center gap-1"><Info size={12} /> {selectedPhoto.dimensions}</span>
                <span className="flex items-center gap-1 hidden sm:flex"><HardDrive size={12} /> {selectedPhoto.size}</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {selectedPhoto.date}</span>
                <span className="flex items-center gap-1 hidden sm:flex"><MapPin size={12} /> {selectedPhoto.location}</span>
            </div>
          </div>
        ) : (
          // Grid View
          <div className="flex-1 overflow-y-auto p-4 sm:p-6">
             <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  {isMobile && (
                    <button 
                      onClick={() => setIsSidebarOpen(true)}
                      className="p-2 hover:bg-white/10 rounded-lg text-slate-400"
                    >
                      <Menu size={20} />
                    </button>
                  )}
                  <h1 className="text-xl sm:text-2xl font-semibold">
                      {sidebarItems.find(i => i.id === activeTab)?.label || 'Photos'}
                  </h1>
                </div>
                <div className="text-xs text-slate-400">{PHOTOS.length} items</div>
             </div>

             <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {PHOTOS.map(photo => (
                    <div 
                        key={photo.id}
                        onClick={() => setSelectedPhoto(photo)}
                        className="group relative aspect-square bg-slate-800 rounded-lg overflow-hidden border border-white/5 cursor-pointer hover:border-blue-500/50 transition-colors"
                    >
                        <img 
                            src={photo.url} 
                            alt={photo.title}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                            loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <div className="absolute bottom-2 left-2 right-2">
                                <p className="text-[10px] sm:text-xs font-medium text-white truncate">{photo.title}</p>
                                <p className="text-[8px] sm:text-[10px] text-slate-300">{photo.date}</p>
                            </div>
                            <div className="absolute top-2 right-2">
                                <button className="p-1.5 bg-black/40 backdrop-blur-sm rounded-full hover:bg-white/20">
                                    <Maximize2 size={12} className="text-white" />
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
             </div>
          </div>
        )}
      </div>

      {/* Mobile Backdrop */}
      {isMobile && isSidebarOpen && (
        <div 
          className="absolute inset-0 bg-black/40 backdrop-blur-sm z-40 animate-in fade-in"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default GalleryApp;