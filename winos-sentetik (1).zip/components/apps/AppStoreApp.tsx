
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { AppID, AppMetadata, AppCategory } from '../../types';
import { APP_CONFIGS } from '../../constants';
import { AVAILABLE_PLUGINS } from '../../services/pluginService';
import { 
  ShoppingBag, Search, Download, Check, 
  Trash2, Star, Grid, List, Layers, 
  Code2, Music, Wrench, Cpu, MessageSquare,
  Puzzle, Brain, CheckCircle
} from 'lucide-react';

const AppStoreApp: React.FC = () => {
  const { installedApps, installApp, uninstallApp, openApp, addNotification, pluginState, installPlugin, uninstallPlugin } = useOS();
  const [activeTab, setActiveTab] = useState<'apps' | 'plugins'>('apps');
  const [activeCategory, setActiveCategory] = useState<AppCategory | 'all' | 'featured'>('featured');
  const [searchQuery, setSearchQuery] = useState('');
  const [installing, setInstalling] = useState<string | null>(null);

  // Filter apps
  const allApps = Object.values(APP_CONFIGS).filter(app => app.id !== AppID.APP_STORE);
  const filteredApps = allApps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          app.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || activeCategory === 'featured' || app.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  // Filter plugins
  const filteredPlugins = AVAILABLE_PLUGINS.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSearch;
  });

  const handleInstallApp = (appId: AppID) => {
    setInstalling(appId);
    setTimeout(() => {
      installApp(appId);
      setInstalling(null);
    }, 2000);
  };

  const handleInstallPlugin = (pluginId: string) => {
      const plugin = AVAILABLE_PLUGINS.find(p => p.id === pluginId);
      if (!plugin) return;
      
      setInstalling(pluginId);
      setTimeout(() => {
          installPlugin(plugin);
          setInstalling(null);
      }, 1500);
  };

  const handleUninstall = (appId: AppID) => {
    if (confirm('Are you sure you want to uninstall this app?')) {
        uninstallApp(appId);
    }
  };

  const isAppInstalled = (appId: AppID) => installedApps.some(a => a.id === appId);
  const isPluginInstalled = (id: string) => pluginState.some(p => p.id === id);

  const CategoryButton: React.FC<{ id: string, label: string, icon: React.ElementType }> = ({ id, label, icon: Icon }) => (
    <button
      onClick={() => { setActiveTab('apps'); setActiveCategory(id as any); }}
      className={`
        w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-sm font-medium
        ${activeTab === 'apps' && activeCategory === id 
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
          : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}
      `}
    >
      <Icon size={18} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 font-sans">
      {/* Sidebar */}
      <div className="w-60 bg-slate-900/95 border-r border-white/5 flex flex-col p-4 gap-1 shrink-0">
        <div className="flex items-center gap-2 px-2 mb-6">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <ShoppingBag size={18} className="text-white" />
          </div>
          <span className="font-bold text-lg">App Store</span>
        </div>

        <div className="mb-4">
            <div className="px-4 text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Marketplace</div>
            <div className="space-y-1">
                <button
                    onClick={() => { setActiveTab('apps'); setActiveCategory('featured'); }}
                    className={`
                        w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-sm font-medium
                        ${activeTab === 'apps' 
                        ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30' 
                        : 'text-slate-400 hover:bg-white/5'}
                    `}
                >
                    <Grid size={18} />
                    <span>Applications</span>
                </button>
                <button
                    onClick={() => setActiveTab('plugins')}
                    className={`
                        w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-sm font-medium
                        ${activeTab === 'plugins' 
                        ? 'bg-purple-600/10 text-purple-400 border border-purple-500/30' 
                        : 'text-slate-400 hover:bg-white/5'}
                    `}
                >
                    <Puzzle size={18} />
                    <span>Skills & Plugins</span>
                </button>
            </div>
        </div>

        {activeTab === 'apps' && (
            <>
                <div className="mt-2 mb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Categories</div>
                <div className="space-y-1">
                    <CategoryButton id="featured" label="Discover" icon={Star} />
                    <CategoryButton id="productivity" label="Productivity" icon={MessageSquare} />
                    <CategoryButton id="utilities" label="Utilities" icon={Wrench} />
                    <CategoryButton id="development" label="Developer" icon={Code2} />
                    <CategoryButton id="media" label="Media & Photo" icon={Music} />
                    <CategoryButton id="system" label="System" icon={Cpu} />
                </div>
            </>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-gradient-to-br from-slate-900 to-slate-950">
        {/* Search Header */}
        <div className="h-16 border-b border-white/5 flex items-center px-8 shrink-0 sticky top-0 z-10 bg-slate-900/80 backdrop-blur-xl">
          <div className="relative w-full max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder={activeTab === 'apps' ? "Search apps..." : "Search skills and drivers..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 pl-10 pr-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 transition-all"
            />
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-8">
          
          {/* Featured Hero (Only on Featured tab) */}
          {activeTab === 'apps' && activeCategory === 'featured' && !searchQuery && (
            <div className="mb-10 relative group rounded-2xl overflow-hidden aspect-[21/9] border border-white/10 shadow-2xl">
                <img 
                    src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1974&auto=format&fit=crop" 
                    alt="Featured" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex flex-col justify-end p-8">
                    <div className="flex items-end justify-between">
                        <div>
                            <span className="inline-block px-3 py-1 bg-blue-600 rounded-full text-[10px] font-bold uppercase tracking-wider mb-3">Editor's Choice</span>
                            <h2 className="text-3xl font-bold mb-2">Gemini AI Assistant</h2>
                            <p className="text-slate-300 max-w-lg mb-4 text-sm">Experience the power of Google's Gemini models directly integrated into your workflow. Create, code, and calculate faster.</p>
                        </div>
                        <button 
                            onClick={() => openApp(AppID.CHAT)}
                            className="bg-white text-slate-900 px-6 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors flex items-center gap-2"
                        >
                            Open App
                        </button>
                    </div>
                </div>
            </div>
          )}

          {/* Plugin Hero */}
          {activeTab === 'plugins' && !searchQuery && (
              <div className="mb-10 bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-white/10 rounded-2xl p-8 flex items-center gap-8">
                  <div className="flex-1">
                      <h2 className="text-2xl font-bold mb-2 text-white">Expand Capability (Layer 16)</h2>
                      <p className="text-sm text-slate-300 mb-4">
                          Download new cognitive skills, hardware drivers, and system themes. Plugins are dynamically loaded into the OS kernel.
                      </p>
                  </div>
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center">
                      <Puzzle size={32} className="text-purple-400" />
                  </div>
              </div>
          )}

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {activeTab === 'apps' ? (
                filteredApps.map(app => {
                    const installed = isAppInstalled(app.id);
                    const isDownloading = installing === app.id;

                    return (
                        <div key={app.id} className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-all hover:-translate-y-1 hover:shadow-xl group flex flex-col">
                        <div className="flex items-start justify-between mb-4">
                            <div className="w-16 h-16 bg-slate-800 rounded-xl flex items-center justify-center text-blue-400 shadow-lg group-hover:scale-105 transition-transform">
                            <app.icon size={32} />
                            </div>
                            {installed ? (
                                <div className="px-2 py-1 bg-green-500/10 text-green-400 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                                    <Check size={10} /> Installed
                                </div>
                            ) : (
                                <div className="px-2 py-1 bg-blue-500/10 text-blue-400 rounded text-[10px] font-bold uppercase tracking-wider">
                                    Free
                                </div>
                            )}
                        </div>
                        
                        <h3 className="font-bold text-lg mb-1">{app.name}</h3>
                        <p className="text-xs text-slate-400 mb-4 line-clamp-2 min-h-[2.5em]">{app.description}</p>
                        
                        <div className="mt-auto pt-4 border-t border-white/5 flex gap-2">
                            {installed ? (
                                <>
                                    <button 
                                        onClick={() => openApp(app.id)}
                                        className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-xs font-bold transition-colors"
                                    >
                                        Open
                                    </button>
                                    {!app.isSystem && (
                                        <button 
                                            onClick={() => handleUninstall(app.id)}
                                            className="px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors"
                                            title="Uninstall"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    )}
                                </>
                            ) : (
                                <button 
                                    onClick={() => handleInstallApp(app.id)}
                                    disabled={isDownloading}
                                    className={`
                                        flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2
                                        ${isDownloading 
                                            ? 'bg-blue-600/50 cursor-wait' 
                                            : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20'}
                                    `}
                                >
                                    {isDownloading ? 'Downloading...' : <><Download size={14} /> Get</>}
                                </button>
                            )}
                        </div>
                        </div>
                    );
                })
            ) : (
                filteredPlugins.map(plugin => {
                    const installed = isPluginInstalled(plugin.id);
                    const isDownloading = installing === plugin.id;

                    return (
                        <div key={plugin.id} className="bg-white/5 border border-white/5 rounded-xl p-4 hover:bg-white/10 transition-all hover:-translate-y-1 hover:shadow-xl group flex flex-col">
                            <div className="flex items-start justify-between mb-4">
                                <div className={`w-16 h-16 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform ${plugin.type === 'skill' ? 'bg-purple-900/20 text-purple-400' : 'bg-green-900/20 text-green-400'}`}>
                                    {plugin.type === 'skill' ? <Brain size={32} /> : <Cpu size={32} />}
                                </div>
                                <span className="text-[10px] uppercase font-bold text-slate-500 bg-black/20 px-2 py-1 rounded">
                                    {plugin.type}
                                </span>
                            </div>
                            
                            <h3 className="font-bold text-lg mb-1">{plugin.name}</h3>
                            <div className="text-[10px] text-slate-500 mb-2">v{plugin.version} • {plugin.author}</div>
                            <p className="text-xs text-slate-400 mb-4 line-clamp-3 min-h-[3.6em]">{plugin.description}</p>
                            
                            <div className="mt-auto pt-4 border-t border-white/5">
                                {installed ? (
                                    <div className="w-full bg-green-500/10 text-green-400 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2">
                                        <CheckCircle size={14} /> Installed
                                    </div>
                                ) : (
                                    <button 
                                        onClick={() => handleInstallPlugin(plugin.id)}
                                        disabled={isDownloading}
                                        className={`
                                            w-full py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2
                                            ${isDownloading 
                                                ? 'bg-purple-600/50 cursor-wait' 
                                                : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20'}
                                        `}
                                    >
                                        {isDownloading ? 'Installing...' : <><Download size={14} /> Get ({plugin.downloadSize})</>}
                                    </button>
                                )}
                            </div>
                        </div>
                    );
                })
            )}
          </div>
          
          {((activeTab === 'apps' && filteredApps.length === 0) || (activeTab === 'plugins' && filteredPlugins.length === 0)) && (
              <div className="flex flex-col items-center justify-center py-20 text-slate-500">
                  <Search size={48} className="mb-4 opacity-20" />
                  <p>No results found matching "{searchQuery}"</p>
              </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AppStoreApp;
