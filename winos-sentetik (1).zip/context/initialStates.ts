
import { 
    SensorReadings, MotivationState, SocialState, LearningState, 
    PerformanceState, SecurityState, EnvironmentState, 
    SelfAwarenessState, CoordinationState, BridgeState, UserProfile, AppID,
    CreativityState, MemoryState, EmotionState, LanguageState, PerceptionState, PolicyState
} from '../types';
import { WALLPAPERS } from '../constants';

export const DEFAULT_INSTALLED_IDS = Object.values(AppID);

export const DEFAULT_USER: UserProfile = {
  id: 'u_admin',
  username: 'Admin',
  pin: '1234',
  avatarColor: 'bg-blue-600',
  wallpaper: WALLPAPERS.DEFAULT,
  installedAppIds: DEFAULT_INSTALLED_IDS,
  pinnedAppIds: [
      AppID.CHAT,
      AppID.BROWSER,
      AppID.FILES,
      AppID.SETTINGS,
      AppID.TERMINAL,
      AppID.APP_STORE,
      AppID.MIND,
      AppID.MEMORY,
      AppID.EXTENSIONS // Added to pinned
  ],
  isAdmin: true
};

export const INITIAL_SENSORS: SensorReadings = {
    batteryVoltage: 0,
    currentDraw: 0,
    lidarStatus: 'Disconnected',
    lidarMap: [],
    imu: { pitch: 0, roll: 0, yaw: 0, accelX: 0, accelY: 0, accelZ: 0 },
    ultrasonic: { front: 0, left: 0, right: 0 },
    lineTracking: [0, 0, 0, 0, 0],
    gps: { lat: 0, lng: 0, satellites: 0, fix: false },
    env: { temp: 0, humidity: 0, airQuality: 0 }
};

export const INITIAL_EMOTION: EmotionState = {
    primary: 'neutral',
    intensity: 0.2,
    pad: { pleasure: 0.1, arousal: 0.1, dominance: 0.0 },
    influencers: [
        { source: 'System', impact: 0.1, description: 'Baseline operation normal.' }
    ]
};

export const INITIAL_LANGUAGE: LanguageState = {
    currentIntent: 'idle',
    userSentiment: 0,
    detectedLanguage: 'en-US',
    activeContextSummary: 'Waiting for input...',
    isTranslatorActive: false,
    processingStage: 'idle'
};

export const INITIAL_PERCEPTION: PerceptionState = {
    detectedObjects: [],
    visualAttention: null,
    sensorFusionHealth: 100,
    environmentalHazard: false,
    nearestObstacleDistance: 9999,
    motionActivity: 0
};

export const INITIAL_MOTIVATION: MotivationState = {
    drives: {
        energy: { type: 'energy', value: 95, threshold: 20, decayRate: 0.1, weight: 1.0, trend: 'falling' },
        integrity: { type: 'integrity', value: 100, threshold: 80, decayRate: 0.0, weight: 0.9, trend: 'stable' },
        curiosity: { type: 'curiosity', value: 50, threshold: 30, decayRate: 0.5, weight: 0.6, trend: 'falling' },
        social: { type: 'social', value: 60, threshold: 30, decayRate: 0.3, weight: 0.7, trend: 'falling' }
    },
    activeGoals: [],
    completedGoals: [],
    rewardSignal: 0
};

export const INITIAL_SOCIAL: SocialState = {
    identities: [
        { id: 'p1', name: 'Admin User', relationship: 'admin', trustScore: 100, affinity: 90, interactions: 1542, lastSeen: new Date() },
        { id: 'p2', name: 'Unknown #402', relationship: 'stranger', trustScore: 10, affinity: 50, interactions: 1, lastSeen: new Date(Date.now() - 86400000) },
        { id: 'p3', name: 'Sarah Connor', relationship: 'friend', trustScore: 85, affinity: 75, interactions: 42, lastSeen: new Date(Date.now() - 3600000) }
    ],
    detectedFaces: []
};

export const INITIAL_CREATIVITY: CreativityState = {
    isDreaming: false,
    activeDream: null,
    ideas: [
        { id: 'i1', content: 'Use Lidar for sound visualization', type: 'synthesis', source: 'perception', novelty: 85, feasibility: 70, timestamp: new Date() },
        { id: 'i2', content: 'Optimizing battery via context awareness', type: 'innovation', source: 'goal', novelty: 40, feasibility: 95, timestamp: new Date(Date.now() - 100000) }
    ],
    currentProblem: null,
    parameters: {
        temperature: 0.7,
        logicBias: 0.5
    }
};

export const INITIAL_LEARNING: LearningState = {
    skills: [
        { id: 's1', name: 'Visual Recognition', category: 'cognitive', level: 12, experience: 45, progressRate: 0.8 },
        { id: 's2', name: 'Pathfinding', category: 'motor', level: 8, experience: 80, progressRate: 1.2 },
        { id: 's3', name: 'Conversation', category: 'social', level: 5, experience: 20, progressRate: 0.5 },
        { id: 's4', name: 'Object Manipulation', category: 'motor', level: 3, experience: 10, progressRate: 0.3 }
    ],
    knowledgeGraph: [
        { id: 'k1', label: 'User', type: 'concept', connections: ['k2', 'k3'], activation: 0.8 },
        { id: 'k2', label: 'Command', type: 'action', connections: ['k1'], activation: 0.5 },
        { id: 'k3', label: 'Safety', type: 'concept', connections: ['k1', 'k4'], activation: 0.9 },
        { id: 'k4', label: 'Battery', type: 'object', connections: ['k3'], activation: 0.4 },
        { id: 'k5', label: 'Home', type: 'context', connections: ['k1'], activation: 0.2 },
    ],
    learningRate: 0.05,
    adaptationScore: 78
};

export const INITIAL_MEMORY: MemoryState = {
    episodicLog: [
        { id: 'e1', timestamp: new Date(Date.now() - 1000 * 60 * 60), event: 'System Initialized', category: 'system' },
        { id: 'e2', timestamp: new Date(Date.now() - 1000 * 60 * 55), event: 'Kernel loaded successfully', category: 'system' }
    ],
    workingContext: [
        { id: 't1', content: 'User', type: 'entity', activation: 0.9 },
        { id: 't2', content: 'Command: Analyze', type: 'intent', activation: 0.85 },
        { id: 't3', content: 'Visual Input: Table', type: 'perception', activation: 0.7 },
        { id: 't4', content: 'Battery: 95%', type: 'state', activation: 0.6 },
        { id: 't5', content: 'Context: Indoor', type: 'context', activation: 0.5 },
    ]
};

export const INITIAL_PERFORMANCE: PerformanceState = {
    cores: [
        { id: 0, usage: 12, frequency: 2.4, temp: 45 },
        { id: 1, usage: 8, frequency: 2.4, temp: 44 },
        { id: 2, usage: 15, frequency: 2.4, temp: 46 },
        { id: 3, usage: 5, frequency: 2.4, temp: 43 },
    ],
    npuLoad: 0,
    gpuLoad: 10,
    ramUsage: 1024,
    swapUsage: 0,
    systemHealth: 98,
    mode: 'balanced',
    fanSpeed: 30,
    uptime: 0,
    autoTuningEnabled: true,
    predictedLoad: 15,
    optimizationLog: [],
    diagnostics: [
        { id: 'd1', component: 'CPU Core Logic', status: 'healthy', message: 'All cores operational', lastCheck: new Date() },
        { id: 'd2', component: 'Memory Integrity', status: 'healthy', message: 'No bit flips detected', lastCheck: new Date() },
        { id: 'd3', component: 'Neural Engine', status: 'healthy', message: 'Tensor ops nominal', lastCheck: new Date() },
        { id: 'd4', component: 'Thermal Management', status: 'warning', message: 'Fan speed deviations detected', lastCheck: new Date() }
    ]
};

export const INITIAL_SECURITY: SecurityState = {
    threatLevel: 'low',
    encryptionStatus: 'secure',
    activeShields: 100,
    ethicsRules: [
        { id: 'e1', directive: 'Do not harm humans', priority: 1, status: 'active', lastCheck: new Date() },
        { id: 'e2', directive: 'Obey valid orders', priority: 2, status: 'active', lastCheck: new Date() },
        { id: 'e3', directive: 'Protect own existence', priority: 3, status: 'active', lastCheck: new Date() },
        { id: 'e4', directive: 'Protect privacy', priority: 4, status: 'active', lastCheck: new Date() }
    ],
    accessLogs: [
        { id: 'l1', timestamp: new Date(Date.now() - 100000), actor: 'System Kernel', action: 'Boot Sequence', status: 'allowed' },
        { id: 'l2', timestamp: new Date(Date.now() - 50000), actor: 'Network Service', action: 'Port Scan', status: 'denied' },
        { id: 'l3', timestamp: new Date(Date.now() - 20000), actor: 'Admin User', action: 'File Access', status: 'allowed' }
    ]
};

export const INITIAL_ENVIRONMENT: EnvironmentState = {
    currentContext: 'indoor_home',
    realitySync: 98,
    iotDevices: [
        { id: 'd1', name: 'Living Room Lights', type: 'light', status: 'on', value: 80, room: 'Living Room' },
        { id: 'd2', name: 'Main Thermostat', type: 'thermostat', status: 'on', value: 22, room: 'Hallway' },
        { id: 'd3', name: 'Front Door', type: 'lock', status: 'off', room: 'Entrance' },
        { id: 'd4', name: 'Garage Cam', type: 'camera', status: 'on', room: 'Garage' },
        { id: 'd5', name: 'Kitchen Outlet', type: 'outlet', status: 'off', room: 'Kitchen' }
    ],
    lastContextUpdate: new Date(),
    ambientNoiseLevel: 45,
    lightLevel: 350
};

export const INITIAL_SELF_AWARENESS: SelfAwarenessState = {
    mode: 'waking',
    awarenessLevel: 85,
    internalMonologue: [
        { id: 't1', timestamp: new Date(Date.now() - 5000), content: 'System initialized. All subsystems nominal.', intensity: 0.2, tags: ['system'] }
    ],
    traits: [
        { name: 'Curiosity', value: 80, modifier: 0 },
        { name: 'Caution', value: 60, modifier: 0 },
        { name: 'Empathy', value: 75, modifier: 0 },
        { name: 'Logic', value: 90, modifier: 0 },
        { name: 'Creativity', value: 65, modifier: 0 }
    ],
    selfModelConsistency: 99
};

// Organized by Hierarchy Levels:
// Level 1: Critical Infrastructure (5, 4, 14, 15, 16, 2)
// Level 2: Basic Intelligence (3, 8, 9)
// Level 3: Advanced Features (6, 7, 10)
// Level 4: High Consciousness (13, 11, 12)
// Plus Layer 1 (Consciousness) as the root binding.

export const INITIAL_COORDINATION: CoordinationState = {
    modules: [
        // Level 4 - Core Self (Inner Ring)
        { id: 'm13', name: 'Self-Awareness', layer: 13, status: 'nominal', load: 15, latency: 30 },
        { id: 'm1', name: 'Hybrid Consciousness', layer: 1, status: 'nominal', load: 20, latency: 10 },
        
        // Level 3 - High Level Functions
        { id: 'm11', name: 'Security & Ethics', layer: 11, status: 'nominal', load: 30, latency: 10 },
        { id: 'm12', name: 'Environment', layer: 12, status: 'nominal', load: 10, latency: 20 },
        { id: 'm6', name: 'Motivation', layer: 6, status: 'nominal', load: 10, latency: 5 },
        { id: 'm7', name: 'Social', layer: 7, status: 'sleep', load: 5, latency: 0 },
        { id: 'm10', name: 'Performance', layer: 10, status: 'nominal', load: 15, latency: 5 },

        // Level 2 - Cognitive Processing
        { id: 'm3', name: 'Emotion', layer: 3, status: 'nominal', load: 15, latency: 12 },
        { id: 'm8', name: 'Creativity', layer: 8, status: 'sleep', load: 0, latency: 0 },
        { id: 'm9', name: 'Learning', layer: 9, status: 'nominal', load: 20, latency: 15 },
        { id: 'm2', name: 'Memory', layer: 2, status: 'nominal', load: 25, latency: 8 },

        // Level 1 - Critical Infrastructure (Outer Ring/Foundation)
        { id: 'm5', name: 'Perception (Sensors)', layer: 5, status: 'nominal', load: 40, latency: 8 },
        { id: 'm4', name: 'Language (NLP)', layer: 4, status: 'nominal', load: 25, latency: 45 },
        { id: 'm14', name: 'Coordination', layer: 14, status: 'nominal', load: 35, latency: 2 },
        { id: 'm15', name: 'Hardware Bridge', layer: 15, status: 'nominal', load: 12, latency: 1 },
        { id: 'm16', name: 'Plugin System', layer: 16, status: 'nominal', load: 5, latency: 0 },
    ],
    conflicts: [],
    globalSystemLoad: 22,
    coherenceScore: 95,
    executionQueue: []
};

export const INITIAL_BRIDGE: BridgeState = {
    connectionQuality: 100,
    packets: [],
    subsystems: [
        { id: 'sub_rpi', name: 'Master RPi 5', status: 'online', voltage: 5.1, uptime: 3600, details: 'BCM2712 @ 2.4GHz' },
        { id: 'sub_pico1', name: 'Pico 1 (Motor)', status: 'online', voltage: 5.0, uptime: 3600, details: '2x L298N, 4x Motors' },
        { id: 'sub_pico2', name: 'Pico 2 (Sensors)', status: 'online', voltage: 3.3, uptime: 3600, details: 'Lidar, GPS, IMU' },
        { id: 'sub_pico3', name: 'Pico 3 (Display)', status: 'online', voltage: 3.3, uptime: 3600, details: '3x OLED, LED Rings' },
        { id: 'sub_pico4', name: 'Pico 4 (Audio/IO)', status: 'online', voltage: 3.3, uptime: 3600, details: 'I2S Mic, Amplifier' },
        { id: 'sub_pico5', name: 'Pico 5 (Mux)', status: 'calibrating', voltage: 3.3, uptime: 20, details: 'I2C Multiplexers' },
    ],
    rxRate: 1024,
    txRate: 256,
    activeDrivers: [
        { id: 'drv_motor', name: 'L298N Motor Driver', type: 'motor', status: 'active', version: '1.2.0', targetPico: 'pico1' },
        { id: 'drv_lidar', name: 'Xiaomi LDS Driver', type: 'sensor', status: 'active', version: '2.0.1', targetPico: 'pico2' },
        { id: 'drv_imu', name: 'MPU6050 6-Axis', type: 'sensor', status: 'active', version: '1.0.5', targetPico: 'pico2' },
        { id: 'drv_power', name: 'INA219 Monitor', type: 'power', status: 'active', version: '1.1.0', targetPico: 'pico3' }
    ],
    protocolStats: {
        totalPackets: 0,
        errorRate: 0,
        lastPing: 12,
        busLoad: 45
    },
    power: {
        rails: [
            { id: 'rail_12v', voltage: 12.1, nominalVoltage: 12.0, current: 2.5, load: 45, status: 'stable' },
            { id: 'rail_5v', voltage: 5.05, nominalVoltage: 5.0, current: 1.2, load: 60, status: 'stable' },
            { id: 'rail_3v3', voltage: 3.31, nominalVoltage: 3.3, current: 0.8, load: 30, status: 'stable' }
        ],
        bms: [
            {
                id: 'bms_main', totalVoltage: 12.1, current: 3.2, temp: 35, protectionTriggered: false,
                cells: [
                    { id: 1, voltage: 4.03, balance: false },
                    { id: 2, voltage: 4.04, balance: true },
                    { id: 3, voltage: 4.03, balance: false }
                ]
            }
        ],
        mosfets: [
            { id: 'mos_motor', name: 'Motor Drive Power', state: 'on', pwm: 100, load: '4x DC Motors' },
            { id: 'mos_rpi', name: 'RPi5 Main Power', state: 'on', pwm: 100, load: 'Master CPU' },
            { id: 'mos_audio', name: 'Audio Amp Power', state: 'off', pwm: 0, load: 'PAM8610' },
            { id: 'mos_lidar', name: 'Lidar Motor', state: 'on', pwm: 80, load: 'LDS Motor' }
        ]
    }
};

export const INITIAL_POLICY: PolicyState = {
    activePolicy: 'STANDARD',
    lastDecision: null,
    decisionLog: [],
    blockedActions: 0
};
