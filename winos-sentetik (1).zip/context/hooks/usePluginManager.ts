
import { useState, useCallback, useEffect } from 'react';
import { PluginMetadata, PluginStatus } from '../../types';
import { WALLPAPER_PRESETS } from '../../constants';

// Initial pre-installed plugins
const CORE_DRIVERS: PluginStatus[] = [
    {
        id: 'pl_core_hal',
        isEnabled: true,
        lifecycle: 'active',
        loadTime: 120,
        memoryUsage: 15,
        securityCheck: 'passed',
        metadata: {
            id: 'pl_core_hal',
            name: 'Core HAL Bridge',
            version: '1.0.0',
            author: 'WinOS System',
            description: 'Hardware Abstraction Layer for RPi 5 and Pico slaves.',
            type: 'driver',
            permissions: ['hardware'],
            downloadSize: '0 MB'
        },
        resources: { cpu: 2.5, ram: 15 }
    }
];

export const usePluginManager = (
    onNotify: (n: any) => void,
    setWallpaper: (url: string) => void
) => {
    const [pluginState, setPluginState] = useState<PluginStatus[]>(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('winos_plugins');
            if (saved) return JSON.parse(saved);
        }
        return CORE_DRIVERS;
    });

    useEffect(() => {
        localStorage.setItem('winos_plugins', JSON.stringify(pluginState));
    }, [pluginState]);

    // Plugin Side Effect Monitor
    useEffect(() => {
        const cyberPlugin = pluginState.find(p => p.id === 'theme_cyber');
        if (cyberPlugin && cyberPlugin.isEnabled && cyberPlugin.lifecycle === 'active') {
            // Apply Neon Theme if active
            const neonWallpaper = WALLPAPER_PRESETS.find(p => p.name.includes('Neon'))?.url;
            if (neonWallpaper) setWallpaper(neonWallpaper);
        }
    }, [pluginState, setWallpaper]);

    const installPlugin = useCallback((meta: PluginMetadata) => {
        // Check if already installed
        if (pluginState.some(p => p.id === meta.id)) {
            onNotify({ title: 'Already Installed', message: `${meta.name} is already in your library.`, type: 'info' });
            return;
        }

        const newPlugin: PluginStatus = {
            id: meta.id,
            isEnabled: true,
            lifecycle: 'unloaded', // Start unloaded
            loadTime: 0,
            memoryUsage: 0,
            securityCheck: 'pending',
            metadata: meta,
            resources: { cpu: 0, ram: 0 }
        };

        setPluginState(prev => [...prev, newPlugin]);
        // Trigger simulation loading sequence
        simulatePluginLoad(newPlugin.id);
        
        onNotify({ title: 'Plugin Added', message: `${meta.name} added to registry. Initializing...`, type: 'success' });
    }, [pluginState, onNotify]);

    const simulatePluginLoad = useCallback((id: string) => {
        // Step 1: Validating
        setPluginState(prev => prev.map(p => p.id === id ? { ...p, lifecycle: 'validating', securityCheck: 'pending' } : p));
        
        setTimeout(() => {
            // Step 2: Loading
            setPluginState(prev => prev.map(p => p.id === id ? { ...p, lifecycle: 'loading', securityCheck: 'passed' } : p));
            
            setTimeout(() => {
                // Step 3: Initializing
                setPluginState(prev => prev.map(p => p.id === id ? { 
                    ...p, 
                    lifecycle: 'initializing',
                    memoryUsage: Math.floor(Math.random() * 50) + 10 
                } : p));

                setTimeout(() => {
                    // Step 4: Active
                    setPluginState(prev => prev.map(p => p.id === id ? { 
                        ...p, 
                        lifecycle: 'active', 
                        isEnabled: true,
                        loadTime: Math.floor(Math.random() * 500) + 50,
                        resources: { cpu: Math.random() * 5, ram: Math.floor(Math.random() * 100) + 20 }
                    } : p));
                }, 1000);

            }, 1000);
        }, 1500);
    }, []);

    const uninstallPlugin = useCallback((id: string) => {
        setPluginState(prev => prev.filter(p => p.id !== id));
        onNotify({ title: 'Plugin Removed', message: 'Extension uninstalled and resources freed.', type: 'info' });
    }, [onNotify]);

    const togglePlugin = useCallback((id: string) => {
        setPluginState(prev => prev.map(p => {
            if (p.id === id) {
                const willEnable = !p.isEnabled;
                if (willEnable) {
                    // Start load sequence if re-enabling
                    setTimeout(() => simulatePluginLoad(id), 100);
                    return { ...p, isEnabled: true, lifecycle: 'validating' }; 
                } else {
                    // Immediate unload
                    return { ...p, isEnabled: false, lifecycle: 'unloaded', resources: { cpu: 0, ram: 0 } };
                }
            }
            return p;
        }));
    }, [simulatePluginLoad]);

    return {
        pluginState,
        installPlugin,
        uninstallPlugin,
        togglePlugin
    };
};
