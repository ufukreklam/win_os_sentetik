# WinOS Hybrid - Design System & Architecture

## 1. The "Hybrid" Concept
This project implements a unique UI paradigm that merging "Mobile" and "Desktop" metaphors:

| UI Element | Source Inspiration | Behavior |
|------------|-------------------|----------|
| **Top Bar** | **iOS** | Fixed, translucent, status information. |
| **Taskbar** | **Windows 11** | Centered dock. **Crucial:** Only shows active apps. |
| **Start Menu** | **Windows 11** | Centered, floating panel app launcher. |
| **Windows** | **Desktop OS** | Floating, resizable, draggable containers. |
| **Sidebars** | **Hybrid** | Persistent on Desktop, Hamburger-toggled on Mobile. |

## 2. Window Mechanics
The `Window` component is the core interactive shell:
- **Movement**: Draggable via the title bar.
- **Resizing**: Resizable via the bottom-right handle (desktop only).
- **Maximization**: Toggles full-screen mode. Automatically enabled on mobile.
- **Z-Index**: Focused windows are promoted to the top layer.

## 3. Mobile Navigation Pattern
To accommodate small screens within a desktop metaphor:
1. **Hamburger Menu**: Apps with sidebars (e.g., Settings, Files) must implement a `Menu` icon that toggles the sidebar as an overlay.
2. **Backdrops**: Mobile overlays should use a darkened backdrop to maintain focus.
3. **Auto-Maximize**: Windows occupy 100% of the viewport on mobile by default.

## 4. State Model (`types.ts`)
```typescript
interface WindowState {
  id: AppID;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  x: number;
  y: number;
  width: number;
  height: number;
}
```

## 5. Styling Guidelines (Tailwind)
- **Glass Background**: `bg-slate-900/80 backdrop-blur-xl border border-white/10`
- **Active Accents**: Use `blue-600` for system-level actions and `green-400` for terminal/dev text.