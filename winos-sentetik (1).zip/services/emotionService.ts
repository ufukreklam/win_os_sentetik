
import { CoreEmotion, EmotionState } from "../types";

// PAD (Pleasure, Arousal, Dominance) Uzayı Tanımları
// Her duygu 3 boyutlu bir vektör olarak tanımlanır (-1.0 ile 1.0 arası)
const EMOTION_MAP: Record<CoreEmotion, { p: number, a: number, d: number }> = {
    neutral:   { p: 0.0, a: 0.0, d: 0.0 },
    happy:     { p: 0.8, a: 0.6, d: 0.7 },   // Yüksek keyif, orta uyarılma
    sad:       { p: -0.8, a: -0.5, d: -0.6 }, // Düşük keyif, düşük uyarılma
    angry:     { p: -0.7, a: 0.8, d: 0.8 },   // Düşük keyif, yüksek uyarılma, yüksek baskınlık
    fear:      { p: -0.8, a: 0.9, d: -0.7 },  // Düşük keyif, yüksek uyarılma, düşük baskınlık
    surprised: { p: 0.5, a: 0.9, d: 0.1 },    // Yüksek uyarılma, nötr baskınlık
    curious:   { p: 0.4, a: 0.6, d: 0.3 }     // Pozitif keyif, orta uyarılma
};

// Basit anahtar kelime tabanlı duygu analizi (Local, hızlı tepki için)
const KEYWORD_SENTIMENT = {
    positive: ['harika', 'güzel', 'teşekkür', 'sevdim', 'iyi', 'süper', 'muhteşem', 'mutlu', 'başarılı', 'zeki', 'zekisin'],
    negative: ['kötü', 'berbat', 'hata', 'yanlış', 'aptal', 'nefret', 'üzgün', 'kızgın', 'başarısız', 'yavaş'],
    urgent: ['hemen', 'çabuk', 'acil', 'dikkat', 'dur', 'koş', 'tehlike', 'yardım'],
    question: ['nedir', 'nasıl', 'nerede', 'kim', 'niye', 'açıkla', 'göster']
};

export class EmotionService {
    private currentPAD = { p: 0.0, a: 0.0, d: 0.0 };
    private decayRate = 0.005; // Her güncellemede nötr duruma dönüş hızı (Yavaşlatıldı)

    /**
     * Metin ve ses verisine göre PAD değerlerini günceller.
     * @param text Kullanıcı girdisi
     * @param voiceEnergy Ses seviyesi (0-100)
     */
    processInput(text: string, voiceEnergy: number = 0): void {
        const lowerText = text.toLowerCase();
        
        // 1. Pleasure (Keyif) Analizi
        let sentimentDelta = 0;
        KEYWORD_SENTIMENT.positive.forEach(w => { if (lowerText.includes(w)) sentimentDelta += 0.3; });
        KEYWORD_SENTIMENT.negative.forEach(w => { if (lowerText.includes(w)) sentimentDelta -= 0.4; });
        
        // 2. Arousal (Uyarılma) Analizi
        let arousalDelta = 0;
        // Ses enerjisi etki eder (Bağırma vs.)
        if (voiceEnergy > 60) arousalDelta += 0.4;
        // Aciliyet kelimeleri
        KEYWORD_SENTIMENT.urgent.forEach(w => { if (lowerText.includes(w)) arousalDelta += 0.5; });
        // Soru sormak merak uyandırır
        KEYWORD_SENTIMENT.question.forEach(w => { if (lowerText.includes(w)) arousalDelta += 0.2; });

        // 3. Dominance (Baskınlık) Analizi
        let dominanceDelta = 0;
        // Kullanıcı çok negatifse robot biraz çekinikleşebilir (veya duruma göre değişir)
        if (sentimentDelta < -0.3) dominanceDelta -= 0.2;
        // Övgü alırsa özgüven artar
        if (sentimentDelta > 0.3) dominanceDelta += 0.2;

        // PAD Güncelleme (Sınırlandırma ile)
        this.currentPAD.p = Math.max(-1, Math.min(1, this.currentPAD.p + sentimentDelta));
        this.currentPAD.a = Math.max(-1, Math.min(1, this.currentPAD.a + arousalDelta));
        this.currentPAD.d = Math.max(-1, Math.min(1, this.currentPAD.d + dominanceDelta));
    }

    /**
     * Zamanla duyguları nötr duruma çeker (Emotional Decay).
     * @returns Güncel duygu durumu
     */
    decay(): EmotionState {
        // Sıfıra doğru yavaşça yaklaş
        this.currentPAD.p *= (1 - this.decayRate);
        this.currentPAD.a *= (1 - this.decayRate);
        this.currentPAD.d *= (1 - this.decayRate);

        return this.getCurrentState();
    }

    /**
     * Mevcut PAD değerlerine en yakın isimlendirilmiş duyguyu bulur.
     */
    getCurrentState(): EmotionState {
        let bestEmotion: CoreEmotion = 'neutral';
        let minDistance = Infinity;

        // En yakın duyguyu bul (Öklid mesafesi)
        (Object.keys(EMOTION_MAP) as CoreEmotion[]).forEach(emotion => {
            const target = EMOTION_MAP[emotion];
            const dist = Math.sqrt(
                Math.pow(this.currentPAD.p - target.p, 2) +
                Math.pow(this.currentPAD.a - target.a, 2) +
                Math.pow(this.currentPAD.d - target.d, 2)
            );
            
            if (dist < minDistance) {
                minDistance = dist;
                bestEmotion = emotion;
            }
        });

        // Eğer tüm değerler çok düşükse direkt neutral yap
        if (Math.abs(this.currentPAD.p) < 0.1 && Math.abs(this.currentPAD.a) < 0.1) {
            bestEmotion = 'neutral';
        }

        // Intensity (Yoğunluk) vektörün büyüklüğü
        const intensity = Math.min(1, Math.sqrt(
            this.currentPAD.p**2 + this.currentPAD.a**2 + this.currentPAD.d**2
        ) / 1.73); // 1.73 = sqrt(1^2 + 1^2 + 1^2) max distance

        return {
            primary: bestEmotion,
            intensity,
            pad: { 
                pleasure: this.currentPAD.p, 
                arousal: this.currentPAD.a, 
                dominance: this.currentPAD.d 
            },
            influencers: [] // Bu kısım dışarıdan eklenebilir
        };
    }
    
    // Doğrudan PAD müdahalesi (Örn: Pil bitince yorgun hisset)
    injectEmotion(p: number, a: number, d: number) {
        this.currentPAD.p = (this.currentPAD.p + p) / 2;
        this.currentPAD.a = (this.currentPAD.a + a) / 2;
        this.currentPAD.d = (this.currentPAD.d + d) / 2;
    }
}

export const emotionService = new EmotionService();
