
# Aktif Bağlam

## Mevcut Durum
Proje, **Aşama 4: Donanım ve Fiziksel Etkileşim**'de ilerlemektedir.
*   **Faz 34 (Servo Kafa Kontrolü)** tamamlandı. `HeadNode` ile robot artık görsel hedefleri (yüzleri) PID algoritmasıyla fiziksel olarak takip edebiliyor.

### Son Yapılan Değişiklikler
*   `HeadNode` eklendi: Pan/Tilt servo kontrolü ve takip mantığı.
*   `pico_main.py` güncellendi: Servo PWM desteği ve protokolü.
*   `phase34_head_spec.md` oluşturuldu.

## Aktif Odak
Sıradaki odak noktası **Faz 35: Ses Donanımı**. Robotun duyma (I2S Mikrofon) ve konuşma (I2S/PWM Hoparlör) yeteneklerini fiziksel donanıma entegre edeceğiz.

### Sırada Ne Var? (Faz 35 Uygulama)
1.  **AudioNode (Backend)**: Ses giriş/çıkışını yöneten düğüm.
2.  **Streaming**: RPi mikrofonundan alınan sesi WebSocket üzerinden frontend'e (VAD ve STT için) aktarmak.
3.  **Output**: Frontend TTS'den gelen sesi RPi hoparlörüne aktarmak.

## Sonraki Adımlar
1.  **Faz 35**: Ses Donanımı.
2.  **Faz 36**: Sensör Füzyonu.
