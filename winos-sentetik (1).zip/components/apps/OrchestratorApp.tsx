
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Workflow, Network, AlertTriangle, Activity, Play, CheckCircle, XCircle, Clock, Layers, Zap } from 'lucide-react';
import { ModuleStatus } from '../../types';

const OrchestratorApp: React.FC = () => {
  const { coordinationState } = useOS();
  const [activeTab, setActiveTab] = useState<'network' | 'logs' | 'workflow'>('network');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // OPTIMIZASYON: Koordinasyon durumunu ref içinde tutuyoruz.
  // Bu sayede animasyon döngüsü state değişimlerinde kesilmeden devam edebilir.
  const stateRef = useRef(coordinationState);

  useEffect(() => {
      stateRef.current = coordinationState;
  }, [coordinationState]);

  // Network Visualization Logic (Orbital Hierarchy)
  useEffect(() => {
    if (activeTab !== 'network' || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Responsive Resize
    const resize = () => {
        if (canvas.parentElement) {
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
        }
    };
    resize();
    window.addEventListener('resize', resize);

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    const getLevelInfo = (layer: number) => {
        if (layer === 13) return { level: 0, color: '#a855f7', name: 'CORE' }; // Self
        if ([14, 15, 16].includes(layer)) return { level: 3, color: '#ef4444', name: 'BRIDGE' }; // Bridge/Orch
        if ([6, 7, 10, 11, 12].includes(layer)) return { level: 1, color: '#f59e0b', name: 'HIGH' }; // Advanced
        return { level: 2, color: '#3b82f6', name: 'INFRA' }; // Basic/Infra
    };

    const radii = [0, 100, 180, 260]; // Orbit distances
    let frameId: number;
    let tick = 0;

    const draw = () => {
        // Clear with fade effect for trails
        ctx.fillStyle = 'rgba(10, 10, 10, 0.2)'; 
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        tick += 0.005;

        // Ref üzerinden güncel durumu al
        const currentCoordination = stateRef.current;

        // Prepare Nodes inside the loop to get latest state without re-render
        const nodes = currentCoordination.modules.map(mod => {
            const info = getLevelInfo(mod.layer);
            return { ...mod, ...info };
        });

        // Draw Orbits
        radii.forEach((r, i) => {
            if (i === 0) return;
            ctx.beginPath();
            ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.05 + (i * 0.02)})`;
            ctx.lineWidth = 1;
            ctx.setLineDash([5, 15]); // Dashed orbits
            ctx.stroke();
            ctx.setLineDash([]);
        });

        // Calculate Positions
        const activeNodes = nodes.map((node, i) => {
            if (node.level === 0) return { ...node, x: centerX, y: centerY }; // Center Node

            // Distribute nodes evenly on their orbit
            const countInLevel = nodes.filter(n => n.level === node.level).length;
            const indexInLevel = nodes.filter(n => n.level === node.level && n.id <= node.id).length;
            
            // Orbit speed varies by level
            const angleOffset = tick * (node.level % 2 === 0 ? 1 : -1) * (1 / node.level); 
            const angle = (indexInLevel / countInLevel) * Math.PI * 2 + angleOffset;
            
            const r = radii[node.level];
            return {
                ...node,
                x: centerX + Math.cos(angle) * r,
                y: centerY + Math.sin(angle) * r
            };
        });

        // Draw Connections (Neural Links)
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.15)';
        ctx.lineWidth = 1;
        activeNodes.forEach(node => {
            if (node.level === 0) return;
            
            // Connect to center
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(centerX, centerY);
            ctx.stroke();

            // Connect to nearby nodes (simulating coherence)
            activeNodes.forEach(other => {
                if (node.id === other.id) return;
                const dist = Math.hypot(node.x - other.x, node.y - other.y);
                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(node.x, node.y);
                    ctx.lineTo(other.x, other.y);
                    ctx.strokeStyle = `rgba(59, 130, 246, ${1 - dist/120})`;
                    ctx.stroke();
                }
            });
        });

        // Draw Nodes
        activeNodes.forEach(node => {
            // Pulse size based on load
            const pulse = Math.sin(tick * 5 + node.id.length) * 2;
            const size = 6 + (node.load / 20) + pulse; 

            // Glow
            const gradient = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, size * 2);
            gradient.addColorStop(0, node.color);
            gradient.addColorStop(1, 'transparent');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(node.x, node.y, size * 2, 0, Math.PI * 2);
            ctx.fill();

            // Core
            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(node.x, node.y, size * 0.4, 0, Math.PI * 2);
            ctx.fill();

            // Label
            ctx.fillStyle = '#94a3b8';
            ctx.font = '10px Inter';
            ctx.textAlign = 'center';
            ctx.fillText(`L${node.layer}`, node.x, node.y - size - 5);
            
            ctx.fillStyle = '#cbd5e1';
            ctx.font = 'bold 11px Inter';
            ctx.fillText(node.name, node.x, node.y + size + 12);
            
            // Status Indicator
            if (node.status !== 'nominal') {
                ctx.fillStyle = node.status === 'error' ? '#ef4444' : '#f59e0b';
                ctx.font = '9px Inter';
                ctx.fillText(node.status.toUpperCase(), node.x, node.y + size + 22);
            }
        });

        frameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(frameId);
    };
  }, [activeTab]); // Sadece tab değişince effect çalışır

  const ModuleListRow: React.FC<{ module: ModuleStatus }> = ({ module }) => (
      <div className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-lg hover:bg-white/10 transition-colors group">
          <div className="flex items-center gap-4">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shadow-lg ${
                  module.status === 'nominal' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                  module.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                  module.status === 'sleep' ? 'bg-slate-500/20 text-slate-400 border border-slate-500/30' :
                  'bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse'
              }`}>
                  L{module.layer}
              </div>
              <div>
                  <div className="text-sm font-medium text-slate-200">{module.name}</div>
                  <div className="flex gap-2 text-[10px] text-slate-400">
                      <span className="uppercase">{module.status}</span>
                      <span>•</span>
                      <span>{module.latency}ms</span>
                  </div>
              </div>
          </div>
          <div className="text-right w-24">
              <div className="text-xs font-mono text-white mb-1">{module.load.toFixed(0)}%</div>
              <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                      className={`h-full transition-all duration-500 ${module.load > 80 ? 'bg-red-500' : 'bg-green-500'}`} 
                      style={{ width: `${module.load}%` }}
                  />
              </div>
          </div>
      </div>
  );

  return (
    <div className="flex h-full bg-[#0a0a0a] text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-64 bg-slate-900/80 border-r border-white/10 flex flex-col py-4 gap-2 shrink-0 backdrop-blur-xl">
            <div className="px-4 mb-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Activity className="text-blue-500" /> Orchestrator
                </h2>
                <div className="text-xs text-slate-500">System Core L14</div>
            </div>
            
            <button 
                onClick={() => setActiveTab('network')}
                className={`flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-all ${activeTab === 'network' ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-white/5'}`}
            >
                <Network size={18} />
                <span className="hidden md:inline text-sm font-medium">Neural Map</span>
            </button>
            <button 
                onClick={() => setActiveTab('workflow')}
                className={`flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-all ${activeTab === 'workflow' ? 'bg-green-600 text-white shadow-lg shadow-green-900/20' : 'text-slate-400 hover:bg-white/5'}`}
            >
                <Play size={18} />
                <span className="hidden md:inline text-sm font-medium">Execution Flow</span>
            </button>
            <button 
                onClick={() => setActiveTab('logs')}
                className={`flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-all ${activeTab === 'logs' ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/20' : 'text-slate-400 hover:bg-white/5'}`}
            >
                <Layers size={18} />
                <span className="hidden md:inline text-sm font-medium">Module Status</span>
            </button>
            
            <div className="mt-auto px-4 py-4 border-t border-white/5">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-slate-400 uppercase font-bold">Coherence</span>
                    <span className="text-xs text-green-400 font-mono">{coordinationState.coherenceScore}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-500 to-green-500" style={{ width: `${coordinationState.coherenceScore}%` }} />
                </div>
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0f1014]">
            {activeTab === 'network' && (
                <div className="flex-1 relative flex flex-col">
                    <canvas ref={canvasRef} className="w-full h-full block" />
                    
                    {/* Legend */}
                    <div className="absolute top-4 left-4 z-10 bg-slate-900/90 backdrop-blur border border-white/10 p-3 rounded-xl shadow-2xl">
                        <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">Layer Topology</h3>
                        <div className="space-y-2 text-xs">
                            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-[#a855f7]" /><span className="text-purple-200">Self-Awareness (L13)</span></div>
                            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-[#ef4444]" /><span className="text-red-200">Bridge/Orch (L14-16)</span></div>
                            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-[#f59e0b]" /><span className="text-amber-200">Advanced (L6-12)</span></div>
                            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-[#3b82f6]" /><span className="text-blue-200">Infrastructure (L1-5)</span></div>
                        </div>
                    </div>

                    {/* Conflicts Monitor */}
                    <div className="absolute bottom-0 left-0 right-0 h-48 bg-slate-900/95 backdrop-blur-xl border-t border-white/10 p-4 transition-transform hover:h-64">
                         <div className="flex items-center justify-between mb-3">
                             <h3 className="text-sm font-bold text-white flex items-center gap-2">
                                 <AlertTriangle size={16} className="text-yellow-500" /> Active Conflicts
                             </h3>
                             <span className="text-xs text-slate-500">{coordinationState.conflicts.length} Events</span>
                         </div>
                         <div className="overflow-y-auto h-full pb-8">
                             {coordinationState.conflicts.length === 0 ? (
                                 <div className="text-center text-slate-600 text-sm italic py-4">System nominal. No active conflicts detected.</div>
                             ) : (
                                 <div className="space-y-2">
                                     {coordinationState.conflicts.map(c => (
                                         <div key={c.id} className="bg-red-500/10 border border-red-500/20 p-3 rounded-lg flex justify-between items-center">
                                             <div>
                                                 <span className="text-xs font-bold text-red-400 block mb-1">{c.sourceLayer} vs {c.targetLayer}</span>
                                                 <span className="text-xs text-slate-300">{c.description}</span>
                                             </div>
                                             <span className="px-2 py-1 rounded bg-black/30 text-[10px] text-slate-400 font-mono border border-white/5">
                                                 {c.resolution}
                                             </span>
                                         </div>
                                     ))}
                                 </div>
                             )}
                         </div>
                    </div>
                </div>
            )}

            {activeTab === 'workflow' && (
                <div className="flex-1 overflow-y-auto p-8">
                    <div className="flex items-center justify-between mb-8">
                        <h2 className="text-2xl font-light text-white flex items-center gap-3">
                            <Zap className="text-green-500" fill="currentColor" /> Active Execution Pipeline
                        </h2>
                        <div className="flex gap-4 text-xs text-slate-400">
                             <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500" /> Success</div>
                             <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" /> Processing</div>
                             <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500" /> Failed</div>
                        </div>
                    </div>

                    <div className="space-y-0 relative before:absolute before:left-[19px] before:top-4 before:bottom-4 before:w-[2px] before:bg-slate-800">
                        {coordinationState.executionQueue.map((exec, idx) => (
                            <div key={exec.id} className="relative pl-12 pb-6 group animate-in slide-in-from-left-4 duration-300" style={{ animationDelay: `${idx * 50}ms` }}>
                                <div className={`
                                    absolute left-0 top-0 w-10 h-10 rounded-full border-4 border-[#0f1014] flex items-center justify-center z-10
                                    ${exec.status === 'success' ? 'bg-green-600 text-white' : exec.status === 'failed' ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'}
                                `}>
                                    {exec.status === 'success' ? <CheckCircle size={18} /> : exec.status === 'failed' ? <XCircle size={18} /> : <Activity size={18} className="animate-spin" />}
                                </div>
                                
                                <div className="bg-slate-800/50 border border-white/5 rounded-xl p-4 hover:bg-slate-800 transition-colors">
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-2">
                                            <span className="text-sm font-bold text-white">{exec.actionType}</span>
                                            <span className="text-slate-500 text-xs">➔</span>
                                            <span className="text-sm font-medium text-slate-300">{exec.target}</span>
                                        </div>
                                        <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                                            <Clock size={12} />
                                            {exec.timestamp.toLocaleTimeString()}
                                        </div>
                                    </div>
                                    <p className="text-xs text-slate-400">{exec.details}</p>
                                </div>
                            </div>
                        ))}
                        {coordinationState.executionQueue.length === 0 && (
                             <div className="pl-12 py-10 text-slate-500 italic">No tasks in execution pipeline.</div>
                        )}
                    </div>
                </div>
            )}

            {activeTab === 'logs' && (
                <div className="flex-1 overflow-y-auto p-8">
                    <h2 className="text-xl font-bold mb-6 text-white">System Modules Registry</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {coordinationState.modules.sort((a,b) => b.layer - a.layer).map(mod => (
                            <ModuleListRow key={mod.id} module={mod} />
                        ))}
                    </div>

                    <div className="mt-8 bg-slate-900 border border-white/10 rounded-2xl p-6">
                        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Global System Load</h3>
                        <div className="h-32 flex items-end gap-1">
                            {[...Array(60)].map((_, i) => {
                                const height = Math.random() * coordinationState.globalSystemLoad + 10;
                                return (
                                    <div 
                                        key={i} 
                                        className="flex-1 bg-blue-600/30 rounded-t-sm transition-all duration-500 hover:bg-blue-500"
                                        style={{ height: `${Math.min(100, height)}%` }}
                                    />
                                );
                            })}
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default OrchestratorApp;
