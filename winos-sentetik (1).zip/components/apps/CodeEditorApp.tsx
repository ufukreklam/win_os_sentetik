
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { 
  Save, Play, FileCode, Files, 
  Settings as SettingsIcon, ChevronRight, X, 
  Terminal as TerminalIcon, Search
} from 'lucide-react';

const CodeEditorApp: React.FC = () => {
  const { writeFile, readFile, readdir, openApp, addNotification, playSound } = useOS();
  const [content, setContent] = useState('// Welcome to WinOS Code Editor\n\nfunction main() {\n  console.log("Hello, WinOS Hybrid!");\n}\n\nmain();');
  const [fileName, setFileName] = useState('script.js');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('editor'); // 'editor' | 'output'
  const [output, setOutput] = useState<string[]>([]);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Simple Syntax Highlighting Logic
  const highlightCode = (code: string) => {
    // Escaping HTML
    let highlighted = code
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Keywords
    const keywords = ['function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'import', 'export', 'class', 'extends', 'echo', 'bash'];
    const keywordRegex = new RegExp(`\\b(${keywords.join('|')})\\b`, 'g');
    highlighted = highlighted.replace(keywordRegex, '<span class="text-purple-400">$1</span>');

    // Strings
    highlighted = highlighted.replace(/(["'])(?:(?=(\\?))\2.)*?\1/g, '<span class="text-green-300">$0</span>');

    // Numbers
    highlighted = highlighted.replace(/\b\d+\b/g, '<span class="text-orange-400">$0</span>');

    // Comments
    highlighted = highlighted.replace(/\/\/.*|\/\*[\s\S]*?\*\//g, '<span class="text-slate-500 italic">$0</span>');

    return highlighted;
  };

  const handleScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  const handleSave = () => {
    writeFile('/home/user/Documents', {
      name: fileName,
      type: 'file',
      fileType: 'code',
      size: `${content.length} B`,
      permissions: '-rw-r--r--',
      content: content
    });
    addNotification({ title: 'Code Saved', message: `${fileName} saved to Documents.`, type: 'success' });
    playSound('notification');
  };

  const handleRun = () => {
    setActiveTab('output');
    setOutput(prev => [...prev, `[${new Date().toLocaleTimeString()}] Running ${fileName}...`]);
    
    // Simulate execution
    setTimeout(() => {
      if (fileName.endsWith('.js')) {
        setOutput(prev => [...prev, '> Hello, WinOS Hybrid!', '> Execution finished with exit code 0.']);
      } else if (fileName.endsWith('.sh')) {
        setOutput(prev => [...prev, '> bash: hello from script', '> process exited.']);
      } else {
        setOutput(prev => [...prev, '> output: ' + content.slice(0, 20) + '...']);
      }
      playSound('click');
    }, 800);
  };

  const handleFileOpen = (name: string) => {
     const file = readFile('/home/user/Documents', name) || readFile('/home/user/Desktop', name) || readFile('/home/user', name);
     if (file && file.type === 'file') {
         setContent(file.content || '');
         setFileName(name);
         setActiveTab('editor');
         if (isMobile) setIsSidebarOpen(false);
     }
  };

  const desktopFiles = readdir('/home/user/Desktop').filter(f => f.type === 'file');
  const documentFiles = readdir('/home/user/Documents').filter(f => f.type === 'file');

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 font-sans overflow-hidden">
      {/* Sidebar - Explorer */}
      <div className={`
        bg-slate-900/90 border-r border-white/5 flex flex-col transition-all duration-300 z-50
        ${isSidebarOpen ? (isMobile ? 'w-full absolute inset-0' : 'w-60 shrink-0') : 'w-0 overflow-hidden'}
      `}>
        <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 shrink-0">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Explorer</span>
          <button onClick={() => setIsSidebarOpen(false)} className="p-1 hover:bg-white/10 rounded">
            <X size={14} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-4">
          <div>
            <div className="flex items-center gap-2 px-2 py-1 text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">
              <ChevronRight size={10} /> Desktop
            </div>
            {desktopFiles.map(f => (
              <button 
                key={f.name}
                onClick={() => handleFileOpen(f.name)}
                className="w-full flex items-center gap-2 px-4 py-1.5 rounded hover:bg-white/5 text-xs text-slate-300 truncate transition-colors"
              >
                <FileCode size={14} className="text-blue-400 shrink-0" />
                <span className="truncate">{f.name}</span>
              </button>
            ))}
          </div>

          <div>
            <div className="flex items-center gap-2 px-2 py-1 text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">
              <ChevronRight size={10} /> Documents
            </div>
            {documentFiles.map(f => (
              <button 
                key={f.name}
                onClick={() => handleFileOpen(f.name)}
                className="w-full flex items-center gap-2 px-4 py-1.5 rounded hover:bg-white/5 text-xs text-slate-300 truncate transition-colors"
              >
                <FileCode size={14} className="text-purple-400 shrink-0" />
                <span className="truncate">{f.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="h-10 border-t border-white/5 flex items-center justify-around px-2">
           <button className="p-1.5 hover:bg-white/10 rounded text-slate-400"><Search size={16} /></button>
           <button className="p-1.5 hover:bg-white/10 rounded text-slate-400"><Files size={16} /></button>
           <button className="p-1.5 hover:bg-white/10 rounded text-slate-400"><SettingsIcon size={16} /></button>
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 bg-slate-900/50 shrink-0">
          <div className="flex items-center gap-4">
            {!isSidebarOpen && (
              <button onClick={() => setIsSidebarOpen(true)} className="p-1.5 hover:bg-white/10 rounded text-slate-400">
                <Files size={18} />
              </button>
            )}
            <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border-t border-x border-white/10 rounded-t-md text-xs font-medium text-blue-400">
               <FileCode size={14} />
               <span>{fileName}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={handleRun}
              className="flex items-center gap-2 px-3 py-1 bg-green-600 hover:bg-green-500 text-white rounded text-xs font-bold transition-all active:scale-95 shadow-lg shadow-green-500/20"
            >
              <Play size={12} fill="currentColor" />
              <span>Run</span>
            </button>
            <button 
              onClick={handleSave}
              className="p-1.5 hover:bg-white/10 rounded text-slate-400 hover:text-white transition-colors"
            >
              <Save size={16} />
            </button>
          </div>
        </div>

        {/* View Selection Tabs */}
        <div className="h-8 border-b border-white/5 flex items-center px-4 gap-4 bg-slate-950/20 shrink-0">
           <button 
            onClick={() => setActiveTab('editor')}
            className={`text-[10px] uppercase font-bold tracking-widest h-full px-2 border-b-2 transition-all ${activeTab === 'editor' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
           >
            Editor
           </button>
           <button 
            onClick={() => setActiveTab('output')}
            className={`text-[10px] uppercase font-bold tracking-widest h-full px-2 border-b-2 transition-all ${activeTab === 'output' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}
           >
            Output
           </button>
        </div>

        {/* Editor or Output Content */}
        <div className="flex-1 relative overflow-hidden bg-slate-950/30">
          {activeTab === 'editor' ? (
            <div className="absolute inset-0 flex">
              {/* Line Numbers Simulation */}
              <div className="w-10 bg-slate-900/50 border-r border-white/5 pt-4 flex flex-col items-center text-[10px] font-mono text-slate-600 select-none">
                {Array.from({ length: content.split('\n').length + 5 }).map((_, i) => (
                  <div key={i} className="h-5 leading-5">{i + 1}</div>
                ))}
              </div>
              
              <div className="flex-1 relative group overflow-hidden">
                <pre 
                  ref={preRef}
                  className="absolute inset-0 p-4 m-0 font-mono text-sm leading-5 pointer-events-none whitespace-pre overflow-hidden"
                  dangerouslySetInnerHTML={{ __html: highlightCode(content) + '\n' }}
                />
                <textarea
                  ref={textareaRef}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  onScroll={handleScroll}
                  className="absolute inset-0 w-full h-full p-4 font-mono text-sm leading-5 bg-transparent text-transparent caret-blue-400 resize-none outline-none overflow-auto whitespace-pre custom-scrollbar"
                  spellCheck={false}
                />
              </div>
            </div>
          ) : (
            <div className="absolute inset-0 p-4 font-mono text-xs overflow-y-auto custom-scrollbar bg-slate-950">
               <div className="flex items-center gap-2 text-slate-500 mb-4 pb-2 border-b border-white/5">
                  <TerminalIcon size={14} />
                  <span>Output Console</span>
                  <button onClick={() => setOutput([])} className="ml-auto hover:text-white transition-colors">Clear</button>
               </div>
               {output.map((line, i) => (
                 <div key={i} className={`mb-1 ${line.startsWith('>') ? 'text-green-400' : line.startsWith('[') ? 'text-slate-500' : 'text-slate-300'}`}>
                    {line}
                 </div>
               ))}
               {output.length === 0 && (
                 <div className="text-slate-600 italic">No output yet. Click 'Run' to execute code.</div>
               )}
            </div>
          )}
        </div>

        {/* Status Bar */}
        <div className="h-6 bg-slate-900 border-t border-white/5 px-4 flex items-center justify-between text-[10px] text-slate-500 shrink-0 font-mono">
           <div className="flex items-center gap-4">
              <span>UTF-8</span>
              <span>JavaScript</span>
           </div>
           <div className="flex items-center gap-4">
              <span>Spaces: 2</span>
              <span>Ln {content.split('\n').length}, Col {content.length}</span>
           </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
};

export default CodeEditorApp;
