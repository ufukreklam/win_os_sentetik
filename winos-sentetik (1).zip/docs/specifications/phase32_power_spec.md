
# Faz 32: Güç Yönetim ve Enerji Analiz Spesifikasyonu

Bu döküman, WinOS Robotik Çekirdeği için **Güç Yönetim Sistemi (PowerNode)** tasarımını içerir.

## 1. Hedef
Robotun enerji kaynağını (Batarya) izlemek, tüketimi analiz etmek, kalan kullanım süresini tahmin etmek ve kritik enerji seviyelerinde sistemi korumaya almak.

## 2. Teknik Mimari

### 2.1 PowerNode (Backend)
`PowerNode`, `hardware_update` kanalını dinler ve ham voltaj/akım verilerini işleyerek zenginleştirilmiş güç verisi üretir.

*   **Girdiler:**
    *   `batteryVoltage` (V): Protokol düğümünden gelen ham voltaj.
    *   `currentDraw` (A): Çekilen anlık akım.
*   **İşlemler:**
    *   **SoC (State of Charge) Hesabı:** Voltaj tabanlı doluluk tahmini (3S Li-ion eğrisi).
    *   **Güç Hesabı:** P = V * I (Watt cinsinden anlık güç).
    *   **Kalan Süre Tahmini:** Batarya kapasitesine göre tahmini çalışma süresi.
    *   **Anomali Tespiti:** Aşırı akım veya ani voltaj düşüşü kontrolü.
*   **Çıktılar:**
    *   `power_info`: Frontend için özet veri (%, Watt, Durum).
    *   `system_alert`: Kritik seviye uyarısı.

### 2.2 Batarya Modeli (3S Li-ion)
3 Seri bağlı 18650 Li-ion pil paketi referans alınmıştır.

*   **Tam Dolu:** 12.6V (%100)
*   **Nominal:** 11.1V (~%50)
*   **Kritik Seviye:** 9.6V (%10 - Uyarı Limiti)
*   **Kesim (Cutoff):** 9.0V (%0 - Sistem Kapatma)

### 2.3 Hesaplama Mantığı

```python
# Basitleştirilmiş Lineer İnterpolasyon
voltage_map = [
    (12.6, 100),
    (12.0, 80),
    (11.1, 50),
    (10.5, 20),
    (9.6, 10),
    (9.0, 0)
]
```

## 3. Güvenlik Protokolleri

1.  **Düşük Voltaj Uyarısı (%20):**
    *   Frontend'e "Düşük Pil" bildirimi gönderilir.
    *   Yapay Zeka (Layer 6) "Enerji" dürtüsünü artırır.
2.  **Kritik Voltaj Koruması (%5):**
    *   Motorlar devre dışı bırakılır (Safety Stop).
    *   Sistem "Deep Sleep" veya "Shutdown" moduna hazırlanır.
3.  **Aşırı Akım Koruması:**
    *   Anlık akım belirlenen eşiği (örn. 5A) aşarsa motorlar durdurulur.

## 4. Veri Yapısı (Yayınlanan)

```json
{
  "type": "power_info",
  "battery": {
    "voltage": 11.5,
    "percentage": 65,
    "status": "discharging", // charging, critical
    "health": "good"
  },
  "consumption": {
    "current": 1.2, // Amper
    "power": 13.8,  // Watt
    "average_power": 12.5
  },
  "estimation": {
    "time_remaining": 3600 // Saniye
  }
}
```
