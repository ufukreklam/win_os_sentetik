
import React, { ReactNode, useState, useRef, useEffect, useCallback } from 'react';
import { useOS } from '../../context/OSContext';
import { AppID } from '../../types';
import { X, Minus, Square, Copy } from 'lucide-react';

interface WindowProps {
  appId: AppID;
  children?: ReactNode;
}

type ResizeDirection = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

const Window: React.FC<WindowProps> = ({ appId, children }) => {
  const { windows, closeApp, focusApp, minimizeApp, maximizeApp, updateWindow, isMovingWindow, setMovingWindow, setSnapPreview } = useOS();
  const winState = windows[appId];
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [showSnapMenu, setShowSnapMenu] = useState(false);
  const [isDragging, setIsDragging] = useState(false); // Used for both drag and resize to disable content interaction
  const snapTimeoutRef = useRef<number | null>(null);

  const dragRef = useRef<{ startX: number; startY: number; winX: number; winY: number } | null>(null);
  
  const resizeRef = useRef<{ 
    startX: number; 
    startY: number; 
    startWinX: number; 
    startWinY: number;
    startWinW: number; 
    startWinH: number;
    direction: ResizeDirection;
  } | null>(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // --- MOUSE DRAG LOGIC ---
  const startDrag = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    if (winState.isMaximized || isMobile) return;
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('.resize-handle')) return;

    e.preventDefault();
    setMovingWindow(true);
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      winX: winState.x || 0,
      winY: winState.y || 0,
    };
    focusApp(appId);
    window.addEventListener('mousemove', onDrag);
    window.addEventListener('mouseup', stopDrag);
  };

  const onDrag = useCallback((e: MouseEvent) => {
    if (!dragRef.current) return;
    const deltaX = e.clientX - dragRef.current.startX;
    const deltaY = e.clientY - dragRef.current.startY;
    
    let newX = dragRef.current.winX + deltaX;
    let newY = dragRef.current.winY + deltaY;

    const topLimit = 0; 
    // Desktop margin is 48px top, 48px bottom = 96px chrome total.
    const desktopHeight = window.innerHeight - 96;
    const bottomLimit = desktopHeight - 40;

    if (newY < topLimit) newY = topLimit;
    if (newY > bottomLimit) newY = bottomLimit;

    updateWindow(appId, { x: newX, y: newY });

    // Snap Logic
    const SNAP_THRESHOLD = 20;
    const screenW = window.innerWidth;
    const snapH = window.innerHeight - 96;
    let snapRect = null;
    if (e.clientX < SNAP_THRESHOLD) snapRect = { x: 0, y: 0, width: screenW / 2, height: snapH };
    else if (e.clientX > screenW - SNAP_THRESHOLD) snapRect = { x: screenW / 2, y: 0, width: screenW / 2, height: snapH };
    setSnapPreview(snapRect);
  }, [appId, updateWindow, setSnapPreview]);

  const stopDrag = (e: MouseEvent) => {
    setMovingWindow(false);
    setIsDragging(false);
    dragRef.current = null;
    window.removeEventListener('mousemove', onDrag);
    window.removeEventListener('mouseup', stopDrag);

    const SNAP_THRESHOLD = 20;
    const screenW = window.innerWidth;
    const desktopH = window.innerHeight - 96;
    if (e.clientX < SNAP_THRESHOLD) updateWindow(appId, { x: 0, y: 0, width: screenW/2, height: desktopH, isMaximized: false });
    else if (e.clientX > screenW - SNAP_THRESHOLD) updateWindow(appId, { x: screenW/2, y: 0, width: screenW/2, height: desktopH, isMaximized: false });
    setSnapPreview(null);
  };

  // --- TOUCH DRAG LOGIC ---
  const startDragTouch = (e: React.TouchEvent) => {
    if (winState.isMaximized || isMobile) return;
    if ((e.target as HTMLElement).closest('button') || (e.target as HTMLElement).closest('.resize-handle')) return;
    setMovingWindow(true);
    setIsDragging(true);
    const touch = e.touches[0];
    dragRef.current = { startX: touch.clientX, startY: touch.clientY, winX: winState.x || 0, winY: winState.y || 0 };
    focusApp(appId);
    window.addEventListener('touchmove', onDragTouch, { passive: false });
    window.addEventListener('touchend', stopDragTouch);
  };

  const onDragTouch = useCallback((e: TouchEvent) => {
    if (!dragRef.current) return;
    e.preventDefault();
    const touch = e.touches[0];
    const deltaX = touch.clientX - dragRef.current.startX;
    const deltaY = touch.clientY - dragRef.current.startY;
    let newX = dragRef.current.winX + deltaX;
    let newY = dragRef.current.winY + deltaY;
    const topLimit = 0; 
    const desktopHeight = window.innerHeight - 96; 
    const bottomLimit = desktopHeight - 40;
    
    if (newY < topLimit) newY = topLimit;
    if (newY > bottomLimit) newY = bottomLimit;
    updateWindow(appId, { x: newX, y: newY });
  }, [appId, updateWindow]);

  const stopDragTouch = () => {
    setMovingWindow(false); 
    setIsDragging(false);
    dragRef.current = null;
    window.removeEventListener('touchmove', onDragTouch); 
    window.removeEventListener('touchend', stopDragTouch);
  };

  // --- RESIZE LOGIC ---
  const startResize = (e: React.MouseEvent, direction: ResizeDirection) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true); // Disable content interaction while resizing
    setMovingWindow(true); // Show global overlay

    resizeRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        startWinX: winState.x || 0,
        startWinY: winState.y || 0,
        startWinW: winState.width || 400,
        startWinH: winState.height || 300,
        direction
    };

    window.addEventListener('mousemove', onResize);
    window.addEventListener('mouseup', stopResize);
  };

  const onResize = useCallback((e: MouseEvent) => {
    if (!resizeRef.current) return;
    const { startX, startY, startWinX, startWinY, startWinW, startWinH, direction } = resizeRef.current;

    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;

    let newX = startWinX;
    let newY = startWinY;
    let newW = startWinW;
    let newH = startWinH;

    const minW = 300;
    const minH = 200;

    // Width & X calculation
    if (direction.includes('e')) {
        newW = Math.max(minW, startWinW + deltaX);
    } else if (direction.includes('w')) {
        const proposedW = startWinW - deltaX;
        if (proposedW >= minW) {
            newW = proposedW;
            newX = startWinX + deltaX;
        }
    }

    // Height & Y calculation
    if (direction.includes('s')) {
        newH = Math.max(minH, startWinH + deltaY);
    } else if (direction.includes('n')) {
        const proposedH = startWinH - deltaY;
        if (proposedH >= minH) {
            newH = proposedH;
            newY = startWinY + deltaY;
        }
    }

    updateWindow(appId, { x: newX, y: newY, width: newW, height: newH });
  }, [appId, updateWindow]);

  const stopResize = () => {
    setIsDragging(false);
    setMovingWindow(false);
    resizeRef.current = null;
    window.removeEventListener('mousemove', onResize);
    window.removeEventListener('mouseup', stopResize);
  };

  const handleSnap = (type: 'left' | 'right') => {
    const desktopH = window.innerHeight - 96;
    const desktopW = window.innerWidth;
    let newState: Partial<typeof winState> = { y: 0, height: desktopH, width: desktopW / 2, isMaximized: false };
    if (type === 'left') newState.x = 0; else newState.x = desktopW / 2;
    updateWindow(appId, newState); setShowSnapMenu(false);
  };

  if (!winState.isOpen) return null;

  // ANIMATION & LAYOUT LOGIC
  const commonStyle: React.CSSProperties = {
      zIndex: winState.zIndex,
      transformOrigin: 'bottom center',
      // Disable transitions during drag/resize to prevent lag
      transition: isDragging 
        ? 'none' 
        : 'transform 0.3s cubic-bezier(0.16,1,0.3,1), opacity 0.2s, width 0.2s, height 0.2s, top 0.2s, left 0.2s'
  };

  // Mobile veya Maximize durumunda TopBar (48px) ve StatusBar (48px) için boşluk bırak
  const style: React.CSSProperties = isMobile || winState.isMaximized
    ? {
        ...commonStyle,
        top: 48, // TopBar yüksekliği kadar aşağı
        left: 0, 
        width: '100%', 
        height: 'calc(100% - 96px)', // TopBar + StatusBar toplamı kadar çıkar
        borderRadius: 0,
        transform: winState.isMinimized ? 'translateY(100vh) scale(0.5)' : 'none',
        opacity: winState.isMinimized ? 0 : 1,
      }
    : {
        ...commonStyle,
        top: winState.y, left: winState.x, width: winState.width, height: winState.height,
        transform: winState.isMinimized ? `translate(0px, ${window.innerHeight/2}px) scale(0.1)` : 'none',
        opacity: winState.isMinimized ? 0 : 1,
      };

  return (
    <div
      className={`absolute flex flex-col overflow-hidden
        ${winState.isMinimized ? 'pointer-events-none' : 'pointer-events-auto'}
        ${winState.isOpen && !winState.isMinimized ? 'animate-in zoom-in-95 fade-in duration-200' : ''}
        bg-slate-900/90 backdrop-blur-2xl border border-white/10 shadow-2xl
        ${isMobile || winState.isMaximized ? 'border-0' : 'rounded-xl'}
      `}
      style={style}
      onMouseDown={() => focusApp(appId)}
      onContextMenu={(e) => { e.stopPropagation(); }}
      role="dialog"
      aria-label={winState.title}
    >
      {/* Title Bar */}
      <div 
        className="h-10 bg-white/5 border-b border-white/5 flex items-center justify-between px-4 select-none cursor-default shrink-0 touch-none relative z-50" 
        onMouseDown={startDrag} onTouchStart={startDragTouch} onDoubleClick={() => maximizeApp(appId)}
      >
        <div className="flex items-center gap-3 text-slate-200 ml-2">
          <winState.icon size={16} className="text-blue-400" />
          <span className="text-sm font-medium">{winState.title}</span>
        </div>
        
        <div className="flex items-center gap-1 mr-2">
          <button 
            onClick={(e) => { e.stopPropagation(); minimizeApp(appId); }} 
            className="p-2 hover:bg-white/10 rounded-md transition-colors text-slate-400 hover:text-white"
            aria-label="Minimize"
            title="Minimize"
          >
            <Minus size={16} />
          </button>
          {!isMobile && (
             <div className="relative" onMouseEnter={() => { if (snapTimeoutRef.current) clearTimeout(snapTimeoutRef.current); setShowSnapMenu(true); }} onMouseLeave={() => { snapTimeoutRef.current = window.setTimeout(() => setShowSnapMenu(false), 300); }}>
                <button 
                    onClick={(e) => { e.stopPropagation(); maximizeApp(appId); setShowSnapMenu(false); }} 
                    className="p-2 hover:bg-white/10 rounded-md transition-colors text-slate-400 hover:text-white"
                    aria-label={winState.isMaximized ? "Restore" : "Maximize"}
                    title={winState.isMaximized ? "Restore" : "Maximize"}
                >
                    {winState.isMaximized ? <Copy size={14} /> : <Square size={14} />}
                </button>
                {showSnapMenu && (
                    <div className="absolute top-8 right-0 bg-slate-900/95 backdrop-blur-xl border border-white/10 p-2 rounded-lg shadow-2xl flex gap-2 z-[60] w-[140px] animate-in fade-in zoom-in-95 duration-100">
                        <div onClick={(e) => { e.stopPropagation(); handleSnap('left'); }} className="flex-1 aspect-video bg-slate-700/50 rounded hover:bg-blue-500/20 cursor-pointer p-1 border border-white/5" role="button" aria-label="Snap Left"><div className="w-1/2 h-full bg-slate-400/50 rounded-l" /></div>
                        <div onClick={(e) => { e.stopPropagation(); handleSnap('right'); }} className="flex-1 aspect-video bg-slate-700/50 rounded hover:bg-blue-500/20 cursor-pointer p-1 border border-white/5" role="button" aria-label="Snap Right"><div className="w-1/2 h-full bg-slate-400/50 rounded-r ml-auto" /></div>
                    </div>
                )}
             </div>
          )}
          <button 
            onClick={(e) => { e.stopPropagation(); closeApp(appId); }} 
            className="p-2 hover:bg-red-500/80 rounded-md transition-colors text-slate-400 hover:text-white"
            aria-label="Close"
            title="Close"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden relative bg-slate-900/40">
        {children}
        {isDragging && <div className="absolute inset-0 z-50 bg-transparent" />}
      </div>

      {/* Resize Handles (Corners & Sides) */}
      {!isMobile && !winState.isMaximized && (
         <>
            {/* Corners */}
            <div className="absolute top-0 left-0 w-4 h-4 cursor-nw-resize z-[60] resize-handle" onMouseDown={(e) => startResize(e, 'nw')} />
            <div className="absolute top-0 right-0 w-4 h-4 cursor-ne-resize z-[60] resize-handle" onMouseDown={(e) => startResize(e, 'ne')} />
            <div className="absolute bottom-0 left-0 w-4 h-4 cursor-sw-resize z-[60] resize-handle" onMouseDown={(e) => startResize(e, 'sw')} />
            <div className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize z-[60] resize-handle" onMouseDown={(e) => startResize(e, 'se')} />
            
            {/* Sides */}
            <div className="absolute top-0 left-4 right-4 h-2 cursor-n-resize z-[59] resize-handle" onMouseDown={(e) => startResize(e, 'n')} />
            <div className="absolute bottom-0 left-4 right-4 h-2 cursor-s-resize z-[59] resize-handle" onMouseDown={(e) => startResize(e, 's')} />
            <div className="absolute top-4 bottom-4 left-0 w-2 cursor-w-resize z-[59] resize-handle" onMouseDown={(e) => startResize(e, 'w')} />
            <div className="absolute top-4 bottom-4 right-0 w-2 cursor-e-resize z-[59] resize-handle" onMouseDown={(e) => startResize(e, 'e')} />
         </>
      )}
    </div>
  );
};

export default Window;
