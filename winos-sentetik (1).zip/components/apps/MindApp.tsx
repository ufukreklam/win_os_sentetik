
import React, { useEffect, useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Activity, BrainCircuit, Heart, Zap, Smile, Frown, Meh, AlertCircle, HelpCircle, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { CoreEmotion } from '../../types';

const MindApp: React.FC = () => {
  const { emotionState, sensorReadings } = useOS();
  const [history, setHistory] = useState<number[]>(new Array(50).fill(0));

  // Update history graph based on arousal/intensity
  useEffect(() => {
      const interval = setInterval(() => {
          setHistory(prev => [...prev.slice(1), emotionState.pad.arousal * 100]);
      }, 200);
      return () => clearInterval(interval);
  }, [emotionState.pad.arousal]);

  const getEmotionIcon = (emotion: CoreEmotion) => {
      switch (emotion) {
          case 'happy': return <Smile size={48} className="text-yellow-400" />;
          case 'sad': return <Frown size={48} className="text-indigo-400" />;
          case 'angry': return <AlertCircle size={48} className="text-red-500" />;
          case 'fear': return <Activity size={48} className="text-purple-500" />;
          case 'curious': return <HelpCircle size={48} className="text-green-400" />;
          case 'surprised': return <Zap size={48} className="text-pink-400" />;
          default: return <Meh size={48} className="text-blue-300" />;
      }
  };

  const getGradient = (emotion: CoreEmotion) => {
      switch (emotion) {
          case 'happy': return 'from-yellow-500/20 to-orange-500/10';
          case 'sad': return 'from-indigo-500/20 to-blue-500/10';
          case 'angry': return 'from-red-600/20 to-orange-600/10';
          case 'fear': return 'from-purple-900/30 to-black/20';
          case 'curious': return 'from-green-500/20 to-emerald-500/10';
          default: return 'from-slate-700/20 to-slate-800/10';
      }
  };

  return (
    <div className={`flex h-full bg-gradient-to-br ${getGradient(emotionState.primary)} text-slate-100 font-sans p-6 gap-6 overflow-hidden transition-colors duration-1000`}>
        {/* Left Column: Core Status */}
        <div className="w-1/3 flex flex-col gap-6">
            <div className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center flex-1 shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40 pointer-events-none" />
                
                {/* Pulsing Aura */}
                <div className={`absolute w-64 h-64 rounded-full blur-3xl opacity-30 animate-pulse transition-colors duration-1000 ${
                    emotionState.primary === 'angry' ? 'bg-red-500' : 
                    emotionState.primary === 'happy' ? 'bg-yellow-400' : 'bg-blue-500'
                }`} />

                <div className="z-10 flex flex-col items-center gap-4">
                    {getEmotionIcon(emotionState.primary)}
                    <div className="text-center">
                        <h2 className="text-3xl font-light uppercase tracking-widest">{emotionState.primary}</h2>
                        <span className="text-xs text-slate-400 font-mono">Current Dominant State</span>
                    </div>
                </div>
            </div>

            <div className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                <h3 className="text-xs font-bold text-slate-500 uppercase mb-4 flex items-center gap-2">
                    <BrainCircuit size={14} /> Neural Load
                </h3>
                <div className="space-y-4">
                    <div>
                        <div className="flex justify-between text-xs mb-1">
                            <span>Processing</span>
                            <span>{Math.round(emotionState.intensity * 100)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${emotionState.intensity * 100}%` }} />
                        </div>
                    </div>
                    <div>
                        <div className="flex justify-between text-xs mb-1">
                            <span>Memory Access</span>
                            <span>{Math.round(Math.random() * 40 + 20)}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-purple-500 transition-all duration-500" style={{ width: '45%' }} />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {/* Right Column: PAD Model & Analytics */}
        <div className="flex-1 flex flex-col gap-6">
            {/* PAD Sliders */}
            <div className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-6 flex-1 flex flex-col justify-center">
                <h3 className="text-xs font-bold text-slate-500 uppercase mb-6 flex items-center gap-2">
                    <Heart size={14} /> P.A.D. Model (Russell's Circumplex)
                </h3>
                
                <div className="space-y-8">
                    <div className="relative group">
                        <div className="flex justify-between text-xs mb-2 font-mono text-slate-300">
                            <span>Displeasure (-1.0)</span>
                            <span className="text-white font-bold">{emotionState.pad.pleasure.toFixed(2)}</span>
                            <span>Pleasure (+1.0)</span>
                        </div>
                        <div className="w-full h-2 bg-slate-800 rounded-full relative">
                            <div className="absolute top-0 bottom-0 bg-gradient-to-r from-red-500 via-slate-500 to-green-500 opacity-50 rounded-full w-full" />
                            <div 
                                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg transition-all duration-500 border-2 border-slate-900"
                                style={{ left: `${((emotionState.pad.pleasure + 1) / 2) * 100}%` }}
                            />
                        </div>
                    </div>

                    <div className="relative group">
                        <div className="flex justify-between text-xs mb-2 font-mono text-slate-300">
                            <span>Sleepy (-1.0)</span>
                            <span className="text-white font-bold">{emotionState.pad.arousal.toFixed(2)}</span>
                            <span>Aroused (+1.0)</span>
                        </div>
                        <div className="w-full h-2 bg-slate-800 rounded-full relative">
                            <div className="absolute top-0 bottom-0 bg-gradient-to-r from-blue-900 via-slate-500 to-yellow-500 opacity-50 rounded-full w-full" />
                            <div 
                                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg transition-all duration-500 border-2 border-slate-900"
                                style={{ left: `${((emotionState.pad.arousal + 1) / 2) * 100}%` }}
                            />
                        </div>
                    </div>

                    <div className="relative group">
                        <div className="flex justify-between text-xs mb-2 font-mono text-slate-300">
                            <span>Submissive (-1.0)</span>
                            <span className="text-white font-bold">{emotionState.pad.dominance.toFixed(2)}</span>
                            <span>Dominant (+1.0)</span>
                        </div>
                        <div className="w-full h-2 bg-slate-800 rounded-full relative">
                            <div className="absolute top-0 bottom-0 bg-gradient-to-r from-gray-700 via-slate-500 to-purple-500 opacity-50 rounded-full w-full" />
                            <div 
                                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg transition-all duration-500 border-2 border-slate-900"
                                style={{ left: `${((emotionState.pad.dominance + 1) / 2) * 100}%` }}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Influencers */}
            <div className="h-40 flex gap-4">
                <div className="w-1/2 bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 overflow-y-auto">
                    <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Active Influencers</h3>
                    <div className="space-y-2">
                        {emotionState.influencers.map((inf, idx) => (
                            <div key={idx} className="flex items-center justify-between text-xs p-2 bg-white/5 rounded-lg">
                                <div>
                                    <span className="font-bold text-blue-300 block">{inf.source}</span>
                                    <span className="text-slate-400 text-[10px]">{inf.description}</span>
                                </div>
                                <div className={`flex items-center gap-1 font-bold ${inf.impact > 0 ? 'text-green-400' : inf.impact < 0 ? 'text-red-400' : 'text-slate-400'}`}>
                                    {inf.impact > 0 ? <ArrowUp size={12} /> : inf.impact < 0 ? <ArrowDown size={12} /> : <Minus size={12} />}
                                    {Math.abs(inf.impact).toFixed(1)}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="flex-1 bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 flex flex-col">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-bold text-slate-500 uppercase">Arousal History</span>
                        <Activity size={14} className="text-slate-500" />
                    </div>
                    <div className="flex-1 flex items-end gap-1 overflow-hidden">
                        {history.map((val, i) => (
                            <div 
                                key={i} 
                                className="flex-1 bg-blue-500/50 rounded-t-sm transition-all duration-300" 
                                style={{ 
                                    height: `${Math.abs(val)}%`, 
                                    opacity: i / history.length,
                                    backgroundColor: val > 0 ? '#3b82f6' : '#6366f1'
                                }} 
                            />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default MindApp;
