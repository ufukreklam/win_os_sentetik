
import React from 'react';
import { Radar, Map, Eye, Target } from 'lucide-react';
import { PerceptionState } from '../../../types';

interface FusionViewProps {
    perceptionState: PerceptionState;
}

export const FusionView: React.FC<FusionViewProps> = ({ perceptionState }) => {
    return (
        <div className="flex-1 p-8 overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-light">Sensör Füzyon Durumu</h2>
                <div className="flex items-center gap-2 bg-green-900/20 text-green-400 px-3 py-1 rounded-full border border-green-500/30 text-sm">
                    <Radar size={16} />
                    Sağlık: {perceptionState.sensorFusionHealth}%
                </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
                <div className="bg-slate-800/50 border border-white/5 p-6 rounded-2xl">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Girdiler</h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="flex items-center gap-2"><Map size={16} className="text-blue-400"/> Lidar (2D)</span>
                            <span className="text-green-400 text-xs">AKTİF</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="flex items-center gap-2"><Eye size={16} className="text-purple-400"/> Stereo Kam (3D)</span>
                            <span className="text-green-400 text-xs">AKTİF</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="flex items-center gap-2"><Target size={16} className="text-red-400"/> Ultrasonik (1D)</span>
                            <span className="text-green-400 text-xs">AKTİF</span>
                        </div>
                    </div>
                </div>

                <div className="bg-slate-800/50 border border-white/5 p-6 rounded-2xl">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Güvenlik Kontrolü</h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span>En Yakın Engel</span>
                            <span className="font-mono text-xl">{perceptionState.nearestObstacleDistance} mm</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>Tehlike Durumu</span>
                            <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${perceptionState.environmentalHazard ? 'bg-red-500 text-white' : 'bg-green-500/20 text-green-400'}`}>
                                {perceptionState.environmentalHazard ? 'KRİTİK' : 'GÜVENLİ'}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="mt-6 bg-slate-900 border border-white/10 rounded-xl p-4 font-mono text-xs text-slate-400 h-64 overflow-y-auto">
                <div className="mb-2 text-slate-500 border-b border-white/5 pb-1">FUSION_LOG_STREAM</div>
                <div>[T+0.00s] Lidar frame acquired (360pts)</div>
                <div>[T+0.02s] Stereo Camera disparity calculated (640x480)</div>
                <div>[T+0.05s] Merging geometric occupancy with visual depth...</div>
                {perceptionState.detectedObjects.map(obj => (
                    <div key={obj.id} className="text-blue-300">
                        {`> Eşleşme Bulundu: Nesne ID ${obj.id} (${obj.label}) Lidar derinliği ile doğrulandı.`}
                    </div>
                ))}
                <div className="animate-pulse">_</div>
            </div>
        </div>
    );
};
