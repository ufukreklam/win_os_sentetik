
export class VADService {
    private audioContext: AudioContext | null = null;
    private analyser: AnalyserNode | null = null;
    private microphone: MediaStreamAudioSourceNode | null = null;
    private stream: MediaStream | null = null;
    
    private animationFrameId: number | null = null;
    private isListening = false;
    
    // Thresholds
    private readonly SILENCE_THRESHOLD = -50; // dB
    private readonly SPEECH_THRESHOLD = -40; // dB
    private readonly SILENCE_DURATION = 1500; // ms to trigger end of speech
    
    // State
    private isSpeaking = false;
    private silenceStart: number = 0;
    
    // Callbacks
    public onEnergy: ((energy: number) => void) | null = null;
    public onSpeechStart: (() => void) | null = null;
    public onSpeechEnd: (() => void) | null = null;

    async start() {
        if (this.isListening) return;

        try {
            this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 512;
            this.analyser.smoothingTimeConstant = 0.4;
            
            this.microphone = this.audioContext.createMediaStreamSource(this.stream);
            this.microphone.connect(this.analyser);
            
            this.isListening = true;
            this.analyze();
            
            console.log("[VAD] Service started.");
        } catch (e) {
            console.error("[VAD] Failed to start:", e);
        }
    }

    private analyze = () => {
        if (!this.isListening || !this.analyser) return;

        const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
        this.analyser.getByteFrequencyData(dataArray);

        // Calculate Average Volume (RMS approximation)
        let sum = 0;
        for(let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
        }
        const average = sum / dataArray.length;
        
        // Normalize 0-100 for UI
        const visualEnergy = Math.min(100, (average / 255) * 100 * 2); // Boost visually
        if (this.onEnergy) this.onEnergy(visualEnergy);

        // Logic for VAD
        // Convert to dB approx for thresholding (simplistic)
        // Note: dataArray is 0-255. 0 is -infinity dB, 255 is 0 dB.
        // Approx: dB = 20 * log10(val / 255)
        // But linear average is easier to tune for simple VAD.
        
        const SPEECH_LEVEL = 15; // 0-255 scale (approx noise floor)

        if (average > SPEECH_LEVEL) {
            this.silenceStart = 0;
            if (!this.isSpeaking) {
                this.isSpeaking = true;
                if (this.onSpeechStart) this.onSpeechStart();
                console.log("[VAD] Speech Detected");
            }
        } else {
            if (this.isSpeaking) {
                if (this.silenceStart === 0) {
                    this.silenceStart = Date.now();
                } else if (Date.now() - this.silenceStart > this.SILENCE_DURATION) {
                    this.isSpeaking = false;
                    this.silenceStart = 0;
                    if (this.onSpeechEnd) this.onSpeechEnd();
                    console.log("[VAD] Silence Detected (Speech Ended)");
                }
            }
        }

        this.animationFrameId = requestAnimationFrame(this.analyze);
    };

    stop() {
        this.isListening = false;
        if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
        
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        
        console.log("[VAD] Service stopped.");
    }
}

export const vadService = new VADService();
