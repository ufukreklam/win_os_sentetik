# Cursor Rules - React Theme Behavior

You are working on a React-based UI theme that mimics:
- Windows 11 desktop layout
- iOS-style topbar
- Modern glassmorphism UI principles

## RULES

1. **Layout Architecture**
   - Always separate UI into:
     - TopBar (iOS-like, fixed, translucent)
     - MainContent (desktop/workspace area)
     - StatusBar (Windows 11 style, bottom fixed)
     - StartMenu (centered modal/drawer)

2. **Component Philosophy**
   - Every UI element MUST be a reusable React component
   - No inline layout logic inside pages
   - Layout logic lives in Layout components

3. **Visual Language**
   - Use glassmorphism by default:
     - `backdrop-filter: blur()`
     - subtle transparency
   - Avoid heavy borders
   - Prefer shadows and elevation

4. **State Management**
   - StartMenu visibility is global state
   - Time, locale, system status are derived state
   - Avoid prop-drilling for layout state

5. **Responsiveness**
   - Desktop-first
   - Tablet: collapse StartMenu
   - Mobile: TopBar remains, StatusBar hidden

6. **Naming Conventions**
   - Components: PascalCase
   - Hooks: useSomething
   - Layout wrappers must include "Layout" in name

7. **NO random UI decisions**
   - Always follow Windows 11 + iOS hybrid logic