import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Activity, Cpu, Layers, Search, Zap, Thermometer, Fan, Server, Box, Stethoscope, CheckCircle, AlertTriangle, AlertCircle, RefreshCw } from 'lucide-react';
import { PerformanceMode, WindowState } from '../../types';

const TaskManagerApp: React.FC = () => {
  const { windows, closeApp, crashSystem, performanceState, setPerformanceMode, toggleAutoTuning, runDiagnostics } = useOS();
  const [activeTab, setActiveTab] = useState<'processes' | 'performance' | 'tuning' | 'diagnostics'>('performance');
  const [selectedTask, setSelectedTask] = useState<string | null>(null);

  // Background processes simulation (Static list for now)
  const SYSTEM_PROCESSES = [
      { id: 'sys_kernel', name: 'System Kernel', cpu: 0.5, mem: 120, critical: true },
      { id: 'sys_win_mgr', name: 'Window Manager', cpu: 1.2, mem: 250, critical: true },
      { id: 'sys_net', name: 'Network Service', cpu: 0.1, mem: 45, critical: false },
      { id: 'sys_audio', name: 'Audio Daemon', cpu: 0.3, mem: 30, critical: false },
      { id: 'sys_ai', name: 'Gemini AI Agent', cpu: 0.0, mem: 450, critical: false },
  ];

  const activeApps = (Object.values(windows) as WindowState[]).filter(w => w.isOpen).map(w => ({
      id: w.id,
      name: w.title,
      icon: w.icon,
      cpu: Math.random() * 5 + 0.1,
      mem: Math.random() * 100 + 50
  }));

  const handleEndTask = () => {
      if (!selectedTask) return;
      
      const sysProc = SYSTEM_PROCESSES.find(p => p.id === selectedTask);
      if (sysProc) {
          if (sysProc.critical) {
              crashSystem('CRITICAL_PROCESS_DIED');
          } else {
              setSelectedTask(null);
          }
          return;
      }

      if (Object.values(windows).find(w => w.id === selectedTask)) {
          closeApp(selectedTask as any);
      }
      setSelectedTask(null);
  };

  const getHealthColor = (score: number) => {
      if (score > 90) return 'text-green-400';
      if (score > 70) return 'text-yellow-400';
      return 'text-red-400';
  };

  const CoreVisualizer = () => (
      <div className="grid grid-cols-2 gap-4">
          {performanceState.cores.map(core => (
              <div key={core.id} className="bg-slate-800/50 rounded-lg p-3 border border-white/5 relative overflow-hidden">
                  <div className="flex justify-between items-center mb-2 z-10 relative">
                      <span className="text-xs font-bold text-slate-400">CORE {core.id}</span>
                      <span className="text-xs font-mono">{core.usage.toFixed(0)}%</span>
                  </div>
                  <div className="h-16 flex items-end gap-1">
                      {[...Array(20)].map((_, i) => {
                          const height = Math.random() * core.usage;
                          return (
                              <div 
                                  key={i} 
                                  className="flex-1 bg-blue-500/50 rounded-t-sm transition-all duration-300"
                                  style={{ height: `${height}%` }}
                              />
                          );
                      })}
                  </div>
                  <div className="mt-2 flex justify-between text-[10px] text-slate-500 z-10 relative">
                      <span>{core.frequency} GHz</span>
                      <span className={core.temp > 70 ? 'text-red-400' : 'text-slate-500'}>{core.temp.toFixed(1)}°C</span>
                  </div>
              </div>
          ))}
      </div>
  );

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 font-sans">
      {/* Sidebar */}
      <div className="w-16 md:w-48 bg-slate-900/95 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2">
          <button 
            onClick={() => setActiveTab('processes')}
            className={`p-3 md:px-4 md:py-2 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'processes' ? 'border-l-2 border-blue-500 bg-white/5' : ''}`}
          >
              <Layers size={20} className="text-blue-400" />
              <span className="hidden md:inline text-sm font-medium">Processes</span>
          </button>
          <button 
            onClick={() => setActiveTab('performance')}
            className={`p-3 md:px-4 md:py-2 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'performance' ? 'border-l-2 border-blue-500 bg-white/5' : ''}`}
          >
              <Activity size={20} className="text-green-400" />
              <span className="hidden md:inline text-sm font-medium">Performance</span>
          </button>
          <button 
            onClick={() => setActiveTab('tuning')}
            className={`p-3 md:px-4 md:py-2 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'tuning' ? 'border-l-2 border-blue-500 bg-white/5' : ''}`}
          >
              <Zap size={20} className="text-yellow-400" />
              <span className="hidden md:inline text-sm font-medium">Optimization</span>
          </button>
          <button 
            onClick={() => setActiveTab('diagnostics')}
            className={`p-3 md:px-4 md:py-2 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'diagnostics' ? 'border-l-2 border-blue-500 bg-white/5' : ''}`}
          >
              <Stethoscope size={20} className="text-pink-400" />
              <span className="hidden md:inline text-sm font-medium">Diagnostics</span>
          </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col min-w-0">
          {activeTab === 'processes' && (
              <>
                <div className="h-12 border-b border-white/5 flex items-center justify-between px-4 bg-slate-900/50">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
                        <input type="text" placeholder="Filter processes" className="bg-black/20 border border-white/10 rounded-full py-1.5 pl-8 pr-4 text-xs focus:outline-none focus:border-blue-500 w-48" />
                    </div>
                    <button 
                        onClick={handleEndTask}
                        disabled={!selectedTask}
                        className="text-xs bg-slate-800 hover:bg-red-900/50 hover:text-red-400 border border-white/10 px-3 py-1.5 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        End Task
                    </button>
                </div>
                
                <div className="flex-1 overflow-y-auto">
                    <table className="w-full text-xs text-left">
                        <thead className="bg-slate-950/50 sticky top-0 backdrop-blur-md z-10">
                            <tr>
                                <th className="px-4 py-2 font-medium text-slate-400">Name</th>
                                <th className="px-4 py-2 font-medium text-slate-400 w-20">Status</th>
                                <th className="px-4 py-2 font-medium text-slate-400 w-20">CPU</th>
                                <th className="px-4 py-2 font-medium text-slate-400 w-24">Memory</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="bg-slate-800/30"><td colSpan={4} className="px-4 py-1 text-[10px] font-bold text-slate-500 uppercase">Apps ({activeApps.length})</td></tr>
                            {activeApps.map(app => (
                                <tr 
                                    key={app.id} 
                                    onClick={() => setSelectedTask(app.id)}
                                    className={`border-b border-white/5 cursor-pointer hover:bg-white/5 ${selectedTask === app.id ? 'bg-blue-600/20' : ''}`}
                                >
                                    <td className="px-4 py-2 flex items-center gap-2">
                                        <app.icon size={14} className="text-blue-400" />
                                        {app.name}
                                    </td>
                                    <td className="px-4 py-2 text-green-400">Running</td>
                                    <td className="px-4 py-2">{app.cpu.toFixed(1)}%</td>
                                    <td className="px-4 py-2">{app.mem.toFixed(0)} MB</td>
                                </tr>
                            ))}

                            <tr className="bg-slate-800/30"><td colSpan={4} className="px-4 py-1 text-[10px] font-bold text-slate-500 uppercase mt-4">Background Processes ({SYSTEM_PROCESSES.length})</td></tr>
                            {SYSTEM_PROCESSES.map(proc => (
                                <tr 
                                    key={proc.id} 
                                    onClick={() => setSelectedTask(proc.id)}
                                    className={`border-b border-white/5 cursor-pointer hover:bg-white/5 ${selectedTask === proc.id ? 'bg-blue-600/20' : ''} ${proc.critical ? 'text-red-300' : 'text-slate-300'}`}
                                >
                                    <td className="px-4 py-2 flex items-center gap-2">
                                        <Box size={14} className={proc.critical ? 'text-red-400' : 'text-slate-500'} />
                                        {proc.name}
                                    </td>
                                    <td className="px-4 py-2 text-slate-500">Service</td>
                                    <td className="px-4 py-2">{proc.cpu.toFixed(1)}%</td>
                                    <td className="px-4 py-2">{proc.mem} MB</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
              </>
          )}

          {activeTab === 'performance' && (
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {/* Overall Status */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                          <div className="text-xs text-slate-400 uppercase font-bold mb-1">Total Load</div>
                          <div className="text-2xl font-light">{performanceState.cores.reduce((a, b) => a + b.usage, 0) / 4}%</div>
                      </div>
                      <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                          <div className="text-xs text-slate-400 uppercase font-bold mb-1">NPU Load</div>
                          <div className="text-2xl font-light text-purple-400">{performanceState.npuLoad.toFixed(0)}%</div>
                      </div>
                      <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                          <div className="text-xs text-slate-400 uppercase font-bold mb-1">Fan Speed</div>
                          <div className="text-2xl font-light flex items-center gap-2">
                              {performanceState.fanSpeed.toFixed(0)}%
                              <Fan size={16} className={`text-slate-500 ${performanceState.fanSpeed > 50 ? 'animate-spin' : ''}`} />
                          </div>
                      </div>
                      <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                          <div className="text-xs text-slate-400 uppercase font-bold mb-1">System Health</div>
                          <div className={`text-2xl font-light ${getHealthColor(performanceState.systemHealth)}`}>
                              {performanceState.systemHealth}%
                          </div>
                      </div>
                  </div>
                  
                  {/* Predictive Load */}
                  <div className="bg-blue-900/10 border border-blue-500/20 rounded-xl p-4 flex items-center justify-between">
                       <div>
                           <h3 className="text-sm font-bold text-blue-400">Predictive Load Analytics</h3>
                           <p className="text-xs text-slate-400">Forecasted system usage for next minute based on current trend.</p>
                       </div>
                       <div className="text-right">
                           <div className="text-2xl font-mono text-blue-300">{performanceState.predictedLoad.toFixed(0)}%</div>
                           <div className="text-[10px] text-blue-500 uppercase tracking-widest">Expected</div>
                       </div>
                  </div>

                  {/* CPU Cores */}
                  <div>
                      <h3 className="text-sm font-bold text-slate-400 mb-3 flex items-center gap-2">
                          <Cpu size={16} /> Processor (Broadcom BCM2712)
                      </h3>
                      <CoreVisualizer />
                  </div>

                  {/* NPU & Memory */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white/5 border border-white/5 rounded-xl p-4">
                          <h3 className="text-sm font-bold text-slate-400 mb-3 flex items-center gap-2">
                              <Server size={16} /> Neural Processing Unit
                          </h3>
                          <div className="flex items-end h-32 gap-1 mb-2 bg-slate-950/30 rounded p-2">
                              {[...Array(30)].map((_, i) => (
                                  <div 
                                      key={i} 
                                      className="flex-1 bg-purple-500/50 rounded-t-sm"
                                      style={{ height: `${Math.random() * performanceState.npuLoad}%` }}
                                  />
                              ))}
                          </div>
                          <div className="text-xs text-slate-500">12 TOPS AI Accelerator</div>
                      </div>

                      <div className="bg-white/5 border border-white/5 rounded-xl p-4">
                          <h3 className="text-sm font-bold text-slate-400 mb-3">Memory (RAM)</h3>
                          <div className="flex items-center gap-4 mb-4">
                              <div className="flex-1">
                                  <div className="flex justify-between text-xs mb-1">
                                      <span>Used</span>
                                      <span>{performanceState.ramUsage} MB</span>
                                  </div>
                                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                                      <div className="h-full bg-blue-500" style={{ width: `${(performanceState.ramUsage / 4096) * 100}%` }} />
                                  </div>
                              </div>
                          </div>
                          <div className="text-xs text-slate-500">
                              <div>Total: 4.0 GB</div>
                              <div>Type: LPDDR4X</div>
                          </div>
                      </div>
                  </div>
              </div>
          )}

          {activeTab === 'tuning' && (
              <div className="flex-1 overflow-y-auto p-6 space-y-8">
                  <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold mb-2">Power Plan</h2>
                        <p className="text-sm text-slate-400 mb-6">Adjust system performance to balance speed and power consumption.</p>
                    </div>
                    
                    <div className="flex flex-col items-end">
                         <div className="flex items-center gap-3 bg-white/5 p-2 rounded-lg border border-white/10">
                            <span className="text-xs font-bold text-slate-400 uppercase">Auto-Tuning</span>
                            <button 
                                onClick={toggleAutoTuning}
                                className={`w-10 h-5 rounded-full relative transition-colors ${performanceState.autoTuningEnabled ? 'bg-green-500' : 'bg-slate-600'}`}
                            >
                                <div className={`absolute top-1 left-1 w-3 h-3 bg-white rounded-full transition-transform ${performanceState.autoTuningEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                            </button>
                         </div>
                    </div>
                  </div>
                      
                  <div className="grid grid-cols-3 gap-4">
                      {(['eco', 'balanced', 'high_perf'] as PerformanceMode[]).map(mode => (
                          <button
                              key={mode}
                              onClick={() => setPerformanceMode(mode)}
                              className={`
                                  p-4 rounded-xl border flex flex-col items-center gap-3 transition-all
                                  ${performanceState.mode === mode 
                                      ? 'bg-blue-600/20 border-blue-500 ring-1 ring-blue-500' 
                                      : 'bg-white/5 border-white/10 hover:bg-white/10'}
                              `}
                          >
                              {mode === 'eco' ? <Zap size={24} className="text-green-400" /> :
                               mode === 'balanced' ? <Activity size={24} className="text-blue-400" /> :
                               <RocketIcon size={24} className="text-red-400" />}
                              <span className="capitalize font-bold text-sm">
                                  {mode.replace('_', ' ')}
                              </span>
                          </button>
                      ))}
                  </div>

                  <div className="bg-slate-800/50 border border-white/5 rounded-xl p-6">
                      <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
                          <Thermometer size={16} className="text-orange-400" /> Thermal Throttle Check
                      </h3>
                      <div className="flex items-center gap-4">
                          <div className="flex-1 h-2 bg-slate-900 rounded-full overflow-hidden">
                              <div 
                                  className="h-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500" 
                                  style={{ width: `${Math.max(...performanceState.cores.map(c => c.temp))}%` }}
                              />
                          </div>
                          <span className="text-sm font-mono">{Math.max(...performanceState.cores.map(c => c.temp)).toFixed(1)}°C</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">
                          System will automatically throttle CPU frequency if temperature exceeds 80°C.
                      </p>
                  </div>
                  
                  {/* Optimization Log */}
                  <div>
                      <h3 className="text-sm font-bold text-slate-400 mb-3 uppercase tracking-wider">Optimization Log</h3>
                      <div className="bg-black/20 rounded-xl border border-white/5 overflow-hidden">
                          {performanceState.optimizationLog.length === 0 ? (
                              <div className="p-4 text-xs text-slate-500 italic text-center">No optimization events recorded yet.</div>
                          ) : (
                              performanceState.optimizationLog.map(log => (
                                  <div key={log.id} className="p-3 border-b border-white/5 flex justify-between items-center text-xs">
                                      <div className="flex items-center gap-3">
                                          <div className={`p-1.5 rounded-full ${log.type === 'auto' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                                              <RefreshCw size={12} />
                                          </div>
                                          <div>
                                              <div className="font-bold text-slate-200">{log.action}</div>
                                              <div className="text-slate-500">{log.timestamp.toLocaleTimeString()}</div>
                                          </div>
                                      </div>
                                      <div className="text-green-400 font-mono">{log.impact}</div>
                                  </div>
                              ))
                          )}
                      </div>
                  </div>
              </div>
          )}
          
          {activeTab === 'diagnostics' && (
              <div className="flex-1 p-6 overflow-y-auto">
                  <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-bold">System Diagnostics</h2>
                      <button 
                        onClick={runDiagnostics}
                        className="flex items-center gap-2 px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white rounded-lg text-xs font-bold transition-all"
                      >
                          <RefreshCw size={14} /> Run Scan
                      </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {performanceState.diagnostics.map(diag => (
                          <div key={diag.id} className="bg-white/5 border border-white/5 rounded-xl p-4 flex items-start gap-4">
                              <div className={`p-3 rounded-full shrink-0 ${
                                  diag.status === 'healthy' ? 'bg-green-500/20 text-green-400' : 
                                  diag.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' : 
                                  'bg-red-500/20 text-red-400'
                              }`}>
                                  {diag.status === 'healthy' ? <CheckCircle size={20} /> : 
                                   diag.status === 'warning' ? <AlertTriangle size={20} /> : 
                                   <AlertCircle size={20} />}
                              </div>
                              <div className="flex-1">
                                  <h3 className="font-bold text-sm">{diag.component}</h3>
                                  <p className="text-xs text-slate-400 mt-1">{diag.message}</p>
                                  <div className="text-[10px] text-slate-600 mt-2 font-mono">Last Check: {diag.lastCheck.toLocaleTimeString()}</div>
                              </div>
                              <div className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded bg-black/20 ${
                                  diag.status === 'healthy' ? 'text-green-400' : 
                                  diag.status === 'warning' ? 'text-yellow-400' : 
                                  'text-red-400'
                              }`}>
                                  {diag.status}
                              </div>
                          </div>
                      ))}
                  </div>
                  
                  <div className="mt-8 bg-slate-800/50 p-6 rounded-xl border border-white/5">
                      <h3 className="text-sm font-bold mb-4">Self-Healing Status</h3>
                      <div className="space-y-4">
                          <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-400">Automatic Recovery</span>
                              <span className="text-green-400 font-bold">ACTIVE</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-400">Watchdog Timer</span>
                              <span className="text-green-400 font-bold">ARMED</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-400">Last Recovery Action</span>
                              <span className="text-slate-300">None (System Stable)</span>
                          </div>
                      </div>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};

// Helper Icon
const RocketIcon = ({ size, className }: { size: number, className?: string }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} 
        height={size} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        className={className}
    >
        <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
        <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
        <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
        <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
    </svg>
);

export default TaskManagerApp;