
import React, { useState, useEffect, useCallback } from 'react';
import { History, Trash2, ChevronRight } from 'lucide-react';

interface HistoryItem {
  expression: string;
  result: string;
}

const CalculatorApp: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const handleNumber = useCallback((num: string) => {
    setDisplay(prev => {
      if (waitingForNewValue) {
        return num;
      }
      return prev === '0' ? num : prev + num;
    });
    if (waitingForNewValue) setWaitingForNewValue(false);
  }, [waitingForNewValue]);

  const calculate = (prev: string | null, current: string, op: string | null) => {
    const a = parseFloat(prev || '0');
    const b = parseFloat(current);
    if (isNaN(a) || isNaN(b)) return 0;

    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return b === 0 ? 'Error' : a / b;
      default: return b;
    }
  };

  const handleOperator = useCallback((op: string) => {
    setDisplay(prevDisplay => {
        if (operator && !waitingForNewValue && previousValue) {
            const result = calculate(previousValue, prevDisplay, operator);
            const resultStr = String(result);
            
            // Add intermediate calculation to history
            setHistory(prev => [...prev, { 
                expression: `${previousValue} ${operator} ${prevDisplay}`, 
                result: resultStr 
            }]);

            setPreviousValue(resultStr);
            return resultStr;
        }
        setPreviousValue(prevDisplay);
        return prevDisplay;
    });
    setOperator(op);
    setWaitingForNewValue(true);
  }, [operator, waitingForNewValue, previousValue]);

  const handleEqual = useCallback(() => {
    if (!operator || !previousValue) return;
    
    const currentDisplay = display;
    const result = calculate(previousValue, currentDisplay, operator);
    const resultStr = String(result);

    setHistory(prev => [...prev, { 
        expression: `${previousValue} ${operator} ${currentDisplay}`, 
        result: resultStr 
    }]);
    
    setDisplay(resultStr);
    setPreviousValue(null);
    setOperator(null);
    setWaitingForNewValue(true);
  }, [operator, previousValue, display]);

  const handleClear = useCallback(() => {
    setDisplay('0');
    setPreviousValue(null);
    setOperator(null);
    setWaitingForNewValue(false);
  }, []);

  const handleBackspace = useCallback(() => {
    if (waitingForNewValue) return;
    setDisplay(prev => {
        if (prev.length === 1 || (prev.startsWith('-') && prev.length === 2) || prev === 'Error') {
            return '0';
        }
        return prev.slice(0, -1);
    });
  }, [waitingForNewValue]);

  const handlePercentage = () => {
    const value = parseFloat(display);
    setDisplay(String(value / 100));
  };

  const handleSign = () => {
    const value = parseFloat(display);
    setDisplay(String(value * -1));
  };

  // Keyboard Support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;

      if (/^[0-9]$/.test(key)) {
        handleNumber(key);
      } else if (key === '.' || key === ',') {
        if (!display.includes('.')) handleNumber('.');
      } else if (['+', '-', '/', '*', 'x'].includes(key)) {
        const opMap: Record<string, string> = { '*': '×', 'x': '×', '/': '÷', '+': '+', '-': '-' };
        handleOperator(opMap[key] || key);
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleEqual();
      } else if (key === 'Escape' || key === 'Delete') {
        handleClear();
      } else if (key === 'Backspace') {
        handleBackspace();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, handleNumber, handleOperator, handleEqual, handleClear, handleBackspace]);

  const Button = ({ 
    label, 
    onClick, 
    className = "", 
    isOperator = false, 
    isAction = false 
  }: { 
    label: string; 
    onClick: () => void; 
    className?: string; 
    isOperator?: boolean;
    isAction?: boolean;
  }) => (
    <button
      onClick={onClick}
      className={`
        h-full w-full rounded-xl text-xl font-medium transition-all duration-150 active:scale-95 flex items-center justify-center
        ${isOperator 
            ? 'bg-blue-600 hover:bg-blue-500 text-white' 
            : isAction 
                ? 'bg-slate-300 hover:bg-slate-200 text-slate-900' 
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-white/5'}
        ${className}
      `}
    >
      {label}
    </button>
  );

  return (
    <div className="h-full w-full bg-slate-950 flex font-sans overflow-hidden relative">
      {/* Main Calculator Area */}
      <div className="flex-1 flex flex-col p-2 select-none min-w-0">
          {/* Display */}
          <div className="flex-shrink-0 flex flex-col justify-end items-end mb-2 px-2 min-h-[80px] h-[25%] relative group">
             {/* History Toggle */}
             <button 
                onClick={() => setShowHistory(!showHistory)}
                className={`absolute top-0 left-0 p-2 rounded-lg transition-colors ${showHistory ? 'text-blue-400 bg-white/5' : 'text-slate-500 hover:text-slate-300'}`}
                title="History"
             >
                 <History size={20} />
             </button>

             <div className="text-slate-400 text-sm h-6 flex gap-1 font-mono">
                <span>{previousValue}</span>
                <span>{operator}</span>
             </div>
             <div 
                className={`font-light text-white truncate w-full text-right tracking-tight transition-all duration-200
                    ${display.length > 10 ? 'text-3xl' : display.length > 7 ? 'text-4xl' : 'text-5xl'}
                `}
             >
                {display}
             </div>
          </div>

          {/* Keypad */}
          <div className="flex-1 grid grid-cols-4 gap-2 min-h-0">
            <Button label={display === '0' ? 'AC' : 'C'} onClick={handleClear} isAction />
            <Button label="±" onClick={handleSign} isAction />
            <Button label="%" onClick={handlePercentage} isAction />
            <Button label="÷" onClick={() => handleOperator('÷')} isOperator className={operator === '÷' ? 'ring-2 ring-white/50' : ''} />

            <Button label="7" onClick={() => handleNumber('7')} />
            <Button label="8" onClick={() => handleNumber('8')} />
            <Button label="9" onClick={() => handleNumber('9')} />
            <Button label="×" onClick={() => handleOperator('×')} isOperator className={operator === '×' ? 'ring-2 ring-white/50' : ''} />

            <Button label="4" onClick={() => handleNumber('4')} />
            <Button label="5" onClick={() => handleNumber('5')} />
            <Button label="6" onClick={() => handleNumber('6')} />
            <Button label="-" onClick={() => handleOperator('-')} isOperator className={operator === '-' ? 'ring-2 ring-white/50' : ''} />

            <Button label="1" onClick={() => handleNumber('1')} />
            <Button label="2" onClick={() => handleNumber('2')} />
            <Button label="3" onClick={() => handleNumber('3')} />
            <Button label="+" onClick={() => handleOperator('+')} isOperator className={operator === '+' ? 'ring-2 ring-white/50' : ''} />

            <Button label="0" onClick={() => handleNumber('0')} className="col-span-2 !w-auto" />
            <Button label="." onClick={() => !display.includes('.') && handleNumber('.')} />
            <Button label="=" onClick={handleEqual} isOperator />
          </div>
      </div>

      {/* History Sidebar */}
      <div 
        className={`
            absolute top-0 right-0 h-full bg-slate-900/95 backdrop-blur-xl border-l border-white/10 z-10 transition-all duration-300 flex flex-col
            ${showHistory ? 'w-64 translate-x-0' : 'w-64 translate-x-full pointer-events-none'}
        `}
      >
          <div className="h-10 flex items-center justify-between px-4 border-b border-white/5 shrink-0">
              <span className="text-sm font-medium text-slate-300">History</span>
              <button 
                onClick={() => setHistory([])} 
                className="p-1.5 hover:bg-white/10 rounded-md text-slate-500 hover:text-red-400 transition-colors"
                title="Clear History"
              >
                  <Trash2 size={14} />
              </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {history.length === 0 ? (
                  <div className="text-center text-slate-600 text-xs italic mt-10">No history yet</div>
              ) : (
                  history.slice().reverse().map((item, idx) => (
                      <div key={idx} className="group flex flex-col items-end gap-1 cursor-pointer hover:bg-white/5 p-2 rounded-lg transition-colors" onClick={() => {
                          setDisplay(item.result);
                          setShowHistory(false);
                      }}>
                          <div className="text-xs text-slate-400 font-mono">{item.expression} =</div>
                          <div className="text-lg font-light text-white">{item.result}</div>
                      </div>
                  ))
              )}
          </div>

          <button 
            onClick={() => setShowHistory(false)}
            className="absolute top-1/2 -left-3 w-6 h-12 bg-slate-700 rounded-l-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-600 shadow-lg"
          >
              <ChevronRight size={14} />
          </button>
      </div>
    </div>
  );
};

export default CalculatorApp;
