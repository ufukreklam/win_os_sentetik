
import { IdentityTrait, CoreEmotion } from "../types";

// OCEAN Modeli (Big Five)
export type BigFiveTrait = 'Openness' | 'Conscientiousness' | 'Extraversion' | 'Agreeableness' | 'Neuroticism';

interface TraitDefinition {
    name: BigFiveTrait;
    description: string;
    value: number; // 0-100 (Base value)
    volatility: number; // 0-1 (Ne kadar hızlı değişebileceği)
}

class PersonalityService {
    private traits: Record<BigFiveTrait, TraitDefinition> = {
        'Openness': { 
            name: 'Openness', 
            description: 'Yaratıcılık, merak ve yeni deneyimlere açıklık.', 
            value: 75, 
            volatility: 0.1 
        },
        'Conscientiousness': { 
            name: 'Conscientiousness', 
            description: 'Disiplin, düzen ve sorumluluk bilinci.', 
            value: 80, 
            volatility: 0.05 
        },
        'Extraversion': { 
            name: 'Extraversion', 
            description: 'Sosyallik, enerji ve dışa dönüklük.', 
            value: 60, 
            volatility: 0.2 
        },
        'Agreeableness': { 
            name: 'Agreeableness', 
            description: 'Uyumluluk, güven ve işbirliği.', 
            value: 70, 
            volatility: 0.15 
        },
        'Neuroticism': { 
            name: 'Neuroticism', 
            description: 'Duygusal dengesizlik ve stres tepkisi.', 
            value: 30, 
            volatility: 0.3 
        }
    };

    // Geçmiş değişimleri takip etmek için
    private history: { timestamp: number, traits: Record<BigFiveTrait, number> }[] = [];

    constructor() {
        // Başlangıç tarihçesi
        this.logHistory();
    }

    /**
     * Mevcut kişilik özelliklerini UI formatında döndürür.
     */
    getTraits(): IdentityTrait[] {
        return Object.values(this.traits).map(t => ({
            name: t.name,
            value: t.value,
            modifier: 0 // Dinamik modifier şimdilik ana değere işleniyor
        }));
    }

    /**
     * Bir deneyim veya etkileşime göre kişiliği günceller.
     * @param type Etkileşim türü
     * @param impact Etki gücü (-1.0 ile 1.0 arası)
     */
    evolve(type: 'social_success' | 'social_failure' | 'stress' | 'creativity' | 'achievement', impact: number) {
        const adjustment = impact * 2; // Temel değişim katsayısı

        switch (type) {
            case 'social_success':
                this.updateTrait('Extraversion', adjustment);
                this.updateTrait('Agreeableness', adjustment * 0.5);
                this.updateTrait('Neuroticism', -adjustment * 0.5); // Güven artar, kaygı azalır
                break;
            case 'social_failure':
                this.updateTrait('Extraversion', -adjustment);
                this.updateTrait('Neuroticism', adjustment);
                break;
            case 'stress':
                this.updateTrait('Neuroticism', adjustment);
                this.updateTrait('Conscientiousness', -adjustment * 0.5); // Stres altında düzen bozulabilir
                break;
            case 'creativity':
                this.updateTrait('Openness', adjustment);
                break;
            case 'achievement':
                this.updateTrait('Conscientiousness', adjustment);
                this.updateTrait('Neuroticism', -adjustment * 0.2);
                break;
        }

        this.logHistory();
    }

    /**
     * Duygusal duruma göre geçici kişilik dalgalanmaları yaratır.
     * @param emotion Mevcut duygu
     */
    applyEmotionalBias(emotion: CoreEmotion) {
        // Bu metod kalıcı değişiklik yapmaz, sadece o anki tepkileri etkileyecek geçici sapmalar hesaplar
        // (İleride implemente edilebilir)
    }

    private updateTrait(trait: BigFiveTrait, delta: number) {
        const target = this.traits[trait];
        // Volatiliteye göre değişim miktarını ayarla
        const actualChange = delta * target.volatility;
        
        // Sınırları koru (0-100)
        target.value = Math.max(0, Math.min(100, target.value + actualChange));
    }

    private logHistory() {
        const snapshot: Record<string, number> = {};
        Object.keys(this.traits).forEach(key => {
            snapshot[key] = this.traits[key as BigFiveTrait].value;
        });
        
        this.history.push({
            timestamp: Date.now(),
            traits: snapshot as Record<BigFiveTrait, number>
        });

        // Son 50 kaydı tut
        if (this.history.length > 50) this.history.shift();
    }

    getHistory() {
        return this.history;
    }
}

export const personalityService = new PersonalityService();
