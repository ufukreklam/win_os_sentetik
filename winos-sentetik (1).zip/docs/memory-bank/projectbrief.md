# Proje Özeti: WinOS Hybrid HRI Arayüzü

## Genel Bakış
WinOS Hybrid, karmaşık robotik platformlar için tasarlanmış, **Windows 11 masaüstü mekanikleri** ile **iOS estetik prensiplerini** birleştiren gelişmiş bir **HRI (İnsan-Robot Etkileşimi) ve Telemetri Arayüzüdür**.

Bu proje, sadece görsel bir "İşletim Sistemi" teması değil; arka planda (Raspberry Pi 5 / Python) çalışan gerçek yapay zeka ve donanım katmanlarının **görselleştirilmesi, kontrolü ve simülasyonu** için kullanılan React tabanlı "Bilinçli Yüz" (Conscious Face) katmanıdır.

## Temel Hedefler
1.  **Hibrit UI Paradigması**: Masaüstü üretkenliğini (pencere yönetimi, çoklu görev) ve mobil sadeliği (dokunmatik dostu, widgetlar) birleştiren bir kontrol paneli sunmak.
2.  **Dijital İkiz (Digital Twin) Görselleştirmesi**: Arka plandaki 16 katmanlı AI yapısının (Duygu, Hafıza, Algı) ve donanım durumunun (Lidar, Batarya, Motorlar) görsel karşılığını anlık olarak sunmak.
3.  **Simülasyon ve Gerçeklik Köprüsü**: Donanım bağlı olmadığında fizik kurallarına dayalı tutarlı simülasyonlar sunmak; donanım bağlandığında Web Serial API üzerinden gerçek zamanlı kontrol sağlamak.
4.  **AI Arayüzü**: Google Gemini (Bulut) ve Yerel LLM modelleri (Llama-3 vb.) için birleşik bir etkileşim katmanı oluşturmak.

## Ana Özellikler
- **Dashboard (React)**: Sistem durumu, sensör verileri ve AI düşünce süreçlerinin izlendiği ana ekran.
- **Hardware Bridge (Web Serial)**: Tarayıcı ve Robot (Master RPi5 + Slave Pico Cluster) arasındaki veri köprüsü.
- **Mocking Engine**: Donanım yokluğunda geliştirme yapılabilmesi için gerçekçi veri simülatörleri (Pil tüketimi, Isınma vb.).
- **Window System**: Karmaşık verileri organize etmek için geliştirilmiş pencere yöneticisi.
- **16 Katmanlı AI Görselleştirme**: Bilinç, Duygu, Sosyal, Güvenlik gibi soyut katmanların somut arayüzleri.