
import { PluginMetadata } from '../types';

// Mock Repository of Plugins available for download
export const AVAILABLE_PLUGINS: PluginMetadata[] = [
    {
        id: 'skill_chess',
        name: 'DeepBlue Chess',
        version: '2.4.0',
        author: 'IBM Legacy',
        description: 'Advanced chess engine skill module. Adds strategic planning capabilities to Layer 8.',
        type: 'skill',
        permissions: ['cpu', 'memory'],
        downloadSize: '45 MB'
    },
    {
        id: 'driver_lidar_v2',
        name: 'Lidar HD+',
        version: '1.2.1',
        author: 'RoboSense',
        description: 'Enhanced point cloud resolution driver for Xiaomi Mijia 1S. Supports 360° mapping at 10Hz.',
        type: 'driver',
        permissions: ['hardware', 'serial'],
        downloadSize: '12 MB'
    },
    {
        id: 'theme_cyber',
        name: 'Neon Night City',
        version: '1.0.0',
        author: 'WinOS Community',
        description: 'A dark, high-contrast theme optimized for night operations and OLED displays.',
        type: 'theme',
        permissions: ['display'],
        downloadSize: '8 MB'
    },
    {
        id: 'skill_med',
        name: 'MediBot Base',
        version: '0.9.5',
        author: 'HealthCorp',
        description: 'First aid and symptom analysis knowledge graph extension.',
        type: 'skill',
        permissions: ['knowledge_graph'],
        downloadSize: '120 MB'
    },
    {
        id: 'driver_arm',
        name: '6-DOF Arm IK',
        version: '3.0.0',
        author: 'Kinematics Lab',
        description: 'Inverse Kinematics solver for 6-degree-of-freedom robotic arms.',
        type: 'driver',
        permissions: ['motor_control'],
        downloadSize: '25 MB'
    }
];

export const getPlugins = (): Promise<PluginMetadata[]> => {
    return new Promise((resolve) => {
        setTimeout(() => resolve(AVAILABLE_PLUGINS), 800);
    });
};
