
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Cable, Activity, Database, Server, Cpu, ArrowDown, Play, Square, Settings, Terminal, Info } from 'lucide-react';
import { SubsystemStatus, HardwareDriver } from '../../types';

const BridgeApp: React.FC = () => {
  const { bridgeState, sendBridgeCommand, serialStatus } = useOS();
  const [activeTab, setActiveTab] = useState<'stream' | 'protocol' | 'drivers' | 'health'>('stream');
  const [isCapturing, setIsCapturing] = useState(true);
  const [testCmd, setTestCmd] = useState('ping');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll
  useEffect(() => {
      if (activeTab === 'stream' && scrollRef.current && isCapturing) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
  }, [bridgeState.packets, activeTab, isCapturing]);

  const handleSendTest = (e: React.FormEvent) => {
      e.preventDefault();
      if (!testCmd.trim()) return;
      sendBridgeCommand(testCmd, { timestamp: Date.now() });
      setTestCmd('');
  };

  const getPacketColor = (type: string, direction: string) => {
      if (type === 'error') return 'text-red-400';
      if (direction === 'TX') return 'text-blue-400';
      return 'text-green-400';
  };

  const DriverCard: React.FC<{ driver: HardwareDriver }> = ({ driver }) => (
      <div className="bg-white/5 border border-white/5 rounded-xl p-3 flex justify-between items-center group hover:bg-white/10 transition-colors">
          <div className="flex items-center gap-3">
              <div className="p-2 rounded bg-slate-800 text-blue-400">
                  {driver.type === 'motor' ? <Settings size={18} /> : 
                   driver.type === 'sensor' ? <Activity size={18} /> : 
                   driver.type === 'power' ? <Terminal size={18} /> : <Cpu size={18} />}
              </div>
              <div>
                  <div className="text-sm font-bold text-slate-200">{driver.name}</div>
                  <div className="text-[10px] text-slate-500 font-mono">v{driver.version} • {driver.targetPico.toUpperCase()}</div>
              </div>
          </div>
          <div className="flex items-center gap-2">
              <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${driver.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                  {driver.status}
              </span>
          </div>
      </div>
  );

  const SubsystemCard: React.FC<{ sub: SubsystemStatus }> = ({ sub }) => (
      <div className="bg-white/5 border border-white/5 rounded-xl p-4 flex flex-col gap-2 relative overflow-hidden group">
          <div className="flex justify-between items-start z-10 relative">
              <div className="flex items-center gap-2">
                  <Cpu size={16} className="text-slate-400" />
                  <span className="font-bold text-sm text-slate-200">{sub.name}</span>
              </div>
              <div className={`w-2 h-2 rounded-full ${sub.status === 'online' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : sub.status === 'error' ? 'bg-red-500 animate-pulse' : 'bg-yellow-500'}`} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-slate-500 mt-2 font-mono z-10 relative">
              <div>VOLTAGE: <span className="text-slate-300">{sub.voltage}V</span></div>
              <div>UPTIME: <span className="text-slate-300">{sub.uptime}s</span></div>
          </div>
          {sub.details && (
              <div className="text-[10px] text-slate-500 mt-2 border-t border-white/5 pt-1 truncate z-10 relative">
                  {sub.details}
              </div>
          )}
          <div className="absolute -bottom-4 -right-4 text-white/5 transform -rotate-12 pointer-events-none group-hover:scale-110 transition-transform">
              <Cpu size={80} />
          </div>
      </div>
  );

  return (
    <div className="flex h-full bg-[#0d1117] text-slate-300 font-mono text-sm overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/50 border-r border-white/10 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('stream')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'stream' ? 'bg-blue-900/30 text-blue-400 border-r-2 border-blue-500' : 'text-slate-500'}`}
            >
                <Activity size={18} />
                <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Stream Monitor</span>
            </button>
            <button 
                onClick={() => setActiveTab('protocol')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'protocol' ? 'bg-purple-900/30 text-purple-400 border-r-2 border-purple-500' : 'text-slate-500'}`}
            >
                <Database size={18} />
                <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Protocol Analyzer</span>
            </button>
            <button 
                onClick={() => setActiveTab('drivers')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'drivers' ? 'bg-amber-900/30 text-amber-400 border-r-2 border-amber-500' : 'text-slate-500'}`}
            >
                <Settings size={18} />
                <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Drivers</span>
            </button>
            <button 
                onClick={() => setActiveTab('health')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'health' ? 'bg-green-900/30 text-green-400 border-r-2 border-green-500' : 'text-slate-500'}`}
            >
                <Server size={18} />
                <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Subsystem Health</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'stream' && (
                <div className="flex-1 flex flex-col">
                    {/* Toolbar */}
                    <div className="h-12 bg-slate-900 border-b border-white/10 flex items-center justify-between px-4 shrink-0">
                        <div className="flex items-center gap-4">
                            <button 
                                onClick={() => setIsCapturing(!isCapturing)}
                                className={`p-1.5 rounded hover:bg-white/10 ${isCapturing ? 'text-green-400' : 'text-red-400'}`}
                                title={isCapturing ? "Pause Capture" : "Resume Capture"}
                            >
                                {isCapturing ? <Square size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}
                            </button>
                            <div className="flex items-center gap-2 text-xs">
                                <span className="text-blue-400 font-bold">TX: {bridgeState.txRate} B/s</span>
                                <span className="text-slate-600">|</span>
                                <span className="text-green-400 font-bold">RX: {bridgeState.rxRate} B/s</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${serialStatus === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`} />
                            <span className={`text-xs font-bold ${serialStatus === 'connected' ? 'text-green-400' : 'text-yellow-500'}`}>
                                {serialStatus === 'connected' ? 'CONNECTED (UART0)' : 'SIMULATION MODE'}
                            </span>
                        </div>
                    </div>

                    {/* Console Output */}
                    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-1 font-mono text-xs bg-[#0d1117]">
                        {bridgeState.packets.map((pkt) => (
                            <div key={pkt.id} className="flex gap-2 hover:bg-white/5 p-1 rounded group border-l-2 border-transparent hover:border-slate-600 pl-2">
                                <span className="text-slate-600 w-20 shrink-0">{pkt.timestamp.toLocaleTimeString().split(' ')[0]}.{pkt.timestamp.getMilliseconds().toString().padStart(3, '0')}</span>
                                <span className={`w-8 font-bold ${pkt.direction === 'TX' ? 'text-blue-500' : 'text-green-500'}`}>{pkt.direction}</span>
                                <span className="w-16 text-slate-500">[{pkt.type.substring(0,4).toUpperCase()}]</span>
                                <span className="w-32 text-purple-400 opacity-60 hidden md:inline-block">{pkt.rawHex || "N/A"}</span>
                                <span className={`flex-1 break-all ${getPacketColor(pkt.type, pkt.direction)}`}>
                                    {pkt.payload}
                                </span>
                                <span className="text-slate-600 w-12 text-right">{pkt.latency}ms</span>
                            </div>
                        ))}
                    </div>

                    {/* Input Area */}
                    <div className="h-12 bg-slate-900 border-t border-white/10 p-2">
                        <form onSubmit={handleSendTest} className="flex gap-2 h-full">
                            <span className="flex items-center px-2 text-green-500 font-bold">{'>'}</span>
                            <input 
                                type="text" 
                                value={testCmd}
                                onChange={(e) => setTestCmd(e.target.value)}
                                className="flex-1 bg-transparent outline-none text-slate-200 placeholder-slate-600"
                                placeholder="Inject raw HAL command..."
                            />
                            <button type="submit" className="px-4 bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-300 rounded transition-colors">SEND</button>
                        </form>
                    </div>
                </div>
            )}

            {activeTab === 'protocol' && (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0d1117]">
                    <Cable size={64} className="text-slate-600 mb-6" />
                    <h2 className="text-xl font-bold text-slate-200 mb-2">Protocol Translation Layer</h2>
                    <p className="text-slate-500 max-w-md mb-8">
                        Visualizes how high-level JSON intents are serialized into binary frames for the microcontroller array.
                    </p>
                    
                    <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-xl p-6 flex items-center justify-between gap-4">
                        <div className="flex-1 bg-black/40 p-4 rounded-lg border border-white/5 text-left">
                            <div className="text-xs text-blue-400 font-bold mb-2">REACT STATE</div>
                            <code className="text-xs text-slate-300 block">
                                {"{ action: 'move', velocity: 100 }"}
                            </code>
                        </div>
                        <ArrowDown className="rotate-[-90deg] text-slate-600" />
                        <div className="flex-1 bg-black/40 p-4 rounded-lg border border-white/5 text-left">
                            <div className="text-xs text-purple-400 font-bold mb-2">BRIDGE SERIALIZER</div>
                            <code className="text-xs text-slate-300 block">
                                PROTOCOL_V2
                            </code>
                            <div className="mt-1 text-[10px] text-slate-500">CRC32 Checksumming...</div>
                        </div>
                        <ArrowDown className="rotate-[-90deg] text-slate-600" />
                        <div className="flex-1 bg-black/40 p-4 rounded-lg border border-white/5 text-left">
                            <div className="text-xs text-green-400 font-bold mb-2">UART FRAME</div>
                            <code className="text-xs text-green-300 font-mono block">
                                0xFF 0x02 0x64 0xFE
                            </code>
                        </div>
                    </div>
                    
                    <div className="mt-8 grid grid-cols-2 gap-4 w-full max-w-2xl">
                        <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                            <div className="text-xs text-slate-400 uppercase font-bold mb-1">Total Packets</div>
                            <div className="text-2xl font-light text-white">{bridgeState.protocolStats.totalPackets}</div>
                        </div>
                        <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                            <div className="text-xs text-slate-400 uppercase font-bold mb-1">Bus Load</div>
                            <div className="text-2xl font-light text-blue-400">{bridgeState.protocolStats.busLoad}%</div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'drivers' && (
                <div className="flex-1 p-8 overflow-y-auto">
                    <div className="mb-6">
                        <h2 className="text-2xl font-light text-white mb-1">Hardware Abstraction Layer</h2>
                        <p className="text-slate-400 text-xs">Active drivers managing physical interfaces via Pico cluster.</p>
                    </div>
                    <div className="space-y-3">
                        {bridgeState.activeDrivers.map(driver => (
                            <DriverCard key={driver.id} driver={driver} />
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'health' && (
                <div className="flex-1 p-8 overflow-y-auto">
                    <div className="mb-6 flex justify-between items-end">
                        <div>
                            <h2 className="text-2xl font-light text-white mb-1">Subsystem Diagnostics</h2>
                            <p className="text-slate-400">Monitoring status of connected peripheral controllers.</p>
                        </div>
                        <div className="text-right">
                            <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">Bus Voltage</div>
                            <div className="text-xl font-mono text-green-400">{bridgeState.power.bms[0].totalVoltage} V</div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {bridgeState.subsystems.map(sub => (
                            <SubsystemCard key={sub.id} sub={sub} />
                        ))}
                    </div>

                    <div className="mt-6 flex gap-4 text-xs text-slate-500 bg-white/5 p-3 rounded-lg border border-white/5">
                        <Info size={16} />
                        <div>
                            <strong>Topology Note:</strong> The system is running in Master/Slave configuration. 
                            RPi5 handles logic, while 5x Pico units handle real-time I/O.
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default BridgeApp;
