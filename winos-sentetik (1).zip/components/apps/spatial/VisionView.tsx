
import React from 'react';
import { Box, Eye } from 'lucide-react';
import { PerceptionState } from '../../../types';

interface VisionViewProps {
    perceptionState: PerceptionState;
}

export const VisionView: React.FC<VisionViewProps> = ({ perceptionState }) => {
    return (
        <div className="flex-1 flex flex-col p-4 gap-4 overflow-y-auto">
            <div className="grid grid-cols-2 gap-4 h-64">
                <div className="bg-black rounded-xl border border-white/10 relative overflow-hidden flex items-center justify-center group">
                    <span className="text-slate-600 text-xs uppercase tracking-widest">Sol Göz (Ham)</span>
                    <div className="absolute bottom-2 left-2 text-[10px] bg-red-600 px-1 rounded text-white font-bold">KAYIT</div>
                    {perceptionState.detectedObjects.length > 0 && (
                        <div className="absolute top-10 left-10 w-20 h-30 border-2 border-green-500/50 rounded flex items-start justify-end p-1">
                            <span className="bg-green-500 text-black text-[9px] font-bold px-1">{perceptionState.detectedObjects[0].label}</span>
                        </div>
                    )}
                </div>
                <div className="bg-black rounded-xl border border-white/10 relative overflow-hidden flex items-center justify-center">
                    <span className="text-slate-600 text-xs uppercase tracking-widest">Derinlik Haritası (Disparity)</span>
                    <div className="absolute inset-0 bg-gradient-to-tr from-black to-white opacity-20 mix-blend-overlay" />
                </div>
            </div>
            
            <div className="flex-1 bg-slate-900 rounded-xl border border-white/10 p-6">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                    <Eye className="text-blue-400" /> Görsel Tanıma Hattı
                </h3>
                <div className="grid grid-cols-3 gap-4">
                    {perceptionState.detectedObjects.map(obj => (
                        <div key={obj.id} className="bg-white/5 border border-white/5 rounded-lg p-3 flex items-start gap-3">
                            <div className={`p-2 rounded ${obj.type === 'living' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                                <Box size={20} />
                            </div>
                            <div>
                                <div className="font-bold text-sm">{obj.label}</div>
                                <div className="text-xs text-slate-400 mt-1">
                                    Güven: {(obj.confidence * 100).toFixed(1)}% <br/>
                                    Mesafe: {obj.position.y.toFixed(1)}m
                                </div>
                                <div className="text-[10px] bg-white/10 px-2 py-0.5 rounded mt-2 inline-block uppercase text-slate-300">
                                    {obj.type}
                                </div>
                            </div>
                        </div>
                    ))}
                    {perceptionState.detectedObjects.length === 0 && (
                        <div className="col-span-3 text-center py-10 text-slate-500 italic border-2 border-dashed border-white/5 rounded-lg">
                            Görüş alanında tanımlanmış nesne yok.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
