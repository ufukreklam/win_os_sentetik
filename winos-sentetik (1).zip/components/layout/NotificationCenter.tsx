
import React from 'react';
import { useOS } from '../../context/OSContext';
import { X, Bell, Trash2, CheckCircle, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { format } from 'date-fns';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({ isOpen, onClose }) => {
  const { notifications, removeNotification, clearNotifications } = useOS();

  if (!isOpen) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle size={16} className="text-green-400" />;
      case 'warning': return <AlertTriangle size={16} className="text-yellow-400" />;
      case 'error': return <AlertCircle size={16} className="text-red-400" />;
      default: return <Info size={16} className="text-blue-400" />;
    }
  };

  return (
    <div 
      className="fixed bottom-14 right-4 z-50 w-80 h-[500px]
                 bg-slate-900/90 backdrop-blur-2xl 
                 border border-white/10 rounded-xl shadow-2xl 
                 flex flex-col animate-in slide-in-from-right-5 fade-in duration-200 origin-bottom-right"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-2">
            <Bell size={16} className="text-blue-400" />
            <h2 className="text-sm font-semibold text-white">Notifications</h2>
            <span className="text-xs text-slate-500 bg-white/5 px-1.5 rounded-full">{notifications.length}</span>
        </div>
        <div className="flex gap-1">
            {notifications.length > 0 && (
                <button 
                    onClick={clearNotifications}
                    className="p-1.5 hover:bg-white/10 rounded-md text-slate-400 hover:text-red-400 transition-colors"
                    title="Clear All"
                >
                    <Trash2 size={14} />
                </button>
            )}
            <button 
                onClick={onClose}
                className="p-1.5 hover:bg-white/10 rounded-md text-slate-400 hover:text-white transition-colors"
            >
                <X size={16} />
            </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {notifications.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 gap-2 opacity-50">
                <Bell size={48} strokeWidth={1} />
                <p className="text-sm">No new notifications</p>
            </div>
        ) : (
            notifications.map((n) => (
                <div 
                    key={n.id}
                    className="bg-white/5 hover:bg-white/10 border border-white/5 p-3 rounded-lg transition-colors group relative"
                >
                    <div className="flex gap-3">
                        <div className="mt-0.5 shrink-0">{getIcon(n.type)}</div>
                        <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                                <h4 className="text-xs font-bold text-slate-200 truncate pr-4">{n.title}</h4>
                                <span className="text-[10px] text-slate-500 whitespace-nowrap">
                                    {format(new Date(n.timestamp), 'h:mm a')}
                                </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-1 leading-relaxed break-words">{n.message}</p>
                        </div>
                    </div>
                    
                    <button 
                        onClick={() => removeNotification(n.id)}
                        className="absolute top-2 right-2 p-1 text-slate-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Dismiss"
                    >
                        <X size={12} />
                    </button>
                </div>
            ))
        )}
      </div>
    </div>
  );
};

export default NotificationCenter;
