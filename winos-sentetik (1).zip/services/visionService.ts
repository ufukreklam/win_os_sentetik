
export class VisionService {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D | null;
    private previousData: Uint8ClampedArray | null = null;
    private width = 64; 
    private height = 48;

    constructor() {
        this.canvas = document.createElement('canvas');
        this.canvas.width = this.width;
        this.canvas.height = this.height;
        this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    }

    /**
     * Calculates motion score between 0 and 100
     */
    processFrame(source: CanvasImageSource): number {
        if (!this.ctx) return 0;
        
        // Draw current frame
        this.ctx.drawImage(source, 0, 0, this.width, this.height);
        const frame = this.ctx.getImageData(0, 0, this.width, this.height);
        const data = frame.data;

        if (!this.previousData) {
            this.previousData = new Uint8ClampedArray(data);
            return 0;
        }

        let diffScore = 0;
        const len = data.length;
        // Check every 2nd pixel (step 8 bytes) for performance/accuracy balance
        const step = 8; 

        for (let i = 0; i < len; i += step) {
            const rDiff = Math.abs(data[i] - this.previousData[i]);
            const gDiff = Math.abs(data[i+1] - this.previousData[i+1]);
            const bDiff = Math.abs(data[i+2] - this.previousData[i+2]);
            
            // Sensitivity threshold
            if (rDiff + gDiff + bDiff > 80) {
                diffScore++;
            }
        }

        // Store current as previous
        this.previousData.set(data);

        // Normalize
        const totalPixels = (this.width * this.height) / (step / 4);
        const motion = Math.min(100, (diffScore / totalPixels) * 100 * 5); // Scale up

        return motion;
    }
}

export const visionService = new VisionService();
