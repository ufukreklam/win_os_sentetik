
import React, { useState, useEffect, useMemo } from 'react';
import { useOS } from '../../context/OSContext';
import { Search, Power, ChevronRight, Pin, Trash2, ExternalLink, PinOff, Link } from 'lucide-react';
import { AppID, AppMetadata, AppCategory } from '../../types';
import { APP_CONFIGS } from '../../constants';

interface ContextMenuState {
    show: boolean;
    x: number;
    y: number;
    appId: AppID;
    isPinned: boolean;
    isSystem: boolean;
}

const CATEGORY_NAMES: Record<AppCategory, string> = {
    robot: 'Robot Katmanları',
    system: 'İşletim Sistemi',
    productivity: 'Genel Uygulamalar',
    media: 'Medya ve Görsel',
    development: 'Geliştirici Araçları',
    games: 'Oyunlar',
    utilities: 'Araçlar'
};

const StartMenu: React.FC = () => {
  const { isStartMenuOpen, installedApps, pinnedApps, openApp, setLocked, toggleStartMenu, togglePin, uninstallApp, currentUser, writeFile, addNotification } = useOS();
  const [view, setView] = useState<'pinned' | 'all'>('pinned');
  const [searchTerm, setSearchTerm] = useState('');
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);

  // Reset view on close
  useEffect(() => {
      if (!isStartMenuOpen) {
          setView('pinned');
          setSearchTerm('');
          setContextMenu(null);
      }
  }, [isStartMenuOpen]);

  // Global click to close context menu
  useEffect(() => {
      const handleClick = () => setContextMenu(null);
      window.addEventListener('click', handleClick);
      return () => window.removeEventListener('click', handleClick);
  }, []);

  const handleLock = () => {
      toggleStartMenu();
      setLocked(true);
  };

  const handleRightClick = (e: React.MouseEvent, appId: AppID, isSystem: boolean) => {
      e.preventDefault();
      e.stopPropagation();
      const isPinned = pinnedApps.some(p => p.id === appId);
      setContextMenu({
          show: true,
          x: e.pageX,
          y: e.pageY,
          appId,
          isPinned,
          isSystem
      });
  };

  const handleCreateShortcut = (appId: AppID) => {
      const app = APP_CONFIGS[appId];
      if (!app) return;

      const fileName = `${app.name.replace(/\s+/g, '_')}.app`;
      
      writeFile('/home/user/Desktop', {
          name: fileName,
          type: 'file',
          fileType: 'unknown',
          content: appId, // Store AppID in content
          permissions: '-rwxr-xr-x',
          size: '1 KB',
          owner: currentUser?.username
      });
      
      addNotification({ title: 'Kısayol Oluşturuldu', message: `${app.name} masaüstüne eklendi`, type: 'success' });
      setContextMenu(null);
  };

  // Group apps by category for "All Apps" view
  const groupedApps = useMemo(() => {
      const groups: Record<string, AppMetadata[]> = {};
      installedApps.forEach(app => {
          const cat = app.category ? CATEGORY_NAMES[app.category] : 'Diğer';
          if (!groups[cat]) groups[cat] = [];
          groups[cat].push(app);
      });
      
      // Define explicit order for categories
      const order = [
          CATEGORY_NAMES.robot,
          CATEGORY_NAMES.system,
          CATEGORY_NAMES.productivity,
          CATEGORY_NAMES.media,
          CATEGORY_NAMES.development,
          CATEGORY_NAMES.games,
          CATEGORY_NAMES.utilities
      ];

      return order.reduce((obj, key) => {
          if (groups[key]) obj[key] = groups[key];
          return obj;
      }, {} as Record<string, AppMetadata[]>);
  }, [installedApps]);

  const filteredApps = installedApps.filter(app => 
      app.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isStartMenuOpen) return null;

  return (
    <div 
        className="fixed z-[60] 
                   md:bottom-14 md:left-2 md:w-[640px] md:h-[650px] md:rounded-xl md:border md:mb-0
                   bottom-12 left-0 w-full h-[80vh] rounded-t-2xl border-t border-x mb-0
                   bg-slate-900/95 backdrop-blur-3xl 
                   border-white/10 shadow-2xl 
                   flex flex-col text-white 
                   animate-in slide-in-from-bottom-10 fade-in duration-200 origin-bottom"
        role="dialog"
        aria-label="Başlat Menüsü"
        onClick={(e) => e.stopPropagation()}
    >
      {/* Mobile Drag Handle */}
      <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 mb-1 md:hidden" />

      {/* Search Bar */}
      <div className="p-6 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Uygulama, ayar veya belge arayın" 
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); if(e.target.value) setView('all'); }}
            className="w-full bg-black/40 border border-white/5 rounded-full py-2.5 pl-10 pr-4 
                       text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500/50 focus:bg-black/60 transition-all"
            autoFocus
          />
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative">
          
          {/* VIEW: PINNED */}
          {view === 'pinned' && !searchTerm && (
              <div className="h-full flex flex-col p-6 animate-in fade-in slide-in-from-left-4 duration-300">
                  <div className="flex justify-between items-center mb-4 px-2">
                      <h3 className="text-sm font-semibold text-slate-200">Sabitlenmiş</h3>
                      <button 
                        onClick={() => setView('all')}
                        className="flex items-center gap-1 text-xs bg-white/5 hover:bg-white/10 px-3 py-1 rounded transition-colors"
                      >
                          Tüm uygulamalar <ChevronRight size={12} />
                      </button>
                  </div>
                  
                  <div className="grid grid-cols-4 md:grid-cols-6 gap-2 auto-rows-min overflow-y-auto pr-1 pb-4" style={{ maxHeight: '50vh' }}>
                      {pinnedApps.map(app => (
                          <button 
                              key={app.id} 
                              onClick={() => openApp(app.id)}
                              onContextMenu={(e) => handleRightClick(e, app.id, app.isSystem)}
                              className="flex flex-col items-center gap-2 p-2 hover:bg-white/5 rounded-lg transition-colors group active:scale-95"
                              title={app.name}
                          >
                              <div className="w-12 h-12 md:w-10 md:h-10 flex items-center justify-center bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors shadow-sm">
                                  <app.icon size={28} className="text-slate-200 md:w-6 md:h-6" />
                              </div>
                              <span className="text-[11px] font-medium text-slate-200 truncate w-full text-center">{app.name}</span>
                          </button>
                      ))}
                  </div>

                  <div className="mt-4 mb-2 px-2">
                      <h3 className="text-sm font-semibold text-slate-200">Önerilenler</h3>
                  </div>
                  <div className="flex-1 overflow-y-auto space-y-1">
                      <div className="flex items-center gap-4 p-2 hover:bg-white/5 rounded-lg cursor-pointer transition-colors group">
                          <div className="w-8 h-8 bg-blue-500/20 rounded flex items-center justify-center text-xs shrink-0 text-blue-300 group-hover:bg-blue-500/30">BELGE</div>
                          <div className="flex flex-col min-w-0">
                              <span className="text-xs font-medium text-slate-200">Sistem_Ozellikleri_v2.pdf</span>
                              <span className="text-[10px] text-slate-400">2 saat önce</span>
                          </div>
                      </div>
                      <div className="flex items-center gap-4 p-2 hover:bg-white/5 rounded-lg cursor-pointer transition-colors group">
                          <div className="w-8 h-8 bg-green-500/20 rounded flex items-center justify-center text-xs shrink-0 text-green-300 group-hover:bg-green-500/30">TABLO</div>
                          <div className="flex flex-col min-w-0">
                              <span className="text-xs font-medium text-slate-200">Butce_2024_Ceyrek1.xlsx</span>
                              <span className="text-[10px] text-slate-400">Dün 16:20</span>
                          </div>
                      </div>
                  </div>
              </div>
          )}

          {/* VIEW: ALL APPS (Grid Mode) */}
          {(view === 'all' || searchTerm) && (
              <div className="h-full flex flex-col p-6 animate-in fade-in slide-in-from-right-4 duration-300">
                  <div className="flex justify-between items-center mb-4 px-2">
                      <h3 className="text-sm font-semibold text-slate-200">{searchTerm ? 'Arama Sonuçları' : 'Tüm Uygulamalar'}</h3>
                      {!searchTerm && (
                          <button 
                            onClick={() => setView('pinned')}
                            className="text-xs bg-white/5 hover:bg-white/10 px-3 py-1 rounded transition-colors"
                          >
                              Geri
                          </button>
                      )}
                  </div>

                  <div className="flex-1 overflow-y-auto pr-1 pb-4">
                      {searchTerm ? (
                          // Search Results (Grid)
                          <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                              {filteredApps.map(app => (
                                  <button
                                      key={app.id}
                                      onClick={() => openApp(app.id)}
                                      onContextMenu={(e) => handleRightClick(e, app.id, app.isSystem)}
                                      className="flex flex-col items-center gap-2 p-2 hover:bg-white/5 rounded-lg transition-colors group active:scale-95"
                                  >
                                      <div className="w-12 h-12 md:w-10 md:h-10 flex items-center justify-center bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors shadow-sm">
                                          <app.icon size={28} className="text-slate-200 md:w-6 md:h-6" />
                                      </div>
                                      <span className="text-[11px] font-medium text-slate-200 truncate w-full text-center">{app.name}</span>
                                  </button>
                              ))}
                              {filteredApps.length === 0 && <div className="text-slate-500 text-sm p-4 col-span-6 text-center">Uygulama bulunamadı.</div>}
                          </div>
                      ) : (
                          // Grouped List (Grid Style)
                          (Object.entries(groupedApps) as [string, AppMetadata[]][]).map(([category, apps]) => (
                              <div key={category} className="mb-4">
                                  <div className="sticky top-0 bg-slate-900/90 backdrop-blur z-10 px-2 py-1 mb-2 border-b border-white/5">
                                      <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">{category}</span>
                                  </div>
                                  <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                                      {apps.map(app => (
                                          <button
                                              key={app.id}
                                              onClick={() => openApp(app.id)}
                                              onContextMenu={(e) => handleRightClick(e, app.id, app.isSystem)}
                                              className="flex flex-col items-center gap-2 p-2 hover:bg-white/5 rounded-lg transition-colors group active:scale-95"
                                          >
                                              <div className="w-12 h-12 md:w-10 md:h-10 flex items-center justify-center bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors shadow-sm">
                                                  <app.icon size={28} className="text-slate-200 md:w-6 md:h-6" />
                                              </div>
                                              <span className="text-[11px] font-medium text-slate-200 truncate w-full text-center">{app.name}</span>
                                          </button>
                                      ))}
                                  </div>
                              </div>
                          ))
                      )}
                  </div>
              </div>
          )}
      </div>

      {/* Footer */}
      <div className="h-16 bg-black/40 border-t border-white/5 px-6 flex items-center justify-between rounded-b-none md:rounded-b-xl shrink-0 backdrop-blur-md pb-4 md:pb-0">
        <div 
            className="flex items-center gap-3 hover:bg-white/10 p-2 rounded-lg cursor-pointer transition-colors"
            role="button"
            aria-label="Kullanıcı Profili"
        >
            <div className={`w-8 h-8 rounded-full ${currentUser?.avatarColor || 'bg-blue-600'} flex items-center justify-center text-xs font-bold shadow-sm`}>
                {currentUser?.username.charAt(0)}
            </div>
            <div className="flex flex-col">
                <span className="text-xs font-medium text-slate-200">{currentUser?.username}</span>
            </div>
        </div>
        <button 
            onClick={handleLock}
            className="hover:bg-white/10 p-2 rounded-lg transition-colors text-slate-300 hover:text-white"
            title="Sistemi Kilitle"
        >
            <Power size={20} />
        </button>
      </div>

      {/* Context Menu Overlay */}
      {contextMenu && (
          <div 
            className="fixed z-[100] w-64 bg-slate-800 border border-white/10 rounded-lg shadow-xl py-1 animate-in fade-in zoom-in-95 duration-100"
            style={{ 
                top: Math.min(contextMenu.y, window.innerHeight - 250), 
                left: contextMenu.x 
            }}
            onClick={(e) => e.stopPropagation()}
          >
              <button 
                onClick={() => { openApp(contextMenu.appId); setContextMenu(null); toggleStartMenu(); }}
                className="w-full text-left px-4 py-2 hover:bg-white/10 text-xs text-white flex items-center gap-2"
              >
                  <ExternalLink size={14} /> Aç
              </button>
              <button 
                onClick={() => { togglePin(contextMenu.appId); setContextMenu(null); }}
                className="w-full text-left px-4 py-2 hover:bg-white/10 text-xs text-white flex items-center gap-2"
              >
                  {contextMenu.isPinned ? <PinOff size={14} /> : <Pin size={14} />} 
                  {contextMenu.isPinned ? 'Başlattan Kaldır' : 'Başlata Sabitle'}
              </button>
              <button 
                onClick={() => handleCreateShortcut(contextMenu.appId)}
                className="w-full text-left px-4 py-2 hover:bg-white/10 text-xs text-white flex items-center gap-2"
              >
                  <Link size={14} /> Masaüstü Kısayolu Oluştur
              </button>
              {!contextMenu.isSystem && (
                  <>
                    <div className="h-[1px] bg-white/10 my-1" />
                    <button 
                        onClick={() => { if(confirm('Bu uygulamayı kaldırmak istediğinize emin misiniz?')) uninstallApp(contextMenu.appId); setContextMenu(null); }}
                        className="w-full text-left px-4 py-2 hover:bg-white/10 text-xs text-red-400 flex items-center gap-2"
                    >
                        <Trash2 size={14} /> Uygulamayı Kaldır
                    </button>
                  </>
              )}
          </div>
      )}
    </div>
  );
};

export default StartMenu;
