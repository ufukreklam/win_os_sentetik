
import { useState, useCallback, useEffect } from 'react';
import { EmotionState } from '../../../types';
import { INITIAL_EMOTION } from '../../initialStates';
import { emotionService } from '../../../services/emotionService';
import { websocketService } from '../../../services/websocketService';

export const useAIEmotion = () => {
    const [emotionState, setEmotionState] = useState<EmotionState>(INITIAL_EMOTION);

    // Backend'e duygu durumu gönder
    const syncToBackend = useCallback((state: EmotionState) => {
        if (websocketService.getConnectionStatus()) {
            websocketService.send({
                type: 'emotion_sync',
                payload: {
                    primary: state.primary,
                    intensity: state.intensity,
                    pad: state.pad
                }
            });
        }
    }, []);

    const updateEmotionState = useCallback((state: Partial<EmotionState>) => {
        setEmotionState(prev => {
            const newState = { ...prev, ...state };
            // Sadece primary duygu değiştiğinde sync yap (trafik optimizasyonu)
            if (prev.primary !== newState.primary) {
                 syncToBackend(newState);
            }
            return newState;
        });
    }, [syncToBackend]);

    // Duygu durumunu zamanla nötrleme (Decay) ve dış etkenleri işleme
    const processEmotionTick = useCallback((batteryVoltage: number) => {
        // 1. Decay
        const newEmotion = emotionService.decay();
        
        // 2. Donanım Etkileri (Düşük pil stresi artırır)
        if (batteryVoltage < 10.5 && batteryVoltage > 0) {
             emotionService.injectEmotion(0, -0.1, -0.1); 
        }

        setEmotionState(prev => {
            const nextState = {
                ...prev,
                ...newEmotion
            };
            
            // Periyodik sync (her decayde değil, sadece büyük değişimde veya belirli aralıkla yapılabilir)
            // Şimdilik sadece primary değişimde updateEmotionState içinden yapıyoruz.
            // Ancak donanım etkileri burada işlendiği için burada da kontrol edelim.
            if (prev.primary !== nextState.primary) {
                syncToBackend(nextState);
            }
            
            return nextState;
        });
    }, [syncToBackend]);

    return {
        emotionState,
        setEmotionState: updateEmotionState,
        processEmotionTick
    };
};
