# Ürün Bağlamı

## Problem
Gelişmiş robotik sistemlerin geliştirilmesi genellikle kopuk araçlar gerektirir: SSH için bir terminal, video akışı için ayrı bir web sunucusu, sensör verileri için ham loglar ve AI durumunu anlamak için karmaşık debug ekranları. Robotu tutarlı, "bilinçli" bir varlık gibi hissettiren birleşik bir "İşletim Sistemi" görsel metaforu eksiktir.

## Çözüm
**WinOS Hybrid**, robotun "Yüzü" ve "Beyin Arayüzü"dür. Şunları birleştirir:
-   **Donanım Soyutlama**: Fiziksel motorları kontrol etme ve sensörleri (Lidar, Ultrasonik) tanıdık bir "Ayarlar" veya "Telemetri" uygulaması üzerinden okuma.
-   **Yapay Bilinç Görselleştirme**: 16 katmanlı AI modelinin iç durumunu (örn. mevcut "Duygu", "Motivasyon" veya "Karar Ağacı") gerçek zamanlı görselleştirme.
-   **Sistem Yönetimi**: Raspberry Pi önyükleme yapılandırması ve servis yönetimi üzerinde BIOS seviyesinde kontrol sağlama (Simüle edilmiş BIOS/POST ekranları dahil).

## Kullanıcı Deneyimi Hedefleri
1.  **Sürükleyicilik (Immersiveness)**: Kullanıcı, robotla bir dizi kod betiğiyle değil, üst düzey bir bilgisayarla etkileşime giriyormuş gibi hisseder.
2.  **Şeffaflık (Transparency)**: İç durumlar (AI düşünce süreci, sensör füzyon verileri) "Orchestrator" ve "Mind" uygulamalarıyla görünür hale gelir.
3.  **Güvenlik ve Kontrol**: Acil durdurma (Task Manager veya Sistem Çökertme mantığı) ve güvenli mod önyüklemesine anında erişim.
4.  **Hibrit İşlevsellik**: Karmaşık yapılandırma için "Masaüstü Modu" ve saha operasyonu kontrolü için "Mobil Mod" arasında sorunsuz geçiş.