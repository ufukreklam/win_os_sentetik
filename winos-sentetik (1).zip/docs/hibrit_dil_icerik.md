# 🎯 Hibrit Dil Sistemi Dashboard Talimatlari

## 📋 Sayfa Yapısı ve İçerik Gereksinimleri

### **1. ANA HEADER BÖLÜMÜ**
- Sistem başlığı: "Hibrit Dil ve İletişim Sistemi"
- Anlık durum göstergesi (online/processing/idle)
- Sistem sağlık skoru (0-100)
- Aktif modül sayısı

---

### **2. GENEL DURUM KARTLARI (4 Kart)**

#### Kart 1: Anlama Performansı
- Intent detection accuracy (%)
- İşlenen mesaj sayısı (bugün)
- Ortalama yanıt süresi (ms)
- Trend göstergesi (↑/↓)

#### Kart 2: Dil Kapasitesi
- Desteklenen dil sayısı
- Aktif çeviri işlemleri
- Kelime hazinesi boyutu
- Öğrenilen yeni pattern sayısı

#### Kart 3: Duygusal Zeka
- Duygu tespit doğruluğu (%)
- İşlenen duygusal bağlam sayısı
- Empati skoru (0-10)
- Kişilik tutarlılığı (%)

#### Kart 4: Multimodal İletişim
- Aktif modaliteler (text/speech/visual)
- Ses sentez kalitesi skoru
- Görsel işleme hızı
- Senkronizasyon başarı oranı

---

### **3. ANA MODÜL DURUM PANELİ (Grid Layout)**

Her modül için ayrı kart içermeli:

#### **Core Modules (3 Kart)**
- **Semantic Engine**
  - Status: Active/Idle/Error
  - İşlem sayısı/saat
  - CPU kullanımı (%)
  - Bellek kullanımı (MB)
  
- **Language Model**
  - Model versiyonu
  - Token işleme hızı
  - Cache hit rate (%)
  - Son güncelleme zamanı

- **Context Manager**
  - Aktif bağlam sayısı
  - Bağlam geçiş süresi (ms)
  - Bellek tüketimi
  - Bağlam kaybı oranı (%)

#### **Understanding Layer (4 Kart)**
- **Intent Detection**: Tespit edilen niyet sayısı, doğruluk oranı
- **Emotion Analysis**: Analiz edilen duygu sayısı, tespit edilen duygular (grafik)
- **Context Extraction**: Çıkarılan bağlam sayısı, işlem süresi
- **Pragmatic Analysis**: Pragmatik analiz sayısı, başarı oranı

#### **Generation Layer (4 Kart)**
- **Text Generator**: Üretilen metin sayısı, kalite skoru
- **Style Adapter**: Uygulanan stil sayısı, adaptasyon başarısı
- **Personality Voice**: Kişilik tutarlılığı, ton uygulamaları
- **Creative Writer**: Yaratıcı içerik sayısı, özgünlük skoru

#### **Conversation Management (4 Kart)**
- **Dialogue Manager**: Aktif diyalog sayısı, ortalama süre
- **Turn Taking**: Söz alma başarısı, gecikme süresi
- **Topic Tracker**: İzlenen konu sayısı, konu değişim sıklığı
- **Coherence Keeper**: Tutarlılık skoru, düzeltme sayısı

#### **Multimodal (4 Kart)**
- **Speech Synthesis**: Sentez edilen ses süresi (dk), kalite
- **Speech Recognition**: Tanınan konuşma süresi, doğruluk
- **Visual Language**: İşlenen görsel sayısı, işlem süresi
- **Gesture Communication**: Yorumlanan jest sayısı

#### **Translation (4 Kart)**
- **Neural Translator**: Çeviri sayısı, doğruluk oranı
- **Cultural Adapter**: Uyarlama sayısı, başarı oranı
- **Idiom Handler**: İşlenen deyim sayısı
- **Localization**: Desteklenen locale sayısı

#### **Learning System (4 Kart)**
- **Language Learner**: Öğrenilen pattern sayısı, öğrenme hızı
- **Style Mimicker**: Taklit edilen stil sayısı, başarı oranı
- **Vocabulary Expander**: Yeni kelime sayısı, entegrasyon oranı
- **Pattern Extractor**: Çıkarılan pattern sayısı, kalite skoru

---

### **4. PERFORMANS GRAFİKLERİ (3 Grafik)**

#### Grafik 1: Zaman Serisi - Yanıt Süreleri
- Son 24 saatlik yanıt süresi trendi (line chart)
- X: Zaman (saat), Y: Süre (ms)
- Ortalama çizgi göstergesi

#### Grafik 2: Dil Dağılımı
- Kullanılan dillerin dağılımı (pie chart)
- Her dil için yüzde oranı
- İşlem sayısı bilgisi

#### Grafik 3: Modül Aktivitesi
- Tüm modüllerin son 1 saatlik aktivitesi (heatmap/bar chart)
- X: Modüller, Y: İşlem sayısı
- Renk kodlu aktivite seviyesi

---

### **5. KALİTE METRİKLERİ PANELİ**

#### Quality Assessment Kartı
- Fluency Score: 0-100
- Coherence Score: 0-100
- Appropriateness Score: 0-100
- Creativity Score: 0-100
- Overall Quality: Genel skor ve trend

#### Real-time Quality Monitor
- Son 10 yanıtın kalite skorları (bar chart)
- Kalite eşik çizgisi (threshold line)
- Düşük kaliteli yanıt uyarıları

---

### **6. KÜLTÜREL ADAPTASYON PANELİ**

- Desteklenen kültür sayısı
- Aktif cultural adapter sayısı
- Politeness strategy kullanım dağılımı
- Taboo detection başarı oranı
- Kültürel uyumluluk skoru

---

### **7. BELLEK VE KAYNAK KULLANIMI**

#### System Resources Kartı
- CPU Kullanımı: % ve grafik
- RAM Kullanımı: MB/GB ve grafik
- GPU Kullanımı: % (varsa)
- Disk I/O: MB/s

#### Memory System Integration
- Conversation memory boyutu (MB)
- Linguistic memory pattern sayısı
- Cache boyutu ve hit rate
- Memory retrieval hızı (ms)

---

### **8. CANLI KONUŞMA İZLEME**

#### Active Conversations Panel
- Aktif konuşma sayısı
- Konuşma süreleri
- Ortalama dönüş sayısı
- Kullanıcı memnuniyet tahmini

#### Recent Interactions (Tablo)
| Zaman | Kullanıcı | Niyet | Duygu | Yanıt Süresi | Kalite |
|-------|-----------|-------|-------|--------------|--------|
| ...   | ...       | ...   | ...   | ...          | ...    |

---

### **9. UYARI VE BİLDİRİMLER**

#### Alert System
- Critical: Sistem hataları (kırmızı)
- Warning: Performans düşüşleri (sarı)
- Info: Genel bilgiler (mavi)
- Success: Başarılı optimizasyonlar (yeşil)

#### Recent Alerts (Liste)
- Timestamp
- Alert tipi
- Modül adı
- Mesaj
- Durum (resolved/pending)

---

### **10. ROADMAP İLERLEME TAKIP**

#### Development Phases
Her faz için:
- Faz adı (Faz 1-6)
- Tamamlanma yüzdesi (progress bar)
- Tamamlanan görev sayısı / Toplam görev
- Beklenen bitiş tarihi
- Durum: On Track / Delayed / Completed

---

## 🔌 API Endpoints ve Veri Yolları

### **Genel Sistem Durumu**
```
GET /api/system/status
Response: {
  status: "online" | "processing" | "idle" | "error",
  healthScore: number,
  activeModules: number,
  uptime: number
}
```

### **Performans Metrikleri**
```
GET /api/metrics/understanding
Response: {
  intentAccuracy: number,
  processedMessages: number,
  avgResponseTime: number,
  trend: "up" | "down" | "stable"
}

GET /api/metrics/language
Response: {
  supportedLanguages: number,
  activeTranslations: number,
  vocabularySize: number,
  newPatterns: number
}

GET /api/metrics/emotional
Response: {
  emotionAccuracy: number,
  processedContexts: number,
  empathyScore: number,
  personalityConsistency: number
}

GET /api/metrics/multimodal
Response: {
  activeModalities: string[],
  speechQuality: number,
  visualProcessingSpeed: number,
  syncSuccessRate: number
}
```

### **Modül Durumları**
```
GET /api/modules/core
GET /api/modules/understanding
GET /api/modules/generation
GET /api/modules/conversation
GET /api/modules/multimodal
GET /api/modules/translation
GET /api/modules/learning

Response (her endpoint için): {
  modules: [{
    name: string,
    status: "active" | "idle" | "error",
    processCount: number,
    cpuUsage: number,
    memoryUsage: number,
    lastUpdate: timestamp
  }]
}
```

### **Performans Grafikleri**
```
GET /api/charts/response-times?hours=24
Response: {
  data: [{ timestamp: string, value: number }],
  average: number
}

GET /api/charts/language-distribution
Response: {
  data: [{ language: string, percentage: number, count: number }]
}

GET /api/charts/module-activity?hours=1
Response: {
  modules: string[],
  data: [{ module: string, count: number }]
}
```

### **Kalite Metrikleri**
```
GET /api/quality/assessment
Response: {
  fluency: number,
  coherence: number,
  appropriateness: number,
  creativity: number,
  overall: number,
  trend: "improving" | "stable" | "declining"
}

GET /api/quality/recent?limit=10
Response: {
  responses: [{
    id: string,
    timestamp: timestamp,
    scores: { fluency, coherence, appropriateness, creativity }
  }]
}
```

### **Kültürel Adaptasyon**
```
GET /api/cultural/metrics
Response: {
  supportedCultures: number,
  activeAdapters: number,
  politenessStrategies: { [key: string]: number },
  tabooDetectionRate: number,
  culturalCompatibility: number
}
```

### **Kaynak Kullanımı**
```
GET /api/resources/system
Response: {
  cpu: { usage: number, trend: number[] },
  ram: { used: number, total: number, trend: number[] },
  gpu: { usage: number } | null,
  disk: { ioSpeed: number }
}

GET /api/resources/memory
Response: {
  conversationMemorySize: number,
  linguisticPatterns: number,
  cacheSize: number,
  cacheHitRate: number,
  retrievalSpeed: number
}
```

### **Canlı Konuşmalar**
```
GET /api/conversations/active
Response: {
  activeCount: number,
  conversations: [{
    id: string,
    duration: number,
    turns: number,
    satisfactionScore: number
  }]
}

GET /api/conversations/recent?limit=20
Response: {
  interactions: [{
    timestamp: timestamp,
    userId: string,
    intent: string,
    emotion: string,
    responseTime: number,
    qualityScore: number
  }]
}
```

### **Uyarılar**
```
GET /api/alerts?status=pending
Response: {
  alerts: [{
    id: string,
    timestamp: timestamp,
    type: "critical" | "warning" | "info" | "success",
    module: string,
    message: string,
    status: "resolved" | "pending"
  }]
}
```

### **Roadmap İlerleme**
```
GET /api/roadmap/progress
Response: {
  phases: [{
    id: number,
    name: string,
    completionPercentage: number,
    completedTasks: number,
    totalTasks: number,
    expectedEndDate: string,
    status: "on-track" | "delayed" | "completed"
  }]
}
```

### **WebSocket (Real-time Updates)**
```
WS /ws/realtime
Messages: {
  type: "metric-update" | "alert" | "conversation-update",
  data: { ... }
}
```

---

## 🎨 UI/UX Gereksinimleri

### **Renk Kodlama**
- Başarı/İyi: Yeşil tonları
- Uyarı: Sarı/Turuncu tonları
- Hata/Kritik: Kırmızı tonları
- Bilgi: Mavi tonları
- Nötr: Gri tonları

### **Responsive Gereksinimler**
- Desktop: 3-4 kolonlu grid
- Tablet: 2 kolonlu grid
- Mobile: 1 kolonlu stack

### **Güncellenme Sıklıkları**
- Sistem durumu: 5 saniye
- Metrikler: 10 saniye
- Grafikler: 30 saniye
- Modül durumları: 15 saniye
- Canlı konuşmalar: 5 saniye (WebSocket)

### **Etkileşim Gereksinimleri**
- Her modül kartına tıklandığında detay modal açılmalı
- Grafiklere hover ile detay göster
- Alert'lere tıklayarak detay ve çözüm önerileri
- Filtreleme ve zaman aralığı seçimi

---

Bu talimatlar ile Google AI Studio benzeri, profesyonel ve kapsamlı bir dashboard oluşturabilirsin! 🚀