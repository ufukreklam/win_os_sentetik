
# Faz 30: Otonom Navigasyon ve Yol Planlama Spesifikasyonu

Bu döküman, WinOS Robotik Çekirdeği için **A* (A-Star)** algoritması tabanlı otonom navigasyon sisteminin tasarımını içerir.

## 1. Hedef
Robotun, SLAM tarafından oluşturulan doluluk haritası (Occupancy Grid) üzerinde, kullanıcının belirlediği bir hedefe (X, Y) en kısa ve güvenli rotayı bulup bu rotayı takip etmesini sağlamak.

## 2. Sistem Mimarisi

### 2.1 NavigationNode (Backend)
Yeni bir `NavigationNode` oluşturulacaktır. Bu düğüm, haritalama ve motor kontrolü arasında bir köprü görevi görecektir.

*   **Girdiler:**
    *   `map_data`: SlamNode tarafından üretilen 800x800 ızgara.
    *   `telemetry`: Robotun tahmini konumu (Odometri/SLAM'den).
    *   `user_input`: Hedef nokta (Goal Pose).
*   **İşlem:**
    *   **Global Planner:** A* Algoritması ile grid üzerinde path bulma.
    *   **Path Smoothing:** Köşeli A* yolunu yumuşatma (Opsiyonel).
    *   **Local Planner (Controller):** Pure Pursuit veya basit PID ile robotu çizilen yolda tutma.
*   **Çıktılar:**
    *   `navigation_path`: Frontend'de çizim için yol koordinatları (WebSocket).
    *   `serial_write`: Motorlara hız ve dönüş komutları (V, W).

### 2.2 Veri Yapıları

#### Hedef Belirleme Komutu (Frontend -> Backend)
```json
{
  "command": "set_goal",
  "parameters": {
    "x": 3500,  // mm cinsinden harita koordinatı veya grid indeksi
    "y": 1200
  }
}
```

#### Yol Verisi (Backend -> Frontend)
```json
{
  "type": "navigation_path",
  "points": [
    {"x": 0, "y": 0},
    {"x": 50, "y": 10},
    ...
  ]
}
```

## 3. Algoritma Detayları (A*)

1.  **Grid İndirgeme:** 800x800 harita navigasyon için çok büyük olabilir. Yol planlama için 5cm/piksel yerine 10cm veya 20cm/piksel çözünürlükte downsample edilmiş bir "Costmap" kullanılabilir.
2.  **Maliyet Haritası (Costmap):**
    *   Engeller (`L_occ > 50`): Sonsuz maliyet.
    *   Şişirme (Inflation): Robotun fiziksel yarıçapı kadar engellerin etrafı "riskli bölge" olarak işaretlenir.
3.  **Heuristic:** Euclidean distance (Öklid mesafesi).

## 4. Frontend Entegrasyonu

*   **SlamCanvas.tsx:**
    *   Kullanıcı haritaya tıkladığında (`onClick`) tıklanan piksel koordinatları `set_goal` komutu olarak gönderilir.
    *   Backend'den gelen `navigation_path` verisi harita üzerine yeşil bir çizgi olarak çizilir.
*   **SpatialApp.tsx:** Navigasyon kontrolleri (Başlat, Durdur, Hedefi Temizle) eklenebilir.

## 5. Uygulama Planı
1.  `NavigationNode` iskeletinin oluşturulması.
2.  A* algoritmasının Python implementasyonu.
3.  Frontend tıklama olayının WebSocket üzerinden iletilmesi.
4.  Yolun görselleştirilmesi.
5.  Motor kontrol entegrasyonu (Pure Pursuit).
