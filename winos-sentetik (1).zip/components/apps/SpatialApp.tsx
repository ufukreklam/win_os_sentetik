
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Plus, Minus, Maximize, Move } from 'lucide-react';
import { useSpatialControls } from './spatial/useSpatialControls';
import { SpatialSidebar } from './spatial/SpatialSidebar';
import { SpatialStats } from './spatial/SpatialStats';
import { SlamCanvas } from './spatial/SlamCanvas';
import { VisionView } from './spatial/VisionView';
import { FusionView } from './spatial/FusionView';

const SpatialApp: React.FC = () => {
  const { sensorReadings, serialStatus, perceptionState, slamMap } = useOS();
  const [activeTab, setActiveTab] = useState<'slam_2d' | 'slam_3d' | 'vision' | 'fusion'>('slam_2d');
  
  // Custom Hook for View Logic
  const { 
      viewState, 
      resetView, 
      handleZoom, 
      toggleAutoRotate, 
      handleMouseDown, 
      handleMouseMove, 
      handleMouseUp, 
      handleWheel 
  } = useSpatialControls(activeTab);

  // Tab değiştiğinde view ayarlarını sıfırla/ayarla
  useEffect(() => {
      resetView(activeTab);
  }, [activeTab, resetView]);

  return (
    <div className="flex h-full bg-slate-950 text-slate-100 font-sans overflow-hidden">
        
        {/* Sol Menü */}
        <SpatialSidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Ana İçerik */}
        <div className="flex-1 relative flex flex-col">
            {(activeTab === 'slam_2d' || activeTab === 'slam_3d') && (
                <div className="flex-1 relative bg-black overflow-hidden">
                    
                    {/* Render Canvas */}
                    <SlamCanvas 
                        activeTab={activeTab}
                        viewState={viewState}
                        sensorReadings={sensorReadings}
                        perceptionState={perceptionState}
                        serialStatus={serialStatus}
                        slamMap={slamMap}
                        onMouseDown={handleMouseDown}
                        onMouseMove={(e) => handleMouseMove(e, activeTab)}
                        onMouseUp={handleMouseUp}
                        onWheel={handleWheel}
                    />
                    
                    {/* Kontrol Butonları */}
                    <div className="absolute bottom-6 right-6 flex flex-col gap-2 bg-slate-900/80 backdrop-blur border border-white/10 p-2 rounded-lg">
                        <button onClick={() => handleZoom(0.1)} className="p-2 hover:bg-white/10 rounded text-slate-300 hover:text-white" title="Yakınlaş"><Plus size={18} /></button>
                        <button onClick={() => handleZoom(-0.1)} className="p-2 hover:bg-white/10 rounded text-slate-300 hover:text-white" title="Uzaklaş"><Minus size={18} /></button>
                        <button onClick={() => resetView(activeTab)} className="p-2 hover:bg-white/10 rounded text-slate-300 hover:text-white" title="Sıfırla"><Maximize size={18} /></button>
                        {activeTab === 'slam_3d' && (
                             <button onClick={toggleAutoRotate} className="p-2 hover:bg-white/10 rounded text-slate-300 hover:text-white" title="Otomatik Döndür"><Move size={18} /></button>
                        )}
                    </div>

                    {/* Bilgi Paneli */}
                    <SpatialStats 
                        serialStatus={serialStatus}
                        activeTab={activeTab}
                        sensorReadings={sensorReadings}
                        perceptionState={perceptionState}
                    />
                </div>
            )}

            {/* Diğer Sekmeler */}
            {activeTab === 'vision' && <VisionView perceptionState={perceptionState} />}
            {activeTab === 'fusion' && <FusionView perceptionState={perceptionState} />}
        </div>
    </div>
  );
};

export default SpatialApp;
