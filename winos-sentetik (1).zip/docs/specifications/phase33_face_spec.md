
# Faz 33: Yüz İfadesi Donanım Spesifikasyonu

Bu döküman, WinOS Robotik Çekirdeği için **Yüz İfadesi ve Duygu Dışavurum Sistemi (FaceNode)** tasarımını içerir.

## 1. Hedef
Robotun dijital "duygu durumu"nu (Emotion State), fiziksel OLED ekranlar ve RGB LED halkalar aracılığıyla dış dünyaya yansıtmak.

## 2. Donanım Mimarisi (Pico 3 - Display Controller)

*   **Gözler:** 2x SSD1306 128x64 I2C OLED Ekran (Sol ve Sağ Göz).
*   **Ağız:** 1x SSD1306 128x32 veya 128x64 I2C OLED Ekran.
*   **Yanaklar:** 2x WS2812B (NeoPixel) 8-LED Halka.
*   **İletişim:** RPi 5 -> USB Serial -> Pico 3.

## 3. Protokol Genişletmesi

RPi 5'ten Pico'ya giden JSON komut setine yeni anahtarlar eklenir.

### 3.1 Display (Ekran) Komutları (`d`)
Göz ve ağız şekillerini belirler. Önceden tanımlı şekiller (bitmap ID'leri) kullanılır.

```json
{
  "d": {
    "l": "normal",   // Sol Göz: normal, blink, happy, sad, angry, heart, dead
    "r": "normal",   // Sağ Göz
    "m": "smile"     // Ağız: smile, sad, neutral, talk_open, talk_closed
  }
}
```

### 3.2 LED Komutları (`l`)
Yanak ve durum LED'lerini kontrol eder.

```json
{
  "l": {
    "c": [255, 0, 0], // Renk (R, G, B)
    "m": "solid",     // Mod: solid, breathe, blink, rainbow
    "i": 100          // Parlaklık (0-255)
  }
}
```

## 4. Yazılım Mimarisi (FaceNode)

`FaceNode`, soyut duygu durumlarını somut donanım komutlarına çeviren bir "Duygu Derleyicisi" gibi çalışır.

### 4.1 Girdi (Input)
*   `emotion_state`: Frontend veya AI çekirdeğinden gelen duygu paketi (örn. `{"primary": "happy", "intensity": 0.8}`).
*   `speech_activity`: Konuşma durumu (Ağız senkronizasyonu için).

### 4.2 İşlem (Process)
1.  **Duygu Eşlemesi:**
    *   `happy` -> Gözler: `happy_arc`, Ağız: `smile`, LED: `Yellow`.
    *   `angry` -> Gözler: `angry_slope`, Ağız: `frown`, LED: `Red`.
    *   `neutral` -> Gözler: `normal`, Ağız: `line`, LED: `Blue`.
2.  **Otomatik Davranışlar:**
    *   **Göz Kırpma:** Rastgele aralıklarla (2-6 sn) "blink" komutu gönderir.
    *   **Nefes Alma:** LED parlaklığını sinüs dalgası şeklinde değiştirir (Eğer mod `breathe` ise).

### 4.3 Çıktı (Output)
*   `serial_write`: Donanım komut paketi.

## 5. Güvenlik
*   Ekran yanmasını (Burn-in) önlemek için sistem boşta kaldığında (Idle > 5dk) ekranlar otomatik kapanır veya "Ekran Koruyucu" moduna geçer.
