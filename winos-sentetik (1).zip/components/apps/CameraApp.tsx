
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useOS } from '../../context/OSContext';
import { analyzeImage } from '../../services/geminiService';
import { 
  Camera, RefreshCw, Sparkles, Download, 
  X, Circle, AlertCircle, Info, Maximize2, Activity, Wifi, Video
} from 'lucide-react';

const CameraApp: React.FC = () => {
  const { writeFile, addNotification, playSound, processVisualFrame, perceptionState, robotCameraFrame, serialStatus } = useOS();
  const [source, setSource] = useState<'local' | 'robot'>('local');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [isMotionDetectionEnabled, setIsMotionDetectionEnabled] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const robotImageRef = useRef<HTMLImageElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  const startLocalCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setError(null);
    } catch (err) {
      console.error("Camera access error:", err);
      setError("Camera access denied. Please check permissions.");
      addNotification({ title: "Camera Error", message: "Could not access local hardware camera.", type: "error" });
    }
  }, [addNotification]);

  // Source değiştiğinde akışı yönet
  useEffect(() => {
      if (source === 'local') {
          startLocalCamera();
      } else {
          // Stop local stream if switching to robot
          if (stream) {
              stream.getTracks().forEach(track => track.stop());
              setStream(null);
          }
          if (serialStatus !== 'connected') {
               setError("Robot Not Connected. Please connect to hardware first.");
          } else {
               setError(null);
          }
      }
      return () => {
          if (stream) {
              stream.getTracks().forEach(track => track.stop());
          }
      };
  }, [source, serialStatus]); // serialStatus bağımlılığını ekledik

  // Motion Detection Loop
  useEffect(() => {
      if (!isMotionDetectionEnabled || capturedImage) return;

      const loop = () => {
          if (source === 'local' && videoRef.current && videoRef.current.readyState === 4) {
              processVisualFrame(videoRef.current);
          } else if (source === 'robot' && robotImageRef.current) {
              // Robot kamerasından gelen görüntüyü işle
              // Not: HTMLImageElement de CanvasImageSource tipindedir
              processVisualFrame(robotImageRef.current);
          }
          animationFrameRef.current = requestAnimationFrame(loop);
      };
      
      loop();
      return () => {
          if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      };
  }, [isMotionDetectionEnabled, stream, capturedImage, processVisualFrame, source, robotCameraFrame]);

  const takePhoto = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (source === 'local' && videoRef.current) {
        const video = videoRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
    } else if (source === 'robot' && robotImageRef.current) {
        const img = robotImageRef.current;
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
    } else {
        return;
    }
    
    const dataUrl = canvas.toDataURL('image/png');
    setCapturedImage(dataUrl);
    playSound('click');
  };

  const savePhoto = () => {
    if (!capturedImage) return;
    
    const fileName = `IMG_${Date.now()}.png`;
    // Remove prefix for saving to FS
    const base64Data = capturedImage.split(',')[1];
    
    writeFile('/home/user/Pictures', {
      name: fileName,
      type: 'file',
      fileType: 'image',
      size: `${Math.round(base64Data.length * 0.75 / 1024)} KB`,
      permissions: '-rw-r--r--',
      content: base64Data // Save base64
    });
    
    addNotification({ title: "Photo Saved", message: `${fileName} added to Gallery.`, type: "success" });
    setCapturedImage(null);
  };

  const handleAnalyze = async () => {
    if (!capturedImage) return;
    
    setIsAnalyzing(true);
    setAnalysisResult(null);
    playSound('notification');

    // Prepare base64 for API
    const base64Data = capturedImage.split(',')[1];
    
    try {
        const result = await analyzeImage(base64Data, 'image/png');
        setAnalysisResult(result);
    } catch (err) {
        setAnalysisResult("AI analysis failed.");
    } finally {
        setIsAnalyzing(false);
    }
  };

  const discardPhoto = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
  };

  const toggleSource = () => {
      setSource(prev => prev === 'local' ? 'robot' : 'local');
      setCapturedImage(null);
      setError(null);
  };

  return (
    <div className="flex flex-col h-full bg-black text-white relative overflow-hidden select-none">
      {/* Viewport */}
      <div className="flex-1 relative flex items-center justify-center bg-slate-900 overflow-hidden">
        {error ? (
          <div className="flex flex-col items-center gap-4 text-slate-400">
            <AlertCircle size={48} />
            <p className="text-sm">{error}</p>
            {source === 'local' && <button onClick={startLocalCamera} className="bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold">Try Again</button>}
            {source === 'robot' && <button onClick={toggleSource} className="bg-slate-700 text-white px-4 py-2 rounded-lg text-xs font-bold">Switch to Local</button>}
          </div>
        ) : capturedImage ? (
           <div className="w-full h-full relative animate-in fade-in zoom-in-95 duration-300">
              <img src={capturedImage} alt="Captured" className="w-full h-full object-contain" />
              
              {/* AI Analysis Overlay */}
              {isAnalyzing && (
                 <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
                    <Sparkles size={48} className="text-yellow-400 animate-spin" />
                    <span className="text-sm font-bold tracking-widest animate-pulse">AI ANALYZING...</span>
                 </div>
              )}

              {analysisResult && (
                  <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 backdrop-blur-xl border border-white/10 p-4 rounded-xl shadow-2xl animate-in slide-in-from-bottom-4">
                     <div className="flex items-center gap-2 mb-2 text-yellow-400 font-bold text-xs">
                        <Sparkles size={14} />
                        GEMINI VISION SAYS:
                     </div>
                     <p className="text-xs leading-relaxed text-slate-200">{analysisResult}</p>
                     <button onClick={() => setAnalysisResult(null)} className="absolute top-2 right-2 p-1 hover:bg-white/10 rounded-full text-slate-400"><X size={14} /></button>
                  </div>
              )}
           </div>
        ) : (
           source === 'local' ? (
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover mirror-mode"
              />
           ) : (
              <div className="w-full h-full flex items-center justify-center bg-slate-950">
                  {robotCameraFrame ? (
                      <img 
                          ref={robotImageRef}
                          src={robotCameraFrame} 
                          alt="Robot Feed" 
                          className="w-full h-full object-contain"
                      />
                  ) : (
                      <div className="flex flex-col items-center text-slate-500 gap-2 animate-pulse">
                          <Wifi size={32} />
                          <span className="text-xs font-mono">WAITING FOR ROBOT STREAM...</span>
                      </div>
                  )}
              </div>
           )
        )}

        {/* HUD Elements */}
        {!capturedImage && !error && (
            <div className="absolute top-4 left-4 flex flex-col gap-2">
                <div className="flex gap-2 items-center">
                   <div className="bg-red-500 w-2 h-2 rounded-full animate-pulse" />
                   <span className="text-[10px] font-mono tracking-tighter opacity-70">
                       {source === 'local' ? 'LOCAL CAM • 30 FPS' : 'ROBOT STREAM • MJPEG'}
                   </span>
                </div>
                {isMotionDetectionEnabled && (
                    <div className="flex items-center gap-2 bg-black/40 px-2 py-1 rounded backdrop-blur-sm border border-white/10">
                        <Activity size={12} className={perceptionState.motionActivity > 20 ? 'text-red-400' : 'text-green-400'} />
                        <div className="w-16 h-1 bg-slate-700 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 transition-all duration-100" style={{ width: `${perceptionState.motionActivity}%` }} />
                        </div>
                        <span className="text-[10px] font-mono w-6 text-right">{perceptionState.motionActivity.toFixed(0)}%</span>
                    </div>
                )}
            </div>
        )}
        
        {/* Source Toggle */}
        {!capturedImage && (
            <div className="absolute top-4 right-4 flex gap-2">
                 <button 
                    onClick={() => setIsMotionDetectionEnabled(!isMotionDetectionEnabled)}
                    className={`p-2 rounded-full backdrop-blur-md border border-white/10 transition-colors ${isMotionDetectionEnabled ? 'bg-blue-600/20 text-blue-400 border-blue-500/50' : 'bg-black/30 text-slate-400'}`}
                    title="Motion Detection"
                >
                    <Activity size={16} />
                </button>
                <button 
                    onClick={toggleSource}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md border border-white/10 bg-black/30 text-xs font-bold hover:bg-white/10 transition-colors"
                >
                    {source === 'local' ? <Wifi size={14} className="text-slate-400" /> : <Video size={14} className="text-green-400" />}
                    {source === 'local' ? 'LOCAL' : 'ROBOT'}
                </button>
            </div>
        )}
      </div>

      {/* Hidden Canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Controls Bar */}
      <div className="h-24 bg-slate-950/80 backdrop-blur-xl border-t border-white/5 flex items-center justify-around px-8 relative shrink-0">
         {capturedImage ? (
           <>
              <button 
                onClick={discardPhoto}
                className="flex flex-col items-center gap-1 group"
              >
                 <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-red-500/20 transition-colors">
                    <X size={24} className="group-hover:text-red-400" />
                 </div>
                 <span className="text-[10px] uppercase font-bold text-slate-500">Discard</span>
              </button>

              <button 
                onClick={handleAnalyze}
                disabled={isAnalyzing}
                className="flex flex-col items-center gap-1 group"
              >
                 <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-yellow-600 to-amber-400 flex items-center justify-center shadow-lg shadow-amber-500/20 active:scale-95 transition-transform">
                    <Sparkles size={28} className="text-white" />
                 </div>
                 <span className="text-[10px] uppercase font-bold text-amber-400">AI Vision</span>
              </button>

              <button 
                onClick={savePhoto}
                className="flex flex-col items-center gap-1 group"
              >
                 <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center hover:bg-blue-500 transition-colors shadow-lg shadow-blue-500/20">
                    <Download size={24} className="text-white" />
                 </div>
                 <span className="text-[10px] uppercase font-bold text-blue-400">Save</span>
              </button>
           </>
         ) : (
           <>
              <div className="w-12" /> {/* Placeholder */}
              
              <button 
                onClick={takePhoto}
                disabled={!!error || (source === 'robot' && !robotCameraFrame)}
                className="w-16 h-16 rounded-full border-4 border-white/30 p-1 active:scale-90 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
              >
                 <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full border border-slate-300" />
                 </div>
              </button>

              <button 
                onClick={toggleSource}
                className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                title="Switch Source"
              >
                 <RefreshCw size={20} className="text-slate-400" />
              </button>
           </>
         )}
      </div>

      <style>{`
        .mirror-mode {
            transform: scaleX(-1);
        }
      `}</style>
    </div>
  );
};

export default CameraApp;
