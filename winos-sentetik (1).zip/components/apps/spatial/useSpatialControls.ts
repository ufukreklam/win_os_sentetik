
import { useRef, useCallback } from 'react';

export interface ViewState {
    scale: number;
    offsetX: number;
    offsetY: number;
    rotationAngle: number;
    autoRotate: boolean;
    isDragging: boolean;
    lastMouseX: number;
    lastMouseY: number;
}

export const useSpatialControls = (initialTab: string) => {
    const viewState = useRef<ViewState>({
        scale: 1.0,
        offsetX: 0,
        offsetY: 0,
        isDragging: false,
        lastMouseX: 0,
        lastMouseY: 0,
        rotationAngle: 0,
        autoRotate: true
    });

    const resetView = useCallback((tab: string) => {
        if (tab === 'slam_3d') {
            viewState.current = { 
                ...viewState.current, 
                scale: 0.8, 
                offsetX: 0, 
                offsetY: 100, 
                rotationAngle: 0, 
                autoRotate: true 
            };
        } else {
            viewState.current = { 
                ...viewState.current, 
                scale: 1.0, 
                offsetX: 0, 
                offsetY: 0, 
                autoRotate: false 
            };
        }
    }, []);

    const handleZoom = useCallback((delta: number) => {
        viewState.current.scale = Math.max(0.1, Math.min(5.0, viewState.current.scale + delta));
    }, []);

    const toggleAutoRotate = useCallback(() => {
        viewState.current.autoRotate = !viewState.current.autoRotate;
    }, []);

    const handleMouseDown = useCallback((e: React.MouseEvent) => {
        viewState.current.isDragging = true;
        viewState.current.lastMouseX = e.clientX;
        viewState.current.lastMouseY = e.clientY;
        // Kullanıcı müdahale ederse otomatik dönmeyi durdur (3D için)
        viewState.current.autoRotate = false;
    }, []);

    const handleMouseMove = useCallback((e: React.MouseEvent, activeTab: string) => {
        if (!viewState.current.isDragging) return;
        
        const dx = e.clientX - viewState.current.lastMouseX;
        const dy = e.clientY - viewState.current.lastMouseY;
        
        viewState.current.lastMouseX = e.clientX;
        viewState.current.lastMouseY = e.clientY;

        if (activeTab === 'slam_3d') {
            // 3D modunda X hareketi döndürür, Y hareketi yukarı/aşağı taşır
            viewState.current.rotationAngle += dx * 0.01;
            viewState.current.offsetY += dy;
        } else {
            // 2D modunda pan yapar
            viewState.current.offsetX += dx;
            viewState.current.offsetY += dy;
        }
    }, []);

    const handleMouseUp = useCallback(() => {
        viewState.current.isDragging = false;
    }, []);

    const handleWheel = useCallback((e: React.WheelEvent) => {
        const scaleAmount = -e.deltaY * 0.001;
        handleZoom(scaleAmount);
    }, [handleZoom]);

    return {
        viewState,
        resetView,
        handleZoom,
        toggleAutoRotate,
        handleMouseDown,
        handleMouseMove,
        handleMouseUp,
        handleWheel
    };
};
