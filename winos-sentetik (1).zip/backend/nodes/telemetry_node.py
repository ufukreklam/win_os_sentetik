
import time
import random
import logging
from ..core.robot_system import RobotNode

logger = logging.getLogger("TelemetryNode")

class TelemetryNode(RobotNode):
    """
    Sistemin ana telemetri kaynağı.
    1. ProtocolNode'dan gelen 'hardware_update' verisini önbelleğe alır.
    2. PowerNode'dan gelen 'power_analysis' verisini önbelleğe alır.
    3. RPi sistem verilerini okur.
    4. Hepsini birleştirip 'telemetry' kanalına basar.
    """
    def __init__(self, bus):
        super().__init__("TelemetryNode", bus)
        self.loop_interval = 0.1 # 10Hz Yayın Hızı
        self.start_time = time.time()
        
        # Son bilinen donanım durumu (Cache)
        self.hardware_state = {
            "batteryVoltage": 0.0,
            "currentDraw": 0.0,
            "lidarStatus": "Waiting...",
            "imu": {"pitch": 0, "roll": 0, "yaw": 0},
            "ultrasonic": {"front": 0, "left": 0, "right": 0}
        }
        
        # Güç Analiz Verisi (PowerNode'dan)
        self.power_state = {
            "battery": {"percentage": 0, "status": "unknown"},
            "consumption": {"power": 0},
            "estimation": {"time_remaining_seconds": 0}
        }
        
        self.last_hw_update = 0

    async def setup(self):
        # Donanım güncellemelerini dinle
        self.bus.subscribe("hardware_update", self.update_hardware_state)
        # Güç analizlerini dinle
        self.bus.subscribe("power_analysis", self.update_power_state)

    async def update_hardware_state(self, data):
        """ProtocolNode'dan gelen veriyi önbelleğe al"""
        self.hardware_state.update(data)
        self.last_hw_update = time.time()

    async def update_power_state(self, data):
        """PowerNode'dan gelen veriyi önbelleğe al"""
        self.power_state = data

    async def loop(self):
        current_time = time.time()
        
        # 1. Sistem Verilerini Topla (RPi 5 Stats)
        system_stats = {
            "uptime": int(current_time - self.start_time),
            "cpu_usage": 15.0 + (random.random() * 5),
            "memory_usage": 32.0 + (random.random() * 2),
            "disk_usage": 45.0,
            "temperature": 42.0 + (random.random() * 3)
        }

        # 2. Çevresel Veri Simülasyonu
        env_data = {
            "env": {
                "temp": system_stats["temperature"], 
                "humidity": 45.0,
                "airQuality": 100
            }
        }

        # 3. Verileri Birleştir (Merge)
        # System Stats + Hardware Cache + Power Analysis + Env Data
        final_packet = {
            "type": "telemetry",
            "timestamp": current_time,
            **system_stats,
            **self.hardware_state,
            "power": self.power_state, # PowerNode verisi eklendi
            **env_data
        }

        # 4. Donanım Zaman Aşımı Kontrolü
        if current_time - self.last_hw_update > 2.0:
            final_packet["lidarStatus"] = "Hardware Timeout"

        # 5. Frontend'e gönderilmek üzere yayınla
        await self.bus.publish("telemetry", final_packet)
