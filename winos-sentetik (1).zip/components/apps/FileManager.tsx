
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { FileSystemItem, AppID } from '../../types';
import { 
  Folder, FileText, Image, Music, Video, HardDrive, 
  Home, ChevronRight, ArrowLeft, ArrowUp, Terminal,
  Download, Trash2, FileCode, Disc, FolderOpen, Menu, X, Share2, Bluetooth, RotateCcw
} from 'lucide-react';

const FileManager: React.FC = () => {
  const { readdir, deleteItem, restoreItem, moveFile, bluetoothDevices, sendFileBluetooth, addNotification, openApp } = useOS();
  const [currentPath, setCurrentPath] = useState('/home/user');
  const [history, setHistory] = useState<string[]>(['/home/user']);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // Context Menu
  const [contextMenu, setContextMenu] = useState<{ show: boolean; x: number; y: number; item: FileSystemItem } | null>(null);
  const [showShareModal, setShowShareModal] = useState<FileSystemItem | null>(null);

  // Drag State
  const [draggedItem, setDraggedItem] = useState<FileSystemItem | null>(null);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close context menu on global click
  useEffect(() => {
      const handleClick = () => setContextMenu(null);
      window.addEventListener('click', handleClick);
      return () => window.removeEventListener('click', handleClick);
  }, []);

  const getContents = (path: string) => {
    return readdir(path);
  };

  const navigateTo = (path: string) => {
    if (path !== currentPath) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(path);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
      setCurrentPath(path);
      setSelectedItem(null);
    }
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
      setCurrentPath(history[historyIndex - 1]);
      setSelectedItem(null);
    }
  };

  const handleUp = () => {
    if (currentPath === '/') return;
    const parts = currentPath.split('/').filter(Boolean);
    parts.pop();
    const parentPath = '/' + parts.join('/');
    navigateTo(parentPath);
  };

  const handleItemClick = (item: FileSystemItem) => {
    setSelectedItem(item.name);
  };

  const handleItemDoubleClick = (item: FileSystemItem) => {
    if (item.type === 'folder') {
      const nextPath = currentPath === '/' ? `/${item.name}` : `${currentPath}/${item.name}`;
      navigateTo(nextPath);
    } else {
      // File Opening Logic
      if (item.fileType === 'code' || item.name.endsWith('.js') || item.name.endsWith('.sh') || item.name.endsWith('.code')) {
         openApp(AppID.CODE_EDITOR);
      } else if (item.fileType === 'text') {
         openApp(AppID.NOTEPAD);
      } else if (item.name.endsWith('.sh')) {
         openApp(AppID.TERMINAL);
      } else if (item.fileType === 'image') {
         openApp(AppID.PHOTOS);
      } else if (item.fileType === 'music' || item.fileType === 'video') {
         openApp(AppID.MEDIA);
      }
    }
  };

  const handleContextMenu = (e: React.MouseEvent, item: FileSystemItem) => {
      e.preventDefault();
      e.stopPropagation();
      setContextMenu({ show: true, x: e.pageX, y: e.pageY, item });
  };

  const handleDelete = (itemName: string) => {
      // Different message for permanent delete vs move to trash
      const isTrash = currentPath === '/home/user/.Trash';
      const msg = isTrash ? `Permanently delete ${itemName}?` : `Move ${itemName} to Recycle Bin?`;
      
      if(confirm(msg)) {
          deleteItem(currentPath, itemName);
          if (selectedItem === itemName) setSelectedItem(null);
      }
  };

  const handleRestore = (itemName: string) => {
      restoreItem(itemName);
      setContextMenu(null);
  };

  const handleShare = (item: FileSystemItem) => {
      const connectedDevices = bluetoothDevices.filter(d => d.status === 'connected');
      if (connectedDevices.length === 0) {
          addNotification({ title: 'Sharing Failed', message: 'No Bluetooth devices connected. Pair a device in Settings first.', type: 'warning' });
      } else {
          setShowShareModal(item);
      }
  };

  const confirmShare = (deviceId: string) => {
      if (showShareModal) {
          sendFileBluetooth(showShareModal, deviceId);
          setShowShareModal(null);
      }
  };

  // --- Drag and Drop Handlers ---
  const handleDragStart = (e: React.DragEvent, item: FileSystemItem) => {
    setDraggedItem(item);
    e.dataTransfer.setData('text/plain', item.name);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, targetItem?: FileSystemItem) => {
    e.preventDefault();
    if (targetItem && targetItem.type === 'folder' && targetItem.name !== draggedItem?.name) {
       e.dataTransfer.dropEffect = 'move';
    } else {
       e.dataTransfer.dropEffect = 'none';
    }
  };

  const handleDrop = (e: React.DragEvent, targetItem: FileSystemItem) => {
    e.preventDefault();
    if (!draggedItem) return;
    
    // Logic for dropping INTO a subfolder in the current view
    if (targetItem.type === 'folder' && targetItem.name !== draggedItem.name) {
        const destPath = currentPath === '/' ? `/${targetItem.name}` : `${currentPath}/${targetItem.name}`;
        moveFile(currentPath, destPath, draggedItem.name);
    }
    setDraggedItem(null);
  };

  const handleSidebarDrop = (e: React.DragEvent, destPath: string) => {
      e.preventDefault();
      if (!draggedItem) return;
      
      // Prevent moving to self/current folder
      if (destPath === currentPath) return;

      moveFile(currentPath, destPath, draggedItem.name);
      setDraggedItem(null);
  };


  const getIcon = (item: FileSystemItem) => {
    if (item.type === 'folder') return <Folder className="text-blue-400 fill-blue-400/20" size={40} />;
    
    switch (item.fileType) {
      case 'image': return <Image className="text-purple-400" size={40} />;
      case 'music': return <Music className="text-pink-400" size={40} />;
      case 'video': return <Video className="text-red-400" size={40} />;
      case 'code': return <FileCode className="text-green-400" size={40} />;
      default: return <FileText className="text-slate-400" size={40} />;
    }
  };

  const sidebarItems = [
    { name: 'Home', path: '/home/user', icon: Home },
    { name: 'Documents', path: '/home/user/Documents', icon: FileText },
    { name: 'Downloads', path: '/home/user/Downloads', icon: Download },
    { name: 'Pictures', path: '/home/user/Pictures', icon: Image },
    { name: 'Music', path: '/home/user/Music', icon: Music },
    { name: 'Videos', path: '/home/user/Videos', icon: Video },
    { name: 'Recycle Bin', path: '/home/user/.Trash', icon: Trash2 },
    { name: 'Root', path: '/', icon: HardDrive },
  ];

  const currentFiles = getContents(currentPath);

  return (
    <div className="flex h-full bg-slate-900 text-slate-100 font-sans relative overflow-hidden">
      {/* Sidebar - Linux GTK Style */}
      <div className={`
        w-48 bg-slate-900/90 backdrop-blur-xl border-r border-white/5 flex flex-col pt-2
        transition-transform duration-300 z-50
        ${isMobile ? 'absolute h-full' : 'relative'}
        ${isMobile && !isSidebarOpen ? '-translate-x-full' : 'translate-x-0'}
      `}>
        <div className="flex items-center justify-between px-4 py-2">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Places</div>
          {isMobile && (
            <button onClick={() => setIsSidebarOpen(false)} className="p-1 hover:bg-white/10 rounded">
              <X size={16} />
            </button>
          )}
        </div>
        {sidebarItems.map((item) => (
          <button
            key={item.name}
            onClick={() => {
              navigateTo(item.path);
              if (isMobile) setIsSidebarOpen(false);
            }}
            onDragOver={(e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
            }}
            onDrop={(e) => handleSidebarDrop(e, item.path)}
            className={`
              flex items-center gap-3 px-4 py-2 mx-2 rounded-md transition-colors text-sm
              ${currentPath === item.path ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'}
            `}
          >
            <item.icon size={16} className={item.name === 'Recycle Bin' ? 'text-red-400' : ''} />
            <span>{item.name}</span>
          </button>
        ))}
        
        <div className="px-4 py-2 mt-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Devices</div>
        <button className="flex items-center gap-3 px-4 py-2 mx-2 rounded-md text-slate-400 hover:text-slate-200 hover:bg-white/10 text-sm">
             <Disc size={16} />
             <span>WinOS Hybrid</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Navigation Bar */}
        <div className="h-12 border-b border-white/5 flex items-center px-4 gap-2 bg-slate-800/30">
          {isMobile && (
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-1.5 hover:bg-white/10 rounded-md mr-2"
            >
              <Menu size={20} />
            </button>
          )}
          <div className="flex items-center gap-1 mr-2 shrink-0">
            <button 
                onClick={handleBack} 
                disabled={historyIndex === 0}
                className="p-1.5 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:cursor-not-allowed"
            >
                <ArrowLeft size={16} />
            </button>
            <button 
                onClick={handleUp}
                disabled={currentPath === '/'}
                className="p-1.5 hover:bg-white/10 rounded-full disabled:opacity-30 disabled:cursor-not-allowed"
            >
                <ArrowUp size={16} />
            </button>
          </div>

          {/* Linux-style Breadcrumb / Path Bar */}
          <div className="flex-1 bg-slate-900/50 border border-white/10 rounded-md px-3 py-1.5 flex items-center text-sm font-mono text-green-400 truncate">
             <span className="opacity-50 select-none mr-2 hidden sm:inline">user@winos:</span>
             <span className="truncate">{currentPath}</span>
          </div>
        </div>

        {/* File Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-[repeat(auto-fill,minmax(90px,1fr))] gap-2 sm:gap-4">
             {currentFiles.map((item, idx) => (
               <div
                 key={idx}
                 draggable={true}
                 onDragStart={(e) => handleDragStart(e, item)}
                 onDragOver={(e) => handleDragOver(e, item)}
                 onDrop={(e) => handleDrop(e, item)}
                 onContextMenu={(e) => handleContextMenu(e, item)}
                 className={`
                    group relative flex flex-col items-center gap-2 p-2 sm:p-3 rounded-lg hover:bg-white/5 transition-all cursor-pointer select-none
                    ${selectedItem === item.name ? 'bg-blue-600/20 ring-1 ring-blue-500/50' : ''}
                    ${draggedItem?.name === item.name ? 'opacity-50 border border-dashed border-white/30' : ''}
                 `}
                 onClick={() => handleItemClick(item)}
                 onDoubleClick={() => handleItemDoubleClick(item)}
               >
                 <div className="transition-transform active:scale-95 pointer-events-none">
                    {getIcon(item)}
                 </div>
                 <span className="text-[10px] sm:text-xs text-center break-all line-clamp-2">{item.name}</span>
               </div>
             ))}
             
             {currentFiles.length === 0 && (
                <div className="col-span-full flex flex-col items-center justify-center text-slate-500 py-10 opacity-50">
                    <FolderOpen size={48} className="mb-2" />
                    <span className="text-sm">
                        {currentPath === '/home/user/.Trash' ? 'Recycle Bin is Empty' : 'Empty Directory'}
                    </span>
                </div>
             )}
          </div>
        </div>

        {/* Footer / Status Bar (Linux Terminal Aesthetic) */}
        <div className="h-8 bg-slate-900 border-t border-white/5 px-4 flex items-center justify-between text-[10px] sm:text-xs font-mono text-slate-400 select-none">
            <div className="flex items-center gap-2 truncate">
                <Terminal size={12} className="shrink-0" />
                <span>{currentFiles.length} items</span>
            </div>
            <div className="truncate ml-4">
               {selectedItem ? (
                 <span className="text-slate-300">Selected: {selectedItem}</span>
               ) : (
                 <span className="hidden sm:inline">Free space: 42.0 GB</span>
               )}
            </div>
        </div>

        {/* Context Menu */}
        {contextMenu && (
            <div 
                className="fixed z-[9999] bg-slate-800 border border-white/10 rounded-lg shadow-xl py-1 text-xs text-slate-200 min-w-[140px] animate-in fade-in zoom-in-95 duration-100"
                style={{ top: contextMenu.y, left: contextMenu.x }}
            >
                <div className="px-3 py-1 font-bold text-slate-400 truncate border-b border-white/5 mb-1 max-w-[140px]">
                    {contextMenu.item.name}
                </div>
                <button 
                    onClick={() => { handleItemDoubleClick(contextMenu.item); setContextMenu(null); }}
                    className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2"
                >
                    <FolderOpen size={12} /> Open
                </button>
                {/* Restore Option - Only in Trash */}
                {currentPath === '/home/user/.Trash' && (
                    <button 
                        onClick={() => handleRestore(contextMenu.item.name)}
                        className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2 text-green-400"
                    >
                        <RotateCcw size={12} /> Restore
                    </button>
                )}
                {contextMenu.item.type === 'file' && currentPath !== '/home/user/.Trash' && (
                    <button 
                        onClick={() => { handleShare(contextMenu.item); setContextMenu(null); }}
                        className="w-full text-left px-3 py-1.5 hover:bg-white/10 flex items-center gap-2"
                    >
                        <Share2 size={12} /> Share via Bluetooth
                    </button>
                )}
                <div className="h-[1px] bg-white/5 my-1" />
                <button 
                    onClick={() => { handleDelete(contextMenu.item.name); setContextMenu(null); }}
                    className="w-full text-left px-3 py-1.5 hover:bg-white/10 text-red-400 flex items-center gap-2"
                >
                    <Trash2 size={12} /> {currentPath === '/home/user/.Trash' ? 'Delete Permanently' : 'Delete'}
                </button>
            </div>
        )}

        {/* Share Modal */}
        {showShareModal && (
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
                <div className="bg-slate-900 border border-white/10 rounded-xl w-80 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
                    <div className="bg-slate-800 px-4 py-3 border-b border-white/10 flex justify-between items-center">
                        <div className="font-bold text-sm flex items-center gap-2">
                            <Bluetooth size={16} className="text-blue-400" />
                            Select Device
                        </div>
                        <button onClick={() => setShowShareModal(null)} className="hover:text-white text-slate-400"><X size={16} /></button>
                    </div>
                    <div className="p-2">
                        <div className="text-xs text-center text-slate-400 mb-2">
                            Sharing: <span className="text-white">{showShareModal.name}</span>
                        </div>
                        <div className="space-y-1">
                            {bluetoothDevices.filter(d => d.status === 'connected').map(dev => (
                                <button
                                    key={dev.id}
                                    onClick={() => confirmShare(dev.id)}
                                    className="w-full text-left px-3 py-2 hover:bg-white/5 rounded-lg flex items-center justify-between group transition-colors"
                                >
                                    <span className="text-sm">{dev.name}</span>
                                    <span className="text-xs text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity">Send</span>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        )}
      </div>

      {/* Mobile Backdrop */}
      {isMobile && isSidebarOpen && (
        <div 
          className="absolute inset-0 bg-black/40 backdrop-blur-sm z-40 animate-in fade-in"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default FileManager;
