
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { HardwareConfig } from '../../types';

const BiosScreen: React.FC = () => {
  const { hardwareConfig, setHardwareConfig, setBootState, bootMode, setBootMode } = useOS();
  const [activeTab, setActiveTab] = useState(0);
  const [selectedRow, setSelectedRow] = useState(0);
  const [tempConfig, setTempConfig] = useState<HardwareConfig>({ ...hardwareConfig });
  const [tempBootMode, setTempBootMode] = useState(bootMode);
  const [showExitDialog, setShowExitDialog] = useState(false);

  const TABS = ['Main', 'Advanced', 'Boot', 'Exit'];
  
  const handleKeyDown = (e: KeyboardEvent) => {
    if (showExitDialog) {
        if (e.key === 'y' || e.key === 'Enter') handleSaveExit();
        if (e.key === 'n' || e.key === 'Escape') setShowExitDialog(false);
        return;
    }

    switch (e.key) {
      case 'ArrowRight':
        setActiveTab(prev => (prev + 1) % TABS.length);
        setSelectedRow(0);
        break;
      case 'ArrowLeft':
        setActiveTab(prev => (prev - 1 + TABS.length) % TABS.length);
        setSelectedRow(0);
        break;
      case 'ArrowDown':
        setSelectedRow(prev => Math.min(prev + 1, 5)); // Limit based on max items
        break;
      case 'ArrowUp':
        setSelectedRow(prev => Math.max(prev - 1, 0));
        break;
      case 'Enter':
        handleInteraction();
        break;
      case 'Escape':
        setShowExitDialog(true);
        break;
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTab, selectedRow, showExitDialog]);

  const handleInteraction = () => {
    if (activeTab === 1) { // Advanced
        if (selectedRow === 0) {
            setTempConfig(prev => ({ ...prev, overclock: !prev.overclock }));
        }
    } else if (activeTab === 2) { // Boot
        if (selectedRow === 0) {
            setTempConfig(prev => ({ ...prev, fastBoot: !prev.fastBoot }));
        } else if (selectedRow === 1) {
            // Cycle boot order simplistic
            const orders = ['SD -> NVMe -> USB', 'NVMe -> USB -> SD', 'USB -> SD -> NVMe'];
            const currentIdx = orders.findIndex(o => tempConfig.bootOrder.includes(o));
            const nextOrder = orders[(currentIdx + 1) % orders.length];
            setTempConfig(prev => ({ ...prev, bootOrder: `0x${(currentIdx+2) * 10} (${nextOrder})` }));
        } else if (selectedRow === 2) {
            setTempBootMode(prev => prev === 'normal' ? 'safe' : 'normal');
        }
    } else if (activeTab === 3) { // Exit
        if (selectedRow === 0) handleSaveExit();
        if (selectedRow === 1) setBootState('os'); // Discard
    }
  };

  const handleSaveExit = () => {
      setHardwareConfig(tempConfig);
      setBootMode(tempBootMode);
      setBootState('os');
  };

  const renderContent = () => {
    switch (activeTab) {
        case 0: // Main
            return (
                <div className="space-y-2">
                    <div className="flex justify-between w-96"><span className="text-blue-900">System Time</span> <span className="text-white">{new Date().toLocaleTimeString()}</span></div>
                    <div className="flex justify-between w-96"><span className="text-blue-900">System Date</span> <span className="text-white">{new Date().toLocaleDateString()}</span></div>
                    <div className="mt-4 text-gray-500">Legacy Diskette A: [None]</div>
                    <div className="text-gray-500">Legacy Diskette B: [None]</div>
                    <div className="mt-4 flex justify-between w-96"><span className="text-blue-900">Total Memory</span> <span className="text-white">{tempConfig.ramSize}</span></div>
                </div>
            );
        case 1: // Advanced
            return (
                <div className="space-y-2">
                    <div className={`flex justify-between w-96 px-1 ${selectedRow === 0 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>
                        <span>Overclocking Profile</span> 
                        <span>[{tempConfig.overclock ? 'Performance' : 'Standard'}]</span>
                    </div>
                    <div className="text-gray-500 px-1 mt-4"> CPU Configuration</div>
                    <div className="text-gray-500 px-1"> Chipset Configuration</div>
                    <div className="text-gray-500 px-1"> Onboard Devices Configuration</div>
                </div>
            );
        case 2: // Boot
            return (
                <div className="space-y-2">
                    <div className={`flex justify-between w-96 px-1 ${selectedRow === 0 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>
                        <span>Quick Boot</span> 
                        <span>[{tempConfig.fastBoot ? 'Enabled' : 'Disabled'}]</span>
                    </div>
                    <div className={`flex justify-between w-96 px-1 ${selectedRow === 1 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>
                        <span>Boot Priority</span> 
                        <span>[{tempConfig.bootOrder.split('(')[1].replace(')', '')}]</span>
                    </div>
                    <div className={`flex justify-between w-96 px-1 ${selectedRow === 2 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>
                        <span>Boot Mode</span> 
                        <span>[{tempBootMode === 'safe' ? 'Safe Mode' : 'Normal'}]</span>
                    </div>
                </div>
            );
        case 3: // Exit
            return (
                <div className="space-y-2">
                    <div className={`px-1 ${selectedRow === 0 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>Save Changes and Exit</div>
                    <div className={`px-1 ${selectedRow === 1 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>Discard Changes and Exit</div>
                    <div className={`px-1 ${selectedRow === 2 ? 'bg-white text-blue-800' : 'text-blue-900'}`}>Load Optimal Defaults</div>
                </div>
            );
    }
  };

  return (
    <div className="fixed inset-0 bg-blue-700 font-mono text-white select-none z-[9999] p-4 flex flex-col">
       {/* Header */}
       <div className="border border-white p-1 text-center bg-gray-300 text-blue-800 font-bold shadow-md mb-4">
          WinOS Hybrid BIOS Setup Utility
       </div>

       {/* Tabs */}
       <div className="flex gap-8 px-4 mb-2">
          {TABS.map((tab, i) => (
             <div key={tab} className={`${activeTab === i ? 'bg-white text-blue-800' : 'text-gray-300'} px-2`}>
                {tab}
             </div>
          ))}
       </div>

       {/* Main Content Area */}
       <div className="flex-1 border-2 border-white flex">
           {/* Left Config Panel */}
           <div className="w-2/3 p-4 border-r border-white/50">
               {renderContent()}
           </div>

           {/* Right Help Panel */}
           <div className="w-1/3 p-4 text-blue-900 bg-gray-300 text-sm leading-relaxed">
              <div className="font-bold mb-2">Item Specific Help</div>
              {activeTab === 0 && <p>Sets the system time and date. Use Tab to switch between elements.</p>}
              {activeTab === 1 && <p>Enable Overclocking to boost Pi5 CPU clock to 2.8GHz. Requires active cooling.</p>}
              {activeTab === 2 && <p>Select Boot Mode. Safe Mode loads minimal drivers and disables network features.</p>}
              {activeTab === 3 && <p>Exit system setup after saving the changes. <br/>F10 key can be used for this operation.</p>}
           </div>
       </div>

       {/* Footer */}
       <div className="mt-4 flex justify-between text-sm text-gray-300">
          <div>Esc: Exit</div>
          <div>↑↓: Select Item</div>
          <div>←→: Select Menu</div>
          <div>Enter: Select \ Sub-menu</div>
          <div>F10: Save and Exit</div>
       </div>

       {/* Exit Dialog */}
       {showExitDialog && (
           <div className="absolute inset-0 flex items-center justify-center bg-black/50">
               <div className="bg-red-700 p-1 border-2 border-white shadow-xl w-64">
                   <div className="bg-gray-300 text-black text-center py-4 px-2">
                       <p className="mb-4">Save configuration changes and exit now?</p>
                       <div className="flex justify-center gap-4">
                           <span className="bg-black text-white px-2 cursor-pointer">[Ok]</span>
                           <span className="bg-gray-400 px-2 cursor-pointer">[Cancel]</span>
                       </div>
                   </div>
               </div>
           </div>
       )}
    </div>
  );
};

export default BiosScreen;
