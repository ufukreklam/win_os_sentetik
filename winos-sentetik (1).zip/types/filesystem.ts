
export interface FileSystemItem {
  name: string;
  type: 'folder' | 'file';
  fileType?: 'text' | 'image' | 'code' | 'music' | 'video' | 'unknown';
  size?: string;
  permissions?: string;
  owner?: string; // Username of the owner
  content?: string;
  dateModified?: Date;
  originalPath?: string; // For Recycle Bin restoration
}

export interface FileSystemContextType {
  fs: Record<string, FileSystemItem[]>; // Key is path, Value is contents
  readdir: (path: string) => FileSystemItem[];
  readFile: (path: string, fileName: string) => FileSystemItem | null;
  writeFile: (path: string, file: FileSystemItem) => void;
  mkdir: (path: string, folderName: string) => void;
  deleteItem: (path: string, itemName: string) => void;
  restoreItem: (itemName: string) => void;
  moveFile: (sourcePath: string, destPath: string, itemName: string) => void;
  updateFileMetadata: (path: string, fileName: string, updates: Partial<FileSystemItem>) => void;
}

export type SyncStatus = 'synced' | 'syncing' | 'error' | 'offline';
