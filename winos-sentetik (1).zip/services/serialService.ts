
/**
 * Service to handle Web Serial API interactions for the WinOS Hybrid Robotics Platform.
 * Supports reading newline-delimited JSON or text data from a microcontroller.
 */
export class SerialService {
  private port: any | null = null;
  private reader: ReadableStreamDefaultReader | null = null;
  private writer: WritableStreamDefaultWriter | null = null;
  private keepReading = false;
  private decoder = new TextDecoder();
  private encoder = new TextEncoder();
  private buffer = '';

  /**
   * Request a port and open a connection.
   * @param onData Callback for received data lines
   * @param onError Callback for errors
   */
  async connect(onData: (data: string) => void, onError: (err: Error) => void) {
    if (!('serial' in navigator)) {
      throw new Error('Web Serial API not supported in this browser.');
    }

    try {
      // @ts-ignore - Navigator serial types
      this.port = await navigator.serial.requestPort();
      await this.port.open({ baudRate: 115200 }); // Standard baud rate for RP2040/ESP32

      this.keepReading = true;
      
      // Setup Writer
      if (this.port.writable) {
         this.writer = this.port.writable.getWriter();
      }

      // Start Read Loop
      this.readLoop(onData, onError);
      return true;
    } catch (err) {
      console.error('Serial Connection Failed:', err);
      throw err;
    }
  }

  /**
   * Internal loop to continuously read from the port.
   */
  private async readLoop(onData: (data: string) => void, onError: (err: Error) => void) {
    while (this.port?.readable && this.keepReading) {
      try {
        this.reader = this.port.readable.getReader();
        
        while (true) {
          const { value, done } = await this.reader.read();
          if (done) {
            // Allow the serial port to be closed later.
            break;
          }
          if (value) {
            const chunk = this.decoder.decode(value);
            this.buffer += chunk;
            this.processBuffer(onData);
          }
        }
      } catch (error) {
        onError(error as Error);
        break;
      } finally {
        if (this.reader) {
            this.reader.releaseLock();
        }
      }
    }
  }

  /**
   * Process the buffer to extract complete lines (newline delimited).
   */
  private processBuffer(onData: (data: string) => void) {
    const lines = this.buffer.split('\n');
    // The last element is potentially incomplete, keep it in buffer
    this.buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.trim()) {
        onData(line.trim());
      }
    }
  }

  /**
   * Send data to the connected device.
   */
  async send(data: string) {
    if (!this.writer) return;
    try {
        await this.writer.write(this.encoder.encode(data + '\n'));
    } catch (err) {
        console.error('Failed to send serial data:', err);
    }
  }

  /**
   * Close the connection.
   */
  async disconnect() {
    this.keepReading = false;
    
    if (this.reader) {
      await this.reader.cancel();
    }
    
    if (this.writer) {
        await this.writer.close();
        this.writer = null;
    }

    if (this.port) {
      await this.port.close();
      this.port = null;
    }
  }
}

export const serialService = new SerialService();
