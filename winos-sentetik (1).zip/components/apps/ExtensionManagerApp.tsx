
import React, { useState } from 'react';
import { useOS } from '../../context/OSContext';
import { Puzzle, ShieldCheck, Cpu, HardDrive, RefreshCw, AlertTriangle, Play, Pause, Activity, Lock } from 'lucide-react';
import { PluginStatus } from '../../types';

const ExtensionManagerApp: React.FC = () => {
  const { pluginState, togglePlugin, uninstallPlugin } = useOS();
  const [activeTab, setActiveTab] = useState<'runtime' | 'security'>('runtime');

  const getLifecycleColor = (status: string) => {
      switch(status) {
          case 'active': return 'text-green-400';
          case 'loading': return 'text-blue-400';
          case 'validating': return 'text-yellow-400';
          case 'error': return 'text-red-400';
          case 'unloaded': return 'text-slate-500';
          default: return 'text-slate-400';
      }
  };

  const RuntimeCard: React.FC<{ plugin: PluginStatus }> = ({ plugin }) => (
      <div className="bg-white/5 border border-white/5 rounded-xl p-4 flex flex-col gap-3 group hover:border-white/10 transition-colors">
          <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${plugin.isEnabled ? 'bg-purple-600/20 text-purple-400' : 'bg-slate-800 text-slate-500'}`}>
                      <Puzzle size={20} />
                  </div>
                  <div>
                      <h3 className="font-bold text-sm text-slate-200">{plugin.metadata.name}</h3>
                      <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono uppercase tracking-wider">
                          <span className={getLifecycleColor(plugin.lifecycle)}>{plugin.lifecycle}</span>
                          <span>•</span>
                          <span>v{plugin.metadata.version}</span>
                      </div>
                  </div>
              </div>
              <button 
                  onClick={() => togglePlugin(plugin.id)}
                  className={`p-2 rounded-full transition-colors ${plugin.isEnabled ? 'hover:bg-red-500/20 text-green-400 hover:text-red-400' : 'hover:bg-green-500/20 text-slate-500 hover:text-green-400'}`}
                  title={plugin.isEnabled ? 'Disable' : 'Enable'}
              >
                  {plugin.isEnabled ? <Pause size={16} /> : <Play size={16} />}
              </button>
          </div>

          {/* Resources */}
          {plugin.isEnabled && (
              <div className="grid grid-cols-2 gap-2 mt-2 bg-black/20 p-2 rounded-lg">
                  <div className="flex items-center gap-2">
                      <Cpu size={12} className="text-blue-400" />
                      <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${(plugin.resources?.cpu || 0) * 10}%` }} />
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 w-8 text-right">{(plugin.resources?.cpu || 0).toFixed(1)}%</span>
                  </div>
                  <div className="flex items-center gap-2">
                      <HardDrive size={12} className="text-orange-400" />
                      <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-orange-500 transition-all duration-500" style={{ width: `${Math.min(100, (plugin.resources?.ram || 0) / 2)}%` }} />
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 w-8 text-right">{(plugin.resources?.ram || 0).toFixed(0)}MB</span>
                  </div>
              </div>
          )}
      </div>
  );

  const SecurityRow: React.FC<{ plugin: PluginStatus }> = ({ plugin }) => (
      <div className="flex items-center justify-between p-3 border-b border-white/5 hover:bg-white/5 transition-colors">
          <div className="flex items-center gap-3">
              <ShieldCheck size={16} className={plugin.securityCheck === 'passed' ? 'text-green-400' : 'text-yellow-400'} />
              <span className="text-sm font-medium">{plugin.metadata.name}</span>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-400">
              <span className="bg-white/5 px-2 py-0.5 rounded font-mono">{plugin.metadata.permissions.join(', ')}</span>
              <span className={`uppercase font-bold ${plugin.securityCheck === 'passed' ? 'text-green-500' : 'text-yellow-500'}`}>
                  {plugin.securityCheck}
              </span>
          </div>
      </div>
  );

  return (
    <div className="flex h-full bg-[#111] text-slate-200 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/50 border-r border-white/10 flex flex-col py-4 gap-2 shrink-0">
            <div className="px-4 mb-4">
                <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Orchestrator</h2>
                <div className="text-xs text-slate-600">Layer 16 Control</div>
            </div>
            
            <button 
                onClick={() => setActiveTab('runtime')}
                className={`flex items-center gap-3 px-4 py-2 mx-2 rounded-lg transition-colors ${activeTab === 'runtime' ? 'bg-purple-600/20 text-purple-400' : 'text-slate-400 hover:bg-white/5'}`}
            >
                <Activity size={18} />
                <span className="hidden md:inline text-sm font-medium">Runtime</span>
            </button>
            <button 
                onClick={() => setActiveTab('security')}
                className={`flex items-center gap-3 px-4 py-2 mx-2 rounded-lg transition-colors ${activeTab === 'security' ? 'bg-green-600/20 text-green-400' : 'text-slate-400 hover:bg-white/5'}`}
            >
                <Lock size={18} />
                <span className="hidden md:inline text-sm font-medium">Security</span>
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col min-w-0">
            {activeTab === 'runtime' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-light">Active Extensions</h2>
                        <div className="flex gap-2 text-xs">
                            <span className="px-2 py-1 bg-green-500/10 text-green-400 rounded border border-green-500/20">
                                {pluginState.filter(p => p.lifecycle === 'active').length} Running
                            </span>
                            <span className="px-2 py-1 bg-slate-800 text-slate-400 rounded border border-white/5">
                                {pluginState.reduce((acc, curr) => acc + (curr.resources?.ram || 0), 0).toFixed(0)} MB Total
                            </span>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {pluginState.map(plugin => (
                            <RuntimeCard key={plugin.id} plugin={plugin} />
                        ))}
                    </div>
                    
                    {pluginState.length === 0 && (
                        <div className="text-center py-20 text-slate-500 italic">
                            No extensions loaded. Visit the App Store to install plugins.
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'security' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="bg-slate-900 border border-white/10 rounded-xl overflow-hidden">
                        <div className="p-4 border-b border-white/10 bg-white/5 flex justify-between items-center">
                            <h3 className="font-bold text-sm text-slate-300">Sandboxed Execution Environment</h3>
                            <span className="text-xs text-green-400 font-mono">SECURE_BOOT_VERIFIED</span>
                        </div>
                        <div className="divide-y divide-white/5">
                            {pluginState.map(plugin => (
                                <SecurityRow key={plugin.id} plugin={plugin} />
                            ))}
                        </div>
                    </div>
                    
                    <div className="mt-6 p-4 bg-yellow-900/10 border border-yellow-500/20 rounded-xl flex gap-3">
                        <AlertTriangle className="text-yellow-500 shrink-0" size={20} />
                        <div>
                            <h4 className="text-sm font-bold text-yellow-500">Isolation Protocol Active</h4>
                            <p className="text-xs text-slate-400 mt-1">
                                All plugins operate within restricted memory spaces. Direct hardware access is mediated through the Layer 15 HAL Bridge.
                                Unauthorized access attempts will trigger an immediate suspension.
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default ExtensionManagerApp;
