
import React, { useState, useEffect } from 'react';
import { useOS } from '../../context/OSContext';
import { vectorStore } from '../../services/vectorStore';
import { Database, Clock, Zap, Search, HardDrive, FileText, Brain, Hash, Layers, RefreshCw } from 'lucide-react';

const MemoryApp: React.FC = () => {
  const { learningState, memoryState } = useOS();
  const [activeTab, setActiveTab] = useState<'working' | 'episodic' | 'semantic' | 'vector'>('working');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Vector Stats State
  const [vectorStats, setVectorStats] = useState({ count: 0, memoryUsage: 0 });

  useEffect(() => {
      const stats = vectorStore.getStats();
      setVectorStats(stats);
      const interval = setInterval(() => {
          setVectorStats(vectorStore.getStats());
      }, 2000);
      return () => clearInterval(interval);
  }, []);

  const handleClearVector = () => {
      if(confirm("Are you sure you want to clear all semantic memories?")) {
          vectorStore.clear();
          setVectorStats(vectorStore.getStats());
      }
  };

  const episodicMemories = memoryState.episodicLog;
  const workingMemoryTokens = memoryState.workingContext;

  return (
    <div className="flex h-full bg-[#0a0a0a] text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-slate-900/50 border-r border-white/10 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('working')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'working' ? 'bg-orange-600/20 text-orange-400 border-l-2 border-orange-500' : 'text-slate-500'}`}
            >
                <Zap size={20} />
                <span className="hidden md:inline text-sm font-medium">Working Memory</span>
            </button>
            <button 
                onClick={() => setActiveTab('episodic')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'episodic' ? 'bg-blue-600/20 text-blue-400 border-l-2 border-blue-500' : 'text-slate-500'}`}
            >
                <Clock size={20} />
                <span className="hidden md:inline text-sm font-medium">Episodic Log</span>
            </button>
            <button 
                onClick={() => setActiveTab('semantic')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'semantic' ? 'bg-purple-600/20 text-purple-400 border-l-2 border-purple-500' : 'text-slate-500'}`}
            >
                <Database size={20} />
                <span className="hidden md:inline text-sm font-medium">Semantic DB</span>
            </button>
            <button 
                onClick={() => setActiveTab('vector')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'vector' ? 'bg-green-600/20 text-green-400 border-l-2 border-green-500' : 'text-slate-500'}`}
            >
                <Brain size={20} />
                <span className="hidden md:inline text-sm font-medium">Vector Store</span>
            </button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col min-w-0">
            
            {activeTab === 'working' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="mb-6 flex justify-between items-end">
                        <div>
                            <h2 className="text-2xl font-light text-white mb-1 flex items-center gap-2">
                                <Zap className="text-orange-400" /> Active Context
                            </h2>
                            <p className="text-sm text-slate-400">Short-term volatile memory buffer (Simulated RAM).</p>
                        </div>
                        <div className="text-right">
                            <div className="text-xs text-slate-500 uppercase tracking-widest mb-1">Context Load</div>
                            <div className="text-xl font-mono text-orange-400">{workingMemoryTokens.length * 32} / 4096 <span className="text-xs">Tokens</span></div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                        <div className="bg-slate-900/50 border border-white/5 rounded-xl p-6 relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-20">
                                <Layers size={100} />
                            </div>
                            
                            <h3 className="text-sm font-bold text-slate-300 mb-4">Focus Stream</h3>
                            <div className="flex gap-4 overflow-x-auto pb-4">
                                {workingMemoryTokens.map(token => (
                                    <div key={token.id} className="min-w-[120px] bg-white/5 border border-white/10 rounded-lg p-3 flex flex-col gap-2">
                                        <div className="flex justify-between items-center">
                                            <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                                                token.type === 'entity' ? 'bg-blue-500/20 text-blue-300' :
                                                token.type === 'intent' ? 'bg-red-500/20 text-red-300' :
                                                'bg-slate-500/20 text-slate-300'
                                            }`}>
                                                {token.type}
                                            </span>
                                            <span className="text-[10px] text-slate-500">{token.activation.toFixed(1)}</span>
                                        </div>
                                        <span className="font-medium text-sm truncate">{token.content}</span>
                                        <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                                            <div className="h-full bg-orange-500" style={{ width: `${token.activation * 100}%` }} />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'episodic' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <h2 className="text-2xl font-light text-white mb-6 flex items-center gap-2">
                        <Clock className="text-blue-400" /> Event Timeline
                    </h2>
                    <div className="relative border-l border-white/10 ml-3 space-y-8">
                        {episodicMemories.map((mem) => (
                            <div key={mem.id} className="ml-6 relative animate-in slide-in-from-left-2 duration-300">
                                <div className={`absolute -left-[31px] top-0 w-4 h-4 rounded-full border-2 ${
                                    mem.category === 'system' ? 'bg-slate-900 border-blue-500' :
                                    mem.category === 'error' ? 'bg-slate-900 border-red-500' :
                                    mem.category === 'achievement' ? 'bg-slate-900 border-green-500' :
                                    'bg-slate-900 border-purple-500'
                                }`} />
                                <div className="bg-white/5 rounded-lg p-4 border border-white/5 hover:bg-white/10 transition-colors">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="font-bold text-sm text-slate-200">{mem.event}</span>
                                        <span className="text-xs text-slate-500 font-mono">
                                            {mem.timestamp.toLocaleTimeString()}
                                        </span>
                                    </div>
                                    <div className="flex gap-2 mt-2">
                                        <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-slate-400 uppercase tracking-wider">
                                            {mem.category}
                                        </span>
                                        {mem.emotion && (
                                            <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-slate-400 uppercase tracking-wider">
                                                Mood: {mem.emotion}
                                            </span>
                                        )}
                                        <span className="text-[10px] text-slate-500 font-mono ml-auto">
                                            ID: {mem.id.substring(0, 8)}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'semantic' && (
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-light text-white flex items-center gap-2">
                            <Database className="text-purple-400" /> Knowledge Base
                        </h2>
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
                            <input 
                                type="text" 
                                placeholder="Search concepts..." 
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="bg-white/5 border border-white/10 rounded-full py-1.5 pl-9 pr-4 text-xs text-slate-200 outline-none focus:border-purple-500 w-48"
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {learningState.knowledgeGraph
                            .filter(n => n.label.toLowerCase().includes(searchQuery.toLowerCase()))
                            .map(node => (
                            <div key={node.id} className="bg-white/5 border border-white/5 rounded-xl p-4 hover:border-purple-500/50 transition-colors group">
                                <div className="flex justify-between items-start mb-2">
                                    <div className={`p-2 rounded-lg ${
                                        node.type === 'concept' ? 'bg-blue-500/20 text-blue-400' :
                                        node.type === 'action' ? 'bg-pink-500/20 text-pink-400' :
                                        'bg-yellow-500/20 text-yellow-400'
                                    }`}>
                                        {node.type === 'concept' ? <Brain size={16} /> : 
                                         node.type === 'action' ? <Zap size={16} /> : <HardDrive size={16} />}
                                    </div>
                                    <span className="text-[10px] font-mono text-slate-500">#{node.id}</span>
                                </div>
                                <h3 className="font-bold text-sm mb-1">{node.label}</h3>
                                <div className="text-xs text-slate-400 mb-3">
                                    Connections: {node.connections.length}
                                </div>
                                <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-purple-500" style={{ width: `${node.activation * 100}%` }} />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            {activeTab === 'vector' && (
                <div className="flex-1 p-6 overflow-y-auto">
                     <div className="mb-6 flex justify-between items-end">
                        <div>
                            <h2 className="text-2xl font-light text-white mb-1 flex items-center gap-2">
                                <Brain className="text-green-400" /> Vector Database
                            </h2>
                            <p className="text-sm text-slate-400">RAG (Retrieval-Augmented Generation) Index.</p>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={handleClearVector} className="text-xs bg-red-900/30 text-red-400 px-3 py-1.5 rounded border border-red-500/30 hover:bg-red-900/50">Clear DB</button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white/5 border border-white/5 rounded-xl p-6">
                            <h3 className="text-sm font-bold text-slate-300 mb-4">Storage Stats</h3>
                            <div className="space-y-4">
                                <div className="flex justify-between items-center">
                                    <span className="text-slate-400">Total Vectors</span>
                                    <span className="text-2xl font-mono text-green-400">{vectorStats.count}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-slate-400">Approx. Size</span>
                                    <span className="text-xl font-mono text-slate-200">{(vectorStats.memoryUsage / 1024).toFixed(2)} KB</span>
                                </div>
                                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-500" style={{ width: `${Math.min(100, (vectorStats.count / 1000) * 100)}%` }} />
                                </div>
                            </div>
                        </div>
                        
                        <div className="bg-white/5 border border-white/5 rounded-xl p-6">
                             <h3 className="text-sm font-bold text-slate-300 mb-4">Vector Search Test</h3>
                             <p className="text-xs text-slate-400 mb-4">
                                The system automatically embeds episodic memories and chat logs. 
                                When you ask the AI a question, it searches this database first.
                             </p>
                             <div className="flex items-center gap-2 text-xs bg-black/30 p-2 rounded text-slate-300">
                                 <RefreshCw size={14} className="animate-spin" />
                                 <span>Indexing runs automatically on background...</span>
                             </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default MemoryApp;
