
import { AppID } from './enums';
import { 
    WindowState, Rect, Notification, UserProfile, 
    BootState, BootMode, HardwareConfig, PluginMetadata, PluginStatus,
    AppMetadata
} from './system';
import { FileSystemContextType, FileSystemItem, SyncStatus } from './filesystem';
import { 
    SerialStatus, SensorReadings, BluetoothDevice, FileTransfer, BridgeState 
} from './hardware';
import { 
    MemoryState, EpisodicMemory, EmotionState, LanguageState, 
    PerceptionState, MotivationState, Goal, VoiceState, SocialState, Identity,
    CreativityState, LearningState, PerformanceState, PerformanceMode,
    SecurityState, EnvironmentState, IoTDevice, SelfAwarenessState,
    CoordinationState, AIMode, LocalModelStatus, LocalModelProgress,
    PolicyState, Action
} from './ai';
import { BackendConnectionStatus } from './ai';

export interface OSContextType extends FileSystemContextType {
  // Window Manager
  isStartMenuOpen: boolean;
  toggleStartMenu: () => void;
  openApp: (appId: AppID) => void;
  closeApp: (appId: AppID) => void;
  minimizeApp: (appId: AppID) => void;
  maximizeApp: (appId: AppID) => void;
  focusApp: (appId: AppID) => void;
  updateWindow: (appId: AppID, updates: Partial<WindowState>) => void;
  windows: Record<AppID, WindowState>;
  
  // Layout
  wallpaper: string; 
  setWallpaper: (url: string) => void;
  isMovingWindow: boolean;
  setMovingWindow: (moving: boolean) => void;
  snapPreview: Rect | null;
  setSnapPreview: (rect: Rect | null) => void;
  
  // Apps & System
  installedApps: AppMetadata[];
  installApp: (appId: AppID) => void;
  uninstallApp: (appId: AppID) => void;
  togglePin: (appId: AppID) => void;
  pinnedApps: AppMetadata[];

  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;

  // Time
  timeOffset: number;
  isAutoTime: boolean;
  setTimeConfig: (config: { isAuto: boolean, offset: number }) => void;

  // Security
  isLocked: boolean;
  setLocked: (locked: boolean) => void;
  playSound: (type: any) => void;

  // Users
  users: UserProfile[];
  currentUser: UserProfile | null;
  login: (userId: string, pin: string) => boolean;
  logout: () => void;
  addUser: (user: Omit<UserProfile, 'id' | 'wallpaper' | 'installedAppIds' | 'pinnedAppIds'>) => void;
  removeUser: (userId: string) => void;
  updateUser: (userId: string, updates: Partial<UserProfile>) => void;

  // Hardware & Boot
  bootState: BootState;
  setBootState: (state: BootState) => void;
  bootMode: BootMode;
  setBootMode: (mode: BootMode) => void;
  hardwareConfig: HardwareConfig;
  setHardwareConfig: (config: HardwareConfig) => void;
  crashSystem: (error?: string) => void;
  factoryReset: () => void;

  // Serial & Sensors
  serialStatus: SerialStatus;
  sensorReadings: SensorReadings;
  connectSerial: () => Promise<void>;
  disconnectSerial: () => Promise<void>;
  sendSerialCommand: (cmd: string) => Promise<void>;
  
  // Backend Bridge
  backendStatus: BackendConnectionStatus; 
  
  // Robot Feeds
  robotCameraFrame: string | null;
  slamMap: string | null; // Base64 map image
  navigationPath: { x: number, y: number }[] | null;
  setNavigationGoal: (x: number, y: number) => void;

  // Network & Sharing
  bluetoothDevices: BluetoothDevice[];
  fileTransfers: FileTransfer[];
  scanBluetooth: () => void;
  pairDevice: (deviceId: string) => void;
  unpairDevice: (deviceId: string) => void;
  sendFileBluetooth: (file: FileSystemItem, deviceId: string) => void;

  // Cloud & Sync
  syncStatus: SyncStatus;
  isCloudEnabled: boolean;
  setCloudEnabled: (enabled: boolean) => void;
  
  // PWA & Network Status
  isOnline: boolean;
  installPWA: () => void;
  canInstallPWA: boolean;

  // --- AI Layers ---
  
  // Layer 2 (Memory)
  memoryState: MemoryState;
  addEpisodicMemory: (event: string, category: EpisodicMemory['category']) => void;

  // Layer 3 (Emotion)
  emotionState: EmotionState;
  setEmotionState: (state: Partial<EmotionState>) => void;

  // Layer 4 (Language)
  languageState: LanguageState;
  setLanguageState: (state: Partial<LanguageState>) => void;

  // Layer 5 (Perception)
  perceptionState: PerceptionState;
  processVisualFrame: (source: CanvasImageSource) => void;

  // Layer 6 (Motivation)
  motivationState: MotivationState;
  addGoal: (goal: Omit<Goal, 'id' | 'status' | 'progress' | 'created'>) => void;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  completeGoal: (id: string, success: boolean) => void;

  // Layer 4 & 7 (Social & Voice)
  voiceState: VoiceState;
  isHandsFree: boolean;
  toggleHandsFree: () => void;
  voiceEnergy: number;
  lastVoiceText: string;
  startListening: () => void;
  stopListening: () => void;
  speak: (text: string) => void;

  // Social Cognition
  socialState: SocialState;
  updateIdentity: (id: string, updates: Partial<Identity>) => void;
  triggerSocialEvent: (type: 'meet' | 'detect', identityId?: string) => void;

  // Creativity (Layer 8)
  creativityState: CreativityState;
  setCreativityState: (state: Partial<CreativityState>) => void;

  // Learning & Adaptation
  learningState: LearningState;

  // Performance (Layer 10)
  performanceState: PerformanceState;
  setPerformanceMode: (mode: PerformanceMode) => void;
  toggleAutoTuning: () => void;
  runDiagnostics: () => void;

  // Security & Ethics (Layer 11)
  securityState: SecurityState;

  // Environment & IoT (Layer 12)
  environmentState: EnvironmentState;
  toggleIoTDevice: (id: string) => void;
  updateIoTDevice: (id: string, updates: Partial<IoTDevice>) => void;

  // Self-Awareness (Layer 13)
  selfAwarenessState: SelfAwarenessState;

  // Coordination (Layer 14)
  coordinationState: CoordinationState;

  // Hybrid Bridge (Layer 15)
  bridgeState: BridgeState;
  sendBridgeCommand: (type: string, payload: any) => void;

  // Plugin Architecture (Layer 16)
  availablePlugins: PluginMetadata[];
  pluginState: PluginStatus[];
  installPlugin: (plugin: PluginMetadata) => void;
  uninstallPlugin: (id: string) => void;
  togglePlugin: (id: string) => void;

  // Policy Core
  policyState: PolicyState;
  evaluateAction: (action: Omit<Action, 'id'>) => boolean;

  // Local Intelligence
  aiMode: AIMode;
  setAIMode: (mode: AIMode) => void;
  localModelStatus: LocalModelStatus;
  loadLocalModel: () => Promise<void>;
  modelLoadingProgress: LocalModelProgress | null;
  askAI: (prompt: string) => Promise<{ text: string, provider: 'cloud' | 'local', analysis?: any }>;
}
