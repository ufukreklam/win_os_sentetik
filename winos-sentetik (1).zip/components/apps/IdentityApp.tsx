
import React, { useState, useEffect, useRef } from 'react';
import { useOS } from '../../context/OSContext';
import { Fingerprint, Brain, User, Activity, Sparkles, Hash, Layers } from 'lucide-react';
import { IdentityTrait, Thought } from '../../types';

const IdentityApp: React.FC = () => {
  const { selfAwarenessState, emotionState } = useOS();
  const [activeTab, setActiveTab] = useState<'stream' | 'core' | 'mirror'>('stream');
  const streamEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      if (activeTab === 'stream') {
          streamEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
  }, [selfAwarenessState.internalMonologue, activeTab]);

  const getTraitColor = (value: number) => {
      if (value > 75) return 'bg-purple-500';
      if (value > 50) return 'bg-blue-500';
      return 'bg-slate-500';
  };

  const TraitBar: React.FC<{ trait: IdentityTrait }> = ({ trait }) => {
      const total = Math.min(100, Math.max(0, trait.value + trait.modifier));
      return (
          <div className="mb-4">
              <div className="flex justify-between mb-1 text-xs">
                  <span className="font-bold text-slate-300 uppercase tracking-wider">{trait.name}</span>
                  <span className="font-mono text-slate-400">
                      {trait.value.toFixed(1)}
                  </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                      className={`h-full transition-all duration-500 ${getTraitColor(total)}`} 
                      style={{ width: `${total}%` }}
                  />
              </div>
          </div>
      );
  };

  return (
    <div className="flex h-full bg-[#050505] text-slate-100 font-sans overflow-hidden">
        {/* Sidebar */}
        <div className="w-16 md:w-56 bg-black/50 border-r border-white/5 flex flex-col items-center md:items-stretch py-4 gap-2 shrink-0">
            <button 
                onClick={() => setActiveTab('stream')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'stream' ? 'text-cyan-400 border-l-2 border-cyan-500 bg-cyan-900/10' : 'text-slate-500'}`}
            >
                <Activity size={20} />
                <span className="hidden md:inline text-sm font-medium">Stream</span>
            </button>
            <button 
                onClick={() => setActiveTab('core')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'core' ? 'text-purple-400 border-l-2 border-purple-500 bg-purple-900/10' : 'text-slate-500'}`}
            >
                <Fingerprint size={20} />
                <span className="hidden md:inline text-sm font-medium">Personality</span>
            </button>
            <button 
                onClick={() => setActiveTab('mirror')}
                className={`p-3 md:px-4 md:py-3 flex items-center gap-3 hover:bg-white/5 transition-colors ${activeTab === 'mirror' ? 'text-white border-l-2 border-white bg-white/5' : 'text-slate-500'}`}
            >
                <User size={20} />
                <span className="hidden md:inline text-sm font-medium">Self Model</span>
            </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col relative overflow-hidden">
            {/* Background Effect */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-black to-black opacity-50 pointer-events-none" />

            {activeTab === 'stream' && (
                <div className="flex-1 flex flex-col p-6 z-10 overflow-hidden">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-light text-cyan-400 tracking-tight flex items-center gap-2">
                            <Sparkles size={18} /> Internal Monologue
                        </h2>
                        <div className="text-xs font-mono text-slate-500">
                            MODE: <span className="text-white uppercase">{selfAwarenessState.mode}</span>
                        </div>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto space-y-4 pr-2 mask-linear-fade">
                        {selfAwarenessState.internalMonologue.map((thought) => (
                            <div key={thought.id} className="group flex gap-4 animate-in slide-in-from-bottom-2 fade-in duration-300">
                                <div className="text-[10px] font-mono text-slate-600 w-16 pt-1 shrink-0">
                                    {thought.timestamp.toLocaleTimeString([], { second: '2-digit', fractionalSecondDigits: 2 } as any)}
                                </div>
                                <div className="flex-1">
                                    <div className={`text-sm font-light leading-relaxed ${thought.intensity > 0.7 ? 'text-white' : 'text-slate-400'}`}>
                                        {thought.content}
                                    </div>
                                    <div className="flex gap-2 mt-1">
                                        {thought.tags.map(tag => (
                                            <span key={tag} className="text-[9px] uppercase tracking-wider text-slate-600 bg-white/5 px-1.5 rounded">
                                                #{tag}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                                <div className="w-1 bg-gradient-to-b from-cyan-500/50 to-transparent h-auto opacity-0 group-hover:opacity-100 transition-opacity rounded-full" />
                            </div>
                        ))}
                        <div ref={streamEndRef} />
                    </div>
                </div>
            )}

            {activeTab === 'core' && (
                <div className="flex-1 p-8 z-10 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                        {/* Traits Column */}
                        <div>
                            <h2 className="text-xl font-light text-purple-400 mb-6 flex items-center gap-2">
                                <Hash size={18} /> Big Five Traits (OCEAN)
                            </h2>
                            <div className="bg-white/5 border border-white/5 p-6 rounded-2xl">
                                {selfAwarenessState.traits.map(trait => (
                                    <TraitBar key={trait.name} trait={trait} />
                                ))}
                            </div>
                        </div>

                        {/* Consciousness Column */}
                        <div className="flex flex-col items-center justify-center">
                            <div className="relative w-64 h-64 flex items-center justify-center">
                                {/* Animated Rings */}
                                <div className="absolute inset-0 border-2 border-purple-500/20 rounded-full animate-[spin_10s_linear_infinite]" />
                                <div className="absolute inset-4 border-2 border-cyan-500/20 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
                                <div className="absolute inset-12 border border-white/10 rounded-full" />
                                
                                {/* Core Orb */}
                                <div className={`w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-cyan-600 blur-xl animate-pulse opacity-50`} />
                                
                                <div className="absolute text-center">
                                    <div className="text-4xl font-bold text-white">{selfAwarenessState.awarenessLevel}%</div>
                                    <div className="text-xs text-slate-400 uppercase tracking-widest mt-1">Awareness</div>
                                </div>
                            </div>
                            
                            <div className="mt-8 text-center max-w-xs">
                                <p className="text-sm text-slate-300 leading-relaxed">
                                    The system is currently <strong className="text-white uppercase">{selfAwarenessState.mode}</strong>. 
                                    Processing external stimuli with an emotional bias of <strong className="text-purple-300 uppercase">{emotionState.primary}</strong>.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'mirror' && (
                <div className="flex-1 flex flex-col items-center justify-center z-10 p-8">
                    <div className="relative group cursor-pointer">
                        {/* Mirror Frame */}
                        <div className="w-64 h-80 border-4 border-slate-800 rounded-full bg-black relative overflow-hidden shadow-2xl">
                            {/* Reflection Simulation */}
                            <div className="absolute inset-0 bg-gradient-to-tr from-slate-900 via-slate-800 to-black opacity-80" />
                            
                            {/* "Self" Avatar - Abstract representation */}
                            <div className="absolute inset-0 flex items-center justify-center">
                                <Brain size={64} className="text-slate-600 opacity-50 blur-sm group-hover:opacity-100 group-hover:blur-none transition-all duration-700 group-hover:text-cyan-400" />
                            </div>

                            {/* Scan Line */}
                            <div className="absolute inset-x-0 h-1 bg-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.8)] top-0 animate-[scan_3s_ease-in-out_infinite]" />
                        </div>
                    </div>

                    <div className="mt-8 flex gap-8 text-center">
                        <div>
                            <div className="text-2xl font-light text-cyan-400">{selfAwarenessState.selfModelConsistency}%</div>
                            <div className="text-xs text-slate-500 uppercase tracking-widest mt-1">Consistency</div>
                        </div>
                        <div>
                            <div className="text-2xl font-light text-white">v1.13</div>
                            <div className="text-xs text-slate-500 uppercase tracking-widest mt-1">Ego Version</div>
                        </div>
                    </div>
                    
                    <div className="mt-8 bg-white/5 px-6 py-3 rounded-full border border-white/5 flex items-center gap-2">
                        <Layers size={14} className="text-slate-400" />
                        <span className="text-xs text-slate-300">Self-Recognition Test: <span className="text-green-400">PASSED</span></span>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

export default IdentityApp;
